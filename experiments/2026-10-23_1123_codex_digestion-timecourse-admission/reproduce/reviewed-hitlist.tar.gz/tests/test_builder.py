import json
import os

import pandas as pd
import pyarrow as pa
import pytest

from hitlist.builder import (
    _CATEGORICAL_BUILD_COLUMNS,
    _CONCAT_PROMOTE_OPTIONS,
    _OBSERVATIONS_ARTIFACT_VERSION,
    _cache_is_valid,
    _compress_categoricals,
    _drop_duplicate_iris,
    _drop_short_mhc2_rows,
    _drop_supplementary_duplicates,
    _meta_path,
    _report_mhc_identity_summary,
    _source_fingerprints,
    _validate_mhc_tokens,
)
from hitlist.parquet_io import atomic_write_parquet
from hitlist.supplement import load_supplementary_manifest


@pytest.fixture
def isolated_curation(_isolated_curation_root, tmp_path, monkeypatch):
    """A fake, single-PMID curation tree, on top of ``_isolated_curation_root``
    (#474) -- this fixture only owns the content specific to these tests.
    """
    from hitlist import downloads

    data_root = _isolated_curation_root
    (data_root / "pmid_overrides.yaml").write_text(
        "- pmid: 99999999\n"
        "  restriction_evidence: experimental\n"
        "  peptide_attributions: attributions.csv\n"
    )
    (data_root / "attributions.csv").write_text("peptide,sample\nAAAAAAAAA,donor_a\n")
    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path / "indexes")
    return data_root


@pytest.mark.parametrize(
    "filename",
    [
        "pmid_overrides.yaml",
        "tissue_categories.yaml",
        "monoallelic_lines.yaml",
        "cell_lines.yaml",
        "attributions.csv",
    ],
)
def test_cache_invalidates_curation_content_changes(isolated_curation, filename):
    """A same-size edit with restored mtime must invalidate stored annotations."""
    from hitlist import builder

    path = isolated_curation / filename
    path.write_text(path.read_text() + "\n# review a\n")
    for name in (
        "observations",
        "binding",
        "other_assays",
        "bulk_proteomics",
        "line_expression",
        "observation_contributors",
    ):
        atomic_write_parquet(
            pd.DataFrame({"peptide": ["AAAAAAAAA"]}), builder.data_dir() / f"{name}.parquet"
        )
    _meta_path().write_text(
        json.dumps(
            {
                "artifact_version": _OBSERVATIONS_ARTIFACT_VERSION,
                "provenance": {
                    "schema_version": 1,
                    "sources": {},
                    "indexes": {},
                    "contributors": {},
                },
                "sources": _source_fingerprints({}),
                "parquets": builder._parquet_fingerprints(),
            }
        )
    )
    assert _cache_is_valid({})
    stat = path.stat()
    content = path.read_text()
    path.write_text(content.replace("# review a", "# review b"))
    os.utime(path, ns=(stat.st_atime_ns, stat.st_mtime_ns))
    assert path.stat().st_size == stat.st_size
    assert not _cache_is_valid({})


def test_cache_tracks_new_attribution_reference(isolated_curation):
    """An already-warm YAML loader must not hide newly referenced input files.

    ``isolated_curation`` (via ``_isolated_curation_root``) already guarantees
    a clear cache on entry and clears it again on exit, so warming the loader
    here needs no manual clear/restore of its own (#474).
    """
    from hitlist import curation

    curation.load_pmid_overrides()
    path = isolated_curation / "pmid_overrides.yaml"
    path.write_text(path.read_text().replace("attributions.csv", "new.csv"))
    csv_path = isolated_curation / "new.csv"
    csv_path.write_text("peptide,sample\nCCCCCCCCC,donor_b\n")
    fingerprints = _source_fingerprints({})
    assert str(csv_path) in {value.get("path") for value in fingerprints.values()}


def test_curation_change_rebuilds_stored_evidence(isolated_curation, tmp_path, monkeypatch):
    """Two normal builds in one interpreter must persist changed curation.

    No manual cache clear needed around the builds: ``build_observations``
    already clears curation caches at its own start, and ``isolated_curation``
    (via ``_isolated_curation_root``) clears again on teardown regardless (#474).
    """
    from hitlist import builder, downloads, supplement
    from tests.test_build_smoke import _write_synthetic_iedb

    csv_path = tmp_path / "iedb.csv"
    _write_synthetic_iedb(csv_path)
    overrides = isolated_curation / "pmid_overrides.yaml"
    overrides.write_text(
        "- pmid: 33858848\n  restriction_evidence: experimental\n  override: cancer_patient\n"
    )
    downloads.register("iedb", csv_path)
    monkeypatch.setattr(supplement, "scan_supplementary", lambda **kwargs: pd.DataFrame())

    def write_empty_index(path):
        frame = pd.DataFrame()
        atomic_write_parquet(frame, path)
        return frame

    monkeypatch.setattr(
        builder,
        "build_bulk_proteomics",
        lambda **kw: write_empty_index(builder._bulk_proteomics_path()),
    )
    monkeypatch.setattr(
        builder,
        "build_line_expression",
        lambda **kw: write_empty_index(builder._line_expression_path()),
    )
    path = builder.build_observations(build_mappings=False)
    first = pd.read_parquet(path)
    assert set(first.loc[first.pmid == 33858848, "restriction_evidence"]) == {"experimental"}
    assert first.loc[first.pmid == 33858848, "src_cancer"].all()
    assert _cache_is_valid(builder._source_paths())

    overrides.write_text(
        "- pmid: 33858848\n  restriction_evidence: predicted\n  override: healthy\n"
    )
    rebuilt = builder.build_observations(build_mappings=False)
    assert rebuilt != path
    pd.testing.assert_frame_equal(first, pd.read_parquet(path))
    second = pd.read_parquet(rebuilt)
    assert set(second.loc[second.pmid == 33858848, "restriction_evidence"]) == {"predicted"}
    assert not second.loc[second.pmid == 33858848, "src_cancer"].any()
    identity_columns = ["assay_iri", "peptide", "pmid", "mhc_restriction"]
    pd.testing.assert_frame_equal(first[identity_columns], second[identity_columns])


def test_source_fingerprints_includes_supplementary_csvs(tmp_path):
    """Cache fingerprint should include every supplementary CSV, not just the manifest."""
    # Use a minimal dummy source path dict
    fp = _source_fingerprints({})
    manifest = load_supplementary_manifest()
    for entry in manifest:
        key = f"supplementary_csv:{entry['file']}"
        assert key in fp, f"Missing fingerprint for supplementary CSV: {entry['file']}"
        assert "size" in fp[key]
        assert "mtime" in fp[key]


def test_source_fingerprints_includes_manifest():
    """Cache fingerprint should include the supplementary manifest itself."""
    fp = _source_fingerprints({})
    assert "supplementary_manifest" in fp


def test_cache_valid_when_sources_unchanged(tmp_path, monkeypatch):
    """Cache validity requires all four sibling parquets.

    Since 1.16.0 the build also writes line_expression.parquet; if any
    of the four is missing the cache is invalid so older installs
    rebuild once on upgrade.  ``with_flanking`` is retained on the
    signature for backward compat but no longer changes the result.
    """
    from hitlist import builder, downloads

    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path)

    (tmp_path / "observations.parquet").write_bytes(b"fake parquet")
    (tmp_path / "binding.parquet").write_bytes(b"fake parquet")
    (tmp_path / "other_assays.parquet").write_bytes(b"fake parquet")
    (tmp_path / "bulk_proteomics.parquet").write_bytes(b"fake parquet")
    (tmp_path / "line_expression.parquet").write_bytes(b"fake parquet")
    (tmp_path / "observation_contributors.parquet").write_bytes(b"fake parquet")
    _meta_path().write_text(
        json.dumps(
            {
                "artifact_version": _OBSERVATIONS_ARTIFACT_VERSION,
                "provenance": {
                    "schema_version": 1,
                    "sources": {},
                    "indexes": {},
                    "contributors": {},
                },
                "sources": {},
                "n_rows": 100,
                "n_peptides": 50,
                "n_alleles": 10,
                "n_species": 1,
                "n_binding_rows": 20,
                "n_bulk_rows": 10,
                "with_flanking": False,
            }
        )
    )
    monkeypatch.setattr(builder, "_source_fingerprints", lambda paths, **_kw: {})

    assert _cache_is_valid({}, with_flanking=False) is True
    assert _cache_is_valid({}, with_flanking=True) is True  # no longer invalidates


def test_cache_invalid_when_binding_parquet_missing(tmp_path, monkeypatch):
    """Missing binding.parquet alone should invalidate the cache."""
    from hitlist import builder, downloads

    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path)

    (tmp_path / "observations.parquet").write_bytes(b"fake parquet")
    # Intentionally no binding.parquet
    _meta_path().write_text(json.dumps({"sources": {}, "n_rows": 100}))
    monkeypatch.setattr(builder, "_source_fingerprints", lambda paths, **_kw: {})

    assert _cache_is_valid({}, with_flanking=False) is False


def test_cache_invalid_when_observations_parquet_missing(tmp_path, monkeypatch):
    """Missing observations.parquet alone should also invalidate the cache."""
    from hitlist import builder, downloads

    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path)

    (tmp_path / "binding.parquet").write_bytes(b"fake parquet")
    (tmp_path / "other_assays.parquet").write_bytes(b"fake parquet")
    _meta_path().write_text(json.dumps({"sources": {}, "n_rows": 0}))
    monkeypatch.setattr(builder, "_source_fingerprints", lambda paths, **_kw: {})

    assert _cache_is_valid({}, with_flanking=False) is False


def test_observations_cache_hit_still_validates_mapping_sidecar(tmp_path, monkeypatch):
    """#404: a current observations parquet must not hide stale mappings."""
    from hitlist import builder, downloads, mappings, provenance

    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path)
    observations = tmp_path / "observations.parquet"
    binding = tmp_path / "binding.parquet"
    observations.write_bytes(b"observations")
    binding.write_bytes(b"binding")
    source = tmp_path / "iedb.csv"
    source.write_text("source")

    monkeypatch.setattr(builder, "_source_paths", lambda: {"iedb": source})
    monkeypatch.setattr(builder, "_cache_is_valid", lambda *_a, **_kw: True)
    monkeypatch.setattr(
        builder,
        "_cache_meta",
        lambda: {
            "n_rows": 1,
            "n_peptides": 1,
            "n_alleles": 1,
            "n_species": 1,
            "n_binding_rows": 1,
        },
    )
    calls = []

    def validate_mappings(**kwargs):
        calls.append(kwargs)
        return tmp_path / "peptide_mappings.parquet"

    monkeypatch.setattr(mappings, "build_peptide_mappings", validate_mappings)

    def no_scratch():
        pytest.fail("A current observations index must not allocate provenance scratch")

    monkeypatch.setattr(provenance, "ContributorCollector", no_scratch)

    result = builder.build_observations(
        proteome_release=113,
        fetch_missing_proteomes=False,
        use_uniprot_search=True,
        build_mappings=True,
    )

    assert result == observations
    assert calls == [
        {
            "release": 113,
            "fetch_missing": False,
            "use_uniprot": True,
            "force": False,
        }
    ]


def test_cache_invalid_when_parquet_fingerprint_changes(tmp_path, monkeypatch):
    """If a parquet is replaced (size/mtime changes) after the meta was
    written, the cache must invalidate even if source CSVs look unchanged.
    """
    import os
    import time

    from hitlist import builder, downloads

    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path)

    obs_p = tmp_path / "observations.parquet"
    bind_p = tmp_path / "binding.parquet"
    bulk_p = tmp_path / "bulk_proteomics.parquet"
    le_p = tmp_path / "line_expression.parquet"
    obs_p.write_bytes(b"original observations")
    bind_p.write_bytes(b"original binding")
    (tmp_path / "other_assays.parquet").write_bytes(b"original other assays")
    bulk_p.write_bytes(b"original bulk")
    le_p.write_bytes(b"original line expression")
    (tmp_path / "observation_contributors.parquet").write_bytes(b"contributors")

    monkeypatch.setattr(builder, "_source_fingerprints", lambda paths, **_kw: {})
    _meta_path().write_text(
        json.dumps(
            {
                "artifact_version": _OBSERVATIONS_ARTIFACT_VERSION,
                "provenance": {
                    "schema_version": 1,
                    "sources": {},
                    "indexes": {},
                    "contributors": {},
                },
                "sources": {},
                "parquets": builder._parquet_fingerprints(),
            }
        )
    )
    assert _cache_is_valid({}, with_flanking=False) is True

    # Replace observations.parquet — bump mtime past meta's record
    time.sleep(0.01)
    obs_p.write_bytes(b"mutated observations content that is longer")
    os.utime(obs_p, None)
    assert _cache_is_valid({}, with_flanking=False) is False


@pytest.mark.parametrize("artifact_version", [None, 3])
def test_cache_invalidates_legacy_observations_artifact(tmp_path, monkeypatch, artifact_version):
    """Pre-contract and pre-species-serotype artifacts must regenerate annotations."""
    from hitlist import builder, downloads

    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path)
    for filename in (
        "observations.parquet",
        "binding.parquet",
        "bulk_proteomics.parquet",
        "line_expression.parquet",
    ):
        (tmp_path / filename).write_bytes(b"artifact")
    monkeypatch.setattr(builder, "_source_fingerprints", lambda paths, **_kw: {})
    metadata = {"sources": {}, "parquets": builder._parquet_fingerprints()}
    if artifact_version is not None:
        metadata["artifact_version"] = artifact_version
    _meta_path().write_text(json.dumps(metadata))

    assert _cache_is_valid({}, with_flanking=False) is False


def test_drop_short_mhc2_rows_removes_subset(capsys):
    """8-11 aa peptides labeled mhc_class="II" are dropped (#122)."""
    df = pd.DataFrame(
        {
            "peptide": ["SLLQHLIGL", "PKYVKQNTLKLAT", "KQNTLKL", "SAMPLEPEPTIDE"],
            "mhc_class": ["II", "II", "II", "II"],
            "pmid": [33858848, 12345678, 33858848, 12345678],
        }
    )
    out = _drop_short_mhc2_rows(df, "MS observations")

    assert list(out["peptide"]) == ["PKYVKQNTLKLAT", "SAMPLEPEPTIDE"]
    captured = capsys.readouterr().out
    assert "Dropped 2" in captured
    assert "#122" in captured
    assert "PMID 33858848" in captured


def test_drop_short_mhc2_rows_preserves_class_i():
    """Class-I rows (any length) and long class-II rows are untouched."""
    df = pd.DataFrame(
        {
            "peptide": ["SLLQHLIGL", "AAAAAA", "LONGCLASSIIPEPTIDE"],
            "mhc_class": ["I", "I", "II"],
            "pmid": [1, 2, 3],
        }
    )
    out = _drop_short_mhc2_rows(df, "MS observations")
    assert len(out) == 3


def test_drop_short_mhc2_rows_empty_frame():
    """An empty input returns an empty output without error."""
    df = pd.DataFrame({"peptide": [], "mhc_class": [], "pmid": []})
    out = _drop_short_mhc2_rows(df, "MS observations")
    assert out.empty


def test_drop_short_mhc2_rows_missing_columns():
    """A frame without mhc_class/peptide columns is returned unchanged."""
    df = pd.DataFrame({"other": [1, 2, 3]})
    out = _drop_short_mhc2_rows(df, "MS observations")
    assert len(out) == 3


def test_report_mhc_identity_summary_names_corrected_restrictions(capsys):
    df = pd.DataFrame(
        {
            "mhc_restriction": ["Caja-E", "Mamu-E*02:11", "HLA-A*02:01"],
            "mhc_class_corrected": [True, True, False],
            "mhc_species_context_disagrees": [False, True, False],
        }
    )

    _report_mhc_identity_summary(df, "MS")

    output = capsys.readouterr().out
    assert "2 class corrections" in output
    assert "1 context conflicts" in output
    assert "Caja-E" in output
    assert "Mamu-E*02:11" in output


def test_validate_mhc_tokens_rejects_only_new_unknowns(monkeypatch):
    known = pd.DataFrame(
        {
            "status": ["invalid_source", "parser_gap"],
            "n_records": [2, 1],
            "token": ["HLA-B23", "HLA-Cw16"],
        }
    )
    monkeypatch.setattr("hitlist.qc.mhc_token_audit", lambda **_kwargs: known)
    assert _validate_mhc_tokens(pd.DataFrame(), pd.DataFrame()).equals(known)

    unknown = pd.DataFrame({"status": ["unrecognized"], "n_records": [1], "token": ["BAD-MHC"]})
    monkeypatch.setattr("hitlist.qc.mhc_token_audit", lambda **_kwargs: unknown)
    with pytest.raises(RuntimeError, match="BAD-MHC"):
        _validate_mhc_tokens(pd.DataFrame(), pd.DataFrame())


def test_atomic_write_parquet_replaces_existing(tmp_path):
    """A subsequent write overwrites the prior file in one rename."""
    import pyarrow.parquet as pq

    path = tmp_path / "observations.parquet"
    first = pd.DataFrame({"peptide": ["AAA"], "gene_names": [""]})
    atomic_write_parquet(first, path)
    assert path.exists()
    assert "gene_names" in set(pq.read_schema(path).names)

    second = pd.DataFrame(
        {"peptide": ["AAA", "BBB"], "gene_names": ["HER2", "PRAME"], "extra": [1, 2]}
    )
    atomic_write_parquet(second, path)

    assert not path.with_suffix(".parquet.partial").exists()
    back = pd.read_parquet(path)
    assert set(back.columns) == {"peptide", "gene_names", "extra"}
    assert len(back) == 2


def test_atomic_write_parquet_no_partial_leftover(tmp_path):
    """``.partial`` must not remain after a successful atomic write."""
    path = tmp_path / "binding.parquet"
    atomic_write_parquet(pd.DataFrame({"peptide": ["X"]}), path)
    assert path.exists()
    assert not path.with_suffix(".parquet.partial").exists()


# ── Line-expression cache fingerprints (issue #150) ────────────────────────


def test_source_fingerprints_carry_the_line_expression_index_stamp():
    """The build cache and the index stamp agree on what makes an index stale (#577).

    A reader that reports a stale index names ``hitlist build observations`` as
    one repair, so that build has to reach the same verdict from the same
    evidence — a content hash of every packaged build input plus the index
    build version, not sizes and timestamps an install could preserve.  The
    per-file stat entries the stamp supersedes are gone.
    """
    from hitlist.line_expression import line_expression_index_stamp

    fp = _source_fingerprints({})
    assert fp["line_expression_index"] == line_expression_index_stamp()
    assert not [k for k in fp if k.startswith(("line_expression_csv:", "line_expression_anchors"))]
    assert "line_expression_sources" not in fp


def test_source_fingerprints_includes_registered_depmap_inputs(tmp_path, monkeypatch):
    """A registered DepMap input must appear in the cache fingerprint so
    a re-registered file forces the next build to rebuild line_expression.parquet.
    """
    from hitlist import downloads

    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path)

    fake = tmp_path / "OmicsExpressionProteinCodingGenesTPMLogp1.csv"
    fake.write_text("ModelID,TP53 (7157)\nACH-001,6.0\n")
    downloads.register("depmap_rna", fake)

    fp = _source_fingerprints({})
    assert "line_expression_input:depmap_rna" in fp
    entry = fp["line_expression_input:depmap_rna"]
    assert entry["path"] == str(fake)
    assert entry["size"] > 0


def test_parquet_fingerprints_includes_line_expression(tmp_path, monkeypatch):
    """The parquet-fingerprint set must include line_expression.parquet so a
    swapped parquet invalidates the cache.
    """
    from hitlist import builder, downloads

    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path)
    le = tmp_path / "line_expression.parquet"
    le.write_bytes(b"fake")
    fp = builder._parquet_fingerprints()
    assert "line_expression" in fp


def test_cache_invalid_when_line_expression_parquet_missing(tmp_path, monkeypatch):
    """Missing line_expression.parquet alone should invalidate the cache."""
    from hitlist import builder, downloads

    monkeypatch.setattr(downloads, "_override_data_dir", tmp_path)

    (tmp_path / "observations.parquet").write_bytes(b"fake parquet")
    (tmp_path / "binding.parquet").write_bytes(b"fake parquet")
    (tmp_path / "other_assays.parquet").write_bytes(b"fake parquet")
    (tmp_path / "bulk_proteomics.parquet").write_bytes(b"fake parquet")
    # Intentionally no line_expression.parquet
    _meta_path().write_text(json.dumps({"sources": {}, "n_rows": 100}))
    monkeypatch.setattr(builder, "_source_fingerprints", lambda paths, **_kw: {})

    assert _cache_is_valid({}, with_flanking=False) is False


def test_import_leaves_the_data_dir_untouched(tmp_path):
    """#579: ``import hitlist`` once ``rmtree``-d ``<data_dir>/index`` on every
    import (a one-shot cleanup of a cache retired in 1.30.41) and created the
    data dir. A library import must not delete or create user files."""
    import os
    import subprocess
    import sys

    existing = tmp_path / "existing"
    (existing / "index" / "sub").mkdir(parents=True)
    (existing / "index" / "sub" / "user_file.txt").write_text("keep")
    fresh = tmp_path / "fresh"
    for data_dir in (existing, fresh):
        env = {**os.environ, "HITLIST_DATA_DIR": str(data_dir)}
        subprocess.run([sys.executable, "-c", "import hitlist"], env=env, check=True)

    assert (existing / "index" / "sub" / "user_file.txt").read_text() == "keep"
    assert not fresh.exists()


# ── _compress_categoricals (memory reduction in build_observations) ──────


def _full_obs_fixture(n_rows: int = 50) -> pd.DataFrame:
    """Synthetic obs frame containing every column ``_compress_categoricals``
    targets, plus high-cardinality / numeric columns it must NOT touch."""
    return pd.DataFrame(
        {
            "source": ["iedb"] * n_rows,
            "mhc_class": (["I"] * (n_rows // 2)) + (["II"] * (n_rows - n_rows // 2)),
            "mhc_class_reported": (["I"] * (n_rows // 2)) + (["II"] * (n_rows - n_rows // 2)),
            "mhc_class_source": ["derived"] * n_rows,
            "mhc_species": ["Homo sapiens"] * n_rows,
            "mhc_species_source": ["explicit"] * n_rows,
            "mhc_restriction": ["HLA-A*02:01"] * n_rows,
            "mhc_allele_provenance": ["exact"] * n_rows,
            "restriction_evidence": ["monoallelic"] * n_rows,
            "allele_resolution": ["four_digit"] * n_rows,
            "serotype": ["A2"] * n_rows,
            "serotype_source": ["derived"] * n_rows,
            "host": ["Donor-1"] * n_rows,
            "host_age": [""] * n_rows,
            "process_type": ["natural"] * n_rows,
            "disease": ["healthy"] * n_rows,
            "disease_stage": [""] * n_rows,
            "source_tissue": ["PBMC"] * n_rows,
            # Three distinct cell fields (see classify_ms_row / cell_name_parser):
            #   cell_name      — IEDB's raw catch-all "Cell Name" string,
            #                    preserved verbatim for traceability. Conflates
            #                    lines, types, and "<line>-<type>" hybrids
            #                    (e.g. "Expi293F", "B cell", "K562-Myeloid cell").
            #   cell_line_name — the cell LINE part only (canonicalized, hybrid
            #                    suffix stripped). "" for primary-cell/tissue rows.
            #   cell_type      — the tissue / cell-TYPE part ("B cell",
            #                    "Myeloid cell"). "" when unknown.
            # The synthetic values below are arbitrary low-cardinality strings —
            # this fixture only exercises categorical compression, not parsing.
            "cell_name": ["Line-1-B cell"] * n_rows,
            "cell_line_name": ["Line-1"] * n_rows,
            "cell_type": ["B cell"] * n_rows,
            "culture_condition": ["unperturbed"] * n_rows,
            "assay_method": ["mass spectrometry"] * n_rows,
            "assay_modality": ["ms"] * n_rows,
            "assay_modality_source": ["assay_method"] * n_rows,
            "ms_outcome_status": ["positive_result"] * n_rows,
            "response_measured": [""] * n_rows,
            "measurement_units": [""] * n_rows,
            "measurement_inequality": [""] * n_rows,
            "qualitative_measurement": ["Positive"] * n_rows,
            "species": ["Homo sapiens"] * n_rows,
            "source_organism": ["Homo sapiens"] * n_rows,
            # NOT in the categorical allowlist — must stay object / numeric:
            "peptide": [f"PEP{i:08d}" for i in range(n_rows)],
            "assay_iri": [f"iedb:{i}" for i in range(n_rows)],
            "pmid": pd.array(list(range(n_rows)), dtype="Int64"),
            "mhc_allele_set_size": list(range(n_rows)),
        }
    )


def test_compress_categoricals_targets_low_cardinality_only():
    """Every column in the allowlist becomes ``category``; high-cardinality
    (peptide, assay_iri) and numeric (pmid, mhc_allele_set_size) preserved.

    The peptide / assay_iri assertions check ``not category`` rather than
    ``== "object"`` because pandas 2.2+ may default plain string columns
    to ``StringDtype`` instead of object — both representations are valid
    here; what matters is that the helper didn't convert them."""
    df = _full_obs_fixture()
    _compress_categoricals(df)
    for col in _CATEGORICAL_BUILD_COLUMNS:
        assert df[col].dtype.name == "category", f"{col} not categorical"
    # High-cardinality unique-per-row columns: not categorical (still
    # object or StringDtype, depending on pandas defaults).
    assert df["peptide"].dtype.name != "category"
    assert df["assay_iri"].dtype.name != "category"
    assert pd.api.types.is_string_dtype(df["peptide"])
    assert pd.api.types.is_string_dtype(df["assay_iri"])
    # Numeric: untouched.
    assert df["pmid"].dtype.name == "Int64"
    assert df["mhc_allele_set_size"].dtype.kind in "iuf"


def test_compress_categoricals_is_idempotent():
    """Re-applying the helper is a no-op (already-categorical columns are
    skipped, not re-converted)."""
    df = _full_obs_fixture()
    _compress_categoricals(df)
    snapshot = {col: df[col].dtype for col in df.columns}
    _compress_categoricals(df)
    for col, dt in snapshot.items():
        assert df[col].dtype == dt


def test_compress_categoricals_empty_frame_is_noop():
    """Empty input must not raise (and must not invent columns)."""
    df = pd.DataFrame()
    _compress_categoricals(df)
    assert df.empty
    assert list(df.columns) == []


def test_compress_categoricals_strict_raises_on_missing_column():
    """``strict=True`` catches typos in the allowlist by failing loudly
    when a listed column is missing from the frame.  Default ``strict=False``
    silently skips so the helper can run on per-source partitions."""
    df = pd.DataFrame({"mhc_class": ["I"] * 5, "peptide": list("abcde")})
    # default mode: silently skip missing columns
    _compress_categoricals(df)
    assert df["mhc_class"].dtype.name == "category"
    # strict mode: raise when columns are missing
    df2 = pd.DataFrame({"mhc_class": ["I"] * 5})
    with pytest.raises(KeyError, match="missing columns"):
        _compress_categoricals(df2, strict=True)


def test_compress_categoricals_partial_frame_default_does_not_raise():
    """Default ``strict=False`` works on a partial frame (per-source partitions
    may not have every column the full obs frame eventually carries)."""
    df = pd.DataFrame({"source": ["iedb"] * 5, "peptide": list("abcde")})
    _compress_categoricals(df)
    assert df["source"].dtype.name == "category"


# ── Cross-source dictionary-width concat (#478) ─────────────────────────────
#
# _compress_categoricals runs once per source partition (IEDB, CEDAR), so
# pyarrow picks each partition's dictionary index width from *that
# partition's own* distinct-value count: a small partition needs only
# int8, a large one needs int16. Concatenating the two under
# promote_options="default" raised ArrowTypeError the moment cardinality
# crossed the int8 boundary in only one of them — this reproduces that
# exact split with a real per-source compression, not a hand-built schema.


def _serotype_partition(n_distinct: int, n_rows: int) -> pd.DataFrame:
    df = pd.DataFrame({"serotype": [f"S{i % n_distinct}" for i in range(n_rows)]})
    _compress_categoricals(df)
    return df


def test_concat_tables_default_rejects_mismatched_dictionary_widths():
    """Pin the exact failure #478 reports, so a future pyarrow upgrade that
    changes this behavior is caught rather than silently assumed."""
    small = pa.Table.from_pandas(_serotype_partition(3, 6), preserve_index=False)
    large = pa.Table.from_pandas(_serotype_partition(200, 200), preserve_index=False)
    assert small.schema.field("serotype").type.index_type == pa.int8()
    assert large.schema.field("serotype").type.index_type == pa.int16()
    with pytest.raises(pa.lib.ArrowTypeError, match="serotype"):
        pa.concat_tables([small, large], promote_options="default")


def test_concat_tables_promote_options_unifies_mismatched_dictionary_widths():
    """The actual fix: the same two partitions concatenate cleanly under
    ``_CONCAT_PROMOTE_OPTIONS``, with every row and value preserved."""
    small_df = _serotype_partition(3, 6)
    large_df = _serotype_partition(200, 200)
    small = pa.Table.from_pandas(small_df, preserve_index=False)
    large = pa.Table.from_pandas(large_df, preserve_index=False)

    result = pa.concat_tables([small, large], promote_options=_CONCAT_PROMOTE_OPTIONS)

    assert result.num_rows == len(small_df) + len(large_df)
    got = result.column("serotype").to_pylist()
    assert got == list(small_df["serotype"]) + list(large_df["serotype"])


def test_concat_tables_promote_options_still_rejects_true_type_mismatches():
    """The fix widens compatible types; it must not also start accepting
    genuinely incompatible ones (e.g. a column that is numeric in one
    source and text in another) -- that would trade one silent-wrong-data
    risk for another.
    """
    numeric = pa.table({"x": pa.array([1, 2, 3], type=pa.int64())})
    textual = pa.table({"x": pa.array(["a", "b"], type=pa.large_string())})
    with pytest.raises(pa.lib.ArrowTypeError, match="x"):
        pa.concat_tables([numeric, textual], promote_options=_CONCAT_PROMOTE_OPTIONS)


def test_hitlist_import_enables_pandas_infer_string():
    """Importing hitlist must enable ``pd.options.future.infer_string``
    process-wide.  Without this, the build pipeline holds string columns
    as ``object`` (Python str overhead, ~50-100 bytes/cell) instead of
    ``StringDtype`` (Arrow-backed, ~10 bytes/cell) — a 5x base-cost
    inflation that the categorical compression can only partially
    recover.  Locking this in via test guards against an accidental
    revert in ``hitlist/__init__.py``."""
    import hitlist  # noqa: F401  -- side effect: sets the option

    assert pd.options.future.infer_string is True
    # New string DataFrames default to StringDtype, not object.
    df = pd.DataFrame({"x": ["a", "b"]})
    assert pd.api.types.is_string_dtype(df["x"])
    assert df["x"].dtype.name != "object"


def test_compress_categoricals_handles_pandas_str_dtype():
    """Regression: pandas 2.2+ may default string columns to ``StringDtype``
    (``"str"``) rather than ``object``.  An ``== "object"`` check would
    silently skip these — the helper must use ``is_string_dtype`` to cover
    both representations.  Without this, the categorical compression no-ops
    in CI environments where pandas infers ``str`` dtype by default and the
    full-build memory blow-up returns."""
    df = pd.DataFrame(
        {
            "mhc_class": pd.array(["I", "II", "I"], dtype="string"),
            "source": pd.array(["iedb", "iedb", "cedar"], dtype="string"),
        }
    )
    assert pd.api.types.is_string_dtype(df["mhc_class"])
    _compress_categoricals(df)
    assert df["mhc_class"].dtype.name == "category"
    assert df["source"].dtype.name == "category"


def test_compress_categoricals_reduces_memory_at_scale():
    """Realistic-cardinality fixture: helper cuts memory ~5x or more.

    Lower bound is conservative (CI variance, pandas version differences).
    The actual production reduction on the 4.4 M-row corpus is ~7-10x.
    """
    import numpy as np

    rng = np.random.default_rng(0)
    n = 100_000
    df = pd.DataFrame(
        {
            "mhc_class": rng.choice(["I", "II"], n),
            "source": rng.choice(["iedb", "cedar"], n),
            "mhc_species": rng.choice(["Homo sapiens", "Mus musculus"], n),
            "mhc_restriction": rng.choice(["HLA-A*02:01", "HLA-B*07:02", "HLA-DRB1*15:01"], n),
            "host": rng.choice([f"Donor-{i}" for i in range(50)], n),
            "disease": rng.choice([f"D-{i}" for i in range(80)], n),
            "cell_name": rng.choice([f"L-{i}" for i in range(200)], n),
            "peptide": [f"P{i:08d}" for i in range(n)],  # unique
        }
    )
    before = df.memory_usage(deep=True).sum()
    _compress_categoricals(df)
    after = df.memory_usage(deep=True).sum()
    # 4x is a conservative floor that holds across pandas object-string
    # vs StringDtype defaults.  Production reduction on the 4.4 M-row
    # corpus is ~7-10x; the smaller fixture sees less because the
    # high-cardinality ``peptide`` column dominates the residual.
    assert before / after >= 4.0, f"only {before / after:.2f}x reduction (expected >= 4x)"


# ── _drop_duplicate_iris (replaces ms_seen_iris Python set) ──────────────


def test_drop_duplicate_iris_keeps_first_occurrence():
    """Duplicate ``assay_iri`` values are dropped, first occurrence wins —
    preserves the prior 'IEDB beats CEDAR' tie-break (since IEDB is
    concat'd first)."""
    df = pd.DataFrame(
        {
            "assay_iri": ["a:1", "a:2", "a:1", "a:3"],
            "source": ["iedb", "iedb", "cedar", "cedar"],
            "peptide": ["P1", "P2", "P3", "P4"],
        }
    )
    out = _drop_duplicate_iris(df, label="MS")
    assert len(out) == 3
    assert list(out["assay_iri"]) == ["a:1", "a:2", "a:3"]
    # First-wins semantics: the iedb row for a:1 survives, not the cedar one.
    assert out.loc[out["assay_iri"] == "a:1", "source"].iloc[0] == "iedb"


def test_drop_duplicate_iris_falls_back_to_reference_iri():
    """Rows missing ``assay_iri`` (older intermediates) dedup on
    ``reference_iri`` instead."""
    df = pd.DataFrame(
        {
            "assay_iri": ["", "a:2", "", "a:3"],
            "reference_iri": ["r:1", "r:2", "r:1", "r:3"],
            "peptide": list("abcd"),
        }
    )
    out = _drop_duplicate_iris(df, label="MS")
    # The two empty-iri rows share reference_iri r:1 → second is dropped.
    assert len(out) == 3


def test_drop_duplicate_iris_empty_returns_empty():
    out = _drop_duplicate_iris(pd.DataFrame(), label="MS")
    assert out.empty


def test_drop_duplicate_iris_no_iri_column_returns_unchanged():
    df = pd.DataFrame({"peptide": ["P1", "P2"]})
    out = _drop_duplicate_iris(df, label="MS")
    assert len(out) == 2


def test_drop_duplicate_iris_preserves_per_donor_split_rows():
    """Regression for #236: per-donor split rows from a single IEDB row
    share the same ``assay_iri`` but differ in ``attributed_sample_label``.
    Folding the label into the dedup key prevents the iri-only dedup
    from silently collapsing 3 per-donor rows back to 1.

    Without the label-aware key, only 1 of N matched-donor rows (the
    alphabetically-first label) survived the build for every attributed
    peptide.
    """
    df = pd.DataFrame(
        {
            "assay_iri": ["a:1", "a:1", "a:1", "a:2"],
            "attributed_sample_label": [
                "MEL3 (13240-006)",
                "MEL15 (13240-015)",
                "OV1 (CP-594_v1)",
                "",
            ],
            "peptide": ["SLLQHLIGL", "SLLQHLIGL", "SLLQHLIGL", "OTHERPEP"],
        }
    )
    out = _drop_duplicate_iris(df, label="MS")
    # All 4 input rows survive: the 3 SLLQHLIGL per-donor rows have
    # distinct (assay_iri, attributed_sample_label) keys, and the
    # OTHERPEP row has its own assay_iri.
    assert len(out) == 4
    assert set(out["attributed_sample_label"]) == {
        "MEL3 (13240-006)",
        "MEL15 (13240-015)",
        "OV1 (CP-594_v1)",
        "",
    }


def test_drop_duplicate_iris_dedups_cross_source_within_same_donor():
    """Cross-source dedup still works for per-donor rows: if both IEDB
    and CEDAR scan the same assay and emit the same per-donor split,
    the (assay_iri, attributed_sample_label) key collapses cross-source
    duplicates exactly as the iri-only key did pre-#236.
    """
    df = pd.DataFrame(
        {
            "assay_iri": ["a:1", "a:1", "a:1", "a:1"],
            "attributed_sample_label": [
                "MEL3 (13240-006)",
                "MEL15 (13240-015)",
                "MEL3 (13240-006)",  # cross-source duplicate
                "MEL15 (13240-015)",  # cross-source duplicate
            ],
            "source": ["iedb", "iedb", "cedar", "cedar"],
            "peptide": ["SLLQHLIGL"] * 4,
        }
    )
    out = _drop_duplicate_iris(df, label="MS")
    assert len(out) == 2
    # IEDB-first concat order preserved: both surviving rows are from iedb.
    assert set(out["source"]) == {"iedb"}


# ── supplement anti-join (replaces Python set dedup) ────


def test_drop_supplementary_duplicates_drops_existing_triples():
    """Supp rows with a ``(peptide, mhc_restriction, pmid)`` triple that
    already exists in IEDB/CEDAR are dropped; novel triples kept."""
    obs = pd.DataFrame(
        {
            "peptide": ["P1", "P2", "P3"],
            "mhc_restriction": ["HLA-A*02:01", "HLA-A*02:01", "HLA-B*07:02"],
            "pmid": pd.array([1, 2, 3], dtype="Int64"),
        }
    )
    supp = pd.DataFrame(
        {
            "peptide": ["P1", "P4", "P3"],
            "mhc_restriction": ["HLA-A*02:01", "HLA-A*11:01", "HLA-B*07:02"],
            "pmid": pd.array([1, 99, 3], dtype="Int64"),
        }
    )
    out = _drop_supplementary_duplicates(supp, obs)
    # Only P4 (novel triple) survives.
    assert list(out["peptide"]) == ["P4"]
    assert list(out["mhc_restriction"]) == ["HLA-A*11:01"]
    assert list(out["pmid"]) == [99]


def test_drop_supplementary_duplicates_handles_pmid_dtype_mismatch():
    """Regression: supp PMID stored as Python ``int`` must still match obs
    PMID stored as ``Int64`` (and vice versa).  Without an explicit dtype
    cast pandas merge silently misses these — a row with PMID ``1`` (int)
    on supp wouldn't dedup against PMID ``1`` (Int64) on obs and the
    duplicate would leak through to the parquet."""
    obs = pd.DataFrame(
        {
            "peptide": ["P1"],
            "mhc_restriction": ["HLA-A*02:01"],
            "pmid": pd.array([12345], dtype="Int64"),
        }
    )
    # supp emits pmid as object/python-int (the legacy supplement.py path
    # didn't always normalize) — must still dedup.
    supp = pd.DataFrame(
        {
            "peptide": ["P1"],
            "mhc_restriction": ["HLA-A*02:01"],
            "pmid": [12345],  # plain Python int, dtype int64
        }
    )
    out = _drop_supplementary_duplicates(supp, obs)
    assert out.empty, "supp row should have been dedup'd despite int vs Int64 dtype gap"


def test_drop_supplementary_duplicates_handles_categorical_obs_keys():
    """Regression: obs columns are categorical post-strict-compress; supp
    columns are object.  The helper must reconcile dtypes before merge so
    matching keys actually match."""
    obs = pd.DataFrame(
        {
            "peptide": ["P1"],
            "mhc_restriction": pd.Categorical(["HLA-A*02:01"]),
            "pmid": pd.array([1], dtype="Int64"),
        }
    )
    supp = pd.DataFrame(
        {
            "peptide": ["P1"],
            "mhc_restriction": ["HLA-A*02:01"],  # object
            "pmid": pd.array([1], dtype="Int64"),
        }
    )
    out = _drop_supplementary_duplicates(supp, obs)
    assert out.empty


def test_drop_supplementary_duplicates_empty_obs_returns_supp_unchanged():
    """Regression: when both IEDB and CEDAR scan zero MS rows, ``obs`` is
    an empty ``pd.DataFrame()`` with NO columns.  The prior
    ``set(zip(obs["peptide"], ...))`` raised ``KeyError``; the helper
    must synthesize empty keys and return supp unchanged."""
    obs = pd.DataFrame()
    supp = pd.DataFrame(
        {
            "peptide": ["P1", "P2"],
            "mhc_restriction": ["HLA-A*02:01", "HLA-A*02:01"],
            "pmid": pd.array([1, 2], dtype="Int64"),
        }
    )
    out = _drop_supplementary_duplicates(supp, obs)
    assert len(out) == 2
    assert list(out["peptide"]) == ["P1", "P2"]


def test_drop_supplementary_duplicates_empty_supp_is_noop():
    """Empty supp short-circuits — no merge attempted, returns empty."""
    obs = pd.DataFrame(
        {
            "peptide": ["P1"],
            "mhc_restriction": ["HLA-A*02:01"],
            "pmid": pd.array([1], dtype="Int64"),
        }
    )
    out = _drop_supplementary_duplicates(pd.DataFrame(), obs)
    assert out.empty


def test_fill_gene_names_via_ensembl_fills_blank_from_ensg():
    """Empty gene_name on an ENSG-keyed row is filled from pyensembl; rows that
    already have a symbol, or lack an ENSG id, are untouched."""
    from hitlist.builder import _fill_gene_names_via_ensembl

    df = pd.DataFrame(
        {
            "gene_id": ["ENSG00000141510", "ENSG00000006327", "", "ENSG00000141510"],
            "gene_name": ["", "", "", "TP53"],  # row 0/1 blank+ENSG; 2 no id; 3 already named
        }
    )
    pytest.importorskip("pyensembl")
    out = _fill_gene_names_via_ensembl(df.copy())  # default release chain (75, 112)
    if out.loc[0, "gene_name"] == "":
        pytest.skip("pyensembl Ensembl release data not installed")
    assert out.loc[0, "gene_name"] == "TP53"
    assert out.loc[1, "gene_name"] == "TNFRSF12A"
    assert out.loc[2, "gene_name"] == ""  # no ENSG id -> left blank
    assert out.loc[3, "gene_name"] == "TP53"  # already named -> untouched


def test_fill_gene_names_via_ensembl_noop_when_pyensembl_missing(monkeypatch):
    """The fill degrades gracefully (no crash) when pyensembl/its data is
    unavailable — the build must never hard-fail on it."""
    import builtins

    from hitlist.builder import _fill_gene_names_via_ensembl

    real_import = builtins.__import__

    def boom(name, *args, **kwargs):
        if name == "pyensembl":
            raise ImportError("pyensembl not installed")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", boom)
    df = pd.DataFrame({"gene_id": ["ENSG00000141510"], "gene_name": [""]})
    out = _fill_gene_names_via_ensembl(df.copy())
    assert out.loc[0, "gene_name"] == ""  # unchanged, no exception


def test_fill_gene_names_from_csv_fills_blank_from_ensg():
    """The packaged ENSG→symbol CSV fills blank gene_names without pyensembl;
    rows already named, or lacking an ENSG id, are untouched."""
    from hitlist.line_expression import _fill_gene_names_from_packaged_map

    df = pd.DataFrame(
        {
            "gene_id": ["ENSG00000006327", "ENSG00000018607", "", "ENSG00000006327"],
            "gene_name": ["", "", "", "ALREADY"],  # 0/1 blank+ENSG; 2 no id; 3 named
        }
    )
    out = _fill_gene_names_from_packaged_map(df.copy())
    assert out.loc[0, "gene_name"] == "TNFRSF12A"
    assert out.loc[1, "gene_name"] == "ZNF806"
    assert out.loc[2, "gene_name"] == ""  # no ENSG id -> left blank
    assert out.loc[3, "gene_name"] == "ALREADY"  # already named -> untouched


def test_gene_name_map_csv_is_packaged_and_well_formed():
    """The shipped CSV exists, has the right header, and version-stripped keys."""
    from hitlist.line_expression import _gene_name_map

    id2name = _gene_name_map()
    assert len(id2name) > 9000  # ~9,127 resolved IDs
    assert id2name["ENSG00000006327"] == "TNFRSF12A"
    assert all(k.startswith("ENSG") and "." not in k for k in id2name)  # version-stripped
    assert all(v for v in id2name.values())  # no blank symbols


# ── Cross-source IRI dedup (#351) ─────────────────────────────────────


def test_drop_duplicate_iris_matches_across_iedb_and_cedar_hosts():
    """#351: IEDB and CEDAR publish the same assay under different scheme
    *and* host, so the raw strings never collided and every shared assay
    was counted twice."""
    import pandas as pd

    from hitlist.builder import _drop_duplicate_iris

    df = pd.DataFrame(
        {
            "assay_iri": [
                "http://www.iedb.org/assay/25034276",
                "https://cedar.iedb.org/assay/25034276",
            ],
            "source": ["iedb", "cedar"],
            "peptide": ["AAAAAAAAA", "AAAAAAAAA"],
        }
    )
    out = _drop_duplicate_iris(df.copy(), "ms")
    assert len(out) == 1
    # Concat order is IEDB-before-CEDAR, so IEDB wins the tie-break.
    assert out.iloc[0]["source"] == "iedb"


def test_drop_duplicate_iris_keeps_distinct_assays():
    """Different assay ids under different hosts are not duplicates."""
    import pandas as pd

    from hitlist.builder import _drop_duplicate_iris

    df = pd.DataFrame(
        {
            "assay_iri": [
                "http://www.iedb.org/assay/999",
                "https://cedar.iedb.org/assay/1000",
            ],
            "source": ["iedb", "cedar"],
            "peptide": ["BBBBBBBBB", "CCCCCCCCC"],
        }
    )
    assert len(_drop_duplicate_iris(df.copy(), "ms")) == 2


def test_drop_duplicate_iris_preserves_per_donor_split():
    """#236's per-donor rows share an assay_iri and must survive the
    cross-host normalization."""
    import pandas as pd

    from hitlist.builder import _drop_duplicate_iris

    df = pd.DataFrame(
        {
            "assay_iri": [
                "http://www.iedb.org/assay/1",
                "https://cedar.iedb.org/assay/1",
                "http://www.iedb.org/assay/1",
            ],
            "attributed_sample_label": ["MEL15", "MEL15", "GBM11"],
            "peptide": ["AAAAAAAAA"] * 3,
        }
    )
    out = _drop_duplicate_iris(df.copy(), "ms")
    assert sorted(out["attributed_sample_label"]) == ["GBM11", "MEL15"]


def test_drop_duplicate_iris_reports_the_table_label(capsys):
    """The ``label`` parameter was shadowed by the attributed-sample-label
    Series, so the summary line printed a whole Series instead of "ms".
    Latent until #351 made the message fire at all."""
    import pandas as pd

    from hitlist.builder import _drop_duplicate_iris

    df = pd.DataFrame(
        {
            "assay_iri": [
                "http://www.iedb.org/assay/7",
                "https://cedar.iedb.org/assay/7",
            ],
            "attributed_sample_label": ["", ""],
            "peptide": ["AAAAAAAAA", "AAAAAAAAA"],
        }
    )
    _drop_duplicate_iris(df.copy(), "ms")
    out = capsys.readouterr().out
    assert "Deduplicated 1 ms rows" in out


def test_cedar_download_url_points_at_a_served_filename():
    """#350: ``doc/cedar_mhc_ligand_full.zip`` is not a name CEDAR serves,
    and downloader.php answers 200 with an empty body for unknown names
    rather than 404 — so the fetch failed like an outage."""
    from hitlist.downloads import FETCHABLE_DATASETS

    url = FETCHABLE_DATASETS["cedar"]["url"]
    assert "mhc_ligand_full_single_file.zip" in url
    assert "cedar_mhc_ligand_full.zip" not in url
    assert url.startswith("https://cedar.iedb.org/")


# ── concat dtype stability (#377) ─────────────────────────────────────


def test_concat_non_empty_takes_dtypes_from_frames_with_values():
    """#377: pandas will stop letting all-NA entries drive result dtypes.

    A frame contributing only NA for a column must not turn a typed
    column into object — both call sites feed a parquet write, where an
    object column changes the on-disk schema or is rejected outright.
    """
    import numpy as np
    import pandas as pd

    from hitlist.parquet_io import concat_non_empty

    typed = pd.DataFrame({"line_key": ["HeLa"], "tpm": [1.5], "gene": ["ACTB"]})
    all_na = pd.DataFrame({"line_key": ["K562"], "tpm": [np.nan], "gene": [None]})
    out = concat_non_empty([typed, all_na], ["line_key", "tpm", "gene"])
    assert len(out) == 2
    assert out["tpm"].dtype == typed["tpm"].dtype
    assert out["line_key"].tolist() == ["HeLa", "K562"]


def test_concat_non_empty_does_not_drop_partially_na_frames():
    """Excluding whole frames would lose data: the deprecation is about
    all-NA *columns*, and a frame can be good apart from one."""
    import numpy as np
    import pandas as pd

    from hitlist.parquet_io import concat_non_empty

    good = pd.DataFrame({"a": [1.0], "b": ["x"]})
    partial = pd.DataFrame({"a": [2.0], "b": [np.nan]})  # 'b' all-NA, 'a' fine
    out = concat_non_empty([good, partial], ["a", "b"])
    assert out["a"].tolist() == [1.0, 2.0], "the partially-NA frame must survive"


def test_concat_non_empty_keeps_the_column_contract_when_all_empty():
    import pandas as pd

    from hitlist.parquet_io import concat_non_empty

    out = concat_non_empty([pd.DataFrame(), pd.DataFrame()], ["a", "b", "c"])
    assert out.empty
    assert list(out.columns) == ["a", "b", "c"]


def test_build_paths_raise_no_concat_futurewarning():
    """Guard the deprecation itself, so a new concat site is caught."""
    import warnings

    import numpy as np
    import pandas as pd

    from hitlist.parquet_io import concat_non_empty

    with warnings.catch_warnings():
        warnings.simplefilter("error", FutureWarning)
        concat_non_empty(
            [
                pd.DataFrame({"x": [1.0], "s": ["a"]}),
                pd.DataFrame({"x": [np.nan], "s": [None]}),
            ],
            ["x", "s"],
        )


def test_flanking_schema_matches_the_literal_contract():
    """Pin the schema literally.

    A previous version recomputed ``expected`` with the same expression
    that defines ``_FLANKING_COLS``, so both sides moved together and
    the assertion could not fail for any content.
    """
    from hitlist.builder import _FLANKING_COLS, _FLANKING_SOURCE_COLS

    assert _FLANKING_SOURCE_COLS == (
        "gene_name",
        "gene_id",
        "protein_id",
        "position",
        "n_flank",
        "c_flank",
        "n_sources",
    )
    assert _FLANKING_COLS == (
        "gene_name",
        "gene_id",
        "protein_id",
        "position",
        "n_flank",
        "c_flank",
        "n_source_proteins",
        "flanking_species",
    )


def test_flanking_empty_frame_has_no_duplicate_column():
    """``_FLANKING_COLS`` already ends with ``flanking_species``; listing
    it again made the rename produce two ``_canonical_species`` keys and
    the merge raise "column label is not unique" — on the path where no
    proteome maps anything."""
    import pandas as pd

    from hitlist.builder import _FLANKING_COLS

    cols = ["peptide", *_FLANKING_COLS]
    assert len(cols) == len(set(cols)), f"duplicate column in the empty frame: {cols}"
    renamed = pd.DataFrame(columns=cols).rename(columns={"flanking_species": "_canonical_species"})
    # The merge below is what used to blow up.
    pd.DataFrame({"peptide": ["A"], "_canonical_species": ["x"]}).merge(
        renamed, on=["peptide", "_canonical_species"], how="left"
    )
