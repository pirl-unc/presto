import csv
import warnings

import pandas as pd
import pytest

from hitlist.scanner import _resolve_columns, scan


def test_scan_no_sources():
    df = scan(peptides={"SLYNTVATL"}, iedb_path=None, cedar_path=None)
    assert isinstance(df, pd.DataFrame)
    assert len(df) == 0


def test_scan_nonexistent():
    df = scan(peptides={"SLYNTVATL"}, iedb_path="/nonexistent.csv")
    assert len(df) == 0


def test_scan_profile_mode_no_sources():
    df = scan(peptides=None, iedb_path=None)
    assert len(df) == 0


# ── Deprecation of human_only (hitlist#72) ─────────────────────────────────


def test_human_only_true_emits_deprecation_warning():
    with pytest.warns(DeprecationWarning, match="human_only is deprecated"):
        scan(peptides={"X"}, iedb_path=None, cedar_path=None, human_only=True)


def test_human_only_false_emits_deprecation_warning():
    with pytest.warns(DeprecationWarning, match="human_only is deprecated"):
        scan(peptides={"X"}, iedb_path=None, cedar_path=None, human_only=False)


def test_no_species_kwargs_does_not_warn():
    """Default call path must stay warning-free — only explicit human_only= warns."""
    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        scan(peptides={"X"}, iedb_path=None, cedar_path=None)  # must not raise


def test_explicit_mhc_species_does_not_warn():
    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        scan(peptides={"X"}, iedb_path=None, cedar_path=None, mhc_species="Homo sapiens")


def test_mhc_species_wins_when_both_passed():
    """If both legacy and new kwargs are passed, mhc_species takes precedence.
    We can't observe the filter decision without a real CSV, but the call
    must succeed and emit exactly one DeprecationWarning for human_only."""
    with pytest.warns(DeprecationWarning, match="human_only"):
        scan(
            peptides={"X"},
            iedb_path=None,
            cedar_path=None,
            human_only=True,
            mhc_species="Mus musculus",
        )


# ── species_fallback unit tests (via _apply_species_filter behavior) ───────
#
# We can't hit the real filter logic without IEDB CSVs, so these tests
# exercise the shape guarantees: the kwarg is accepted and the call
# succeeds for the four (mhc_species x species_fallback) cross-product
# cases.


@pytest.mark.parametrize(
    "mhc_species,species_fallback",
    [
        ("Homo sapiens", True),
        ("Homo sapiens", False),
        ("Mus musculus", True),
        (None, True),
    ],
)
def test_species_fallback_accepted(mhc_species, species_fallback):
    df = scan(
        peptides={"X"},
        iedb_path=None,
        cedar_path=None,
        mhc_species=mhc_species,
        species_fallback=species_fallback,
    )
    assert isinstance(df, pd.DataFrame)


# ── assay_iri preservation (issue #146) ────────────────────────────────────


def _write_tiny_iedb_csv(path, rows):
    """Write a minimal IEDB-shaped CSV for scanner tests.

    IEDB exports have TWO header rows (category + field).  The scanner
    reads both via ``next(reader)`` twice, then streams data rows.  The
    tests below stream data rows by preceding the headers with a dummy
    category row so the scanner's header handling mirrors real IEDB.
    """
    field_header = [
        "Assay IRI",
        "Reference IRI",
        "PMID",
        "Submission ID",
        "Title",
        "Epitope | Name",
        "Epitope | Source Organism",
        "Epitope | Species",
        "Host",
        "Host Age",
        "Host | Process Type",
        "Host | Disease",
        "Host | Disease Stage",
        "Antigen Processing Comments",
        "Qualitative Measurement",
        "Assay Comments",
        "Effector Cells | Source Tissue",
        "Effector Cells | Cell Name",
        "Assay | Culture Condition",
        "MHC Restriction | Name",
        "MHC Allele Class",
        "Host | MHC Types Present",
        "Assay | Method",
        "Assay | Response measured",
        "Assay | Units",
        "Assay | Measurement Inequality",
        "Assay | Quantitative measurement",
    ]
    category_header = [""] * len(field_header)  # real IEDB uses grouping labels; "" is safe
    import csv

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(category_header)
        writer.writerow(field_header)
        for row in rows:
            writer.writerow(row)


def test_scan_emits_independent_restriction_evidence_states(tmp_path, monkeypatch):
    """Restriction evidence describes the claim, not allele-set resolution."""
    src = tmp_path / "iedb.csv"

    def _row(
        assay_id,
        peptide,
        *,
        pmid=99900415,
        restriction="HLA-A*02:01",
        qualitative="Positive",
        cell_name="",
        culture_condition="",
        assay_method="",
    ):
        row = [""] * 24
        row[0] = f"http://iedb.org/assay/{assay_id}"
        row[2] = str(pmid)
        row[5] = peptide
        row[14] = qualitative
        row[17] = cell_name
        row[18] = culture_condition
        row[19] = restriction
        row[20] = "I"
        row[22] = assay_method
        return row

    rows = [
        _row(1, "PREDICTED", assay_method="cellular MHC/mass spectrometry"),
        _row(
            2,
            "UNRESOLVED",
            restriction="HLA class I",
            assay_method="cellular MHC/mass spectrometry",
        ),
        _row(
            3,
            "MONOALLELIC",
            pmid=99900416,
            cell_name="721.221",
            culture_condition="Cell Line / Clone",
        ),
        _row(4, "EXPERIMENTAL", pmid=99900417, qualitative="Negative"),
        _row(5, "UNKNOWN", pmid=99900418),
    ]
    _write_tiny_iedb_csv(src, rows)
    monkeypatch.setattr(
        "hitlist.curation.load_pmid_overrides",
        lambda: {
            99900415: {
                "restriction_evidence_rules": [
                    {
                        "condition": {
                            "Assay Method": "cellular MHC/mass spectrometry",
                        },
                        "evidence": "predicted",
                    }
                ]
            }
        },
    )

    by_peptide = scan(peptides=None, iedb_path=src, cedar_path=None).set_index("peptide")

    assert by_peptide.loc["PREDICTED", "restriction_evidence"] == "predicted"
    assert by_peptide.loc["PREDICTED", "mhc_allele_provenance"] == "exact"
    assert by_peptide.loc["UNRESOLVED", "restriction_evidence"] == "unknown"
    assert by_peptide.loc["MONOALLELIC", "restriction_evidence"] == "monoallelic"
    assert by_peptide.loc["EXPERIMENTAL", "restriction_evidence"] == "experimental"
    assert by_peptide.loc["UNKNOWN", "restriction_evidence"] == "unknown"


def test_scan_attributes_resolved_prediction_without_rewriting_restriction(tmp_path):
    """#414: source-backed sample identity is independent of an exact row restriction."""
    src = tmp_path / "iedb.csv"
    row = [""] * 24
    row[0] = "http://iedb.org/assay/414"
    row[2] = "36423003"
    row[5] = "SEIDVKDVL"
    row[14] = "Positive"
    row[19] = "BoLA-6*014:01"
    row[20] = "I"
    row[22] = "cellular MHC/mass spectrometry"
    row[23] = "ligand presentation"
    _write_tiny_iedb_csv(src, [row])

    result = scan(
        peptides=None,
        iedb_path=src,
        cedar_path=None,
        mhc_species="Bos taurus",
    ).iloc[0]

    # The scanner canonicalizes the source's BoLA spelling to mhcgnomes'
    # Bos-taurus prefix, but must preserve the same resolved molecule.
    assert result["mhc_restriction"] == "Bota-6*014:01"
    assert result["mhc_allele_set"] == "Bota-6*014:01"
    assert result["mhc_allele_provenance"] == "exact"
    assert result["restriction_evidence"] == "predicted"
    assert result["attributed_sample_label"] == "2824TP (T. parva-infected, BoLA-I A19)"


def test_scan_preserves_assay_iri_per_row(tmp_path):
    """Every scanner-emitted row must carry a populated ``assay_iri`` column
    (issue #146), not just ``reference_iri``.  The three assay rows below
    share one reference IRI but have distinct assay IRIs — all three must
    survive the dedupe (which is already keyed on assay_iri) AND arrive
    in the output with the assay_iri preserved.
    """
    src = tmp_path / "iedb.csv"
    rows = []
    shared_ref = "http://iedb.org/reference/42"
    for i in range(3):
        row = [""] * 21
        row[0] = f"http://iedb.org/assay/{1000001 + i}"  # Assay IRI
        row[1] = shared_ref
        row[2] = "33858848"
        row[5] = f"PEPTIDE{i}AB"  # Epitope | Name
        row[19] = "HLA-A*02:01"  # MHC Restriction
        row[20] = "I"
        rows.append(row)
    _write_tiny_iedb_csv(src, rows)

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 3
    assert "assay_iri" in df.columns
    assert df["assay_iri"].nunique() == 3
    assert df["reference_iri"].nunique() == 1  # the whole point: same paper
    # All assay_iri values propagated through unchanged.
    for i in range(3):
        assert f"http://iedb.org/assay/{1000001 + i}" in df["assay_iri"].values


@pytest.mark.parametrize("classify_source", [True, False])
def test_scan_resolves_contextual_species_and_molecule_class(
    tmp_path, monkeypatch, classify_source
):
    """#382/#376: both scanner modes use one MHC identity contract."""
    src = tmp_path / "iedb.csv"
    rows = []
    for i, (pmid, restriction, reported_class) in enumerate(
        [
            (36423003, "BoLA class I", "I"),
            (99900001, "Caja-E", "I"),
            (99900002, "Mamu-E*02:11", "I"),
            (99900004, "HLA class II", "II"),
        ]
    ):
        row = [""] * 22
        row[0] = f"http://iedb.org/assay/identity-{i}"
        row[2] = str(pmid)
        row[5] = f"PEPTIDE{i}AA"
        row[19] = restriction
        row[20] = reported_class
        rows.append(row)
    _write_tiny_iedb_csv(src, rows)

    monkeypatch.setattr(
        "hitlist.curation.pmid_mhc_species_context",
        lambda pmid: "Bos taurus" if int(pmid) == 36423003 else "",
    )
    df = scan(
        peptides=None,
        iedb_path=src,
        cedar_path=None,
        mhc_species=None,
        classify_source=classify_source,
    ).set_index("pmid")

    assert df.loc[36423003, "mhc_species"] == "Bos taurus"
    assert df.loc[36423003, "mhc_species_source"] == "context"
    assert df.loc[99900001, "mhc_class"] == "non-classical"
    assert df.loc[99900002, "mhc_class"] == "non-classical"
    assert df.loc[99900001, "mhc_class_reported"] == "I"
    assert bool(df.loc[99900001, "mhc_class_corrected"]) is True
    assert df.loc[99900004, "mhc_class"] == "II"
    assert df.loc[99900004, "mhc_class_source"] == "export"


@pytest.mark.parametrize("classify_source", [True, False])
def test_scan_refreshes_mhc_identity_after_donor_set_promotion(
    tmp_path, monkeypatch, classify_source
):
    """The final restriction and its resolution/class provenance cannot drift."""
    src = tmp_path / "iedb.csv"
    row = [""] * 22
    row[0] = "http://iedb.org/assay/donor-set"
    row[2] = "99900003"
    row[5] = "DONORPEPTIDE"
    row[19] = "HLA class I"
    row[20] = "I"
    row[21] = "HLA-A*02:01;HLA-B*07:02"
    _write_tiny_iedb_csv(src, [row])
    monkeypatch.setattr("hitlist.curation.pmid_mhc_species_context", lambda _pmid: "")

    result = scan(
        peptides=None,
        iedb_path=src,
        cedar_path=None,
        mhc_species=None,
        classify_source=classify_source,
    ).iloc[0]
    assert result["mhc_restriction"] == "HLA-A*02:01;HLA-B*07:02"
    assert result["allele_resolution"] == "donor_set"
    assert result["mhc_class"] == "I"
    assert result["mhc_class_source"] == "donor_set"
    assert result["mhc_species"] == "Homo sapiens"


def test_scan_dedupes_by_assay_iri_within_source(tmp_path):
    """Same ``assay_iri`` appearing twice (shouldn't happen in IEDB but the
    dedupe is defensive) must collapse to one row with that IRI preserved.
    """
    src = tmp_path / "iedb.csv"
    rows = []
    for _ in range(2):
        row = [""] * 21
        row[0] = "http://iedb.org/assay/7777777"  # identical
        row[1] = "http://iedb.org/reference/42"
        row[2] = "33858848"
        row[5] = "PEPTIDEAB"
        row[19] = "HLA-A*02:01"
        row[20] = "I"
        rows.append(row)
    _write_tiny_iedb_csv(src, rows)

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 1
    assert df["assay_iri"].iloc[0] == "http://iedb.org/assay/7777777"


def test_scan_keeps_distinct_rows_with_blank_assay_iri(tmp_path):
    """Regression: rows with a *blank* Assay IRI are distinct observations and
    must not collapse. Previously the first blank-IRI row seeded "" into the
    dedupe set and every later blank-IRI row was silently dropped."""
    src = tmp_path / "iedb.csv"
    rows = []
    for i in range(3):
        row = [""] * 21
        row[0] = ""  # blank Assay IRI (the bug trigger)
        row[1] = "http://iedb.org/reference/99"
        row[2] = "33858848"
        row[5] = f"PEPTIDE{i}AB"  # distinct peptides
        row[19] = "HLA-A*02:01"
        row[20] = "I"
        rows.append(row)
    _write_tiny_iedb_csv(src, rows)

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 3  # all three kept, not collapsed to one


# ── Quantitative binding-assay fields (issue #148) ─────────────────────────


def _write_quant_iedb_csv(path, rows):
    """Write a minimal IEDB CSV with the quantitative-assay columns populated.

    Columns the scanner uses are at fixed indices 0..108; we extend to 97
    so the Quantitative-measurement column (index 96) is writable.
    """
    field_header = [""] * 97
    # Fill the relevant headers at their canonical IEDB positions.
    field_header[0] = "Assay IRI"
    field_header[1] = "Reference IRI"
    field_header[2] = "PMID"
    field_header[5] = "Epitope | Name"
    field_header[90] = "Assay | Method"
    field_header[91] = "Assay | Response measured"
    field_header[92] = "Assay | Units"
    field_header[94] = "Qualitative Measurement"
    field_header[95] = "Assay | Measurement Inequality"
    field_header[96] = "Assay | Quantitative measurement"
    field_header_full = field_header + [""] * (109 - len(field_header))
    field_header_full[107] = "MHC Restriction | Name"
    field_header_full[108] = "MHC Allele Class"
    # Every other key _COLUMN_NAMES declares must still resolve by name
    # (#470: a column resolving by position instead of name can silently
    # read the wrong index the moment a source's layout shifts). This test
    # only cares about the quantitative fields above, so the rest just need
    # *a* resolvable name; appending past the columns already in use keeps
    # every existing row[N] assignment in this file valid.
    field_header_full += [
        "Submission ID",
        "Title",
        "Source Organism",
        "Epitope | Species",
        "Host",
        "Host Age",
        "Process Type",
        "Disease",
        "Disease Stage",
        "Antigen Processing | Comments",
        "Assay | Comments",
        "Source Tissue",
        "Antigen Presenting Cell | Name",
        "Culture Condition",
        "Host | MHC Types Present",
    ]
    category_header = [""] * len(field_header_full)

    import csv

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(category_header)
        writer.writerow(field_header_full)
        for row in rows:
            # Pad each data row to match header width.
            padded = list(row) + [""] * (len(field_header_full) - len(row))
            writer.writerow(padded)


def test_scan_preserves_quantitative_binding_fields(tmp_path):
    """Scanner must emit assay_method / measurement_units /
    measurement_inequality / quantitative_measurement / quantitative_value
    from IEDB binding-assay rows (issue #148).  The float cast of
    ``Quantitative measurement`` lives in ``quantitative_value`` for
    downstream filtering.
    """
    src = tmp_path / "iedb.csv"
    rows: list[list] = []
    # IC50 (competitive binding), Kd (direct dissociation), t_half (kinetic),
    # plus a qualitative-only row.  Each carries a different ``Response measured``
    # so consumers can stratify by readout type.  The Response-measured strings
    # used here are the canonical IEDB values (``df['response_measured']
    # .value_counts()`` shows ``"half maximal inhibitory concentration (IC50)"``,
    # ``"dissociation constant KD"``, ``"half life"``, ``"qualitative binding"``,
    # ``"ligand presentation"`` etc.) so consumers can reproduce these tests
    # against a real build.
    for i, (method, response, units, ineq, q, pep) in enumerate(
        [
            (
                "purified MHC/competitive/fluorescence",
                "half maximal inhibitory concentration (IC50)",
                "nM",
                "=",
                "12.5",
                "QUANTROWAB",
            ),
            (
                "purified MHC/direct/fluorescence",
                "dissociation constant KD",
                "nM",
                "<",
                "500",
                "QUANTROWCD",
            ),
            (
                "cellular MHC/direct/fluorescence",
                "half life",
                "min",
                "=",
                "42",
                "KINETICAB",
            ),
            ("purified MHC/direct", "qualitative binding", "", "", "", "QUALONLYAB"),
        ]
    ):
        row = [""] * 112
        row[0] = f"http://iedb.org/assay/{9000001 + i}"
        row[1] = "http://iedb.org/reference/99"
        row[2] = "33858848"
        row[5] = pep
        row[90] = method
        row[91] = response
        row[92] = units
        row[94] = "Positive"
        row[95] = ineq
        row[96] = q
        row[107] = "HLA-A*02:01"
        row[108] = "I"
        rows.append(row)
    _write_quant_iedb_csv(src, rows)

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 4
    for col in (
        "assay_method",
        "response_measured",
        "measurement_units",
        "measurement_inequality",
        "quantitative_measurement",
        "quantitative_value",
    ):
        assert col in df.columns, f"missing column: {col}"

    quant = df[df["peptide"] == "QUANTROWAB"].iloc[0]
    assert quant["assay_method"] == "purified MHC/competitive/fluorescence"
    assert quant["response_measured"] == "half maximal inhibitory concentration (IC50)"
    assert quant["measurement_units"] == "nM"
    assert quant["measurement_inequality"] == "="
    assert quant["quantitative_measurement"] == "12.5"
    assert quant["quantitative_value"] == pytest.approx(12.5)

    kd = df[df["peptide"] == "QUANTROWCD"].iloc[0]
    assert kd["measurement_inequality"] == "<"
    assert kd["response_measured"] == "dissociation constant KD"
    assert kd["quantitative_value"] == pytest.approx(500.0)

    kinetic = df[df["peptide"] == "KINETICAB"].iloc[0]
    assert kinetic["response_measured"] == "half life"
    assert kinetic["measurement_units"] == "min"
    assert kinetic["quantitative_value"] == pytest.approx(42.0)

    qual_only = df[df["peptide"] == "QUALONLYAB"].iloc[0]
    assert qual_only["assay_method"] == "purified MHC/direct"
    assert qual_only["response_measured"] == "qualitative binding"
    assert qual_only["measurement_units"] == ""
    # Empty Quantitative measurement → NaN float in quantitative_value.
    import math

    assert math.isnan(qual_only["quantitative_value"])


def test_scan_routes_purified_mhc_half_life_away_from_ms(tmp_path):
    """#418: structured assay fields distinguish stability from MS elution."""
    src = tmp_path / "iedb.csv"
    rows = []
    for i, (peptide, method, response) in enumerate(
        [
            (
                "HALFLIFEAB",
                "purified MHC/direct/radioactivity",
                "half life",
            ),
            (
                "MSELUTIONAB",
                "cellular MHC/mass spectrometry",
                "ligand presentation",
            ),
        ]
    ):
        row = [""] * 112
        row[0] = f"http://iedb.org/assay/{4180000 + i}"
        row[1] = "http://iedb.org/reference/418"
        row[2] = "36423003"
        row[5] = peptide
        row[90] = method
        row[91] = response
        row[94] = "Positive"
        row[107] = "BoLA-6*013:01"
        row[108] = "I"
        rows.append(row)
    _write_quant_iedb_csv(src, rows)

    result = scan(
        peptides=None,
        iedb_path=src,
        cedar_path=None,
        mhc_species="Bos taurus",
    ).set_index("peptide")

    assert bool(result.loc["HALFLIFEAB", "is_binding_assay"]) is True
    assert bool(result.loc["MSELUTIONAB", "is_binding_assay"]) is False


def test_scan_quantitative_value_handles_garbage(tmp_path):
    """A non-numeric quantitative_measurement value must become NaN, not
    crash the scanner.
    """
    src = tmp_path / "iedb.csv"
    rows = [[""] * 109]
    rows[0][0] = "http://iedb.org/assay/8888888"
    rows[0][1] = "http://iedb.org/reference/99"
    rows[0][2] = "33858848"
    rows[0][5] = "TRASHROWAB"
    rows[0][90] = "something"
    rows[0][94] = "Positive"
    rows[0][96] = "not a number"
    rows[0][107] = "HLA-A*02:01"
    rows[0][108] = "I"
    _write_quant_iedb_csv(src, rows)

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 1
    import math

    assert df["quantitative_measurement"].iloc[0] == "not a number"
    assert math.isnan(df["quantitative_value"].iloc[0])


# ── Allele-set expansion (issue #137) ──────────────────────────────────────


def _write_set_iedb_csv(path, rows):
    """Variant of _write_quant_iedb_csv that also names the
    ``Host | MHC Types Present`` column at index 49 so the scanner can
    drive set expansion off it.
    """
    field_header = [""] * 112
    field_header[0] = "Assay IRI"
    field_header[1] = "Reference IRI"
    field_header[2] = "PMID"
    field_header[5] = "Epitope | Name"
    field_header[49] = "Host | MHC Types Present"
    field_header[107] = "MHC Restriction | Name"
    field_header[108] = "MHC Allele Class"
    # Every other key _COLUMN_NAMES declares must still resolve by name
    # (#470: a column resolving by position instead of name can silently
    # read the wrong index the moment a source's layout shifts). These
    # tests don't care about the values, so appending past column 108
    # keeps every existing row[N] assignment in this file valid.
    field_header += [
        "Submission ID",
        "Title",
        "Source Organism",
        "Epitope | Species",
        "Host Age",
        "Process Type",
        "Disease",
        "Disease Stage",
        "Antigen Processing | Comments",
        "Qualitative Measurement",
        "Assay | Method",
        "Assay | Response measured",
        "Assay | Units",
        "Assay | Measurement Inequality",
        "Assay | Quantitative measurement",
        "Assay | Comments",
        "Source Tissue",
        "Antigen Presenting Cell | Name",
        "Culture Condition",
    ]
    category_header = [""] * len(field_header)

    import csv

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(category_header)
        writer.writerow(field_header)
        for row in rows:
            padded = list(row) + [""] * (len(field_header) - len(row))
            writer.writerow(padded)


def test_scan_emits_cell_type_column(tmp_path):
    """#261 stage 2: the scanner must emit a ``cell_type`` column and clean
    the ``<line>-<cell_type>`` hybrid suffix out of ``cell_line_name``."""
    src = tmp_path / "iedb.csv"
    rows = []

    # Hybrid cell-line row: "K562-Myeloid cell" → line "K562", type "Myeloblast"
    # (registry lineage overrides the coarse IEDB suffix).
    hybrid = [""] * 21
    hybrid[0] = "http://iedb.org/assay/200001"
    hybrid[1] = "http://iedb.org/reference/1"
    hybrid[2] = "33858848"
    hybrid[5] = "HYBRIDROWAB"
    hybrid[17] = "K562-Myeloid cell"  # Cell Name
    hybrid[18] = "Cell Line / Clone"  # Culture Condition
    hybrid[19] = "HLA-A*02:01"
    hybrid[20] = "I"
    rows.append(hybrid)

    # Pure cell-type primary row: "B cell" → no line, type "B-cell" (normalized).
    primary = [""] * 21
    primary[0] = "http://iedb.org/assay/200002"
    primary[1] = "http://iedb.org/reference/2"
    primary[2] = "33858848"
    primary[5] = "PRIMARYROWAB"
    primary[17] = "B cell"  # Cell Name
    primary[18] = "Direct Ex Vivo"  # Culture Condition
    primary[19] = "HLA-A*02:01"
    primary[20] = "I"
    rows.append(primary)

    _write_tiny_iedb_csv(src, rows)

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert "cell_type" in df.columns

    hybrid_row = df[df["cell_name"] == "K562-Myeloid cell"].iloc[0]
    assert hybrid_row["cell_line_name"] == "K562"
    # K562's registry lineage (Myeloblast) overrides IEDB's coarse suffix.
    assert hybrid_row["cell_type"] == "Myeloblast"

    primary_row = df[df["cell_name"] == "B cell"].iloc[0]
    assert primary_row["cell_line_name"] == ""
    assert primary_row["cell_type"] == "B-cell"  # hyphenated house style


def test_scan_emits_allele_set_columns_with_provenance(tmp_path):
    """Issue #137: every scanner row must carry mhc_allele_set /
    mhc_allele_provenance / mhc_allele_set_size.  Cover the three
    populated provenance buckets (exact / sample_allele_match /
    pmid_class_pool) plus the unmatched fall-through.
    """
    src = tmp_path / "iedb.csv"
    rows: list[list] = []

    # Row A: exact 4-digit (most common case).
    a = [""] * 112
    a[0] = "http://iedb.org/assay/100001"
    a[1] = "http://iedb.org/reference/1"
    a[2] = "33858848"
    a[5] = "EXACTROWAB"
    a[107] = "HLA-A*02:01"
    a[108] = "I"
    rows.append(a)

    # Row B: class_only with donor's MHC Types Present populated → sample_allele_match.
    b = [""] * 112
    b[0] = "http://iedb.org/assay/100002"
    b[1] = "http://iedb.org/reference/2"
    b[2] = "33858848"
    b[5] = "SAMPLEROWAB"
    b[49] = "HLA-A*01:01;HLA-A*02:01;HLA-B*07:02"
    b[107] = "HLA class I"
    b[108] = "I"
    rows.append(b)

    # Row C: class_only with no donor MHC, but PMID 28832583 has a curated
    # hla_alleles pool → pmid_class_pool.
    c = [""] * 112
    c[0] = "http://iedb.org/assay/100003"
    c[1] = "http://iedb.org/reference/3"
    c[2] = "28832583"
    c[5] = "POOLROWABCD"
    c[107] = "HLA class I"
    c[108] = "I"
    rows.append(c)

    # Row D: class_only with no donor MHC, no PMID curation → unmatched.
    d = [""] * 112
    d[0] = "http://iedb.org/assay/100004"
    d[1] = "http://iedb.org/reference/4"
    d[2] = "99999999"
    d[5] = "UNMATCHEDAB"
    d[107] = "HLA class I"
    d[108] = "I"
    rows.append(d)

    _write_set_iedb_csv(src, rows)
    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 4
    for col in ("mhc_allele_set", "mhc_allele_provenance", "mhc_allele_set_size"):
        assert col in df.columns

    by_pep = df.set_index("peptide")
    assert by_pep.loc["EXACTROWAB", "mhc_allele_provenance"] == "exact"
    assert by_pep.loc["EXACTROWAB", "mhc_allele_set"] == "HLA-A*02:01"
    assert by_pep.loc["EXACTROWAB", "mhc_allele_set_size"] == 1

    assert by_pep.loc["SAMPLEROWAB", "mhc_allele_provenance"] == "sample_allele_match"
    assert by_pep.loc["SAMPLEROWAB", "mhc_allele_set_size"] == 3
    assert "HLA-A*02:01" in by_pep.loc["SAMPLEROWAB", "mhc_allele_set"]

    assert by_pep.loc["POOLROWABCD", "mhc_allele_provenance"] == "pmid_class_pool"
    assert by_pep.loc["POOLROWABCD", "mhc_allele_set_size"] > 1
    assert "HLA-A*02:05" in by_pep.loc["POOLROWABCD", "mhc_allele_set"]  # CD165

    assert by_pep.loc["UNMATCHEDAB", "mhc_allele_provenance"] == "unmatched"
    assert by_pep.loc["UNMATCHEDAB", "mhc_allele_set"] == ""
    assert by_pep.loc["UNMATCHEDAB", "mhc_allele_set_size"] == 0


def test_scan_promotes_set_to_mhc_restriction_via_peptide_attribution(tmp_path):
    """End-to-end (#45): a class-only IEDB row whose peptide appears in
    the registered ``peptide_attributions`` CSV (Sarkizova 2020 / PMID
    31844290) gets its set narrowed to the matched donor's typed
    alleles AND its ``mhc_restriction`` promoted to that set.

    ``AAAAAAAAAAAAAAPAP`` is uniquely attributed to MEL2 (13240-005),
    whose ``ms_samples[].mhc`` lists 5 alleles after homozygous-A
    collapse: A*01:01 / B*38:01 / B*56:01 / C*01:02 / C*06:02.  We assert
    the scanner produces exactly that set and that the row's
    ``mhc_restriction`` is no longer ``"HLA class I"``.
    """
    src = tmp_path / "iedb.csv"
    row = [""] * 112
    row[0] = "http://iedb.org/assay/9000001"
    row[1] = "http://iedb.org/reference/sarkizova"
    row[2] = "31844290"
    row[5] = "AAAAAAAAAAAAAAPAP"
    row[49] = "HLA-A*01:01;HLA-B*38:01;HLA-B*56:01;HLA-C*01:02;HLA-C*06:02"
    row[107] = "HLA class I"
    row[108] = "I"
    _write_set_iedb_csv(src, [row])

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 1
    r = df.iloc[0]

    assert r["mhc_allele_provenance"] == "peptide_attribution"
    assert r["mhc_allele_set_size"] == 5
    expected = {
        "HLA-A*01:01",
        "HLA-B*38:01",
        "HLA-B*56:01",
        "HLA-C*01:02",
        "HLA-C*06:02",
    }
    assert set(r["mhc_allele_set"].split(";")) == expected
    # Set promoted to mhc_restriction — class label replaced by the actual
    # presenting-MHC set.
    assert r["mhc_restriction"] != "HLA class I"
    assert set(r["mhc_restriction"].split(";")) == expected
    # Single-donor attribution (#236): one emitted row tagged with the
    # matched donor's sample_label.
    assert r["attributed_sample_label"] == "MEL2 (13240-005)"


def test_scan_falls_back_to_sample_allele_match_when_peptide_unattributed(tmp_path):
    """If a class-only row's PMID has an attribution CSV registered but
    the peptide is NOT in that CSV, scanner falls back to the row's
    ``host_mhc_types`` (provenance ``sample_allele_match``).  Guards
    against the silent-failure mode where ``attribute_peptide_to_sample_alleles``
    might wrongly return non-empty for unattributed peptides."""
    src = tmp_path / "iedb.csv"
    row = [""] * 112
    row[0] = "http://iedb.org/assay/9000002"
    row[1] = "http://iedb.org/reference/sarkizova"
    row[2] = "31844290"
    row[5] = "ZZZZZZZZZZ"  # not in the Sarkizova attribution CSV
    row[49] = "HLA-A*02:01;HLA-B*07:02"  # donor-typed alleles on this row
    row[107] = "HLA class I"
    row[108] = "I"
    _write_set_iedb_csv(src, [row])

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 1
    r = df.iloc[0]
    assert r["mhc_allele_provenance"] == "sample_allele_match"
    assert r["mhc_allele_set_size"] == 2
    assert set(r["mhc_allele_set"].split(";")) == {"HLA-A*02:01", "HLA-B*07:02"}
    assert set(r["mhc_restriction"].split(";")) == {"HLA-A*02:01", "HLA-B*07:02"}
    # Non-attributed row → empty attributed_sample_label.
    assert r["attributed_sample_label"] == ""


def test_scan_per_donor_split_for_multi_donor_attributed_peptide(tmp_path):
    """Issue #236: when the per-peptide attribution CSV maps a peptide
    to N matched donors, the scanner emits N observation rows (one per
    donor with that donor's typing) instead of one row carrying the
    union of donor typings.

    SLLQHLIGL is attributed to 3 Sarkizova patient samples — MEL3,
    MEL15, OV1.  The pre-#236 behavior was a single row with a 15-
    allele union; post-#236 we expect 3 rows, each carrying that
    donor's 6-allele typing in ``mhc_restriction`` and the donor's
    label in the new ``attributed_sample_label`` column.
    """
    src = tmp_path / "iedb.csv"
    row = [""] * 112
    row[0] = "http://iedb.org/assay/9000003"
    row[1] = "http://iedb.org/reference/sarkizova"
    row[2] = "31844290"
    row[5] = "SLLQHLIGL"
    # IEDB stores the disease-wide union here (not used when attribution applies).
    row[49] = "HLA-A*02:01;HLA-A*02:02;HLA-A*03:01;HLA-A*24:02;HLA-B*13:02;HLA-B*27:05"
    row[107] = "HLA class I"
    row[108] = "I"
    _write_set_iedb_csv(src, [row])

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 3

    by_label = df.set_index("attributed_sample_label")
    assert set(by_label.index) == {"MEL3 (13240-006)", "MEL15 (13240-015)", "OV1 (CP-594_v1)"}

    # Each emitted row carries that donor's typing as both
    # mhc_allele_set AND (post-promotion) mhc_restriction.
    for label, expected_alleles in [
        (
            "MEL3 (13240-006)",
            {
                "HLA-A*02:01",
                "HLA-A*03:01",
                "HLA-B*27:05",
                "HLA-B*47:01",
                "HLA-C*01:02",
                "HLA-C*06:02",
            },
        ),
        (
            "MEL15 (13240-015)",
            {
                "HLA-A*02:01",
                "HLA-A*02:02",
                "HLA-B*13:02",
                "HLA-B*40:02",
                "HLA-C*02:02",
                "HLA-C*06:02",
            },
        ),
        (
            "OV1 (CP-594_v1)",
            {
                "HLA-A*02:01",
                "HLA-A*24:02",
                "HLA-B*35:03",
                "HLA-B*44:02",
                "HLA-C*05:01",
                "HLA-C*12:03",
            },
        ),
    ]:
        r = by_label.loc[label]
        assert r["mhc_allele_provenance"] == "peptide_attribution"
        assert r["mhc_allele_set_size"] == len(expected_alleles)
        assert set(r["mhc_allele_set"].split(";")) == expected_alleles
        assert set(r["mhc_restriction"].split(";")) == expected_alleles


def test_scan_non_attributed_pmid_unaffected_by_per_donor_split(tmp_path):
    """Regression for #236: cohorts WITHOUT a peptide_attributions CSV
    registered must produce exactly one row per IEDB row, with an empty
    ``attributed_sample_label``.  The per-donor split must only fire
    for PMIDs explicitly opted in via ``peptide_attributions:`` in
    pmid_overrides.yaml — never for arbitrary class-only rows.

    PMID 99999999 (not in pmid_overrides) with a class-only restriction
    + donor-typed alleles should fall through to ``sample_allele_match``
    as a single row, just like pre-#236.
    """
    src = tmp_path / "iedb.csv"
    row = [""] * 112
    row[0] = "http://iedb.org/assay/9000004"
    row[1] = "http://iedb.org/reference/other"
    row[2] = "99999999"
    row[5] = "OTHERPEP"
    row[49] = "HLA-A*02:01;HLA-B*07:02;HLA-C*07:02"
    row[107] = "HLA class I"
    row[108] = "I"
    _write_set_iedb_csv(src, [row])

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 1
    r = df.iloc[0]
    assert r["attributed_sample_label"] == ""
    assert r["mhc_allele_provenance"] == "sample_allele_match"
    assert set(r["mhc_allele_set"].split(";")) == {"HLA-A*02:01", "HLA-B*07:02", "HLA-C*07:02"}


@pytest.mark.parametrize("restriction", ["HLA-A*02:01", "HLA-G*01:01", "HLA class II"])
@pytest.mark.parametrize("classify_source", [True, False])
def test_patient_peptide_overlap_cannot_relabel_other_cohorts(
    tmp_path, restriction, classify_source
):
    """The Sarkizova map is from patient Data 2, not monoallelic Data 1 (#534)."""
    src = tmp_path / "iedb.csv"
    row = [""] * 112
    row[0] = "http://iedb.org/assay/90000534"
    row[2] = "31844290"
    row[5] = "SLLQHLIGL"  # present in three patient samples
    row[107] = restriction
    row[108] = "II" if restriction == "HLA class II" else "I"
    _write_set_iedb_csv(src, [row])
    result = scan(peptides=None, iedb_path=src, cedar_path=None, classify_source=classify_source)
    assert len(result) == 1
    assert result.iloc[0]["attributed_sample_label"] == ""
    assert result.iloc[0]["mhc_restriction"] == restriction


def test_scoped_patient_map_does_not_invent_a_class_mismatched_donor(tmp_path):
    """A synthetic class-II record is outside this class-I patient source (#534)."""
    src = tmp_path / "iedb.csv"
    row = [""] * 112
    row[0] = "http://iedb.org/assay/9000005"
    row[1] = "http://iedb.org/reference/sarkizova"
    row[2] = "31844290"
    row[5] = "AAAAAAAAAAAAAAPAP"  # attributed only to MEL2
    row[107] = "HLA class II"  # synthetic class mismatch — MEL2 has class-I alleles
    row[108] = "II"
    _write_set_iedb_csv(src, [row])

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 1
    r = df.iloc[0]
    assert r["attributed_sample_label"] == ""
    assert r["mhc_allele_provenance"] == "unmatched"
    assert r["mhc_allele_set_size"] == 0
    assert r["mhc_allele_set"] == ""
    # Set-size 0 → mhc_restriction not promoted; original class label survives.
    assert r["mhc_restriction"] == "HLA class II"


def test_scan_mixed_attribution_within_same_pmid(tmp_path):
    """A single scan over an attributed PMID must route each row by its
    own peptide's attribution status: attributed peptides take the
    per-donor split path; unattributed peptides take the standard
    sample_allele_match / pool / unmatched fallback.  Same PMID, same
    file, two different code paths in one call.
    """
    src = tmp_path / "iedb.csv"
    rows = []

    # Row A: peptide IS in the Sarkizova attribution CSV (MEL2 only).
    a = [""] * 112
    a[0] = "http://iedb.org/assay/9000006"
    a[1] = "http://iedb.org/reference/sarkizova"
    a[2] = "31844290"
    a[5] = "AAAAAAAAAAAAAAPAP"
    a[49] = "HLA-A*01:01;HLA-B*38:01"  # ignored — attribution wins for class-only rows
    a[107] = "HLA class I"
    a[108] = "I"
    rows.append(a)

    # Row B: peptide is NOT in the attribution CSV → standard fallback to host_mhc_types.
    b = [""] * 112
    b[0] = "http://iedb.org/assay/9000007"
    b[1] = "http://iedb.org/reference/sarkizova"
    b[2] = "31844290"
    b[5] = "ZZZZZZZZZZ"
    b[49] = "HLA-A*02:01;HLA-B*07:02"
    b[107] = "HLA class I"
    b[108] = "I"
    rows.append(b)

    _write_set_iedb_csv(src, rows)
    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert len(df) == 2
    by_pep = df.set_index("peptide")

    # Attributed peptide: per-donor row carries the donor label.
    attributed = by_pep.loc["AAAAAAAAAAAAAAPAP"]
    assert attributed["attributed_sample_label"] == "MEL2 (13240-005)"
    assert attributed["mhc_allele_provenance"] == "peptide_attribution"

    # Unattributed peptide in the same PMID: standard fallback, no donor label.
    unattributed = by_pep.loc["ZZZZZZZZZZ"]
    assert unattributed["attributed_sample_label"] == ""
    assert unattributed["mhc_allele_provenance"] == "sample_allele_match"
    assert set(unattributed["mhc_allele_set"].split(";")) == {"HLA-A*02:01", "HLA-B*07:02"}


# ── StringDtype propagation through the build pipeline ─────────────────────


def test_scanner_output_uses_stringdtype(tmp_path):
    """End-to-end check that the scanner's output frame carries pandas
    ``StringDtype`` for string columns, not legacy ``object`` dtype.

    Hitlist sets ``pd.options.future.infer_string = True`` at package
    import (matching the pandas 3.0 default).  Without this, the scanner
    builds DataFrames from ``list[dict]`` that default to ``object``
    dtype — Python ``str`` references with ~50-100 bytes / cell of
    overhead.  The build pipeline holds the full obs + binding frames
    through gene annotation + mappings, so the per-cell cost compounds
    into the ~40 GB peak this PR was written to fix.

    A future pandas API change (or an accidental revert in
    ``hitlist/__init__.py``) could quietly drop us back to ``object``
    dtype.  The lock-in test
    ``test_hitlist_import_enables_pandas_infer_string`` catches the
    option flip; this test catches the case where the option is set but
    something downstream silently coerces back to ``object`` (e.g. an
    intermediate ``.astype(str)`` that returns object on some pandas
    versions).
    """
    src = tmp_path / "iedb.csv"
    rows = []
    for i in range(5):
        row = [""] * 21
        row[0] = f"http://iedb.org/assay/{2000001 + i}"
        row[1] = "http://iedb.org/reference/string-dtype-test"
        row[2] = "33858848"
        row[5] = f"PEPTIDE{i}AB"
        row[19] = "HLA-A*02:01"
        row[20] = "I"
        rows.append(row)
    _write_tiny_iedb_csv(src, rows)

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert not df.empty

    for col in ("peptide", "mhc_restriction", "mhc_class"):
        if col in df.columns:
            assert pd.api.types.is_string_dtype(df[col]), (
                f"{col!r} dtype is {df[col].dtype}; expected string-like "
                "(check that pd.options.future.infer_string is still True)"
            )
            # Specifically not legacy object dtype — that's the regression
            # we're guarding against.
            assert df[col].dtype.name != "object", (
                f"{col!r} fell back to legacy object dtype; the ~5x base-cost "
                "memory inflation is back.  Verify hitlist/__init__.py still "
                "sets pd.options.future.infer_string = True."
            )


# ── CEDAR column resolution (#470) ──────────────────────────────────────────
#
# CEDAR's export inserts one extra "Epitope | Mutation" column relative to
# IEDB's layout. Three keys' name candidates were missing the " | " that
# _resolve_columns inserts when combining the category and field header
# rows, so they never matched by name on EITHER source -- they only ever
# "worked" on IEDB by the coincidence that _FALLBACK_INDICES was calibrated
# against IEDB's own column count. The moment a layout no longer matches
# (CEDAR's extra column, or any future one), the fallback silently reads
# the wrong column with no symptom but wrong data.


#: The real (category, field) header text IEDB uses for every key that
#: had a ``_FALLBACK_INDICES`` entry, keyed by the key's real IEDB column
#: index -- measured directly from a registered IEDB export (#470's own
#: repro methodology). Deliberately includes the category text: three
#: keys' bug was specifically that their name candidates never matched
#: once combined with a *non-empty* category via " | ", so a synthetic
#: header with blank categories (as ``_write_tiny_iedb_csv`` uses) cannot
#: reproduce it -- it has to look exactly like this.
_REAL_HEADER_BY_INDEX: dict[int, tuple[str, str, str]] = {
    0: ("assay_iri", "Assay ID", "IEDB IRI"),
    1: ("ref_iri", "Reference", "IEDB IRI"),
    3: ("pmid", "Reference", "PMID"),
    4: ("submission_id", "Reference", "Submission ID"),
    8: ("ref_title", "Reference", "Title"),
    11: ("epitope_name", "Epitope", "Name"),
    23: ("source_organism", "Epitope", "Source Organism"),
    25: ("species", "Epitope", "Species"),
    43: ("host", "Host", "Name"),
    48: ("host_age", "Host", "Age"),
    49: ("host_mhc_types", "Host", "MHC Types Present"),
    50: ("process_type", "in vivo Process", "Process Type"),
    51: ("disease", "in vivo Process", "Disease"),
    53: ("disease_stage", "in vivo Process", "Disease Stage"),
    88: ("antigen_processing_comments", "Antigen Processing", "Comments"),
    90: ("assay_method", "Assay", "Method"),
    91: ("response_measured", "Assay", "Response measured"),
    92: ("measurement_units", "Assay", "Units"),
    94: ("qualitative_measurement", "Assay", "Qualitative Measurement"),
    95: ("measurement_inequality", "Assay", "Measurement Inequality"),
    96: ("quantitative_measurement", "Assay", "Quantitative measurement"),
    101: ("assay_comments", "Assay", "Comments"),
    102: ("source_tissue", "Antigen Presenting Cell", "Source Tissue"),
    104: ("cell_name", "Antigen Presenting Cell", "Name"),
    106: ("culture_condition", "Antigen Presenting Cell", "Culture Condition"),
    107: ("mhc_restriction", "MHC Restriction", "Name"),
    111: ("mhc_class", "MHC Restriction", "Class"),
}
#: CEDAR's exact reported divergence (#470): one extra column inserted at
#: this real-IEDB index, shifting every real index at or after it by one.
_CEDAR_MUTATION_COLUMN_INDEX = 27


def _iedb_shaped_header(*, cedar_shifted: bool = False):
    """A header shaped like a real IEDB/CEDAR export: every key from
    :data:`_REAL_HEADER_BY_INDEX` at its real column index, unused columns
    blank, sized to 112 real columns (113 when ``cedar_shifted``).
    ``cedar_shifted`` inserts CEDAR's actual extra column at its actual
    reported index, reproducing #470 exactly rather than a simplified
    stand-in -- everything at or after index 27 shifts by one, nothing
    before it moves.

    Returns ``(category_header, field_header, key_to_index)`` -- the last
    one is what test bodies use to place values, so no test ever has to
    know or guess a column's shifted position by hand.
    """
    width = max(_REAL_HEADER_BY_INDEX) + 1
    cat = [""] * width
    fld = [""] * width
    for idx, (_key, c, f) in _REAL_HEADER_BY_INDEX.items():
        cat[idx] = c
        fld[idx] = f
    key_to_index = {key: idx for idx, (key, _c, _f) in _REAL_HEADER_BY_INDEX.items()}

    if cedar_shifted:
        cat = [*cat[:_CEDAR_MUTATION_COLUMN_INDEX], "Epitope", *cat[_CEDAR_MUTATION_COLUMN_INDEX:]]
        fld = [*fld[:_CEDAR_MUTATION_COLUMN_INDEX], "Mutation", *fld[_CEDAR_MUTATION_COLUMN_INDEX:]]
        key_to_index = {
            key: (idx + 1 if idx >= _CEDAR_MUTATION_COLUMN_INDEX else idx)
            for key, idx in key_to_index.items()
        }
    return cat, fld, key_to_index


def test_resolve_columns_matches_by_name_not_by_lucky_position():
    """Every key resolves to the SAME semantic column whether or not
    CEDAR's extra column is present -- proof the match is by name, not by
    a position that only happens to be right on IEDB's own layout.
    """
    plain_cat, plain_fld, plain_idx = _iedb_shaped_header()
    shifted_cat, shifted_fld, shifted_idx = _iedb_shaped_header(cedar_shifted=True)

    plain = _resolve_columns(plain_cat, plain_fld)
    shifted = _resolve_columns(shifted_cat, shifted_fld)

    for key, _cat, _fld in _REAL_HEADER_BY_INDEX.values():
        assert plain[key] == plain_idx[key], key
        assert shifted[key] == shifted_idx[key], key


def test_resolve_columns_finds_the_three_keys_470_reports_broken():
    """The exact three columns #470 reports falling back to the wrong
    index once CEDAR's layout diverges from IEDB's by one column -- using
    the real category text that made their old candidates never match.
    """
    cat, fld, key_to_index = _iedb_shaped_header(cedar_shifted=True)
    resolved = _resolve_columns(cat, fld)
    for key in ("antigen_processing_comments", "assay_comments", "cell_name"):
        assert resolved[key] == key_to_index[key], key


def test_resolve_columns_fails_closed_on_an_unrecognized_header():
    """A header hitlist has never seen must say so, not guess a
    neighboring column via ``_FALLBACK_INDICES`` (#470's second fix).
    """
    with pytest.raises(ValueError, match="cell_name"):
        _resolve_columns(["", "", ""], ["Column A", "Column B", "Column C"])


def _write_shaped_csv(path, category_header, field_header, rows):
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(category_header)
        writer.writerow(field_header)
        for row in rows:
            writer.writerow(row)


def test_scan_detects_binding_assay_on_a_cedar_shaped_layout(tmp_path):
    """#470's first reported consequence: a binding assay must not enter
    the eluted-ligand output just because its layout has CEDAR's extra
    column and ``assay_comments`` is read one column left of where it is.
    """
    cat, fld, idx = _iedb_shaped_header(cedar_shifted=True)
    row = [""] * len(fld)
    row[idx["assay_iri"]] = "http://iedb.org/assay/22938803"
    row[idx["pmid"]] = "24492013"
    row[idx["epitope_name"]] = "AMTKLGFKV"
    row[idx["mhc_restriction"]] = "HLA-A*02:01"
    row[idx["mhc_class"]] = "I"
    row[idx["qualitative_measurement"]] = "Positive"
    row[idx["assay_comments"]] = "Binding was demonstrated by T2 stabilization assay."
    src = tmp_path / "cedar.csv"
    _write_shaped_csv(src, cat, fld, [row])

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    assert bool(df.loc[df["peptide"] == "AMTKLGFKV", "is_binding_assay"].iloc[0]) is True


def test_scan_detects_monoallelic_host_on_a_cedar_shaped_layout(tmp_path):
    """#470's second reported consequence: a mono-allelic cell line must
    still be recognized when ``cell_name`` is read one column left because
    of CEDAR's extra column -- otherwise the one source of unambiguous
    single-allele assignment silently stops firing.
    """
    cat, fld, idx = _iedb_shaped_header(cedar_shifted=True)
    row = [""] * len(fld)
    row[idx["assay_iri"]] = "http://iedb.org/assay/23843967"
    row[idx["pmid"]] = "23843967"
    row[idx["epitope_name"]] = "AFDDIATYF"
    row[idx["mhc_restriction"]] = "HLA-A*02:01"
    row[idx["mhc_class"]] = "I"
    row[idx["cell_name"]] = "HMy2.C1R cell (B cell)"
    row[idx["culture_condition"]] = "Cell Line / Clone"
    src = tmp_path / "cedar.csv"
    _write_shaped_csv(src, cat, fld, [row])

    df = scan(peptides=None, iedb_path=str(src), cedar_path=None)
    hit = df.loc[df["peptide"] == "AFDDIATYF"].iloc[0]
    assert bool(hit["is_monoallelic"]) is True
    assert hit["monoallelic_host"] == "C1R"
