"""Reassignment must select an allele within each biological sample (#547)."""

from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from hitlist import predict
from hitlist.curation import MHC_TYPING_COLUMNS


def _observation(pmid, label, genotype, peptide="AAAAAAAAA"):
    """One observation row as ``generate_observations_table`` emits it.

    Carries the cellular-typing columns -- blank is what an unreviewed study
    exports -- so the stub keeps the real export's contract (#520).

    ``sample_match_type`` is ``pmid_class_pool``, not ``allele_match``: a
    class-only ``mhc_restriction`` is never a key in the allele index, so the
    exporter cannot emit ``allele_match`` for one of these rows. The stub said
    it could, which is how a guard keyed on that column passed its own
    regression suite while dropping 14,532 corpus rows (#564). ``sample_mhc``
    here is the sample's own candidate list, so ``sample_mhc_origin`` is
    ``sample`` -- that is the distinction the guard now reads.
    """
    return {
        "peptide": peptide,
        "pmid": pmid,
        "sample_label": label,
        "sample_mhc": genotype,
        "mhc_restriction": "HLA class I",
        "is_monoallelic": False,
        "sample_match_type": "pmid_class_pool",
        "sample_mhc_origin": "sample",
        **dict.fromkeys(MHC_TYPING_COLUMNS, ""),
    }


def _install_predictions(monkeypatch, rows, ranks, method="mhcflurry"):
    monkeypatch.setattr(
        "hitlist.export.generate_observations_table", lambda **kwargs: pd.DataFrame(rows)
    )
    calls = []

    def score(pairs):
        calls.append(pairs.copy())
        result = pairs.copy()
        result["presentation_percentile"] = result["allele"].map(ranks)
        result["affinity_nM"] = result["presentation_percentile"] * 100
        return result

    monkeypatch.setattr(predict, f"_predict_{method}", score)
    return calls


@pytest.mark.parametrize("method", ["mhcflurry", "netmhcpan"])
def test_shared_peptide_keeps_each_sample_and_its_own_winner(monkeypatch, method):
    rows = [
        _observation(1, "cell_A", "HLA-A*02:01 HLA-B*07:02"),
        _observation(2, "cell_B", "HLA-A*24:02 HLA-B*08:01"),
    ]
    calls = _install_predictions(
        monkeypatch,
        rows,
        {"HLA-A*02:01": 1.0, "HLA-B*07:02": 2.0, "HLA-A*24:02": 0.01, "HLA-B*08:01": 0.1},
        method,
    )
    result = predict.reassign_class_only_alleles(method=method).set_index("sample_label")
    assert set(result.index) == {"cell_A", "cell_B"}
    assert result.loc["cell_A", "best_allele"] == "HLA-A*02:01"
    assert result.loc["cell_B", "best_allele"] == "HLA-A*24:02"
    assert result.loc["cell_A", "best_affinity_nM"] == 100
    assert result.loc["cell_A", "pmid"] == 1
    assert result.loc["cell_B", "pmid"] == 2
    assert result["n_alleles_tested"].tolist() == [2, 2]
    assert len(calls) == 1 and len(calls[0]) == 4
    for row in result.itertuples():
        assert row.best_allele in row.sample_mhc.split()


def test_context_identity_includes_study_label_and_genotype(monkeypatch):
    rows = [
        _observation(1, "same_label", "HLA-A*02:01 HLA-B*07:02"),
        _observation(2, "same_label", "HLA-A*02:01 HLA-B*07:02"),
        _observation(2, "same_label", "HLA-A*24:02 HLA-B*08:01"),
        _observation(2, "other_label", "HLA-A*24:02 HLA-B*08:01"),
    ]
    calls = _install_predictions(
        monkeypatch,
        rows + rows,
        {"HLA-A*02:01": 1, "HLA-B*07:02": 2, "HLA-A*24:02": 0.01, "HLA-B*08:01": 0.1},
    )
    forward = predict.reassign_class_only_alleles()
    assert len(forward) == 4
    assert len(calls[0]) == 4
    assert not calls[0].duplicated(["peptide", "allele"]).any()
    monkeypatch.setattr(
        "hitlist.export.generate_observations_table", lambda **kwargs: pd.DataFrame(rows[::-1])
    )
    reverse = predict.reassign_class_only_alleles()
    keys = ["pmid", "sample_label", "sample_mhc"]
    pd.testing.assert_frame_equal(
        forward.sort_values(keys).reset_index(drop=True),
        reverse.sort_values(keys).reset_index(drop=True),
    )


def test_equal_scores_have_a_stable_winner(monkeypatch):
    _install_predictions(
        monkeypatch,
        [_observation(1, "cell", "HLA-B*07:02 HLA-A*02:01")],
        {"HLA-A*02:01": 0.1, "HLA-B*07:02": 0.1},
    )
    assert predict.reassign_class_only_alleles().iloc[0]["best_allele"] == "HLA-A*02:01"


def test_unidentified_study_pool_is_not_a_predictor_genotype(monkeypatch):
    calls = _install_predictions(monkeypatch, [_observation(1, "", "HLA-A*02:01 HLA-B*07:02")], {})
    assert predict.reassign_class_only_alleles().empty
    assert not calls


@pytest.mark.parametrize(
    "pool,label",
    [
        # PMID 24616531's real curated typing: six loci, all one field.
        ("HLA-A*01 HLA-A*03 HLA-B*07 HLA-B*27 HLA-C*02 HLA-C*07", "pure_one_field"),
        # PMID 28188227 / 29393594 / 29632046: a single allele group.
        ("HLA-B*27", "pure_single_group"),
        # PMID 32938616: five named proteins plus one unresolved group.
        ("HLA-A*02:01 HLA-A*03:01 HLA-B*40:02 HLA-B*47 HLA-C*03:04 HLA-C*06:02", "mixed"),
        # A locus names no protein at all.
        ("HLA-A HLA-B HLA-C", "gene_only"),
        # #574 via a serotype: it reaches the boundary through
        # `SampleMhcCandidates.serotypes`, so a rule reading only `exact`
        # never saw it and scored the remaining allele anyway.
        ("HLA-A2 HLA-B*07:02", "serotype_plus_allele"),
        # ... and via a class sentinel, which arrives through `imprecise`.
        ("HLA-A*02:01 HLA class I", "sentinel_plus_allele"),
        # A class-Ib molecule is a real class-I presenting protein that no
        # wired predictor models.
        ("HLA-A*02:01 HLA-E*01:01", "class_ib_plus_allele"),
    ],
)
def test_unresolved_candidate_pool_never_invokes_a_predictor(monkeypatch, pool, label):
    """#574/#563: an identified sample is necessary but not sufficient.

    Every row here carries a curated label and its own candidate list, so the
    identity guards (#520) let it through -- and the pool still fits under
    ``max_alleles_per_sample``, which is exactly #563's point that a count limit
    does not make a pool biological.  Precision is the other half: none of these
    candidate spaces is resolved to proteins, so no prediction may be attempted
    and no best allele emitted.  The mixed row is the one that matters most --
    dropping ``HLA-B*47`` and scoring the remaining five would return a
    confident winner chosen from an incomplete genotype.
    """
    calls = _install_predictions(
        monkeypatch, [_observation(1, label, pool)], dict.fromkeys(pool.split(), 0.1)
    )
    result = predict.reassign_class_only_alleles()
    assert result.empty
    assert "best_allele" in result
    assert calls == []


@pytest.mark.parametrize(
    "pool,expected",
    [
        ("HLA-A*02:01 HLA-DRB1*15:01", "HLA-A*02:01"),
        ("HLA-A*02:01 HLA-DR15", "HLA-A*02:01"),
        ("HLA-A*02:01 BoLA-DR", "HLA-A*02:01"),
        ("HLA-A*02:01 HLA class II", "HLA-A*02:01"),
        # A non-surface allele is dropped, not counted against completeness.
        ("HLA-A*02:01 HLA-A*24:02:01:02N", "HLA-A*02:01"),
        ("HLA-A*02:01 HLA-B*44:02:01:02S", "HLA-A*02:01"),
    ],
)
def test_other_class_and_non_surface_candidates_do_not_block_prediction(
    monkeypatch, pool, expected
):
    """The other side of the rule, end to end.

    Abstention must be narrow: an imprecise *class-II* designation, or a
    molecule that never reaches the cell surface, leaves the class-I candidate
    space complete and the prediction must still run.
    """
    calls = _install_predictions(monkeypatch, [_observation(1, "cell", pool)], {expected: 0.1})
    result = predict.reassign_class_only_alleles()
    assert len(result) == 1, pool
    assert result.iloc[0]["best_allele"] == expected, pool
    assert calls[0].allele.tolist() == [expected], pool


def test_resolved_pool_of_the_same_shape_still_predicts(monkeypatch):
    """The abstention above must be about precision, not about six candidates.

    Same locus count and same allele-count limit as the pure one-field case,
    typed to two fields: this one predicts.
    """
    pool = "HLA-A*01:01 HLA-A*03:01 HLA-B*07:02 HLA-B*27:05 HLA-C*02:02 HLA-C*07:01"
    calls = _install_predictions(
        monkeypatch, [_observation(1, "resolved", pool)], dict.fromkeys(pool.split(), 0.1)
    )
    result = predict.reassign_class_only_alleles()
    assert len(result) == 1
    assert result.iloc[0]["n_alleles_tested"] == 6
    assert sorted(calls[0].allele) == sorted(pool.split())


def test_cellular_typing_cannot_resolve_an_unresolved_experimental_pool(monkeypatch):
    """#563: the two typings are different data and must not substitute.

    ``mhc_genotype`` is independently sourced cellular typing (#520); the
    experiment's own candidate list is the prediction scope.  A precise genotype
    beside an unresolved ``sample_mhc`` must neither supply candidates nor make
    the context eligible, or the reassignment would claim a restriction the
    experiment never narrowed to.
    """
    row = {
        **_observation(1, "cell", "HLA-B*27"),
        "mhc_genotype": "HLA-A*02:01 HLA-B*27:05 HLA-C*07:01",
        "mhc_genotype_cell": "donor cell line",
        "mhc_genotype_source": "PMID 1, Cell Lines",
    }
    calls = _install_predictions(monkeypatch, [row], {"HLA-A*02:01": 0.1, "HLA-B*27:05": 0.01})
    assert predict.reassign_class_only_alleles().empty
    assert calls == []


def test_imprecise_cellular_typing_does_not_block_a_resolved_experiment(monkeypatch):
    """The separation holds in the other direction too (#563).

    An unresolved ``mhc_genotype`` is not part of the candidate space, so it
    cannot force the experiment's own resolved candidates to abstain; it is
    carried through as metadata unchanged.
    """
    row = {**_observation(1, "cell", "HLA-B*27:05"), "mhc_genotype": "HLA-A HLA-B*27"}
    calls = _install_predictions(monkeypatch, [row], {"HLA-B*27:05": 0.01})
    result = predict.reassign_class_only_alleles().iloc[0]
    assert calls[0].allele.tolist() == ["HLA-B*27:05"]
    assert result.best_allele == "HLA-B*27:05"
    assert result.mhc_genotype == "HLA-A HLA-B*27"


def test_cellular_background_does_not_enter_selected_restriction_prediction(monkeypatch):
    row = {
        **_observation(31530632, "C1R", "HLA-B*40:02"),
        "mhc_basis": "selected_restriction",
        "mhc_genotype": "HLA-B*35:03 HLA-B*40:02 HLA-C*04:01",
        "mhc_genotype_cell": "C1R-B*40:02",
        "mhc_genotype_source": "PMID 31530632, Cell Lines",
    }
    calls = _install_predictions(monkeypatch, [row], {"HLA-B*40:02": 0.1})
    result = predict.reassign_class_only_alleles().iloc[0]
    assert calls[0].allele.tolist() == ["HLA-B*40:02"]
    assert result.mhc_genotype == row["mhc_genotype"]
    assert result.mhc_basis == "selected_restriction"


def test_class_pool_union_is_not_predicted_against_its_named_sample(monkeypatch):
    """A curated label on a pooled row does not make the pool that sample's
    genotype: the class-pool fallback fills ``sample_mhc`` from every arm of
    the study, so scoring it would hand one arm's allele to another (#520)."""
    row = {
        **_observation(1, "armB", "HLA-A*02:01 HLA-B*07:02"),
        "sample_mhc_origin": "class_pool",
    }
    calls = _install_predictions(monkeypatch, [row], {"HLA-A*02:01": 0.1})
    assert predict.reassign_class_only_alleles().empty
    assert not calls


@pytest.mark.parametrize("missing", [np.nan, np.inf, -np.inf])
def test_unscored_sample_does_not_borrow_another_samples_prediction(monkeypatch, missing):
    _install_predictions(
        monkeypatch,
        [
            _observation(1, "unscored", "HLA-A*02:01"),
            _observation(2, "scored", "HLA-A*24:02"),
        ],
        {"HLA-A*02:01": missing, "HLA-A*24:02": 0.01},
    )
    result = predict.reassign_class_only_alleles().set_index("sample_label")
    assert set(result.index) == {"unscored", "scored"}
    for name in ("best_allele", "best_affinity_nM", "best_presentation_percentile"):
        assert pd.isna(result.loc["unscored", name])
    assert not result.loc["unscored", "is_strong_binder"]
    assert not result.loc["unscored", "is_weak_binder"]
    assert result.loc["scored", "best_allele"] == "HLA-A*24:02"


def test_empty_predictor_output_preserves_unscored_context(monkeypatch):
    _install_predictions(monkeypatch, [_observation(1, "cell", "HLA-A*02:01")], {})
    monkeypatch.setattr(
        predict,
        "_predict_mhcflurry",
        lambda pairs: pd.DataFrame(
            columns=["peptide", "allele", "affinity_nM", "presentation_percentile"]
        ),
    )
    result = predict.reassign_class_only_alleles()
    assert len(result) == 1
    assert pd.isna(result.iloc[0]["best_allele"])
    assert not result.iloc[0]["is_weak_binder"]


@pytest.mark.parametrize(
    "peptide,allele", [("AAAAAAAAA", "HLA-B*07:02"), ("CCCCCCCCC", "HLA-A*02:01")]
)
def test_unrequested_prediction_cannot_supply_a_winner(monkeypatch, peptide, allele):
    _install_predictions(monkeypatch, [_observation(1, "cell", "HLA-A*02:01")], {})
    monkeypatch.setattr(
        predict,
        "_predict_mhcflurry",
        lambda pairs: pd.DataFrame(
            {
                "peptide": [peptide],
                "allele": [allele],
                "affinity_nM": [1.0],
                "presentation_percentile": [0.01],
            }
        ),
    )
    result = predict.reassign_class_only_alleles()
    assert len(result) == 1
    assert pd.isna(result.iloc[0]["best_allele"])


def test_no_valid_length_peptides_returns_empty_without_predicting(monkeypatch):
    calls = _install_predictions(
        monkeypatch, [_observation(1, "cell", "HLA-A*02:01", peptide="AAA")], {}
    )
    result = predict.reassign_class_only_alleles()
    assert result.empty
    assert "best_allele" in result
    assert calls == []


def test_six_distinct_allele_default_does_not_truncate_larger_genotypes(monkeypatch):
    alleles = [
        "HLA-A*01:01",
        "HLA-A*02:01",
        "HLA-B*07:02",
        "HLA-B*08:01",
        "HLA-C*07:01",
        "HLA-C*07:02",
    ]
    rows = [
        _observation(1, "six", " ".join(alleles)),
        _observation(2, "seven", " ".join([*alleles, "HLA-A*24:02"])),
        _observation(3, "repeated", " ".join(alleles + alleles)),
    ]
    calls = _install_predictions(monkeypatch, rows, dict.fromkeys([*alleles, "HLA-A*24:02"], 0.1))
    result = predict.reassign_class_only_alleles().set_index("sample_label")
    assert set(result.index) == {"six", "repeated"}
    assert result["n_alleles_tested"].tolist() == [6, 6]
    assert len(calls[0]) == 6
    explicit = predict.reassign_class_only_alleles(max_alleles_per_sample=7)
    assert set(explicit["sample_label"]) == {"six", "seven", "repeated"}


def test_cli_uses_six_alleles_and_reports_sample_contexts(monkeypatch, capsys):
    from hitlist import cli

    seen = []

    def reassign(**kwargs):
        seen.append(kwargs)
        return pd.DataFrame({"is_strong_binder": [False, True], "is_weak_binder": [True, True]})

    monkeypatch.setattr(predict, "reassign_class_only_alleles", reassign)
    monkeypatch.setattr("sys.argv", ["hitlist", "reassign-alleles"])
    cli.main()
    assert seen[0]["max_alleles_per_sample"] == 6
    assert "2 peptide/sample contexts" in capsys.readouterr().err


@pytest.mark.parametrize("empty", [False, True])
@pytest.mark.parametrize("allele", ["HLA-A*02:01", "HLA-A0201"])
def test_netmhcpan_result_preserves_requested_allele_spelling(monkeypatch, empty, allele):
    tokens = ["x"] * 16
    tokens[1], tokens[2], tokens[10], tokens[12], tokens[15] = (
        "HLA-A02:01",
        "AAAAAAAAA",
        "PEPLIST",
        "0.4",
        "25.0",
    )
    monkeypatch.setattr(
        predict.subprocess,
        "run",
        lambda *args, **kwargs: SimpleNamespace(stdout="" if empty else " ".join(tokens)),
    )
    result = predict._predict_netmhcpan(
        pd.DataFrame({"peptide": ["AAAAAAAAA"], "allele": [allele]})
    )
    if empty:
        assert result.empty
        assert "presentation_percentile" in result
    else:
        assert result.iloc[0]["allele"] == allele
        assert result.iloc[0]["presentation_percentile"] == 0.4


def test_netmhcpan_rejects_a_result_for_a_different_allele(monkeypatch):
    monkeypatch.setattr(
        predict.subprocess,
        "run",
        lambda *args, **kwargs: SimpleNamespace(
            stdout="0 HLA-B07:02 AAAAAAAAA AAAAAAAAA 0 0 0 0 0 AAAAAAAAA PEPLIST 0.9 0.4 0.5 0.6 25"
        ),
    )
    with pytest.raises(RuntimeError, match="requested allele"):
        predict._predict_netmhcpan(
            pd.DataFrame({"peptide": ["AAAAAAAAA"], "allele": ["HLA-A*02:01"]})
        )


def test_netmhcpan_receives_the_protein_not_the_reported_spelling(monkeypatch):
    """#574: a finer-than-two-field candidate must not reach netMHCpan as-is.

    ``_netmhcpan_allele_arg`` only strips ``*``, so a reported
    ``HLA-A*02:01:01:02L`` became ``HLA-A02:01:01:02L`` -- an allele netMHCpan
    does not know. Either it exits non-zero (``check=True`` raises
    ``CalledProcessError``) or it answers for a different allele and the
    identity check raises ``RuntimeError``. Scoring the protein avoids both.
    """
    requested = []

    def fake_run(args, **kwargs):
        allele = args[args.index("-a") + 1]
        requested.append(allele)
        if allele != "HLA-A02:01":
            raise AssertionError(f"netMHCpan cannot resolve {allele!r}")
        tokens = ["x"] * 16
        tokens[1], tokens[2], tokens[10], tokens[12], tokens[15] = (
            "HLA-A02:01",
            "AAAAAAAAA",
            "PEPLIST",
            "0.4",
            "25.0",
        )
        return SimpleNamespace(stdout=" ".join(tokens))

    monkeypatch.setattr(predict.subprocess, "run", fake_run)
    monkeypatch.setattr(
        "hitlist.export.generate_observations_table",
        lambda **kw: pd.DataFrame([_observation(1, "cell", "HLA-A*02:01:01:02L")]),
    )
    result = predict.reassign_class_only_alleles(method="netmhcpan")
    assert requested == ["HLA-A02:01"]
    assert result.iloc[0]["best_allele"] == "HLA-A*02:01"
    # The reported precision is not lost -- it is what the context carries.
    assert result.iloc[0]["sample_mhc"] == "HLA-A*02:01:01:02L"


@pytest.mark.parametrize(
    "pool,fragment",
    [
        ("HLA-A*02:01 HLA-B*27", "unresolved class-I candidates"),
        ("HLA-A*24:02:01:02N", "no class-I candidate that could present a peptide"),
        (
            "HLA-A*01:01 HLA-A*02:01 HLA-B*07:02 HLA-B*08:01 HLA-C*07:01 HLA-C*07:02 HLA-A*24:02",
            "more candidates than max_alleles_per_sample",
        ),
    ],
)
def test_every_abstention_reason_is_reported(monkeypatch, pool, fragment):
    """#574: no abstention may look like an absence.

    Three different reasons remove a context from the result, and each one is
    indistinguishable from "this study had no class-only peptides" unless it is
    named.
    """
    calls = _install_predictions(monkeypatch, [_observation(1, "cell", pool)], {})
    with pytest.warns(UserWarning, match=r"Reassignment abstained") as recorded:
        result = predict.reassign_class_only_alleles()
    assert result.empty
    assert calls == []
    message = str(recorded[0].message)
    assert fragment in message, message
    assert "1 peptide/sample contexts" in message


def test_abstention_tally_counts_contexts_after_the_length_filter(monkeypatch):
    """Counted after the filters that decide what would have been predicted.

    The short peptide is never a prediction candidate, so including it in the
    tally would overstate what was lost; the two scorable-but-unresolved rows
    of one context are one context and two observations.
    """
    rows = [
        _observation(1, "cell", "HLA-A*02:01 HLA-B*27", peptide="AAAAAAAAA"),
        _observation(1, "cell", "HLA-A*02:01 HLA-B*27", peptide="CCCCCCCCC"),
        _observation(1, "cell", "HLA-A*02:01 HLA-B*27", peptide="AAA"),
    ]
    _install_predictions(monkeypatch, rows, {})
    with pytest.warns(UserWarning, match=r"Reassignment abstained") as recorded:
        predict.reassign_class_only_alleles()
    message = str(recorded[0].message)
    assert "2 peptide/sample contexts" in message, message
    assert "2 observations" in message, message
