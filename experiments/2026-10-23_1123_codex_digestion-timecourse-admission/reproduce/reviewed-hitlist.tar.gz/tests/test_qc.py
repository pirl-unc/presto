# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for hitlist.qc — corpus + curation diagnostic checks."""

from __future__ import annotations

import pathlib

import pandas as pd
import pytest
import yaml

from hitlist.conditions import (
    ENGINEERING_CONDITION_COLUMNS,
    NONE_PERMITTED_CONDITION_COLUMNS,
)

#: Engineering columns whose findings prescribe `none` as the remedy.
_NONE_PERMITTED_ENGINEERING_COLUMNS = sorted(
    ENGINEERING_CONDITION_COLUMNS & NONE_PERMITTED_CONDITION_COLUMNS
)


def _write_obs_fixture(tmp_path, rows):
    """Write a minimal observations.parquet fixture with the columns
    the qc functions actually project.

    Low-cardinality columns are written as ``category``, because that is the
    dtype a real build produces: ``builder._CATEGORICAL_BUILD_COLUMNS`` casts
    them and the parquet dictionary-encodes them, so ``load_observations``
    hands qc a categorical. A fixture of plain strings is a dtype production
    never has, and it silently hid a sort regression on ``allele_resolution``
    that only categoricals expose (#597). The list is imported rather than
    copied so the fixture follows the build.

    Two details of that dtype are reproduced deliberately, because getting them
    wrong invents shapes the corpus cannot exhibit. Measured on
    ``observations.parquet``, every one of these columns comes back with **0**
    NaN and with ``""`` **among its categories**. So NaN is filled with ``""``
    before the cast, and ``""`` is forced into the category list even when no
    row uses it.

    Forcing ``""`` in is what keeps the fixture usable, and it is not a
    workaround: ``builder._compress_categoricals`` pre-adds ``""`` to every one
    of these columns **on purpose**, with a comment naming the ``fillna("")``
    call sites in ``export.py`` / ``supplement.py`` / ``scanner.py`` that would
    otherwise raise. Under pandas 2.x, ``Categorical.fillna`` validates the fill
    value against the categories *whether or not any NaN is present*, so a
    column without ``""`` raises ``TypeError: Cannot setitem on a Categorical
    with a new category ()``. So the builder maintains an invariant those call
    sites depend on; reproducing it here is reproducing the corpus. #605 tracks
    the fact that the dependency is undocumented at the 13 call sites, not a
    crash waiting to happen.
    """
    from hitlist.builder import _CATEGORICAL_BUILD_COLUMNS

    df = pd.DataFrame(rows)
    for column in _CATEGORICAL_BUILD_COLUMNS:
        if column in df.columns:
            # ``to_numpy(dtype=object)``: handing ``pd.Categorical`` an object
            # *Series* makes pandas infer its dtype and warn (#597).
            values = df[column].astype("object").fillna("").to_numpy(dtype=object)
            df[column] = pd.Categorical(values, categories=sorted(set(values) | {""}))
    path = tmp_path / "observations.parquet"
    df.assign(assay_method="mass spectrometry", qualitative_measurement="Positive").to_parquet(
        path, index=False
    )
    return path


def test_resolution_histogram_buckets_and_pct(tmp_path, monkeypatch):
    """Histogram returns one row per (class, source, bucket) and pct_within_class
    sums to ~100 within each class."""
    from hitlist import qc

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            # Class I: 3 four_digit, 1 class_only.
            {
                "peptide": "AAAAAAAAA",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "four_digit",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 1,
            },
            {
                "peptide": "BBBBBBBBB",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "four_digit",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 1,
            },
            {
                "peptide": "CCCCCCCCC",
                "mhc_class": "I",
                "source": "cedar",
                "allele_resolution": "four_digit",
                "mhc_restriction": "HLA-B*07:02",
                "pmid": 2,
            },
            {
                "peptide": "DDDDDDDDD",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "class_only",
                "mhc_restriction": "",
                "pmid": 3,
            },
            # Class II: 1 two_digit.
            {
                "peptide": "EEEEEEEEEEEEE",
                "mhc_class": "II",
                "source": "iedb",
                "allele_resolution": "two_digit",
                "mhc_restriction": "HLA-DRB1*04",
                "pmid": 4,
            },
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)

    df = qc.resolution_histogram()
    # 3 distinct (mhc_class, source, allele_resolution) combinations for class I,
    # 1 for class II = 4 rows total.
    assert len(df) == 4
    # pct_within_class sums to 100 per class. ``observed=True`` because
    # ``mhc_class`` is categorical: the default groups over every *category*,
    # so an unused one yields an empty group whose percentages sum to 0 and
    # fails an assertion about classes that have rows (#597).
    for _cls, group in df.groupby("mhc_class", observed=True):
        assert abs(group["pct_within_class"].sum() - 100) < 0.5

    # Most-resolved bucket (four_digit) sorts first within each class.
    class_i = df[df["mhc_class"] == "I"]
    assert class_i.iloc[0]["allele_resolution"] == "four_digit"


def test_resolution_histogram_orders_every_public_resolution_tier(tmp_path, monkeypatch):
    """#597: the bucket ordering must cover the whole public vocabulary.

    The literal rank map this replaced predated ``donor_set``, so the
    second-most-specific tier fell to an ``fillna(99)`` default and sorted
    below ``unresolved``.  Asserting the emitted order equals
    ``ALLELE_RESOLUTION_ORDER`` fails on the next tier added rather than
    silently demoting it, which is the point (cf. the #455 round-trip rule).
    """
    from hitlist import qc
    from hitlist.curation import ALLELE_RESOLUTION_ORDER

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            {
                "peptide": "AAAAAAAAA" + chr(ord("A") + i),
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": resolution,
                "mhc_restriction": "HLA-A*02:01",
                "pmid": i + 1,
            }
            for i, resolution in enumerate(ALLELE_RESOLUTION_ORDER)
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)

    df = qc.resolution_histogram()
    assert list(df["allele_resolution"]) == list(ALLELE_RESOLUTION_ORDER)


def test_resolution_histogram_filters(tmp_path, monkeypatch):
    """Class filter narrows the result correctly."""
    from hitlist import qc

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            {
                "peptide": "AAAAAAAAA",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "four_digit",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 1,
            },
            {
                "peptide": "EEEEEEEEEEEEE",
                "mhc_class": "II",
                "source": "iedb",
                "allele_resolution": "two_digit",
                "mhc_restriction": "HLA-DRB1*04",
                "pmid": 4,
            },
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)

    df = qc.resolution_histogram(mhc_class="I")
    assert set(df["mhc_class"]) == {"I"}
    assert len(df) == 1


def test_normalization_drift_flags_changed_alleles(monkeypatch):
    """normalize_allele rewriting an input → drift row.  ``HLA-Cw*04:01``
    is the legacy IMGT C-locus spelling; mhcgnomes rewrites it to the
    modern ``HLA-C*04:01``.  Alleles already in canonical form produce
    no drift row.
    """
    from hitlist import qc

    fake_overrides = {
        12345: {
            "study_label": "Fake Study 2024",
            "hla_alleles": [
                "HLA-Cw*04:01",  # legacy spelling → drifts to HLA-C*04:01
                "HLA-B*07:02",  # already canonical → no drift
            ],
        },
    }
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: fake_overrides)

    df = qc.normalization_drift()
    assert "HLA-Cw*04:01" in df["allele_raw"].values
    assert "HLA-B*07:02" not in df["allele_raw"].values
    drift_row = df[df["allele_raw"] == "HLA-Cw*04:01"].iloc[0]
    assert drift_row["allele_normalized"] == "HLA-C*04:01"
    assert drift_row["pmid"] == 12345


def test_normalization_drift_returns_empty_columns_when_no_drift(monkeypatch):
    """Empty result still has the expected columns (consumers can read
    ``df.columns`` even when nothing's wrong)."""
    from hitlist import qc

    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})
    df = qc.normalization_drift()
    assert list(df.columns) == [
        "pmid",
        "study_label",
        "allele_raw",
        "allele_normalized",
        "severity",
    ]
    assert len(df) == 0


def test_cross_reference_yaml_only_and_data_only(tmp_path, monkeypatch):
    """Cross-reference catches both directions:
    - allele in YAML sample but not in data rows for that PMID → yaml_only
    - 4-digit allele in data but not in any YAML sample for that PMID → data_only
    """
    from hitlist import qc

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            # PMID 100: data has A*02:01 and B*07:02; YAML lists A*02:01 + C*04:01.
            # → C*04:01 yaml_only, B*07:02 data_only.
            {
                "peptide": "AAAAAAAAA",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "four_digit",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 100,
            },
            {
                "peptide": "BBBBBBBBB",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "four_digit",
                "mhc_restriction": "HLA-B*07:02",
                "pmid": 100,
            },
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)

    fake_overrides = {
        100: {
            "study_label": "Test Study",
            "ms_samples": [
                {"sample_label": "donor1", "mhc": ["HLA-A*02:01", "HLA-C*04:01"]},
            ],
        },
    }
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: fake_overrides)

    df = qc.cross_reference()
    assert not df.empty
    yaml_only = df[df["direction"] == "yaml_only"]
    data_only = df[df["direction"] == "data_only"]
    assert "HLA-C*04:01" in yaml_only["allele"].values
    assert "HLA-B*07:02" in data_only["allele"].values
    # The agreed allele (A*02:01) should NOT appear in either bucket.
    assert "HLA-A*02:01" not in df["allele"].values


def test_cross_reference_skips_excluded_from_ms_studies(tmp_path, monkeypatch):
    """A curated arm for an ``exclude_from_ms`` study never reaches the MS
    index, so it must not read as a ``yaml_only`` gap (#471) -- the #444
    rationale is exactly that these studies are not elution experiments.
    """
    from hitlist import qc

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            {
                "peptide": "CCCCCCCCC",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "four_digit",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 200,
            },
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)

    fake_overrides = {
        100: {
            "study_label": "Excluded Study",
            "exclude_from_ms": True,
            "ms_samples": [{"sample_label": "donor1", "mhc": ["HLA-C*04:01"]}],
        },
        200: {"study_label": "Kept Study"},
    }
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: fake_overrides)
    monkeypatch.setattr("hitlist.qc.ms_excluded_pmids", lambda: frozenset({100}))

    df = qc.cross_reference()
    assert 100 not in set(df["pmid"])
    data_only = df[df["direction"] == "data_only"]
    assert "HLA-A*02:01" in data_only["allele"].values


def test_cross_reference_emits_needs_deconvolution_for_class_only_pmids(tmp_path, monkeypatch):
    """v1.30.15: PMIDs with YAML alleles but ZERO 4-digit data rows
    (data is 100% class-only) used to dump every YAML allele under
    ``yaml_only`` — non-actionable noise that inflated curation_plan
    priorities. Now collapsed into a single ``needs_deconvolution``
    sentinel row per PMID.
    """
    from hitlist import qc

    # PMID 200: 3 rows, all class-only (no 4-digit allele in data).
    obs_path = _write_obs_fixture(
        tmp_path,
        [
            {
                "peptide": "AAAAAAAAA",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "class_only",
                "mhc_restriction": "HLA class I",
                "pmid": 200,
            },
            {
                "peptide": "BBBBBBBBB",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "class_only",
                "mhc_restriction": "HLA class I",
                "pmid": 200,
            },
            {
                "peptide": "CCCCCCCCC",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "class_only",
                "mhc_restriction": "HLA class I",
                "pmid": 200,
            },
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    # YAML lists 5 alleles but data has 0 four-digit rows.
    fake_overrides = {
        200: {
            "study_label": "All Class-Only Study",
            "ms_samples": [
                {
                    "sample_label": "donor1",
                    "mhc": ["HLA-A*02:01", "HLA-B*07:02", "HLA-C*04:01"],
                },
                {
                    "sample_label": "donor2",
                    "mhc": ["HLA-A*03:01", "HLA-B*15:01"],
                },
            ],
        },
    }
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: fake_overrides)

    df = qc.cross_reference()
    # Exactly ONE needs_deconvolution row, no per-allele yaml_only spam.
    needs_decon = df[df["direction"] == "needs_deconvolution"]
    yaml_only = df[df["direction"] == "yaml_only"]
    assert len(needs_decon) == 1
    assert needs_decon.iloc[0]["pmid"] == 200
    assert "5 YAML alleles" in needs_decon.iloc[0]["allele"]
    # No per-allele yaml_only rows for this PMID.
    assert (yaml_only["pmid"] != 200).all() if not yaml_only.empty else True


def test_cross_reference_yaml_only_still_fires_when_some_data_is_4digit(tmp_path, monkeypatch):
    """Don't regress the yaml_only path: as long as ANY 4-digit data
    exists for the PMID, the per-allele yaml_only emission still
    runs (because deconvolution isn't structurally blocked)."""
    from hitlist import qc

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            # Mixed: 1 four-digit row + 5 class-only rows.
            {
                "peptide": "AAAAAAAAA",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "four_digit",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 300,
            },
            *[
                {
                    "peptide": f"X{i:08d}",
                    "mhc_class": "I",
                    "source": "iedb",
                    "allele_resolution": "class_only",
                    "mhc_restriction": "HLA class I",
                    "pmid": 300,
                }
                for i in range(5)
            ],
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    fake_overrides = {
        300: {
            "study_label": "Mixed Study",
            "ms_samples": [
                {"sample_label": "donor1", "mhc": ["HLA-A*02:01", "HLA-C*04:01"]},
            ],
        },
    }
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: fake_overrides)

    df = qc.cross_reference()
    # C*04:01 still fires as yaml_only — A*02:01 has data, so this PMID
    # is NOT structurally class-only.
    assert "HLA-C*04:01" in df[df["direction"] == "yaml_only"]["allele"].values
    assert df[df["direction"] == "needs_deconvolution"].empty


def test_run_all_returns_named_dataframes(tmp_path, monkeypatch):
    """The dispatcher returns the expected keys regardless of contents."""
    from hitlist import qc

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            {
                "peptide": "AAAAAAAAA",
                "mhc_class": "I",
                "source": "iedb",
                "allele_resolution": "four_digit",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 1,
                "is_monoallelic": False,
                "mhc_class_label_suspect": False,
                "mhc_allele_provenance": "exact",
                # v1.30.26: proteome_coverage projects source_organism.
                "source_organism": "Homo sapiens",
            },
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})

    results = qc.run_all()
    assert set(results.keys()) == {
        "resolution",
        "normalization",
        "mhc_tokens",
        "cross_reference",
        "discrepancies",
        # v1.30.26: proteome_coverage joined the run_all aggregator
        # (#39 follow-up — proteome registry coverage is its own
        # diagnostic axis, not a rollup of the others).
        "proteome_coverage",
        # #586: engineering drift is a curation axis of its own, and a curator
        # running `hitlist qc` saw none of it while it was absent here.
        "engineering_drift",
    }
    for v in results.values():
        assert isinstance(v, pd.DataFrame)


def test_mhc_token_audit_distinguishes_source_errors_parser_gaps_and_unknowns(monkeypatch):
    """#396: invalid source data and a valid parser gap are not equivalent."""
    from hitlist import qc

    real_parse = qc._cached_parse
    monkeypatch.setattr(
        qc,
        "_cached_parse",
        lambda token: None if token == "HLA-Cw16" else real_parse(token),
    )

    evidence = {
        "ms": pd.DataFrame(
            {
                "pmid": [1, 2, 3, 4],
                "mhc_restriction": ["HLA-A*02:01", "HLA class I", "HLA-A*02:01", "BOGUS-X"],
                "host_mhc_types": [
                    "HLA-A2;HLA-B23",
                    "HLA-Cw16",
                    "unknown",
                    "HLA-A2",
                ],
                "serotype": ["HLA-A2", "", "HLA-DR7A", ""],
                "serotypes": ["HLA-A2;HLA-Bw4", "", "", ""],
            }
        ),
        "binding": pd.DataFrame(
            {
                "pmid": [5],
                "mhc_restriction": ["HLA-B*07:02"],
                "host_mhc_types": ["HLA-B23"],
                "serotype": ["HLA-B7"],
                "serotypes": ["HLA-B7;HLA-Bw6"],
            }
        ),
    }
    curated = pd.DataFrame(
        {
            "pmid": [6],
            "sample_label": ["sample"],
            "mhc": ["HLA-A*02:01 HLA-B*07:02"],
        }
    )

    audit = qc.mhc_token_audit(evidence_frames=evidence, curated_samples=curated)
    by_token = audit.set_index("token")
    assert by_token.loc["HLA-B23", "status"].tolist() == ["invalid_source", "invalid_source"]
    assert by_token.loc["HLA-Cw16", "status"] == "parser_gap"
    assert by_token.loc["HLA-DR7A", "status"] == "invalid_source"
    assert by_token.loc["BOGUS-X", "status"] == "unrecognized"
    assert "unknown" not in set(audit["token"])
    assert "HLA-A*02:01" not in set(audit["token"])
    assert set(audit["evidence_kind"]) == {"ms", "binding"}


def test_mhc_token_audit_uses_curated_overrides_when_samples_not_supplied(monkeypatch):
    from hitlist import qc

    monkeypatch.setattr(
        qc,
        "load_pmid_overrides",
        lambda: {
            7: {
                "ms_samples": [
                    {"sample_label": "bad sample", "mhc": "HLA-A*02:01 BAD-MHC"},
                ]
            }
        },
    )
    audit = qc.mhc_token_audit(evidence_frames={})
    assert audit[["evidence_kind", "field", "token", "status"]].to_dict("records") == [
        {
            "evidence_kind": "curation",
            "field": "sample_mhc",
            "token": "BAD-MHC",
            "status": "unrecognized",
        }
    ]


def test_mhc_token_audit_skips_exclude_from_ms_studies_default_samples(monkeypatch):
    """A study curated ``exclude_from_ms`` never reaches the MS index; its
    samples must not enter the token audit either (#471).
    """
    from hitlist import qc

    monkeypatch.setattr(qc, "ms_excluded_pmids", lambda: frozenset({7}))
    monkeypatch.setattr(
        qc,
        "load_pmid_overrides",
        lambda: {
            7: {
                "exclude_from_ms": True,
                "ms_samples": [
                    {"sample_label": "should be skipped", "mhc": "HLA-A*02:01 BAD-MHC"},
                ],
            },
            8: {
                "ms_samples": [
                    {"sample_label": "kept", "mhc": "HLA-A*02:01 ALSO-BAD"},
                ],
            },
        },
    )
    audit = qc.mhc_token_audit(evidence_frames={})
    assert set(audit["token"]) == {"ALSO-BAD"}


def test_mhc_token_audit_parser_gap_self_expires(monkeypatch):
    """A known parser gap stops reporting once the installed parser accepts it."""
    from hitlist import qc

    parsed_serotype = type("Serotype", (), {})()
    monkeypatch.setattr(qc, "_cached_parse", lambda _token: parsed_serotype)
    evidence = {
        "ms": pd.DataFrame({"pmid": [1], "host_mhc_types": ["HLA-Cw16"]}),
    }

    assert qc.mhc_token_audit(
        evidence_frames=evidence,
        curated_samples=pd.DataFrame(),
    ).empty


@pytest.mark.integration
def test_current_corpus_mhc_token_allowlist_is_complete_and_not_stale():
    """#396/#484: every exceptional token found in the registered corpus is a
    reviewed one; a genuinely new/unreviewed token still fails loudly.

    Not exact-set equality against a hardcoded snapshot (#484): CI's
    published corpus (``ci-corpus-v1``) and a locally rebuilt one legitimately
    hold different subsets of these tokens as curation moves the underlying
    data forward -- e.g. HLA-DR7A/DR3A/DR1B dropped out of a locally rebuilt
    corpus entirely (confirmed by grepping the built parquet files directly)
    while still present in CI's older snapshot. Checking against the same
    registries the audit itself classifies from keeps this self-updating.
    """
    from hitlist.observations import is_built
    from hitlist.qc import _KNOWN_INVALID_MHC_TOKENS, _KNOWN_MHC_PARSER_GAPS, mhc_token_audit

    if not is_built():
        pytest.skip("requires a registered observations corpus")

    audit = mhc_token_audit()

    assert not (audit["status"] == "unrecognized").any(), audit.to_string(index=False)
    reviewed = {(token, "invalid_source") for token in _KNOWN_INVALID_MHC_TOKENS} | {
        (token, "parser_gap") for token in _KNOWN_MHC_PARSER_GAPS
    }
    found = set(zip(audit["token"], audit["status"]))
    assert found <= reviewed, f"unreviewed findings: {found - reviewed}"


def test_cli_routes_mhc_token_audit(monkeypatch, capsys):
    from hitlist import qc
    from hitlist.cli import main

    expected = pd.DataFrame({"token": ["HLA-Cw16"], "status": ["parser_gap"], "n_records": [1]})
    monkeypatch.setattr(qc, "mhc_token_audit", lambda: expected)
    monkeypatch.setattr("sys.argv", ["hitlist", "qc", "mhc-tokens"])

    main()

    assert "HLA-Cw16,parser_gap,1" in capsys.readouterr().out


# ── #182 / #45 / #37 / v1.30.9: discrepancies report ──────────────────


def _disc_fixture_row(
    peptide: str,
    mhc_class: str,
    pmid: int,
    *,
    mhc_restriction: str = "",
    is_monoallelic: bool = False,
    mhc_class_label_suspect: bool = False,
    mhc_allele_provenance: str = "exact",
    cell_name: str = "",
):
    """Build a single fixture row with all columns ``discrepancies`` projects."""
    return {
        "peptide": peptide,
        "mhc_class": mhc_class,
        "mhc_restriction": mhc_restriction,
        "is_monoallelic": is_monoallelic,
        "mhc_class_label_suspect": mhc_class_label_suspect,
        "mhc_allele_provenance": mhc_allele_provenance,
        "cell_name": cell_name,
        "pmid": pmid,
        "reference_iri": f"r-{pmid}-{peptide}",
        "source": "iedb",
        "mhc_species": "Homo sapiens",
        "allele_resolution": (
            "four_digit"
            if mhc_restriction.startswith("HLA-") and "*" in mhc_restriction
            else "class_only"
            if mhc_restriction.startswith("HLA class")
            else "unresolved"
        ),
    }


def test_discrepancies_surfaces_class_label_mismatches(tmp_path, monkeypatch):
    """v1.30.9 / #182: per-PMID rate of ``mhc_class_label_suspect``
    rows is reported. A PMID with many class-II 9-mers (the Marcu 2021
    pattern) sorts to the top of the discrepancy report."""
    from hitlist import qc

    rows = []
    # 60 valid class-I rows on PMID 1 (clean).
    for i in range(60):
        rows.append(_disc_fixture_row(f"P{i:09d}", "I", 1, mhc_restriction="HLA-A*02:01"))
    # 60 rows on PMID 2: 50 valid class-II 14-mers + 10 suspect 7-mers
    # labeled class II. v1.30.17: the suspect tier for class-II is now
    # 5-7 aa (not 8-10 aa, which is borderline) so the test peptides
    # must be 7 aa or shorter to fire the suspect flag.
    for i in range(50):
        rows.append(
            _disc_fixture_row(
                f"Q{i:013d}",
                "II",
                2,
                mhc_restriction="HLA-DRB1*15:01",
            )
        )
    for i in range(10):
        rows.append(
            _disc_fixture_row(
                f"R{i:06d}",
                "II",
                2,
                mhc_restriction="HLA-DRB1*15:01",
                mhc_class_label_suspect=True,
            )
        )
    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: {})
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})

    df = qc.discrepancies(min_rows=10)
    # PMID 2 (with 10 suspects) sorts above PMID 1 (with 0).
    assert df.iloc[0]["pmid"] == 2
    assert df.iloc[0]["suspect_class_label_n"] == 10
    assert abs(df.iloc[0]["suspect_class_label_rate"] - 10 / 60) < 1e-6
    pmid1_row = df[df["pmid"] == 1].iloc[0]
    assert pmid1_row["suspect_class_label_n"] == 0


def test_discrepancies_breaks_down_borderline_vs_implausible(tmp_path, monkeypatch):
    """v1.30.18 / #201: discrepancies surfaces separate
    ``borderline_class_label_n`` and ``implausible_class_label_n``
    columns so a curator can distinguish bulged class-I peptides
    (uncommon but real, 13-14aa) from clear curation drift (≥18aa
    class I). Both feed the binary suspect flag — but only when
    severity is suspect or implausible, not borderline."""
    from hitlist import qc

    rows = []
    # PMID 99: 50 valid class-I 9-mers + 10 borderline 13-mers
    # (bulged class-I, real biology) + 5 implausible 18-mers
    # (class-I should never be 18aa).
    for i in range(50):
        rows.append(
            _disc_fixture_row(
                f"P{i:09d}",
                "I",
                99,
                mhc_restriction="HLA-A*02:01",
            )
        )
    for i in range(10):
        rows.append(
            _disc_fixture_row(
                f"B{i:013d}",  # 14-char placeholder peptide column; class I
                "I",
                99,
                mhc_restriction="HLA-A*02:01",
            )
        )
    for i in range(5):
        rows.append(
            _disc_fixture_row(
                f"I{i:018d}",  # 19-char placeholder; under v1.30.17 this is implausible
                "I",
                99,
                mhc_restriction="HLA-A*02:01",
            )
        )
    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: {})
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})

    df = qc.discrepancies(min_rows=10)
    row = df[df["pmid"] == 99].iloc[0]

    # Borderline (13-14aa class I): uncommon but real, NOT suspect.
    assert row["borderline_class_label_n"] == 10
    # Implausible (≥18aa class I): clearly miscurated.
    assert row["implausible_class_label_n"] == 5
    # Backwards-compat: suspect_class_label_n only counts implausible
    # (no rows in the suspect 15-17 tier in this fixture).
    assert row["suspect_class_label_n"] == 5


def test_discrepancies_flags_monoallelic_class_only(tmp_path, monkeypatch):
    """v1.30.9 / #45: rows that are mono-allelic but carry
    ``HLA class I`` instead of a 4-digit allele are surfaced — IEDB
    lost the per-peptide allele attribution but the paper knows it.
    These appear in the ``monoallelic_class_only_n`` column so a
    curator can prioritize them."""
    from hitlist import qc

    rows = (
        # 5 mono-allelic rows on PMID 99: 3 with proper 4-digit, 2 with class sentinel.
        [
            _disc_fixture_row(
                f"M{i:09d}",
                "I",
                99,
                mhc_restriction="HLA-A*02:01",
                is_monoallelic=True,
            )
            for i in range(3)
        ]
        + [
            _disc_fixture_row(
                f"S{i:09d}",
                "I",
                99,
                mhc_restriction="HLA class I",
                is_monoallelic=True,
            )
            for i in range(2)
        ]
        + [
            # Padding so the bucket clears the min_rows floor.
            _disc_fixture_row(
                f"X{i:09d}",
                "I",
                99,
                mhc_restriction="HLA-A*02:01",
                is_monoallelic=True,
            )
            for i in range(50)
        ]
    )
    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: {})
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})

    df = qc.discrepancies(min_rows=10)
    pmid_99 = df[df["pmid"] == 99].iloc[0]
    assert pmid_99["monoallelic_class_only_n"] == 2
    # severity is "warn" because monoallelic_class_only_n > 0.
    assert pmid_99["severity"] == "warn"


def test_discrepancies_flags_class_pool_rate(tmp_path, monkeypatch):
    """v1.30.9 / #37: per-PMID rate of ``pmid_class_pool`` provenance
    is surfaced. A study where IEDB only stored ``HLA class I`` for
    every peptide ends up with class_pool_rate = 1.0; that's the
    deconvolution-target signal."""
    from hitlist import qc

    rows = [
        _disc_fixture_row(
            f"C{i:09d}",
            "I",
            7,
            mhc_restriction="HLA class I",
            mhc_allele_provenance="pmid_class_pool",
        )
        for i in range(60)
    ]
    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: {})
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})

    df = qc.discrepancies(min_rows=10)
    pmid_7 = df[df["pmid"] == 7].iloc[0]
    assert pmid_7["class_pool_n"] == 60
    assert pmid_7["class_pool_rate"] == 1.0


def test_discrepancies_flags_nonstandard_amino_acids(tmp_path, monkeypatch):
    """v1.30.9: peptides with X / B / Z / U / lowercase / digits get
    counted in ``nonstandard_aa_n``. Catches ambiguous PSM hits and
    upstream string corruption that would otherwise corrupt model
    training inputs."""
    from hitlist import qc

    # All-AA padding (digits in peptide strings would themselves match the
    # nonstandard regex). Use a fixed valid 9-mer for the 58 padding rows.
    rows = [
        _disc_fixture_row("VALIDPEPT", "I", 5, mhc_restriction="HLA-A*02:01") for _ in range(58)
    ] + [
        # Two non-standard peptides — one with X (ambiguous AA), one
        # lowercase (modification carryover).
        _disc_fixture_row("PXPTIDEX", "I", 5, mhc_restriction="HLA-A*02:01"),
        _disc_fixture_row("ppeptidea", "I", 5, mhc_restriction="HLA-A*02:01"),
    ]
    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: {})
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})

    df = qc.discrepancies(min_rows=10)
    pmid_5 = df[df["pmid"] == 5].iloc[0]
    assert pmid_5["nonstandard_aa_n"] == 2
    assert pmid_5["severity"] == "warn"


def test_discrepancies_drops_small_pmid_buckets(tmp_path, monkeypatch):
    """v1.30.9: ``min_rows`` filters out PMID buckets whose row count
    is below the threshold. Length percentiles on tiny buckets (3-5
    rows) are noise; the filter keeps the report focused on real
    cohorts."""
    from hitlist import qc

    rows = (
        # 3 rows on PMID 1 — should be dropped under min_rows=10.
        [_disc_fixture_row(f"A{i:09d}", "I", 1, mhc_restriction="HLA-A*02:01") for i in range(3)]
        # 60 rows on PMID 2 — should survive.
        + [_disc_fixture_row(f"B{i:09d}", "I", 2, mhc_restriction="HLA-A*02:01") for i in range(60)]
    )
    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: {})
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})

    df = qc.discrepancies(min_rows=10)
    assert set(df["pmid"]) == {2}


def test_discrepancies_attaches_study_label_from_overrides(tmp_path, monkeypatch):
    """v1.30.9: the report attaches each PMID's ``study_label`` from
    ``pmid_overrides.yaml`` so the triage list is human-readable
    without a second YAML lookup."""
    from hitlist import qc

    rows = [
        _disc_fixture_row(f"P{i:09d}", "I", 42, mhc_restriction="HLA-A*02:01") for i in range(60)
    ]
    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    overrides = {42: {"study_label": "Pretty Study Name 2026"}}
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: overrides)
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: overrides)

    df = qc.discrepancies(min_rows=10)
    assert df.iloc[0]["study_label"] == "Pretty Study Name 2026"


# ── v1.30.12: by="sample" rollup ──────────────────────────────────────


def test_discrepancies_by_sample_groups_per_cell_name(tmp_path, monkeypatch):
    """v1.30.12: ``by='sample'`` groups by (pmid, mhc_class, cell_name).
    A study with a clean transfectant and a problematic transfectant
    should produce two rows where the dirty one has higher
    suspect_class_label_n than the clean one — exactly the per-sample
    visibility the user asked for ('one transfectant has 30%% suspect
    rows but its sibling has 0%%')."""
    from hitlist import qc

    # Suspect flag is recomputed from peptide length + class at load
    # time, so test fixtures must encode the suspicion in the peptide
    # length itself: class I ≥18aa or class II ≤10aa flags as suspect.
    rows = (
        # K562-A0201: 30 normal 9-aa class-I rows, none suspect.
        [
            _disc_fixture_row(
                "AAAAAAAAA",
                "I",
                7,
                mhc_restriction="HLA-A*02:01",
                cell_name="K562-A0201",
            )
            for _ in range(30)
        ]
        # K562-B0702: 30 clean 9-aa class-I rows + 12 suspect 18-aa rows.
        + [
            _disc_fixture_row(
                "BBBBBBBBB",
                "I",
                7,
                mhc_restriction="HLA-B*07:02",
                cell_name="K562-B0702",
            )
            for _ in range(30)
        ]
        + [
            _disc_fixture_row(
                "CCCCCCCCCCCCCCCCCC",
                "I",
                7,
                mhc_restriction="HLA-B*07:02",
                cell_name="K562-B0702",
            )
            for _ in range(12)
        ]
    )
    obs_path = tmp_path / "observations.parquet"
    pd.DataFrame(rows).assign(
        assay_method="mass spectrometry", qualitative_measurement="Positive"
    ).to_parquet(obs_path, index=False)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: {})
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})

    df = qc.discrepancies(by="sample", min_rows=10)
    # Two output rows — one per cell_name.
    assert "cell_name" in df.columns
    assert set(df["cell_name"]) == {"K562-A0201", "K562-B0702"}
    dirty = df[df["cell_name"] == "K562-B0702"].iloc[0]
    clean = df[df["cell_name"] == "K562-A0201"].iloc[0]
    assert dirty["suspect_class_label_n"] == 12
    assert clean["suspect_class_label_n"] == 0
    # Dirty sample should sort first by score.
    assert df.iloc[0]["cell_name"] == "K562-B0702"


def test_discrepancies_by_sample_no_cell_name_falls_back_to_placeholder(tmp_path, monkeypatch):
    """Rows without a cell_name (patient cohorts, raw IEDB without
    sample identifier) should bucket under '(no cell_name)' rather
    than collapsing into NaN groups that pandas may drop."""
    from hitlist import qc

    rows = [
        _disc_fixture_row(f"P{i:09d}", "I", 9, mhc_restriction="HLA-A*02:01") for i in range(60)
    ]
    obs_path = tmp_path / "observations.parquet"
    pd.DataFrame(rows).assign(
        assay_method="mass spectrometry", qualitative_measurement="Positive"
    ).to_parquet(obs_path, index=False)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: {})
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})

    df = qc.discrepancies(by="sample", min_rows=10)
    assert df.iloc[0]["cell_name"] == "(no cell_name)"
    assert df.iloc[0]["n_rows"] == 60


def test_discrepancies_by_invalid_value_raises():
    """Defensive: only 'pmid' or 'sample' are accepted."""
    import pytest

    from hitlist import qc

    with pytest.raises(ValueError, match="must be 'pmid' or 'sample'"):
        qc.discrepancies(by="study")


# ── v1.30.13: curation_plan / qc plan ──────────────────────────────────


def test_curation_plan_combines_all_qc_signals(tmp_path, monkeypatch):
    """v1.30.13: ``curation_plan`` joins discrepancies, cross_reference,
    and normalization_drift into one PMID-priority list. A PMID with
    drift + suspect rows + a yaml-only allele should sort above a PMID
    with only weak signals."""
    from hitlist import qc

    rows = (
        # PMID 100: 60 valid 9-aa class-I rows + 12 long (suspect) rows.
        [
            _disc_fixture_row(
                "AAAAAAAAA",
                "I",
                100,
                mhc_restriction="HLA-A*02:01",
            )
            for _ in range(60)
        ]
        + [
            _disc_fixture_row(
                "BBBBBBBBBBBBBBBBBB",
                "I",
                100,
                mhc_restriction="HLA-A*02:01",
            )
            for _ in range(12)
        ]
        # PMID 200: 60 clean rows, no signals.
        + [
            _disc_fixture_row(
                "CCCCCCCCC",
                "I",
                200,
                mhc_restriction="HLA-B*07:02",
            )
            for _ in range(60)
        ]
    )
    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    overrides = {
        100: {
            "study_label": "Study With Issues",
            "hla_alleles": ["HLA-Cw*04:01"],  # drifts to HLA-C*04:01
            "ms_samples": [
                {"sample_label": "donor1", "mhc": ["HLA-A*02:01", "HLA-D*99:99"]},
            ],
        },
        200: {"study_label": "Clean Study", "ms_samples": []},
    }
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: overrides)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: overrides)

    plan = qc.curation_plan(min_rows=10)
    assert not plan.empty
    # PMID 100 has signals from all three reports; PMID 200 is clean.
    assert plan.iloc[0]["pmid"] == 100
    pmid_100 = plan[plan["pmid"] == 100].iloc[0]
    assert pmid_100["suspect_class_label_n"] == 12
    # v1.30.19 / #201: severity tiers propagate through the plan.
    # 18-aa class-I peptides fall in the "implausible" tier (which
    # also fires the suspect flag).
    assert "implausible_class_label_n" in plan.columns
    assert "borderline_class_label_n" in plan.columns
    assert pmid_100["implausible_class_label_n"] == 12
    assert pmid_100["borderline_class_label_n"] == 0
    assert pmid_100["normalization_drifts_n"] >= 1  # HLA-Cw*04:01 drift
    assert pmid_100["yaml_only_alleles_n"] >= 1  # HLA-D*99:99 not in data
    assert pmid_100["severity"] == "warn"


def test_curation_plan_ranks_by_priority_score(tmp_path, monkeypatch):
    """A study with normalization drift should beat one with just
    in-data discrepancies — drift means the YAML itself needs editing,
    which is higher-leverage than re-running a length filter."""
    from hitlist import qc

    rows = (
        # PMID 1: 100 suspect-class-label rows. Big number but no drift.
        [
            _disc_fixture_row(
                "BBBBBBBBBBBBBBBBBB",
                "I",
                1,
                mhc_restriction="HLA-A*02:01",
            )
            for _ in range(100)
        ]
        # PMID 2: 60 clean rows. Drift hits.
        + [
            _disc_fixture_row(
                "AAAAAAAAA",
                "I",
                2,
                mhc_restriction="HLA-A*02:01",
            )
            for _ in range(60)
        ]
    )
    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    overrides = {
        1: {"study_label": "PMID 1"},
        2: {
            "study_label": "PMID 2",
            "hla_alleles": ["HLA-Cw*04:01"],  # drifts
        },
    }
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: overrides)
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: overrides)

    plan = qc.curation_plan(min_rows=10)
    # Drift-weighted score (x10000) should put PMID 2 ahead even with
    # only 1 drift vs PMID 1's 100 suspect rows.
    assert plan.iloc[0]["pmid"] == 2


def test_curation_plan_handles_no_signals(tmp_path, monkeypatch):
    """When every input report is empty (no signals at all), the
    plan returns an empty DataFrame with the expected columns rather
    than crashing on the outer-merge."""
    from hitlist import qc

    # A schema-valid but tiny fixture (1 row, no signals worth
    # surfacing — and below min_rows so discrepancies drops it).
    obs_path = _write_obs_fixture(
        tmp_path, [_disc_fixture_row("AAAAAAAAA", "I", 1, mhc_restriction="HLA-A*02:01")]
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    monkeypatch.setattr("hitlist.qc.load_pmid_overrides", lambda: {})
    monkeypatch.setattr("hitlist.curation.load_pmid_overrides", lambda: {})

    plan = qc.curation_plan(min_rows=1000)  # forces all PMIDs to drop
    assert plan.empty
    # Schema must still include priority + severity so consumers can
    # read .columns even when nothing is wrong.
    assert "priority_score" in plan.columns
    assert "severity" in plan.columns


def test_proteome_coverage_resolves_registered_and_flags_missing(tmp_path, monkeypatch):
    """v1.30.23 / #39: proteome_coverage groups rows by source_organism
    and flags species without a registered reference proteome. Severity
    is ``warn`` when a missing-proteome organism exceeds 100 rows
    (curation-priority cluster) and ``info`` otherwise."""
    from hitlist import qc

    rows = []
    # 200 Homo sapiens rows (registered → has_proteome=True, severity=info).
    for i in range(200):
        rows.append(
            {
                "peptide": f"P{i:08d}",
                "mhc_class": "I",
                "mhc_restriction": "HLA-A*02:01",
                "is_monoallelic": False,
                "mhc_class_label_suspect": False,
                "mhc_allele_provenance": "exact",
                "cell_name": "",
                "pmid": 1,
                "reference_iri": f"r-{i}",
                "source": "iedb",
                "mhc_species": "Homo sapiens",
                "source_organism": "Homo sapiens",
            }
        )
    # 150 Felis catus rows (NOT registered, ≥100 rows → severity=warn).
    for i in range(150):
        rows.append(
            {
                "peptide": f"Q{i:08d}",
                "mhc_class": "I",
                "mhc_restriction": "HLA-A*02:01",
                "is_monoallelic": False,
                "mhc_class_label_suspect": False,
                "mhc_allele_provenance": "exact",
                "cell_name": "",
                "pmid": 2,
                "reference_iri": f"q-{i}",
                "source": "iedb",
                "mhc_species": "Felis catus",
                "source_organism": "Felis catus",
            }
        )
    # 30 'unidentified' rows (NOT registered, <100 → severity=info).
    for i in range(30):
        rows.append(
            {
                "peptide": f"U{i:08d}",
                "mhc_class": "I",
                "mhc_restriction": "HLA-A*02:01",
                "is_monoallelic": False,
                "mhc_class_label_suspect": False,
                "mhc_allele_provenance": "exact",
                "cell_name": "",
                "pmid": 3,
                "reference_iri": f"u-{i}",
                "source": "iedb",
                "mhc_species": "Homo sapiens",
                "source_organism": "unidentified",
            }
        )

    obs_path = _write_obs_fixture(tmp_path, rows)
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)

    df = qc.proteome_coverage()

    homo = df[df["source_organism"] == "Homo sapiens"].iloc[0]
    assert homo["n_rows"] == 200
    assert homo["n_pmids"] == 1
    assert bool(homo["has_proteome"])
    assert homo["proteome_kind"] == "ensembl"
    assert homo["severity"] == "info"

    cat = df[df["source_organism"] == "Felis catus"].iloc[0]
    assert cat["n_rows"] == 150
    assert not bool(cat["has_proteome"])
    assert cat["proteome_kind"] == ""
    assert cat["severity"] == "warn"  # missing proteome AND >=100 rows

    unid = df[df["source_organism"] == "unidentified"].iloc[0]
    assert unid["n_rows"] == 30
    assert not bool(unid["has_proteome"])
    assert unid["severity"] == "info"  # missing but <100 rows → long tail

    # Sort order: highest n_rows first.
    assert df.iloc[0]["source_organism"] == "Homo sapiens"


def test_proteome_coverage_empty_observations_returns_schema(tmp_path, monkeypatch):
    """When the corpus is empty (or filtered to nothing), proteome_coverage
    returns an empty DataFrame with the expected schema so callers can
    introspect ``.columns`` without crashing."""
    from hitlist import qc

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            {
                "peptide": "AAAAAAAAA",
                "mhc_class": "I",
                "mhc_restriction": "HLA-A*02:01",
                "is_monoallelic": False,
                "mhc_class_label_suspect": False,
                "mhc_allele_provenance": "exact",
                "cell_name": "",
                "pmid": 1,
                "reference_iri": "r-1",
                "source": "iedb",
                "mhc_species": "Homo sapiens",
                "source_organism": "Homo sapiens",
            }
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)

    # min_rows above the row count → empty result
    df = qc.proteome_coverage(min_rows=1000)
    assert df.empty
    for col in (
        "source_organism",
        "n_rows",
        "n_pmids",
        "has_proteome",
        "proteome_kind",
        "proteome_id",
        "severity",
    ):
        assert col in df.columns


def test_species_axis_audit_flags_chimeric_and_suspicious(tmp_path, monkeypatch):
    """species_axis_audit surfaces chimeric systems grouped by axis triple,
    marks engineered/xenograft rows 'info', and flags chimeric rows with a
    populated host that are neither (likely data errors) 'review'."""
    from hitlist import qc

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            # native human — not chimeric, excluded from audit
            {
                "peptide": "AAAAAAAAA",
                "mhc_class": "I",
                "source": "iedb",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 1,
                "mhc_species": "Homo sapiens",
                "source_organism": "Homo sapiens",
                "host": "Homo sapiens (human)",
            },
            # HLA-tg rat — engineered MHC -> info
            {
                "peptide": "CCCCCCCCC",
                "mhc_class": "I",
                "source": "iedb",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 2,
                "mhc_species": "Homo sapiens",
                "source_organism": "Rattus norvegicus",
                "host": "Rattus norvegicus (brown rat)",
            },
            # bovine allergen on native human cells — chimeric by source but
            # NOT engineered (host != source) and NOT xenograft (host == MHC,
            # native cells); heterologous antigen -> review
            {
                "peptide": "DDDDDDDDD",
                "mhc_class": "I",
                "source": "iedb",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 3,
                "mhc_species": "Homo sapiens",
                "source_organism": "Bos taurus",
                "host": "Homo sapiens (human)",
            },
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)

    audit = qc.species_axis_audit()
    # Only the two chimeric rows appear; the native-human row is excluded.
    assert set(audit["n_rows"]) == {1}
    assert len(audit) == 2

    engineered = audit[audit["is_engineered_mhc"]]
    assert len(engineered) == 1
    assert engineered.iloc[0]["severity"] == "info"
    assert engineered.iloc[0]["source_species"] == "Rattus norvegicus"

    review = audit[audit["severity"] == "review"]
    assert len(review) == 1
    assert review.iloc[0]["host_organism"] == "Homo sapiens"
    assert review.iloc[0]["source_species"] == "Bos taurus"
    assert bool(review.iloc[0]["is_engineered_mhc"]) is False
    assert bool(review.iloc[0]["xenograft"]) is False


def test_species_axis_audit_empty_when_no_chimeric(tmp_path, monkeypatch):
    from hitlist import qc

    obs_path = _write_obs_fixture(
        tmp_path,
        [
            {
                "peptide": "AAAAAAAAA",
                "mhc_class": "I",
                "source": "iedb",
                "mhc_restriction": "HLA-A*02:01",
                "pmid": 1,
                "mhc_species": "Homo sapiens",
                "source_organism": "Homo sapiens",
                "host": "Homo sapiens (human)",
            },
        ],
    )
    monkeypatch.setattr("hitlist.observations.observations_path", lambda: obs_path)
    audit = qc.species_axis_audit()
    assert audit.empty
    assert list(audit.columns) == [
        "host_organism",
        "source_species",
        "mhc_species",
        "is_engineered_mhc",
        "xenograft",
        "n_rows",
        "n_pmids",
        "example_pmids",
        "severity",
    ]


# ── Ploidy audit (#381 and the union-of-samples bug class) ─────────────────


def test_sample_ploidy_audit_flags_a_pooled_genotype():
    """Three alleles at one locus is proof of pooling, not a rare genotype."""
    from hitlist.qc import sample_ploidy_audit

    pooled = {
        1: {
            "ms_samples": [
                # A union across three mono-allelic constructs.
                {"sample_label": "pooled", "mhc": "HLA-A*01:01 HLA-A*02:01 HLA-A*03:01"},
                # A legitimate diploid donor: two DRB1 plus a linked DRB3.
                {
                    "sample_label": "real donor",
                    "mhc": "HLA-DRB1*01:01 HLA-DRB1*03:01 HLA-DRB3*01:01",
                },
                # Imprecise designations name no allele and cannot be pooled.
                {"sample_label": "locus only", "mhc": "BoLA-DR"},
            ]
        }
    }
    found = sample_ploidy_audit(pooled)
    assert list(found["sample_label"]) == ["pooled"]
    row = found.iloc[0]
    assert row["locus"] == "HLA-A" and row["n_alleles"] == 3


@pytest.mark.parametrize("field", ["mhc", "mhc_genotype"])
def test_sample_ploidy_audit_charges_each_heterodimer_chain_to_its_own_locus(field):
    """A DP pair spans two loci, so three pairs are three alphas and three
    betas — not six alleles at one made-up locus."""
    from hitlist.qc import sample_ploidy_audit

    pairs = {
        1: {
            "ms_samples": [
                {
                    "sample_label": "three DP transfectants pooled",
                    field: (
                        "HLA-DPB1*02:01/DPA1*01:03 "
                        "HLA-DPB1*04:01/DPA1*01:03 "
                        "HLA-DPB1*04:02/DPA1*01:03"
                    ),
                }
            ]
        }
    }
    found = sample_ploidy_audit(pairs)
    # DPB1 has three distinct betas; DPA1 is the same alpha three times.
    assert list(found["locus"]) == ["HLA-DPB1"]
    assert list(found["field"]) == [field]
    assert found.iloc[0]["n_alleles"] == 3


def test_curated_corpus_has_no_pooled_genotypes():
    """The real curation must stay clean.

    Every finding here is a sample whose ``mhc`` field pools several
    donors or constructs, which makes the allele join offer every pooled
    allele as a candidate for every peptide in the sample.
    """
    from hitlist.qc import sample_ploidy_audit

    found = sample_ploidy_audit()
    assert found.empty, "curated samples pool multiple genotypes:\n" + found[
        ["pmid", "sample_label", "locus", "alleles"]
    ].to_string(index=False)


@pytest.mark.parametrize("extra", ["", "; BOGUS-X"])
def test_mhc_token_audit_preserves_class_only_component_beside_typed_allele(extra):
    from hitlist.qc import mhc_token_audit

    curated = pd.DataFrame(
        [
            {
                "pmid": 36215666,
                "sample_label": "HeLa-CIITA (Mock)",
                "mhc": "HLA class I; HLA-DRB1*01:02" + extra,
            }
        ]
    )
    audit = mhc_token_audit(evidence_frames={}, curated_samples=curated)
    if extra:
        assert audit.token.tolist() == ["BOGUS-X"]
        assert audit.status.tolist() == ["unrecognized"]
    else:
        assert audit.empty


def test_build_token_gate_accepts_packaged_partial_class_typing():
    from hitlist.builder import _validate_mhc_tokens

    audit = _validate_mhc_tokens(pd.DataFrame(), pd.DataFrame())
    assert audit.empty


# ── Engineering-drift audit (#586, #587 review) ────────────────────────────


def _eng_study(*arms):
    """One study whose arms all carry a condition block."""
    return {
        42: {
            "ms_samples": [
                {"condition_status": "annotated", "condition_evidence": "curated_text", **arm}
                for arm in arms
            ]
        }
    }


def test_engineering_drift_flags_a_silent_arm_beside_an_asserting_sibling():
    from hitlist.qc import engineering_drift_audit

    found = engineering_drift_audit(
        _eng_study(
            {"condition_id": "engineered", "condition_mhc_context": "monoallelic"},
            {"condition_id": "silent"},
        )
    )
    assert list(found["condition_id"]) == ["silent"]
    row = found.iloc[0]
    assert row["column"] == "condition_mhc_context"
    assert row["asserted_by"] == "['engineered']"
    assert row["asserted_values"] == "['monoallelic']"
    assert row["tier_at_risk"] and row["severity"] == "error"


@pytest.mark.parametrize("column", ["condition_knockout_genes", "condition_transduction"])
def test_engineering_drift_covers_the_whole_block_not_just_mhc_context(column):
    """A dropped knockout costs the same tier as a dropped MHC context."""
    from hitlist.qc import engineering_drift_audit

    found = engineering_drift_audit(
        _eng_study({"condition_id": "a", column: "B2M"}, {"condition_id": "b"})
    )
    assert list(found["column"]) == [column]


def test_engineering_drift_accepts_none_as_a_claim_of_absence():
    """``none`` is the documented remedy, so a curated wild-type arm passes."""
    from hitlist.qc import engineering_drift_audit

    assert engineering_drift_audit(
        _eng_study(
            {"condition_id": "ko", "condition_knockout_genes": "B2M"},
            {"condition_id": "wt", "condition_knockout_genes": "none"},
        )
    ).empty


def test_engineering_drift_ignores_two_arms_that_both_assert():
    """``B2M`` beside ``B2M;TAP1`` is the experiment: both resolve at tier 2."""
    from hitlist.qc import engineering_drift_audit

    assert engineering_drift_audit(
        _eng_study(
            {"condition_id": "a", "condition_knockout_genes": "B2M"},
            {"condition_id": "b", "condition_knockout_genes": "B2M;TAP1"},
        )
    ).empty


def test_engineering_drift_exempts_an_unreported_arm():
    """``unreported`` is the module's way to say nothing was recorded."""
    from hitlist.qc import engineering_drift_audit

    assert engineering_drift_audit(
        _eng_study(
            {"condition_id": "a", "condition_mhc_context": "monoallelic"},
            {"condition_id": "b", "condition_status": "unreported"},
        )
    ).empty


def test_engineering_drift_does_not_compare_different_materials():
    from hitlist.qc import engineering_drift_audit

    assert engineering_drift_audit(
        _eng_study(
            {"condition_id": "a", "condition_mhc_context": "monoallelic", "sample_group": "line1"},
            {"condition_id": "b", "sample_group": "line2"},
        )
    ).empty


def test_engineering_drift_compares_a_genotype_as_an_unordered_set():
    """A different write order is not a different material."""
    from hitlist.qc import engineering_drift_audit

    found = engineering_drift_audit(
        _eng_study(
            {
                "condition_id": "a",
                "mhc_genotype": "HLA-A*01:01 HLA-B*07:02",
                "condition_mhc_context": "monoallelic",
            },
            {"condition_id": "b", "mhc_genotype": "HLA-B*07:02 HLA-A*01:01"},
        )
    )
    assert list(found["condition_id"]) == ["b"]


def test_engineering_drift_reports_only_the_silent_arms():
    """A large group reports its drifting arms, not all of its members."""
    from hitlist.qc import engineering_drift_audit

    arms = [{"condition_id": f"ok{i}", "condition_mhc_context": "monoallelic"} for i in range(8)]
    arms.append({"condition_id": "drifted"})
    found = engineering_drift_audit(_eng_study(*arms))
    assert list(found["condition_id"]) == ["drifted"]
    assert found.iloc[0]["n_asserting_arms"] == 8


def test_engineering_drift_warns_without_a_tier_claim_when_another_column_engineers():
    """The message must be true for every case it can fire on."""
    from hitlist.qc import engineering_drift_audit

    found = engineering_drift_audit(
        _eng_study(
            {
                "condition_id": "a",
                "condition_knockout_genes": "B2M",
                "condition_mhc_context": "monoallelic",
            },
            {"condition_id": "b", "condition_knockout_genes": "B2M"},
        )
    )
    row = found.iloc[0]
    assert not row["tier_at_risk"] and row["severity"] == "warn"
    assert "anchor is unaffected" in row["reason"]


def test_engineering_drift_skips_a_study_that_curates_no_condition_block():
    from hitlist.qc import engineering_drift_audit

    assert engineering_drift_audit(
        {42: {"ms_samples": [{"sample_label": "a"}, {"sample_label": "b"}]}}
    ).empty


_ENGINEERING_DRIFT_BASELINE = (
    pathlib.Path(__file__).parent / "data" / "engineering_drift_baseline.yaml"
)


def _baseline_entries():
    doc = yaml.safe_load(_ENGINEERING_DRIFT_BASELINE.read_text()) or {}
    return {(int(pmid), entry) for pmid, entries in doc.items() for entry in entries}


def test_engineering_drift_the_586_studies_are_clean():
    """The studies this audit was written for must carry no drift at all."""
    from hitlist.qc import engineering_drift_audit

    found = engineering_drift_audit()
    for pmid in (26768311, 23543059):
        assert found[found["pmid"] == pmid].empty, f"PMID {pmid} regressed"


@pytest.mark.parametrize(
    ("pmid", "condition_id", "column"),
    [
        (27371725, "wt_bmdc_classical_h2_kb_h2_db", "condition_knockout_genes"),
        (27371725, "wt_bmdc_non_classical_h2_q1_q2", "condition_knockout_genes"),
        (30573663, "mouse_splenocytes_wt", "condition_knockout_genes"),
        (31092671, "721_221_b_51_01_wildtype", "condition_knockout_genes"),
        (32161166, "hela_abc_ko_hla_b_51_01_control_shrna", "condition_knockdown_genes"),
        (36215666, "hela_ciita_control_sirna", "condition_knockdown_genes"),
        (36215666, "hela_ciita_mock", "condition_knockdown_genes"),
    ],
)
def test_source_backed_controls_explicitly_exclude_sibling_perturbation(pmid, condition_id, column):
    """WT, mock and non-targeting controls assert absence on the named axis (#593)."""
    from hitlist.curation import load_pmid_overrides

    arms = {arm["condition_id"]: arm for arm in load_pmid_overrides()[pmid]["ms_samples"]}
    assert arms[condition_id][column] == "none"


@pytest.mark.parametrize("n_dropped", [1, 3, 5])
def test_engineering_drift_catches_a_partial_586_regression(n_dropped):
    """One blanked arm is already the defect: the engineered flag is per arm.

    The first cut of this rule disabled a group at the first intra-level
    disagreement, so dropping four of five passed silently (#587 review).
    """
    from copy import deepcopy

    from hitlist.curation import load_pmid_overrides
    from hitlist.qc import engineering_drift_audit

    study = deepcopy(load_pmid_overrides()[26768311])
    dropped = 0
    for arm in study["ms_samples"]:
        if "vaccinia" in arm["sample_label"] and dropped < n_dropped:
            del arm["condition_mhc_context"]
            dropped += 1
    assert dropped == n_dropped
    found = engineering_drift_audit({26768311: study})
    assert len(found) == n_dropped
    assert set(found["column"]) == {"condition_mhc_context"}


def test_engineering_drift_matches_its_recorded_baseline():
    """Equality, so neither a new finding nor a stale exemption survives.

    The audit is deliberately off the load path (#587 review): a false positive
    here fails CI for whoever makes the edit instead of making the installed
    package unimportable for every consumer.
    """
    from hitlist.qc import engineering_drift_audit

    found = {
        (int(r.pmid), f"{r.condition_id}|{r.column}|{r.severity}")
        for r in engineering_drift_audit().itertuples()
    }
    baseline = _baseline_entries()
    assert found - baseline == set(), f"new engineering drift: {sorted(found - baseline)}"
    assert baseline - found == set(), (
        f"baseline entries no longer found: {sorted(baseline - found)}"
    )


def test_engineering_drift_ignores_a_capture_only_asserting_sibling():
    """A sibling asserting only ``soluble_mhc`` is not engineered either.

    Nothing engineers on either side, so no expression tier differs and there
    is no engineering drift to report — grading it ``error`` with a tier claim
    was false (#587 review 3, PMID 27862975).
    """
    from hitlist.qc import engineering_drift_audit

    assert engineering_drift_audit(
        _eng_study(
            {"condition_id": "captured", "condition_mhc_context": "soluble_mhc"},
            {"condition_id": "silent"},
        )
    ).empty


def test_engineering_drift_exempts_a_mixed_arm():
    """``mixed`` fills only facts true of every contributing condition.

    A blank there is the contract being honoured, so flagging it would fail CI
    for a PR that curated correctly (#587 review 3).
    """
    from hitlist.qc import engineering_drift_audit

    assert engineering_drift_audit(
        _eng_study(
            {"condition_id": "a", "condition_mhc_context": "monoallelic"},
            {"condition_id": "b", "condition_status": "mixed"},
        )
    ).empty


def test_engineering_drift_skips_ms_excluded_studies(monkeypatch):
    """Their arms reach zero observation rows, so no anchor is ever resolved."""
    from hitlist import qc

    study = _eng_study(
        {"condition_id": "a", "condition_mhc_context": "monoallelic"},
        {"condition_id": "b"},
    )
    assert not qc.engineering_drift_audit(study).empty
    monkeypatch.setattr(qc, "ms_excluded_pmids", lambda: frozenset({42}))
    assert qc.engineering_drift_audit(study).empty


def test_engineering_drift_never_joins_distinct_cells_with_a_semicolon():
    """``;`` separates tokens *within* a cell, so joining cells invents one.

    PMID 31092671 reported ``ERAP1;ERAP1;ERAP2;ERAP2`` for three distinct arms;
    a curator pasting that verbatim would pass validation and curate a
    combination nobody performed (#587 review 3).
    """
    from hitlist.qc import engineering_drift_audit

    found = engineering_drift_audit(
        _eng_study(
            {"condition_id": "a", "condition_knockout_genes": "ERAP1"},
            {"condition_id": "b", "condition_knockout_genes": "ERAP2"},
            {"condition_id": "c"},
        )
    )
    assert list(found["condition_id"]) == ["c"]
    values = found.iloc[0]["asserted_values"]
    assert values == "['ERAP1', 'ERAP2']"
    assert "ERAP1;ERAP2" not in values


def test_engineering_drift_only_prescribes_a_remedy_the_loader_accepts():
    """Every remedy must be something a curator can actually write.

    Three times in #587 a rule shipped whose remedy or scope broke something;
    the third was prescribing ``none`` for ``condition_mhc_context``, the one
    engineering column ``NONE_PERMITTED_CONDITION_COLUMNS`` excludes — a
    curator following it would stop the package loading.  This asserts the
    property over every finding in the packaged corpus rather than the one
    column that happened to be wrong.
    """
    from hitlist.conditions import NONE_PERMITTED_CONDITION_COLUMNS
    from hitlist.qc import engineering_drift_audit

    found = engineering_drift_audit()
    assert not found.empty, "the corpus must exercise this"
    offered_none = found[found["reason"].str.contains("or 'none' if")]
    bad = set(offered_none["column"]) - set(NONE_PERMITTED_CONDITION_COLUMNS)
    assert not bad, f"remedy prescribes 'none' where the loader rejects it: {sorted(bad)}"
    for column in set(found["column"]) - set(NONE_PERMITTED_CONDITION_COLUMNS):
        text = found[found["column"] == column].iloc[0]["reason"]
        assert f"'none' is NOT permitted in {column}" in text


def test_engineering_drift_baseline_entries_carry_a_severity():
    """Severity is part of the key: a ``warn`` becoming an ``error`` is drift."""
    for _pmid, entry in _baseline_entries():
        assert len(entry.split("|")) == 3, entry
        assert entry.rsplit("|", 1)[1] in {"warn", "error"}


def _loads_cleanly(tmp_path, monkeypatch, arms):
    """Run synthetic arms through the real loader; True when it accepts them."""
    from hitlist import curation

    path = tmp_path / "pmid_overrides.yaml"
    path.write_text(yaml.safe_dump([{"pmid": 42, "ms_samples": arms}]))
    real = curation._data_path
    monkeypatch.setattr(
        curation,
        "_data_path",
        lambda fn: str(path) if fn == "pmid_overrides.yaml" else real(fn),
    )
    curation.load_pmid_overrides.cache_clear()
    try:
        curation.load_pmid_overrides()
        return True
    except ValueError:
        return False
    finally:
        curation.load_pmid_overrides.cache_clear()


@pytest.mark.parametrize("column", _NONE_PERMITTED_ENGINEERING_COLUMNS)
def test_the_none_remedy_actually_loads(tmp_path, monkeypatch, column):
    """Writing the prescribed ``none`` must not break the package.

    The remedy is only honest if the loader accepts it, and this is the trap
    #587 hit three times in different forms.
    """
    arms = [
        {
            "sample_label": "engineered",
            "condition_id": "engineered",
            "condition_status": "annotated",
            "condition_evidence": "curated_text",
            column: "B2M" if "genes" in column else "unspecified",
        },
        {
            "sample_label": "wt",
            "condition_id": "wt",
            "condition_status": "annotated",
            "condition_evidence": "curated_text",
            column: "none",
        },
    ]
    assert _loads_cleanly(tmp_path, monkeypatch, arms)


def test_the_separate_materials_remedy_actually_loads(tmp_path, monkeypatch):
    """The mhc_genotype trio must load, and the message must not over-promise.

    ``mhc_genotype_cell`` alone is rejected, and ``sample_group`` cannot split a
    two-arm study at all — the message says both rather than naming a remedy
    that fails.
    """
    from hitlist.qc import _engineering_remedy

    def arm(cid, **extra):
        return {
            "sample_label": cid,
            "condition_id": cid,
            "condition_status": "annotated",
            "condition_evidence": "curated_text",
            **extra,
        }

    trio = [
        arm(
            "a",
            mhc_genotype="HLA-A*02:01",
            mhc_genotype_cell="C1R",
            mhc_genotype_source="PMID 1 Methods",
            condition_mhc_context="monoallelic",
        ),
        arm(
            "b",
            mhc_genotype="HLA-B*07:02",
            mhc_genotype_cell="C1R-A2",
            mhc_genotype_source="PMID 1 Methods",
        ),
    ]
    assert _loads_cleanly(tmp_path, monkeypatch, trio)
    assert not _loads_cleanly(
        tmp_path, monkeypatch, [arm("a", mhc_genotype_cell="C1R"), arm("b")]
    ), "mhc_genotype_cell alone is rejected, so the message must not prescribe it alone"
    assert not _loads_cleanly(
        tmp_path, monkeypatch, [arm("a", sample_group="g1"), arm("b", sample_group="g2")]
    ), "a one-to-one sample_group is rejected, so the message must say so"

    text = _engineering_remedy("condition_mhc_context")
    assert "mhc_genotype_source" in text and "all three are required" in text
    assert "must be set on every arm" in text and "two-arm study" in text
