"""Exercise test.sh resource decisions without launching pytest recursively."""

import os
import subprocess
from pathlib import Path

import pytest

SCRIPT = Path(__file__).resolve().parents[1] / "test.sh"


def _stub_env(
    tmp_path, n_free_pages, n_speculative_pages, probe_fails, worker_min, worker_max, **extra_env
):
    stubs = {
        "uname": "echo Darwin",
        "getconf": "echo 16",
        "sysctl": "exit 1" if probe_fails else "echo 16384",
        "vm_stat": (
            f"echo 'Pages free: {n_free_pages}.'\n"
            "echo 'Pages inactive: 2000000.'\n"
            f"echo 'Pages speculative: {n_speculative_pages}.'"
        ),
        "python": 'if [ "$1" = "-c" ]; then exit 0; fi\nprintf "%s\\n" "$@"',
        # A different interpreter's pytest must never be selected from PATH.
        "pytest": "exit 99",
    }
    for name, body in stubs.items():
        executable = tmp_path / name
        executable.write_text(f"#!/bin/sh\n{body}\n")
        executable.chmod(0o755)

    return dict(
        os.environ,
        PATH=f"{tmp_path}{os.pathsep}{os.environ['PATH']}",
        PER_WORKER_GB="2.5",
        INTEGRATION_PER_WORKER_GB="5",
        # Stubbed pytest calls test scheduling, not OS resource accounting.
        TEST_SH_PROFILE="0",
        TEST_SH_MIN=str(worker_min),
        TEST_SH_MAX=str(worker_max),
        **extra_env,
    )


def _split_invocations(args):
    """Split one process's flattened stdout back into per-invocation arg lists.

    Each invocation starts with ``-m pytest``, with optional xdist flags.
    The marker expression's ``-m`` is never followed by ``pytest``.
    """
    starts = [i for i in range(len(args) - 2) if args[i : i + 2] == ["-m", "pytest"]]
    assert starts == sorted(starts) and starts and starts[0] == 0, args
    bounds = [*starts, len(args)]
    return [args[bounds[i] : bounds[i + 1]] for i in range(len(starts))]


def _marker(invocation):
    # Skip the Python module flag; the next -m belongs to pytest.
    for i in range(2, len(invocation) - 1):
        if invocation[i] == "-m":
            return invocation[i + 1]
    return None


@pytest.mark.parametrize(
    (
        "n_free_pages",
        "n_speculative_pages",
        "probe_fails",
        "worker_min",
        "worker_max",
        "expected_light",
        "expected_integration",
    ),
    [
        (100_000, 400_000, False, 1, 0, 3, 1),
        # Enough real memory backs the final (post TEST_SH_MIN-floor,
        # TEST_SH_MAX-ceiling) worker count in both passes here -- unlike an
        # earlier version of this case (10_000 speculative pages), which
        # relied on TEST_SH_MAX clamping 10 back down to 2 while only ever
        # having memory for 3-4, and now correctly aborts instead (#483).
        (100_000, 700_000, False, 10, 2, 2, 2),
    ],
)
def test_all_runs_two_passes_with_independent_worker_budgets(
    tmp_path,
    n_free_pages,
    n_speculative_pages,
    probe_fails,
    worker_min,
    worker_max,
    expected_light,
    expected_integration,
):
    """``--all`` must run non-integration and integration tests as two
    separate pytest processes (#483), each re-probing available memory and
    sizing workers off its own per-worker budget."""
    env = _stub_env(
        tmp_path, n_free_pages, n_speculative_pages, probe_fails, worker_min, worker_max
    )
    result = subprocess.run(["bash", str(SCRIPT), "--all"], env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    args = result.stdout.splitlines()
    assert "--all" not in args

    light, integration = _split_invocations(args)

    assert light[:4] == ["-m", "pytest", "-n", str(expected_light)]
    assert _marker(light) == "not integration"
    assert "--cov=hitlist/" in light
    assert "-vv" not in light
    assert "--cov-append" not in light
    assert "--cov-report=term-missing" not in light

    assert integration[:4] == ["-m", "pytest", "-n", str(expected_integration)]
    assert _marker(integration) == "integration"
    assert "--cov=hitlist/" in integration
    assert "-vv" in integration
    assert "--cov-append" in integration
    assert "--cov-report=term-missing" in integration


def test_default_invocation_is_a_single_non_integration_pass(tmp_path):
    """Without ``--all``, test.sh must stay a single pytest process (the
    common local/dev-loop case) filtered to non-integration tests."""
    env = _stub_env(tmp_path, 100_000, 400_000, probe_fails=False, worker_min=1, worker_max=0)
    result = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    args = result.stdout.splitlines()

    invocations = _split_invocations(args)
    assert len(invocations) == 1
    (invocation,) = invocations

    assert invocation[:4] == ["-m", "pytest", "-n", "3"]
    assert _marker(invocation) == "not integration"
    assert "--cov=hitlist/" in invocation
    assert "--cov-report=term-missing" in invocation
    assert "--cov-append" not in invocation


def test_default_macos_budget_covers_compressed_full_corpus_footprint(tmp_path):
    env = _stub_env(tmp_path, 1_300_000, 0, False, 1, 1)
    del env["INTEGRATION_PER_WORKER_GB"]
    result = subprocess.run(["bash", str(SCRIPT), "--all"], env=env, capture_output=True, text=True)
    assert result.returncode == 1
    assert "need ~24.0GB" in result.stderr
    assert [_marker(call) for call in _split_invocations(result.stdout.splitlines())] == [
        "not integration"
    ]


def test_aborts_with_a_clear_message_when_memory_cant_cover_even_one_worker(tmp_path):
    """#483: when available memory can't cover TEST_SH_MIN workers at the
    pass's own per-worker budget, test.sh must refuse to start and say why,
    rather than silently forcing TEST_SH_MIN and letting the OS SIGKILL
    pytest later with no useful signal."""
    env = _stub_env(tmp_path, 50_000, 50_000, probe_fails=False, worker_min=1, worker_max=0)
    result = subprocess.run(["bash", str(SCRIPT), "--all"], env=env, capture_output=True, text=True)
    assert result.returncode == 1
    assert result.stdout == ""
    assert "only 1.5" in result.stderr
    assert "need ~2.5GB for 1 worker(s)" in result.stderr
    assert "lower TEST_SH_MIN" in result.stderr


def test_light_pass_runs_but_integration_pass_aborts_on_its_own_higher_budget(tmp_path):
    """The two passes must be gated independently: enough memory for the
    light pass's 2.5GB/worker budget but not the integration pass's
    5GB/worker budget must run the light pass and abort before the second."""
    env = _stub_env(tmp_path, 150_000, 50_000, probe_fails=False, worker_min=1, worker_max=0)
    result = subprocess.run(["bash", str(SCRIPT), "--all"], env=env, capture_output=True, text=True)
    assert result.returncode == 1
    args = result.stdout.splitlines()
    (light,) = _split_invocations(args)
    assert _marker(light) == "not integration"
    assert "only 3.0" in result.stderr
    assert "need ~5.0GB" in result.stderr


@pytest.mark.parametrize("retry", [False, True])
def test_probe_unavailable_refuses_to_start_pytest(tmp_path, retry):
    env = _stub_env(tmp_path, 100, 100, probe_fails=True, worker_min=1, worker_max=0)
    (tmp_path / "sleep").write_text("#!/bin/sh\nexit 99\n")
    (tmp_path / "sleep").chmod(0o755)
    args = ["bash", str(SCRIPT), *(["--retry-memory"] if retry else [])]
    result = subprocess.run(args, env=env, capture_output=True, text=True)
    assert result.returncode == 2
    assert result.stdout == ""
    assert "probe unavailable" in result.stderr
    assert "TEST_SH_ALLOW_UNKNOWN_MEMORY=1" in result.stderr
    assert "retrying once" not in result.stderr


@pytest.mark.parametrize("has_xdist", [False, True])
@pytest.mark.parametrize("allow_unknown", ["0", "1"])
def test_zero_worker_floor_cannot_bypass_measured_low_capacity(tmp_path, has_xdist, allow_unknown):
    env = _stub_env(tmp_path, 0, 0, False, 0, 0, TEST_SH_ALLOW_UNKNOWN_MEMORY=allow_unknown)
    if not has_xdist:
        (tmp_path / "python").write_text(
            '#!/bin/sh\nif [ "$1" = "-c" ]; then exit 1; fi\nprintf "%s\\n" "$@"\n'
        )
    result = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True)
    assert result.returncode == 1
    assert result.stdout == ""
    assert "need ~2.5GB for 1 worker(s)" in result.stderr


def test_unknown_memory_requires_explicit_optin_and_one_worker(tmp_path):
    env = _stub_env(tmp_path, 100, 100, True, 8, 0, TEST_SH_ALLOW_UNKNOWN_MEMORY="1")
    result = subprocess.run(["bash", str(SCRIPT), "--all"], env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert "probe unavailable" in result.stderr
    assert "explicit opt-in" in result.stderr
    assert all(
        call[:4] == ["-m", "pytest", "-n", "1"]
        for call in _split_invocations(result.stdout.splitlines())
    )


@pytest.mark.parametrize("vm_stat_body", ["exit 1", "echo garbled", "echo 'Pages free: bogus.'"])
def test_failed_or_malformed_vm_stat_is_a_probe_failure(tmp_path, vm_stat_body):
    env = _stub_env(tmp_path, 600_000, 0, False, 1, 1)
    (tmp_path / "vm_stat").write_text(f"#!/bin/sh\n{vm_stat_body}\n")
    result = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True)
    assert result.returncode == 2
    assert not result.stdout
    assert "probe unavailable" in result.stderr


def test_losing_probe_after_light_phase_never_starts_integration(tmp_path):
    env = _retry_env(tmp_path, has_xdist=True)
    _memory_sequence(tmp_path, [600_000])
    result = subprocess.run(
        ["bash", str(SCRIPT), "--all", "--retry-memory"], env=env, capture_output=True, text=True
    )
    assert result.returncode == 2
    assert [_marker(call) for call in _split_invocations(result.stdout.splitlines())] == [
        "not integration"
    ]


def test_extra_args_are_forwarded_to_every_pass(tmp_path):
    """Args after --all/other flags (e.g. a -k filter) must reach pytest in
    both passes, not just the first."""
    env = _stub_env(tmp_path, 100_000, 400_000, probe_fails=False, worker_min=1, worker_max=0)
    result = subprocess.run(
        ["bash", str(SCRIPT), "--all", "-k", "foo"], env=env, capture_output=True, text=True
    )
    assert result.returncode == 0, result.stderr
    args = result.stdout.splitlines()

    light, integration = _split_invocations(args)
    assert "-k" in light and "foo" in light
    assert "-k" in integration and "foo" in integration


def _memory_sequence(tmp_path, pages):
    counter = tmp_path / "memory_probes"
    cases = "\n".join(f"{i}) pages={value} ;;" for i, value in enumerate(pages, 1))
    (tmp_path / "vm_stat").write_text(
        "#!/bin/sh\n"
        f'n=$(( $(cat "{counter}" 2>/dev/null || echo 0) + 1 ))\n'
        f'echo "$n" > "{counter}"\n'
        f'case "$n" in\n{cases}\n*) exit 97 ;;\nesac\n'
        'echo "Pages free: $pages."\n'
        "echo 'Pages speculative: 0.'\n"
    )
    return counter


def _retry_env(tmp_path, has_xdist):
    env = _stub_env(tmp_path, 600_000, 0, False, 1, 1, TEST_SH_MEMORY_RETRY_DELAY_SECONDS="0")
    if not has_xdist:
        (tmp_path / "python").write_text(
            '#!/bin/sh\nif [ "$1" = "-c" ]; then exit 1; fi\nprintf "%s\\n" "$@"\n'
        )
    return env


@pytest.mark.parametrize("has_xdist", [False, True])
def test_recovered_integration_preflight_never_replays_regular_tests(tmp_path, has_xdist):
    env = _retry_env(tmp_path, has_xdist)
    probes = _memory_sequence(tmp_path, [600_000, 100_000, 600_000])
    result = subprocess.run(
        ["bash", str(SCRIPT), "--all", "--retry-memory"],
        env=env,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert probes.read_text().strip() == "3"
    invocations = _split_invocations(result.stdout.splitlines())
    assert [_marker(call) for call in invocations] == ["not integration", "integration"]
    assert "--retry-memory" not in result.stdout
    assert ("-n" in invocations[0]) == has_xdist


@pytest.mark.parametrize("has_xdist", [False, True])
def test_exhausted_integration_preflight_aborts_without_replaying_regular(tmp_path, has_xdist):
    env = _retry_env(tmp_path, has_xdist)
    probes = _memory_sequence(tmp_path, [600_000, 100_000, 100_000])
    result = subprocess.run(
        ["bash", str(SCRIPT), "--all", "--retry-memory"],
        env=env,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 1
    assert probes.read_text().strip() == "3"
    assert [_marker(call) for call in _split_invocations(result.stdout.splitlines())] == [
        "not integration"
    ]


@pytest.mark.parametrize("has_xdist", [False, True])
def test_first_phase_can_recover_and_new_invocation_runs_both_phases(tmp_path, has_xdist):
    env = _retry_env(tmp_path, has_xdist)
    probes = _memory_sequence(tmp_path, [100_000, 600_000, 600_000, 600_000, 600_000])
    for _ in range(2):
        result = subprocess.run(
            ["bash", str(SCRIPT), "--all", "--retry-memory"],
            env=env,
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr
        assert [_marker(call) for call in _split_invocations(result.stdout.splitlines())] == [
            "not integration",
            "integration",
        ]
    assert probes.read_text().strip() == "5"


@pytest.mark.parametrize("failed_marker", ["not integration", "integration"])
@pytest.mark.parametrize("exit_code", [42, 143])
def test_real_pytest_failure_is_not_retried(tmp_path, failed_marker, exit_code):
    env = _retry_env(tmp_path, has_xdist=True)
    (tmp_path / "python").write_text(
        '#!/bin/sh\nif [ "$1" = "-c" ]; then exit 0; fi\nprintf "%s\\n" "$@"\n'
        f'for arg in "$@"; do [ "$arg" = "{failed_marker}" ] && exit {exit_code}; done\n'
        "exit 0\n"
    )
    result = subprocess.run(
        ["bash", str(SCRIPT), "--all", "--retry-memory"],
        env=env,
        capture_output=True,
        text=True,
    )
    assert result.returncode == exit_code
    markers = [_marker(call) for call in _split_invocations(result.stdout.splitlines())]
    expected = ["not integration"]
    if failed_marker == "integration":
        expected.append("integration")
    assert markers == expected


def test_serial_fallback_obeys_memory_guard_without_retry_optin(tmp_path):
    env = _retry_env(tmp_path, has_xdist=False)
    _memory_sequence(tmp_path, [100_000])
    result = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True)
    assert result.returncode == 1
    assert not result.stdout
    assert "need ~2.5GB for 1 worker(s)" in result.stderr
