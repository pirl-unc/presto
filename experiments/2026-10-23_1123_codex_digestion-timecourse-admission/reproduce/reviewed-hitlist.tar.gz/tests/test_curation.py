import re

import pytest

from hitlist.curation import (
    ALLELE_RESOLUTION_FLOORS,
    ALLELE_RESOLUTION_ORDER,
    _is_resolved_allele,
    allele_resolution_rank,
    allele_to_all_serotypes,
    allele_to_serotype,
    best_4digit_for_serotype,
    classify_allele_resolution,
    classify_mhc_species,
    classify_ms_row,
    detect_monoallelic,
    expand_allele_set,
    is_binding_assay,
    is_cancer_specific,
    load_monoallelic_lines,
    load_pmid_overrides,
    load_tissue_categories,
    normalize_allele,
    normalize_species,
    serotype_to_alleles,
)


def test_load_pmid_overrides():
    overrides = load_pmid_overrides()
    assert len(overrides) >= 10
    assert 33858848 in overrides
    assert overrides[33858848]["override"] == "healthy"


def test_load_tissue_categories():
    cats = load_tissue_categories()
    assert "testis" in cats["reproductive"]
    assert "thymus" in cats["thymus"]
    # Sex-stratified medium reproductive tiers (#286).
    assert "breast" in cats["reproductive_female"]
    assert "ovary" in cats["reproductive_female"]
    assert "prostate" in cats["reproductive_male"]
    # Privileged tier stays sex-agnostic; medium tissues are NOT in it.
    assert "breast" not in cats["reproductive"]
    assert "prostate" not in cats["reproductive"]


def test_cell_line_is_cancer():
    flags = classify_ms_row("No immunization", "healthy", "Cell Line / Clone", "Blood", "HeLa")
    assert flags["src_cancer"] is True
    assert flags["src_healthy_tissue"] is False
    assert flags["cell_line_name"] == "HeLa"


def test_cell_type_split_hybrid():
    """#261: a hybrid ``<line>-<cell_type>`` Cell Name is split into a clean
    line name plus a separate cell_type."""
    flags = classify_ms_row(
        "", "", "Cell Line / Clone", cell_name="K562-Myeloid cell", mhc_restriction="HLA-A*02:01"
    )
    assert flags["cell_line_name"] == "K562"
    # K562's lineage is curated as Myeloblast (CML blast phase) in the registry,
    # which overrides IEDB's coarse "Myeloid cell" suffix.
    assert flags["cell_type"] == "Myeloblast"


def test_cell_type_pure_type_is_not_a_line():
    """A pure cell-type Cell Name (primary-cell sample) yields cell_type but
    no cell_line_name."""
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", cell_name="B cell")
    assert flags["src_cell_line"] is False
    assert flags["cell_line_name"] == ""
    assert flags["cell_type"] == "B-cell"  # normalized to the hyphenated house style


def test_cell_type_unknown_line_keeps_identifier():
    """A cell-line row whose line isn't in the registry must keep its raw
    identifier (no empty cell_line_name regression for #260 counting)."""
    flags = classify_ms_row("", "", "Cell Line / Clone", cell_name="LCL1")
    assert flags["cell_line_name"] == "LCL1"
    assert flags["cell_type"] == ""


def test_ebv_lcl_not_cancer():
    flags = classify_ms_row(
        "No immunization", "healthy", "Cell Line / Clone (EBV transformed, B-LCL)", cell_name="LCL1"
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True


# ── Registry-driven correction (no PMID override; cell_name alone resolves
# to a known line, and the registry's is_cancer/is_ebv_lcl verdict wins over
# both IEDB's raw Culture Condition tag and the generic default heuristic) ──


def test_raji_is_cancer_even_when_iedb_tags_it_ebv_lcl():
    """Raji (Burkitt lymphoma, CVCL_0511) is EBV-genome-positive, so IEDB
    sometimes tags it with the generic "(EBV transformed, B-LCL)" Culture
    Condition -- but it is the malignancy itself, not an EBV-immortalized
    surrogate host, and the registry says so (is_cancer=true,
    is_ebv_lcl=false). No PMID override needed: the cell name alone
    resolves. Regression pin for hitlist#480 (PMID 38480730's Raji rows
    were previously src_cancer=False)."""
    flags = classify_ms_row(
        "No immunization",
        "Burkitt's lymphoma",
        "Cell Line / Clone (EBV transformed, B-LCL)",
        "Blood",
        "Raji",
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is True


def test_jy_is_not_cancer_without_any_pmid_override():
    """JY is a registered EBV-LCL reference host (registry: is_cancer=false,
    is_ebv_lcl=true) immortalized from an unrelated normal donor, distinct
    from a patient tumor line. Previously this only resolved correctly via
    the mono-allelic-host special case or a per-PMID override; a plain "JY"
    cell name with a generic "Cell Line / Clone" tag and no override used to
    default to src_cancer=True."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Lymphoid", "JY cells-B cell"
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True


def test_thp1_is_cancer_even_when_iedb_omits_the_cell_line_tag():
    """THP-1 (acute monocytic leukemia, CVCL_0006) plainly names a
    registered cancer line, but this row's raw Culture Condition doesn't
    match either "Cell Line / Clone" variant -- the registry corrects
    src_cell_line/src_cancer regardless."""
    flags = classify_ms_row("No immunization", "", "", "Blood", "THP-1-Monocyte")
    assert flags["src_cancer"] is True
    assert flags["src_cell_line"] is True
    assert flags["src_ebv_lcl"] is False


def test_hek293t_is_not_cancer():
    """HEK293T is SV40-transformed embryonic kidney -- immortalized, not
    malignant (registry: is_cancer=false, is_ebv_lcl=false). Neither the
    is_ebv_lcl-based default heuristic nor a "cell_line" PMID override can
    express this combination without consulting the registry directly."""
    flags = classify_ms_row("No immunization", "healthy", "Cell Line / Clone", "Kidney", "293-T")
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is True


def test_expi293f_is_not_cancer():
    """Expi293F (a suspension-adapted HEK293 derivative used as a
    transfection/production workhorse) is not malignant."""
    flags = classify_ms_row("No immunization", "healthy", "Cell Line / Clone", "Kidney", "Expi293F")
    assert flags["src_cancer"] is False


def test_healthy_somatic():
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", "Liver")
    assert flags["src_healthy_tissue"] is True
    assert flags["src_cancer"] is False


def test_healthy_thymus():
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", "Thymus")
    assert flags["src_healthy_thymus"] is True
    assert flags["src_healthy_tissue"] is False


def test_healthy_reproductive():
    # Testis is immune-privileged → CTA-safe regardless of patient sex, so it
    # lands in the privileged tier and NOT the sex-stratified male tier.
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", "Testis")
    assert flags["src_healthy_reproductive"] is True
    assert flags["src_healthy_reproductive_female"] is False
    assert flags["src_healthy_reproductive_male"] is False
    assert flags["src_healthy_tissue"] is False


def test_healthy_reproductive_female_breast():
    """Issue #286: healthy ex-vivo breast is a sex-stratified female-reproductive
    tissue, NOT a somatic safety signal (src_healthy_tissue)."""
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", "Breast")
    assert flags["src_healthy_reproductive_female"] is True
    assert flags["src_healthy_tissue"] is False
    assert flags["src_healthy_reproductive"] is False
    assert flags["src_healthy_reproductive_male"] is False


def test_healthy_reproductive_male_prostate():
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", "Prostate")
    assert flags["src_healthy_reproductive_male"] is True
    assert flags["src_healthy_tissue"] is False
    assert flags["src_healthy_reproductive"] is False
    assert flags["src_healthy_reproductive_female"] is False


def test_pmid_28871256_bls_lcl_not_cancer():
    """#33c/#36 batch 9: Scholz 2017 BLS EBV-LCL DR transfectants are tagged
    "B cell" / "Cell Line / Clone" by IEDB (no EBV flag), which would default to
    src_cancer. The ebv_lcl override must clear the false cancer flag."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "B cell", pmid=28871256
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True


def test_pmid_21654843_dr8_lcl_not_cancer():
    """#33c/#36 batch 9: Muixí 2011 DR8-homozygous EBV-LCL, same mislabel."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "B cell", pmid=21654843
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True


def test_pmid_27503676_gr_lcl_not_cancer():
    """#33c/#36 batch 10: Marcilla 2017 GR EBV-LCL (A*01:01/A*03:01/B*07:02/
    B*27:05/C*02:02/C*07:02; Cellosaurus CVCL_C5VZ) tagged "B cell" / "Cell Line
    / Clone" by IEDB (no EBV flag), which would default to src_cancer. The
    ebv_lcl override must clear the false cancer flag.  (Line was mis-named "JY"
    in the original draft; GR is the correct line per PRIDE PXD004233.)"""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "B cell", pmid=27503676
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True


def test_pmid_18512783_ben_dr10_lcl_not_cancer():
    """#33c/#36 batch 10: Alvarez 2008 BEN-DR10 EBV-LCL, same mislabel."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "B cell", pmid=18512783
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True


def test_pmid_18507432_lg2_lcl_not_cancer():
    """#33c/#36 batch 11: Strug 2008 LG2 EBV-LCL (DR1) tagged "B cell" / "Cell
    Line / Clone" by IEDB (no EBV flag), which would default to src_cancer. The
    ebv_lcl override must clear the false cancer flag — including the
    vaccinia-MVA-infected arm, which is still the LG2 EBV-LCL host."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "B cell", pmid=18507432
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True
    # the vaccinia-exposed arm must also be EBV-LCL, not cancer
    infected = classify_ms_row(
        "Exposure without evidence for disease",
        "",
        "Cell Line / Clone",
        "Blood",
        "B cell",
        pmid=18507432,
    )
    assert infected["src_cancer"] is False
    assert infected["src_ebv_lcl"] is True


def test_pmid_23739916_bls_lcl_not_cancer():
    """#33c/#36 batch 11: Wang/Sospedra 2013 BLS DR15 transfectants, same BLS
    EBV-LCL system as Scholz 2017 (batch 9); same mislabel."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "B cell", pmid=23739916
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True


def test_pmid_23328677_raji_is_cancer_not_ebv_lcl():
    """#33c/#36 batch 12: Raji is an EBV-genome+ but MALIGNANT Burkitt lymphoma
    (CVCL_0511). The cell_line override must keep it src_cancer and must NOT
    force-fit it to ebv_lcl (it is not an EBV-immortalized normal B-LCL)."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "B cell", pmid=23328677
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is True


def test_pmid_29774024_t2_is_cancer_not_ebv_lcl():
    """#33c/#36 batch 12: T2 (CVCL_2211) is a cancer-derived TAP-deficient
    T-ALL x B-LCL hybrid; cell_line override keeps src_cancer, not ebv_lcl."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "T2 cells-Lymphoblast", pmid=29774024
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is True


def test_pmid_23555621_t2_is_cancer_not_ebv_lcl():
    """#33c/#36 batch 12: same T2 hybrid line, class I (A*02:01 / B*27:05)."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "T2 cells-Lymphoblast", pmid=23555621
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is True


def test_pmid_19615748_panc1_mcf7_are_cancer():
    """#33c/#36 batch 13: Antwi 2009 PANC-1 + MCF-7 carcinoma lines — cell_line
    override keeps src_cancer (genuine tumor lines), not ebv_lcl."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "Epithelial cell", pmid=19615748
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is True


def test_pmid_21136679_skhep1_is_cancer():
    """#33c/#36 batch 13: Alvarez 2007 SK-HEP-1 (endothelial-origin malignant
    line) — cell_line override keeps src_cancer."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "Endothelial cell", pmid=21136679
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is True


def test_pmid_29371260_sw480_is_cancer():
    """#33c/#36 batch 14: Miyamoto 2018 SW480 colon carcinoma (bulk + CSC
    subpopulation) — cell_line override keeps src_cancer, not ebv_lcl."""
    flags = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "Epithelial cell", pmid=29371260
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is True


def test_pmid_29930882_hct116_is_cancer():
    """#36: Gravett 2018 HCT 116 colon carcinoma (± gemcitabine) — cell_line
    override keeps src_cancer (genuine tumor line)."""
    flags = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        "Large Intestine",
        "HCT 116-Epithelial cell",
        pmid=29930882,
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is True


def test_noncancer_cell_line_override_is_cell_line_not_cancer():
    """#36: the noncancer_cell_line override marks a non-malignant immortalized
    line (hTERT/SV40-LT) as a cell line that is NOT cancer (and not healthy
    ex-vivo donor tissue, and not EBV-LCL)."""
    # ECN90 line arm (30078552): Culture Condition "Cell Line / Clone" rule.
    line = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        "Pancreas",
        "Pancreatic beta cell",
        pmid=30078552,
    )
    assert line["src_cancer"] is False
    assert line["src_cell_line"] is True
    assert line["src_ebv_lcl"] is False
    assert line["src_healthy_tissue"] is False


def test_pmid_30078552_primary_islet_arm_is_healthy():
    """#36: the Direct-Ex-Vivo primary-islet arm of the ECN90 study routes to
    healthy (non-cancer primary tissue), NOT the noncancer_cell_line arm."""
    islet = classify_ms_row(
        "No immunization", "", "Direct Ex Vivo", "Pancreas", "Pancreatic beta cell", pmid=30078552
    )
    assert islet["src_cancer"] is False
    assert islet["src_cell_line"] is False
    assert islet["src_healthy_tissue"] is True


def test_pmid_22299025_tcell_clones_not_cancer():
    """#36 mixed-cohort split: Costantino 2012 activated CD4+ T-cell clones are
    not a tumor (noncancer_cell_line); the B-LCL arm stays ebv_lcl."""
    tcell = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "T cell CD4+", pmid=22299025
    )
    assert tcell["src_cancer"] is False
    assert tcell["src_cell_line"] is True
    blcl = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone (EBV transformed, B-LCL)",
        "Blood",
        "B cell",
        pmid=22299025,
    )
    assert blcl["src_cancer"] is False
    assert blcl["src_ebv_lcl"] is True


def test_pmid_33731925_exvivo_melanoma_is_cancer_not_healthy():
    """#36 mixed-cohort split: Kalaora 2021 ex-vivo melanoma metastases carry a
    blank IEDB disease field and default to healthy_tissue — a FALSE safety
    signal. The cancer_patient override flips them to src_cancer. The APC arm
    routes to activated_apc; the EBV-LCL arm stays ebv_lcl."""
    tumor = classify_ms_row(
        "No immunization", "", "Direct Ex Vivo", "Skin", "Melanocyte", pmid=33731925
    )
    assert tumor["src_cancer"] is True
    assert tumor["src_healthy_tissue"] is False
    apc = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "Macrophage", pmid=33731925
    )
    assert apc["src_activated_apc"] is True
    assert apc["src_cancer"] is False


def test_pmid_31291378_aml_lines_tagged_cell_line():
    """#36 mixed-cohort split: Narayan 2019 AML — primary blasts (cancer_patient)
    vs named leukemia lines (cell_line); all stay src_cancer (no flag flips)."""
    line = classify_ms_row(
        "No immunization", "", "Cell Line / Clone", "Blood", "MV411-Myeloblast", pmid=31291378
    )
    assert line["src_cancer"] is True
    assert line["src_cell_line"] is True
    blasts = classify_ms_row(
        "No immunization", "", "Direct Ex Vivo", "Blood", "PBMC", pmid=31291378
    )
    assert blasts["src_cancer"] is True


def test_pmid_override_adjacent():
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", "Lung", pmid=35051231)
    assert flags["src_adjacent_to_tumor"] is True
    assert flags["src_healthy_tissue"] is False


def test_pmid_override_activated_apc():
    flags = classify_ms_row(
        "No immunization", "healthy", "Direct Ex Vivo", "Blood", "DC", pmid=32983136
    )
    assert flags["src_activated_apc"] is True


def test_ebv_lcl_override():
    """override: ebv_lcl → not cancer, not healthy, is EBV-LCL + cell line."""
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Cell Line / Clone (EBV transformed, B-LCL)",
        "Blood",
        "GR",
        pmid=24616531,
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True
    assert flags["src_cell_line"] is True
    assert flags["src_healthy_tissue"] is False


def test_ebv_lcl_override_forces_flags():
    """override: ebv_lcl should force EBV-LCL even if culture_condition is wrong."""
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Cell Line / Clone",  # NOT the EBV string
        "Blood",
        "GR",
        pmid=24616531,
    )
    assert flags["src_ebv_lcl"] is True
    assert flags["src_cell_line"] is True
    assert flags["src_cancer"] is False


def test_cell_line_override_ebv_lcl_not_cancer():
    """cell_line override with EBV culture_condition → not cancer."""
    # Exercise a cell_line override with a synthetic EBV-LCL row.
    # The actual Ritz study used MAVER-1 and HEK293, not JY.
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Cell Line / Clone (EBV transformed, B-LCL)",
        "Blood",
        "JY",
        pmid=28834231,
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is True


def test_cell_line_override_non_ebv_non_malignant_line_is_not_cancer():
    """cell_line override with a non-EBV but non-malignant registered line
    (HEK293: SV40/Ad5-transformed embryonic kidney, never a tumor) should
    not be cancer -- "not EBV-LCL" alone doesn't imply malignant.  The
    registry (cell_lines.yaml) knows HEK293 is_cancer=false, and this
    exact PMID's own override entry already labels the sample "HEK293
    (embryonic kidney)", not a tumor line."""
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Cell Line / Clone",
        "Blood",
        "HEK293",
        pmid=28834231,
    )
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is False


def test_cell_line_override_non_ebv_malignant_line_still_cancer():
    """cell_line override with a genuinely malignant non-EBV registered
    line (K562: chronic myeloid leukemia) should still be cancer -- the
    registry verdict wins, not a blanket "non-EBV cell line = cancer"
    heuristic."""
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Cell Line / Clone",
        "Blood",
        "K562",
        pmid=28834231,
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False


def test_patient_b_all_is_cancer():
    """Patient B-ALL (not EBV-LCL) should still be cancer."""
    flags = classify_ms_row(
        "Occurrence of cancer",
        "acute lymphoblastic leukemia",
        "Direct Ex Vivo",
        "Blood",
        "B cell",
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False


def test_neidert_tissue_override_blood_healthy():
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", "Blood", pmid=29557506)
    assert flags["src_healthy_tissue"] is True


def test_neidert_tissue_override_colon_adjacent():
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", "Colon", pmid=29557506)
    assert flags["src_adjacent_to_tumor"] is True
    assert flags["src_healthy_tissue"] is False


def test_neidert_tissue_override_kidney_adjacent():
    flags = classify_ms_row("No immunization", "healthy", "Direct Ex Vivo", "Kidney", pmid=29557506)
    assert flags["src_adjacent_to_tumor"] is True


def test_auto_detect_activated_apc():
    flags = classify_ms_row(
        "No immunization", "healthy", "Direct Ex Vivo", "Blood", "Dendritic cell"
    )
    assert flags["src_activated_apc"] is True
    assert flags["src_healthy_tissue"] is False


def test_cancer_specific_true():
    assert is_cancer_specific({"found_in_cancer": True, "found_in_healthy_tissue": False})


def test_cancer_specific_false():
    assert not is_cancer_specific({"found_in_cancer": True, "found_in_healthy_tissue": True})


def test_cancer_specific_thymus_ok():
    assert is_cancer_specific(
        {"found_in_cancer": True, "found_in_healthy_tissue": False, "found_in_healthy_thymus": True}
    )


# ── Mono-allelic detection ─────────────────────────────────────────────


def test_load_monoallelic_lines():
    lines = load_monoallelic_lines()
    assert len(lines) >= 3
    names = {entry["name"] for entry in lines}
    assert "721.221" in names
    assert "C1R" in names
    assert "K562" in names


def test_detect_monoallelic_721_221():
    is_mono, host = detect_monoallelic("B721.221", "HLA-A*02:01")
    assert is_mono is True
    assert host == "721.221"


def test_detect_monoallelic_c1r_transfected():
    is_mono, host = detect_monoallelic("C1R cells-B cell", "HLA-A*02:01")
    assert is_mono is True
    assert host == "C1R"


def test_detect_monoallelic_c1r_endogenous():
    is_mono, _host = detect_monoallelic("C1R cells-B cell", "HLA-B*35:03")
    assert is_mono is False


def test_detect_monoallelic_k562():
    is_mono, host = detect_monoallelic("K562 cells", "HLA-A*24:02")
    assert is_mono is True
    assert host == "K562"


def test_detect_monoallelic_unrelated():
    is_mono, host = detect_monoallelic("HeLa", "HLA-A*02:01")
    assert is_mono is False
    assert host == ""


def test_detect_monoallelic_empty():
    is_mono, _host = detect_monoallelic("", "HLA-A*02:01")
    assert is_mono is False


def test_classify_ms_row_monoallelic():
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Cell Line / Clone",
        "Blood",
        "B721.221",
        pmid="",
        mhc_restriction="HLA-A*02:01",
    )
    assert flags["is_monoallelic"] is True
    assert flags["monoallelic_host"] == "721.221"
    assert flags["src_cell_line"] is True


def test_classify_ms_row_not_monoallelic_ex_vivo():
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Direct Ex Vivo",
        "Blood",
        "B721.221",
        mhc_restriction="HLA-A*02:01",
    )
    assert flags["is_monoallelic"] is False


def test_healthy_override_forces_healthy_path():
    """PMID 33858848 (Marcu 2021 HLA Ligand Atlas) declares override: healthy.

    Even if IEDB fields say "Occurrence of cancer", the override should
    force the row into the healthy-donor classification.
    """
    flags = classify_ms_row(
        "Occurrence of cancer",
        "melanoma",
        "Direct Ex Vivo",
        "Liver",
        "",
        pmid=33858848,
    )
    assert flags["src_cancer"] is False
    assert flags["src_healthy_tissue"] is True


def test_healthy_override_conditional_rule():
    """PMID 36589698 has conditional rules: ex vivo -> healthy."""
    flags = classify_ms_row(
        "No immunization",
        "",
        "Direct Ex Vivo",
        "Blood",
        "",
        pmid=36589698,
    )
    assert flags["src_healthy_tissue"] is True
    assert flags["src_cancer"] is False


# ── PMID curation audits (issues #128 / #129 / #130 / #131) ───────────


def test_pmid_28832583_blood_b_cell_classifies_as_ebv_lcl():
    """Issue #131: IEDB tags Bassani-Sternberg 2017 EBV-LCL rows as
    Culture Condition="Cell Line / Clone" (not the EBV-LCL variant), so a
    PMID rule on Source Tissue=Blood + Cell Name=B cell is required to
    classify them as ebv_lcl rather than cancer/cell_line."""
    flags = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        source_tissue="Blood",
        cell_name="B cell",
        pmid=28832583,
    )
    assert flags["src_ebv_lcl"] is True
    assert flags["src_cancer"] is False
    assert flags["src_cell_line"] is True


def test_pmid_28832583_skin_lymphocyte_classifies_as_cancer():
    """Issue #131: melanoma TIL rows (Source Tissue=Skin + Cell Name=Lymphocyte)
    in Bassani-Sternberg 2017 should remain cancer-derived under the
    cancer_patient override."""
    flags = classify_ms_row(
        "Occurrence of cancer",
        "skin melanoma",
        "Cell Line / Clone",
        source_tissue="Skin",
        cell_name="Lymphocyte",
        pmid=28832583,
    )
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False


def test_pmid_29789417_crc_arm_assay_comments():
    """Issue #128: Löffler 2018 CRC paper — IEDB has no per-row structured
    arm provenance; the only signal is Assay Comments substring. A row tagged
    "eluted from colorectal carcinoma (CRC) tissue." must classify as cancer."""
    flags = classify_ms_row(
        "Occurrence of cancer",
        "colonic benign neoplasm",
        "Direct Ex Vivo",
        source_tissue="Gastrointestinal Tract",
        cell_name="Unknown/Unspecified",
        pmid=29789417,
        assay_comments="The epitope was eluted from colorectal carcinoma (CRC) tissue.",
    )
    assert flags["src_cancer"] is True
    assert flags["src_adjacent_to_tumor"] is False


def test_pmid_29789417_nmc_arm_assay_comments():
    """Issue #128: Löffler 2018 — NMC-only rows must classify as adjacent."""
    flags = classify_ms_row(
        "Occurrence of cancer",
        "colonic benign neoplasm",
        "Direct Ex Vivo",
        source_tissue="Gastrointestinal Tract",
        cell_name="Unknown/Unspecified",
        pmid=29789417,
        assay_comments="The epitope was eluted from nonmalignant colon (NMC) tissue.",
    )
    assert flags["src_cancer"] is False
    assert flags["src_adjacent_to_tumor"] is True


def test_pmid_29789417_combined_arm_keeps_cancer_signal():
    """Issue #128: combined "CRC and NMC" rows preserve the cancer signal —
    NMC-only evidence is captured separately by NMC-only rows for the same
    peptide."""
    flags = classify_ms_row(
        "Occurrence of cancer",
        "colonic benign neoplasm",
        "Direct Ex Vivo",
        source_tissue="Gastrointestinal Tract",
        cell_name="Unknown/Unspecified",
        pmid=29789417,
        assay_comments=(
            "The epitope was eluted from colorectal carcinoma (CRC) and "
            "corresponding nonmalignant colon (NMC) tissue."
        ),
    )
    assert flags["src_cancer"] is True
    assert flags["src_adjacent_to_tumor"] is False


def test_pmid_29789417_combined_then_crc_restatement_classifies_as_cancer():
    """Issue #128 rule-order: when IEDB concatenates the combined-arm
    sentence with an explicit CRC-only restatement (3 rows in shipped data),
    the trailing "(CRC) tissue." substring trips the CRC rule and the row
    classifies as cancer.  Locks first-match-wins ordering: the CRC rule must
    win over the combined-arm rule for these compound comments."""
    flags = classify_ms_row(
        "Occurrence of cancer",
        "colonic benign neoplasm",
        "Direct Ex Vivo",
        source_tissue="Gastrointestinal Tract",
        cell_name="Unknown/Unspecified",
        pmid=29789417,
        assay_comments=(
            "The epitope was eluted from colorectal carcinoma (CRC) and "
            "corresponding nonmalignant colon (NMC) tissue. "
            "The epitope was eluted from colorectal carcinoma (CRC) tissue."
        ),
    )
    assert flags["src_cancer"] is True
    assert flags["src_adjacent_to_tumor"] is False


def test_pmid_29789417_combined_then_nmc_restatement_classifies_as_cancer():
    """Issue #128 rule-order + caveat: when the combined-arm sentence is
    followed by an explicit NMC-only restatement (5 rows in shipped data),
    the combined-arm rule fires first and the row classifies as cancer
    even though the peptide also has explicit NMC-only evidence in its row.
    The trade-off is documented in the PMID 29789417 note: peptides that
    only appear in NMC will be captured separately by NMC-only rows when
    such rows exist."""
    flags = classify_ms_row(
        "Occurrence of cancer",
        "colonic benign neoplasm",
        "Direct Ex Vivo",
        source_tissue="Gastrointestinal Tract",
        cell_name="Unknown/Unspecified",
        pmid=29789417,
        assay_comments=(
            "The epitope was eluted from colorectal carcinoma (CRC) and "
            "corresponding nonmalignant colon (NMC) tissue. "
            "The epitope was eluted from nonmalignant colon (NMC) tissue."
        ),
    )
    assert flags["src_cancer"] is True
    assert flags["src_adjacent_to_tumor"] is False


def test_pmid_29093164_ovarian_carcinoma_arm_classifies_as_cancer():
    """Issue #129: Schuster 2017 ovarian carcinoma rows."""
    flags = classify_ms_row(
        "Occurrence of cancer",
        "ovarian cancer",
        "Direct Ex Vivo",
        source_tissue="Ovary",
        cell_name="Other",
        pmid=29093164,
    )
    assert flags["src_cancer"] is True
    assert flags["src_adjacent_to_tumor"] is False


def test_pmid_29093164_benign_comparator_classifies_as_adjacent():
    """Issue #129: matched benign ovarian comparator from cancer patients
    must classify as adjacent, not healthy_tissue (default would make
    No-immunization + empty disease + ex vivo into healthy_donor)."""
    flags = classify_ms_row(
        "No immunization",
        "",
        "Direct Ex Vivo",
        source_tissue="Other",
        cell_name="Other",
        pmid=29093164,
    )
    assert flags["src_adjacent_to_tumor"] is True
    assert flags["src_cancer"] is False
    assert flags["src_healthy_tissue"] is False


def test_pmid_29331515_breast_cancer_panel_remains_cell_line():
    """Issue #130: Rozanov 2018 — every IEDB row for this PMID should
    classify as cell_line / cancer regardless of which Cell Name string IEDB
    has stamped on it (some rows carry non-breast cell names from
    cross-reference annotations rather than actual MS-elution evidence)."""
    flags = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        source_tissue="Breast",
        cell_name="HCC1187-Epithelial cell",
        pmid=29331515,
    )
    assert flags["src_cell_line"] is True
    assert flags["src_cancer"] is True
    assert flags["src_ebv_lcl"] is False
    # Same classification even when IEDB has tagged a non-breast cell name.
    flags = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        source_tissue="Skin",
        cell_name="MeWo-Fibroblast",
        pmid=29331515,
    )
    assert flags["src_cell_line"] is True
    assert flags["src_cancer"] is True


def test_pmid_36796642_sherpa_pyke_entry_present():
    """Issue #132: SHERPA / Pyke study (HLApollo "personalis_pyke_mhcI_2021")
    citation history. The withdrawn 2021 PMID 34126241 is recorded in the
    aliases of the corrected 2023 PMID 36796642 entry."""
    overrides = load_pmid_overrides()
    assert 36796642 in overrides
    entry = overrides[36796642]
    assert "Pyke" in entry["study_label"] or "SHERPA" in entry["study_label"]
    aliases = entry.get("aliases") or {}
    assert aliases.get("withdrawn_pmid") == 34126241
    assert aliases.get("hlapollo_dataset_name") == "personalis_pyke_mhcI_2021"


# ── Allele resolution ──────────────────────────────────────────────────


def test_classify_allele_resolution_four_digit():
    assert classify_allele_resolution("HLA-A*02:01") == "four_digit"
    assert classify_allele_resolution("HLA-B*49:01") == "four_digit"
    assert classify_allele_resolution("HLA-C*07:02") == "four_digit"
    assert classify_allele_resolution("HLA-DQA1*01:03/DQB1*06:03") == "four_digit"
    assert classify_allele_resolution("HLA-DPA1*02:01/DPB1*05:01") == "four_digit"


def test_classify_allele_resolution_serological():
    assert classify_allele_resolution("HLA-A2") == "serological"
    assert classify_allele_resolution("HLA-B7") == "serological"


def test_classify_allele_resolution_class_only():
    assert classify_allele_resolution("HLA class I") == "class_only"
    assert classify_allele_resolution("HLA class II") == "class_only"


def test_classify_allele_resolution_unresolved():
    assert classify_allele_resolution("") == "unresolved"


def test_classify_allele_resolution_pair_gene_gene_does_not_crash():
    """Regression for #87: mhcgnomes parses locus-only pair strings
    (e.g. "HLA-DRA/DRB1" or "HLA-DPA1*01:03/DPB1") into a Pair whose legs
    are Gene instances, not Allele.  Gene has no allele_fields; the prior
    isinstance dispatch crashed with AttributeError. A Pair[Gene, Gene]
    is below serological/two_digit resolution and should be "unresolved".
    Mixed Pair[Allele, Gene] falls through to "unresolved" as well since
    both sides need to clear the one-digit threshold."""
    assert classify_allele_resolution("HLA-DRA/DRB1") == "unresolved"
    # Mixed Pair — one side has allele fields, the other doesn't.
    assert classify_allele_resolution("HLA-DPA1*01:03/DPB1") == "unresolved"


def test_classify_allele_resolution_haplotype_allele_is_exact():
    """#597: a haplotype-designated allele names one molecule, so it is
    ``four_digit`` even though it carries a single allele field.

    Mouse, rat, pig, chicken and horse nomenclature identifies an allele by
    its haplotype -- ``H2-Kb`` is the H2-K molecule of haplotype ``b``, one
    sequence, with no finer form to resolve to. Counting fields against HLA's
    two-field convention called these truncated, which made
    :func:`expand_allele_set` refuse every mouse observation in the corpus.
    """
    for restriction in ("H2-K*b", "H2-Kb", "H-2Kb", "H2-D*b", "H2-K*d", "H2-L*d"):
        assert classify_allele_resolution(restriction) == "four_digit", restriction
    # Class II arrives as a Pair; both chains are haplotype-designated.
    assert classify_allele_resolution("H2-AA*b/AB*b") == "four_digit"
    assert classify_allele_resolution("H2-EA*k/EB*k") == "four_digit"
    # Rat uses the same convention under the RT1 prefix.
    assert classify_allele_resolution("RT1-Bb*l") == "four_digit"


def test_classify_allele_resolution_rejects_unvalidated_haplotype_letters():
    """#597: the lone field must *name a haplotype*, not merely look like one.

    An interim revision of this change tested only the field's shape ("does not
    start with a digit"), which validates nothing: mhcgnomes builds an ``Allele``
    out of ``H2-K*<anything letter-led>`` without consulting its own tables, so
    a mistyped deposit shipped as a confidently resolved single molecule and
    passed ``--min-allele-resolution four_digit``. An unattributed row is
    honest; a typo presented as an exact molecule is not.
    """
    for restriction in ("H2-K*x", "H2-K*zzz", "H2-D*nonsense", "H2-K*q7", "Mamu-A*ab"):
        assert classify_allele_resolution(restriction) == "two_digit", restriction
        assert expand_allele_set(restriction) == ("", "unmatched", 0), restriction


@pytest.mark.parametrize(
    "restriction,canonical",
    [
        ("H2-Kwm7", "H2-K*wm7"),
        ("H2-K*wm7", "H2-K*wm7"),
        ("H2-Kbm1", "H2-K*bm1"),
        ("H2-K*bm1", "H2-K*bm1"),
        ("H2-Kbm8", "H2-K*bm8"),
        ("H2-Dbm13", "H2-D*bm13"),
        ("Anpl-UAA*SD", "AnasPlat-UAA*sd"),
    ],
)
def test_source_backed_non_roster_alleles_name_exact_molecules(restriction, canonical):
    """#606: upstream's exact, gene-specific catalog validates these names."""
    assert classify_allele_resolution(restriction) == "four_digit"
    assert expand_allele_set(restriction) == (canonical, "exact", 1)


def test_non_roster_catalog_does_not_decompose_or_guess_names():
    """Unknown shapes and wrong-gene variants cannot borrow a known entry."""
    for restriction in (
        "H2-K*bm999",
        "H2-K*wm999",
        "H2-D*bm1",
        "H2-Kj",
        "AnasPlat-UAA*invented",
        # Upstream catalogs these solely to parse compound SahaI*49/82 labels.
        "SahaI*49",
    ):
        assert classify_allele_resolution(restriction) == "two_digit", restriction
        assert expand_allele_set(restriction) == ("", "unmatched", 0), restriction
    # Roster names remain accepted, including a gene absent from that
    # haplotype's member list; this is a separate source of exact names.
    assert classify_allele_resolution("H2-T23*b") == "four_digit"


def test_class_scoped_haplotype_rosters_have_class_resolution():
    """#604: a populated roster bounds a class-scoped restriction."""
    for restriction in ("H2-b class I", "H2-b class II", "H2-d class II", "H2-z/d class II"):
        assert classify_allele_resolution(restriction) == "class_only", restriction
    # Empty-roster and class-ambiguous haplotypes still name no candidate set.
    for restriction in ("RT1-Dn", "RT1-Du", "RT1-Dl", "ELA-A1 class I", "H2-b"):
        assert classify_allele_resolution(restriction) == "unresolved", restriction
    assert classify_allele_resolution("H2-Q2") == "unresolved"


def test_classify_allele_resolution_h2_ie_family_is_inconsistent_upstream():
    """Pins ``H2-IEg7``; the cause is pirl-unc/mhcgnomes#201, NOT #604.

    ``H2-IEg7`` is the only member of the mouse I-E / I-A heterodimer family
    that ``mhcgnomes.parse`` dispatches to ``Haplotype`` -- and to one with an
    empty ``alleles`` tuple. Every sibling becomes a ``Pair`` or an ``Allele``
    and so resolves to ``four_digit``, including ``H2-IAg7``, which carries the
    same ``g7`` haplotype. So the 93 corpus rows reading ``H2-IEg7`` differ from
    their family for a reason that lives in the parse, not in this dispatch,
    which is why the string is not special-cased here.

    Grouping it with #604's populated class-scoped haplotypes would record the
    wrong diagnosis: this is not "a statement over a known allele list", it is
    the same I-E heterodimer as ``H2-IEk``.
    """
    assert classify_allele_resolution("H2-IEg7") == "unresolved"
    for sibling in ("H2-IEk", "H2-IEb", "H2-IEd", "H2-IEs", "H2-IAg7", "H2-IAb", "H2-IAd"):
        assert classify_allele_resolution(sibling) == "four_digit", sibling


def test_classify_allele_resolution_truncated_allele_group_stays_two_digit():
    """The #597 widening must not promote a genuinely truncated allele.

    A numeric first field is an IPD allele *group* standing for every member
    below it, which is strictly coarser than one molecule. These are the whole
    residual: after the widening only 48 observation rows stay ``two_digit``,
    and every one carries a numeric group.
    """
    for restriction in (
        "HLA-A*02",
        "SLA-1*04",
        "AnasPlat-UAA*76",
        "Anpl-UAA*20",
        "Gaga-BF2*21",
        "Mamu-B*098",
        "RLA-A*01",
    ):
        assert classify_allele_resolution(restriction) == "two_digit", restriction


def test_classify_allele_resolution_unparseable_strings_are_unresolved():
    """#597: deleting the regex fallback made mhcgnomes the only authority.

    The regex behind the old ``except ImportError`` read resolution off the
    *shape* of a string mhcgnomes had already refused. ``HLA-B23`` is the one
    verdict that moved (``serological`` -> ``unresolved``) and the new one is
    right: mhcgnomes' serotype table knows ``B21``, ``B22`` and ``B27`` but no
    ``B23``, so the old answer invented a specificity that does not exist.

    These are the only 5 strings that reached the fallback across the 1,474
    entries of both parquet vocabularies plus every curated allele token, and
    none of them appears as any row's ``mhc_restriction``.
    """
    for restriction in ("HLA-B23", "class", "unknown", "Carassius", "gibelio"):
        assert classify_allele_resolution(restriction) == "unresolved", restriction
    # The verdict flows to the mono-allelic / evidence gate, so pin that too.
    assert not _is_resolved_allele("HLA-B23")
    # A serotype mhcgnomes does know is unaffected.
    assert classify_allele_resolution("HLA-B27") == "serological"
    assert _is_resolved_allele("HLA-B27")


def test_allele_resolution_floors_exclude_unresolved():
    """#597: a ``--min-allele-resolution`` floor must be able to exclude something.

    ``unresolved`` is the least specific tier, so a floor there admits every row
    and the filter silently does nothing. The CLI derives its ``choices`` from
    :data:`ALLELE_RESOLUTION_FLOORS` for that reason.
    """
    assert "unresolved" not in ALLELE_RESOLUTION_FLOORS
    assert set(ALLELE_RESOLUTION_FLOORS) == set(ALLELE_RESOLUTION_ORDER) - {"unresolved"}
    # Order is preserved, so the CLI lists tiers most- to least-specific.
    assert list(ALLELE_RESOLUTION_FLOORS) == [
        r for r in ALLELE_RESOLUTION_ORDER if r != "unresolved"
    ]
    # Public and shared by reference into three argparse calls, so immutable.
    assert isinstance(ALLELE_RESOLUTION_ORDER, tuple)
    assert isinstance(ALLELE_RESOLUTION_FLOORS, tuple)


def test_allele_resolution_rank_ordering():
    ranks = [allele_resolution_rank(r) for r in ALLELE_RESOLUTION_ORDER]
    assert ranks == sorted(ranks)
    assert allele_resolution_rank("four_digit") < allele_resolution_rank("serological")
    assert allele_resolution_rank("serological") < allele_resolution_rank("class_only")


def test_classify_ms_row_includes_allele_resolution():
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Direct Ex Vivo",
        "Liver",
        mhc_restriction="HLA-A*02:01",
    )
    assert flags["allele_resolution"] == "four_digit"

    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Direct Ex Vivo",
        "Liver",
        mhc_restriction="HLA class I",
    )
    assert flags["allele_resolution"] == "class_only"


def test_classify_ms_row_haplotype_allele_resolution():
    """The #597 widening reaches the row-level flags the scanner writes."""
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Direct Ex Vivo",
        "Spleen",
        mhc_restriction="H2-K*b",
    )
    assert flags["allele_resolution"] == "four_digit"


# ── Serotype mapping ──────────────────────────────────────────────────


def test_allele_to_serotype_four_digit():
    assert allele_to_serotype("HLA-A*02:01") == "HLA-A2"


def test_allele_to_serotype_already_serotype():
    assert allele_to_serotype("HLA-A2") == "HLA-A2"


def test_allele_to_serotype_class_only():
    assert allele_to_serotype("HLA class I") == ""


def test_allele_to_serotype_empty():
    assert allele_to_serotype("") == ""


def test_classify_ms_row_includes_serotype():
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Direct Ex Vivo",
        "Liver",
        mhc_restriction="HLA-A*02:01",
    )
    assert "serotype" in flags
    assert "serotypes" in flags
    # Most-specific serotype is the broader locus-specific name (A2),
    # not the IEF sub-serotype (A2.1)
    assert flags["serotype"] == "HLA-A2"
    assert "HLA-A2" in flags["serotypes"].split(";")


def test_allele_to_serotype_prefers_locus_specific_over_bw4():
    """hitlist #44: A*24:02 must resolve to HLA-A24, not HLA-Bw4."""
    assert allele_to_serotype("HLA-A*24:02") == "HLA-A24"
    # And the full list should include Bw4 as secondary
    all_sero = allele_to_all_serotypes("HLA-A*24:02")
    assert "HLA-A24" in all_sero
    assert "HLA-Bw4" in all_sero
    assert all_sero[0] == "HLA-A24"  # locus-specific wins


def test_allele_to_serotype_b57_prefers_b57():
    """B*57:01 belongs to B57, B17, AND Bw4 — B57 must win."""
    assert allele_to_serotype("HLA-B*57:01") == "HLA-B57"
    all_sero = allele_to_all_serotypes("HLA-B*57:01")
    assert all_sero[0] == "HLA-B57"
    assert "HLA-Bw4" in all_sero


def test_allele_to_all_serotypes_a02_broader_first():
    """A*02:01 has A2 (broader) and A2.1 (IEF sub-serotype).

    Our ranking prefers the broader name as canonical — clinicians say "A2",
    not "A2.1".
    """
    all_sero = allele_to_all_serotypes("HLA-A*02:01")
    assert all_sero[0] == "HLA-A2"
    assert "HLA-A2" in all_sero


def test_allele_to_all_serotypes_split_includes_broad_parent():
    """A split serotype like A2403 implies its broad parent A24, so a broad
    A24 query matches A*24:03.  The broad parent ranks first (broader-first)."""
    all_sero = allele_to_all_serotypes("HLA-A*24:03")
    assert "HLA-A24" in all_sero
    assert "HLA-A2403" in all_sero
    assert all_sero[0] == "HLA-A24"  # broader name is canonical


def test_allele_to_all_serotypes_empty():
    assert allele_to_all_serotypes("") == ()
    assert allele_to_all_serotypes("HLA class I") == ()


# ── Forward serotype expansion (v1.30.2) ──────────────────────────────


def test_serotype_to_alleles_a2_includes_canonical_member():
    """v1.30.2: HLA-A2 expands to its 4-digit members; A*02:01 must be one
    of them and must be first (lowest-numbered = best-guess heuristic)."""
    members = serotype_to_alleles("HLA-A2")
    assert len(members) >= 10  # A2 has dozens of members in IPD-IMGT/HLA
    assert "HLA-A*02:01" in members
    assert members[0] == "HLA-A*02:01"  # sorted-ascending → lowest-numbered first


def test_serotype_to_alleles_b7_dominated_by_b07_02():
    """v1.30.2: HLA-B7 → B*07:02 as the lowest-numbered member."""
    members = serotype_to_alleles("HLA-B7")
    assert "HLA-B*07:02" in members
    # B*07:02 is the most common B7 in nearly all populations.
    assert members[0] == "HLA-B*07:02"


def test_serotype_to_alleles_no_op_on_4digit_input():
    """v1.30.2: passing a 4-digit allele in returns ``()`` — only true
    serotypes expand."""
    assert serotype_to_alleles("HLA-A*02:01") == ()


def test_serotype_to_alleles_empty_and_unknown():
    """v1.30.2: empty / unknown / class-only inputs return ``()``."""
    assert serotype_to_alleles("") == ()
    assert serotype_to_alleles("HLA class I") == ()
    assert serotype_to_alleles("HLA-A99") == ()  # not a real serotype


def test_best_4digit_for_serotype_a2_a0201():
    """v1.30.2: HLA-A2's best 4-digit guess is HLA-A*02:01."""
    assert best_4digit_for_serotype("HLA-A2") == "HLA-A*02:01"


def test_best_4digit_for_serotype_returns_empty_for_non_serotype():
    """v1.30.2: 4-digit input or unknown serotype → empty string (caller
    decides the fallback)."""
    assert best_4digit_for_serotype("HLA-A*02:01") == ""
    assert best_4digit_for_serotype("") == ""


def test_classify_ms_row_serotypes_plural_populated():
    """serotypes column must be semicolon-joined when multiple serotypes exist."""
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Direct Ex Vivo",
        "Liver",
        mhc_restriction="HLA-A*24:02",
    )
    assert flags["serotype"] == "HLA-A24"
    assert "HLA-A24" in flags["serotypes"].split(";")
    assert "HLA-Bw4" in flags["serotypes"].split(";")


def test_is_binding_assay_competitive_ic50_comment():
    """Marcilla-style acid-strip / flow-cytometry IC50 rows are binding assays."""
    comments = (
        "C1R-B*40:02 cells were acid stripped to dissociate surface HLA class I complexes. "
        "Then, a reference peptide that bound specifically to HLA-B*40:02 was added to the "
        "cells together with human β2m and different concentrations of the test peptides. "
        "Fluorescence was measured by flow cytometry. Experimental data were fitted to "
        "sigmoid curves to allow the estimation of the IC50 values."
    )
    assert is_binding_assay("Positive", comments) is True


def test_is_binding_assay_uses_structured_purified_mhc_half_life_fields():
    """#418: a positive result is still a biochemical stability assay."""
    assert (
        is_binding_assay(
            "Positive",
            "",
            assay_method="purified MHC/direct/radioactivity",
            response_measured="half life",
        )
        is True
    )
    assert (
        is_binding_assay(
            "Positive",
            "",
            assay_method="cellular MHC/mass spectrometry",
            response_measured="ligand presentation",
        )
        is False
    )


# ── MHC species classification ─────────────────────────────────────────


def test_classify_mhc_species_human():
    assert classify_mhc_species("HLA-A*02:01") == "Homo sapiens"
    assert classify_mhc_species("HLA class I") == "Homo sapiens"


def test_classify_mhc_species_mouse():
    assert classify_mhc_species("H-2Kb") == "Mus musculus"


def test_classify_mhc_species_empty():
    assert classify_mhc_species("") == ""


def test_classify_ms_row_includes_mhc_species():
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Direct Ex Vivo",
        "Liver",
        mhc_restriction="HLA-A*02:01",
    )
    assert flags["mhc_species"] == "Homo sapiens"


# ── PMID-level mono-allelic override ───────────────────────────────────


def test_pmid_mono_allelic_override():
    """PMID 28228285 (Sarkizova 2020) is a 721.221 study."""
    flags = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        "Blood",
        "B cell",
        pmid=28228285,
        mhc_restriction="HLA-A*01:01",
    )
    assert flags["is_monoallelic"] is True
    assert flags["monoallelic_host"] == "721.221"


def test_pmid_mono_allelic_override_28514659():
    """PMID 28514659 (HLA-B*46:01) is also a 721.221 study."""
    flags = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        "Spleen",
        "Other",
        pmid=28514659,
        mhc_restriction="HLA-B*46:01",
    )
    assert flags["is_monoallelic"] is True
    assert flags["monoallelic_host"] == "721.221"


def test_pmid_mono_override_skipped_for_unresolved_allele():
    """is_monoallelic is a sample-level claim — a row with no resolved
    allele cannot be flagged mono-allelic even if the paper uses a
    mono-allelic host.  Faridi 2018 (PMID 30315122) has samples with
    mhc: unknown; those rows must not be claimed as mono-allelic.
    """
    flags_empty = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        "Blood",
        "B cell",
        pmid=30315122,
        mhc_restriction="",
    )
    assert flags_empty["is_monoallelic"] is False

    flags_class_only = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        "Blood",
        "B cell",
        pmid=30315122,
        mhc_restriction="HLA class I",
    )
    assert flags_class_only["is_monoallelic"] is False


def test_pmid_mono_override_skipped_for_validation_class_only():
    """Sarkizova 2020 mixes 95 721.221 transfectants (mhc_restriction is a
    specific allele) with 12 patient-derived validation samples whose
    IEDB mhc_restriction is the class-only string ``"HLA class I"``.  The
    allele-resolution gate catches the validation rows — they cannot
    claim mono-allelic status without a resolved allele.
    """
    flags_validation = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        "Blood",
        "Glial cell",
        pmid=31844290,
        mhc_restriction="HLA class I",
    )
    assert flags_validation["is_monoallelic"] is False


def test_pmid_mono_override_applies_across_cell_name_variants():
    """The PMID override is NOT gated on cell_name — IEDB frequently
    mis-labels the host (e.g. Trolle 2016 records 721.221 transfectants
    as ``"HeLa cells-Epithelial cell"``).  As long as the row has a
    resolved allele and the PMID has ``mono_allelic_host``, the row
    flags mono-allelic.
    """
    # Sarkizova transfectants — IEDB label is "B cell", ambiguous
    # Trolle   transfectants — IEDB label is "HeLa cells-Epithelial cell", specific but WRONG
    # Splenocyte etc. — anything goes as long as allele is resolved
    for pmid, cn in (
        (31844290, "B cell"),
        (26783342, "HeLa cells-Epithelial cell"),
        (28514659, "Splenocyte"),
        (28228285, ""),
    ):
        flags = classify_ms_row(
            "No immunization",
            "",
            "Cell Line / Clone",
            "Blood",
            cn,
            pmid=pmid,
            mhc_restriction="HLA-A*02:01",
        )
        assert flags["is_monoallelic"] is True, f"override should apply for PMID={pmid} cn={cn!r}"


def test_pmid_mono_allelic_method_override():
    """mono_allelic_method (e.g. MAPTAC) sets is_monoallelic for resolved
    alleles without requiring a cell-line entry in monoallelic_lines.yaml.
    """
    # PMID 31495665 has mono_allelic_method: "MAPTAC"
    flags = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        "",
        "MAPTAC",
        pmid=31495665,
        mhc_restriction="HLA-A*02:01",
    )
    assert flags["is_monoallelic"] is True
    assert flags["monoallelic_host"] == "MAPTAC"

    # Class-only allele should NOT be flagged mono-allelic
    flags_class = classify_ms_row(
        "No immunization",
        "",
        "Cell Line / Clone",
        "",
        "MAPTAC",
        pmid=31495665,
        mhc_restriction="HLA class II",
    )
    assert flags_class["is_monoallelic"] is False


def test_pmid_mono_allelic_method_override_strazar():
    """Stražar 2023 uses a Strep-tag II tagged-allele pulldown rather than
    a known monoallelic host cell line, so the PMID-level method override
    should mark resolved HLA-II pairs as mono-allelic.
    """
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Cell Line / Clone",
        "Kidney",
        "Expi293F",
        pmid=37301199,
        mhc_restriction="HLA-DQA1*01:03/DQB1*06:03",
    )
    assert flags["is_monoallelic"] is True
    assert flags["monoallelic_host"] == "Strep-tag II"

    flags_class = classify_ms_row(
        "No immunization",
        "healthy",
        "Cell Line / Clone",
        "Kidney",
        "Expi293F",
        pmid=37301199,
        mhc_restriction="HLA class II",
    )
    assert flags_class["is_monoallelic"] is False


def test_illing_2018_monoallelic_host_applies_without_cell_name():
    """Illing 2018 rows that lack the C1R cell_name in IEDB should still be
    flagged mono-allelic via the PMID-level ``mono_allelic_host: C1R``
    override, as long as the allele is resolved."""
    flags = classify_ms_row(
        "No immunization",
        "healthy",
        "Cell Line / Clone",
        "",
        "",  # empty cell_name (the ~33 IEDB rows that lack the C1R label)
        pmid=30410026,
        mhc_restriction="HLA-B*57:01",
    )
    assert flags["is_monoallelic"] is True
    assert flags["monoallelic_host"] == "C1R"


def test_load_pmid_overrides_rejects_unknown_mono_host(tmp_path, monkeypatch):
    """A PMID override with a mono_allelic_host that isn't in
    monoallelic_lines.yaml must raise at load time — silently producing
    rows with a bogus monoallelic_host string would leak typos into the
    published index.
    """
    import yaml as _yaml

    from hitlist import curation

    bad_yaml = tmp_path / "pmid_overrides.yaml"
    bad_yaml.write_text(
        _yaml.safe_dump(
            [
                {
                    "pmid": 99999999,
                    "study_label": "Bogus",
                    "mono_allelic_host": "NOT_A_REAL_HOST",
                }
            ]
        )
    )
    # Resolve other data paths to their real locations — monkeypatch only
    # redirects pmid_overrides.yaml.  Without this, load_monoallelic_lines
    # (called from load_pmid_overrides) would receive the bare filename
    # when its lru_cache happens to be cold.
    real_data_path = curation._data_path
    monkeypatch.setattr(
        curation,
        "_data_path",
        lambda fn: str(bad_yaml) if fn == "pmid_overrides.yaml" else real_data_path(fn),
    )
    curation.load_pmid_overrides.cache_clear()
    try:
        with pytest.raises(ValueError, match="NOT_A_REAL_HOST"):
            curation.load_pmid_overrides()
    finally:
        curation.load_pmid_overrides.cache_clear()


@pytest.mark.parametrize(
    "entry",
    [
        {"pmid": 99999998, "restriction_evidence": "guessed"},
        {
            "pmid": 99999998,
            "restriction_evidence_rules": [
                {"condition": {"Assay Method": "x"}, "evidence": "guessed"}
            ],
        },
    ],
)
def test_load_pmid_overrides_rejects_invalid_restriction_evidence(tmp_path, monkeypatch, entry):
    """Invalid evidence labels must fail before they reach a published index."""
    import yaml as _yaml

    from hitlist import curation

    bad_yaml = tmp_path / "pmid_overrides.yaml"
    bad_yaml.write_text(_yaml.safe_dump([entry]))
    real_data_path = curation._data_path
    monkeypatch.setattr(
        curation,
        "_data_path",
        lambda fn: str(bad_yaml) if fn == "pmid_overrides.yaml" else real_data_path(fn),
    )
    curation.load_pmid_overrides.cache_clear()
    try:
        with pytest.raises(ValueError, match="guessed"):
            curation.load_pmid_overrides()
    finally:
        curation.load_pmid_overrides.cache_clear()


def test_load_pmid_overrides_warns_on_legacy_keys(tmp_path, monkeypatch):
    """Legacy keys ``label:`` / ``type:`` were renamed in v1.7.0.  Loading
    a file with the old names must emit DeprecationWarning so users
    catch schema drift.
    """
    import warnings

    import yaml as _yaml

    from hitlist import curation

    legacy_yaml = tmp_path / "pmid_overrides.yaml"
    legacy_yaml.write_text(
        _yaml.safe_dump(
            [
                {
                    "pmid": 42,
                    "label": "legacy label",
                    "ms_samples": [{"type": "legacy sample"}],
                }
            ]
        )
    )
    # Route only the pmid_overrides.yaml lookup to the temp fixture; the
    # other data files (e.g. monoallelic_lines.yaml that
    # load_pmid_overrides validates against) must continue to resolve to
    # the real package data dir. The previous monkeypatch returned a
    # bare filename for non-pmid-overrides paths, which silently worked
    # only when the lru_cache was already warmed by an earlier test
    # (test-order-dependent flake).
    real_data_path = curation._data_path
    monkeypatch.setattr(
        curation,
        "_data_path",
        lambda fn: str(legacy_yaml) if fn == "pmid_overrides.yaml" else real_data_path(fn),
    )
    curation.load_pmid_overrides.cache_clear()
    curation.load_monoallelic_lines.cache_clear()
    try:
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always", DeprecationWarning)
            curation.load_pmid_overrides()
        messages = [str(x.message) for x in w if issubclass(x.category, DeprecationWarning)]
        assert any("label:" in m for m in messages), messages
        assert any("type:" in m for m in messages), messages
    finally:
        curation.load_pmid_overrides.cache_clear()
        curation.load_monoallelic_lines.cache_clear()


# ── Species normalization ─────────────────────────────────────────────


def test_normalize_species_canonical():
    assert normalize_species("Homo sapiens") == "Homo sapiens"
    assert normalize_species("Mus musculus") == "Mus musculus"


def test_normalize_species_common_names():
    assert normalize_species("human") == "Homo sapiens"
    assert normalize_species("mouse") == "Mus musculus"


def test_normalize_species_underscore():
    assert normalize_species("homo_sapiens") == "Homo sapiens"
    assert normalize_species("Homo_sapiens") == "Homo sapiens"
    assert normalize_species("mus_musculus") == "Mus musculus"


def test_normalize_species_parenthetical():
    assert normalize_species("Homo sapiens (human)") == "Homo sapiens"
    assert normalize_species("Mus musculus (mouse)") == "Mus musculus"
    assert normalize_species("Sus scrofa (pig)") == "Sus scrofa"


def test_normalize_species_empty():
    assert normalize_species("") == ""


def test_normalize_species_idempotent():
    assert normalize_species(normalize_species("human")) == "Homo sapiens"
    assert normalize_species(normalize_species("Homo sapiens (human)")) == "Homo sapiens"


# ── Allele normalization ─────────────────────────────────────────────


def test_normalize_allele_hla():
    assert normalize_allele("HLA-A*02:01") == "HLA-A*02:01"
    assert normalize_allele("HLA-DRB1*04:01") == "HLA-DRB1*04:01"


def test_normalize_allele_mouse():
    # H-2Kb → H2-K*b (canonical mhcgnomes form)
    assert normalize_allele("H-2Kb") == "H2-K*b"


def test_normalize_allele_non_human_species():
    assert normalize_allele("Saha-UA") == "Saha-UA"
    assert normalize_allele("SLA-1*0201") == "SLA-1*02:01"


def test_normalize_allele_preserves_class_only():
    # "HLA class I" should pass through unchanged, not normalize to species
    assert normalize_allele("HLA class I") == "HLA class I"
    assert normalize_allele("HLA class II") == "HLA class II"


def test_normalize_allele_empty_and_unparseable():
    assert normalize_allele("") == ""
    assert normalize_allele("unknown") == "unknown"
    # A truly non-allele string — behaviour should be pass-through across
    # mhcgnomes versions (older mhcgnomes raised ParseError on the prior
    # test string "SahaI*35"; mhcgnomes >= 3.32 parses that successfully
    # as Saha-I*35, which invalidated the assumption).
    assert normalize_allele("definitely not an allele") == "definitely not an allele"


# ── Exact-allele set expansion (issue #137) ─────────────────────────────


def test_expand_allele_set_exact_four_digit():
    """A row already at four-digit resolution returns itself with provenance ``exact``."""
    allele_set, prov, n = expand_allele_set("HLA-A*02:01")
    assert allele_set == "HLA-A*02:01"
    assert prov == "exact"
    assert n == 1


def test_pmid_36423003_prediction_rule_is_scoped_to_resolved_ms_rows():
    """#415: do not label the class-only or purified-MHC arms predicted."""
    from hitlist.curation import restriction_evidence_for_row

    common = {
        "pmid": 36423003,
        "assay_method": "cellular MHC/mass spectrometry",
        "response_measured": "ligand presentation",
    }
    assert restriction_evidence_for_row("BoLA-6*013:01", **common) == "predicted"
    assert restriction_evidence_for_row("BoLA class I", **common) == "unknown"
    assert (
        restriction_evidence_for_row(
            "BoLA-DRB3*011:01",
            pmid=36423003,
            assay_method="purified MHC/direct/radioactivity",
            response_measured="half life",
        )
        == "unknown"
    )


def test_expand_allele_set_class_only_with_sample_mhc():
    """class_only + Host | MHC Types Present yields ``sample_allele_match``
    with the donor's typed alleles, filtered to the row's class.
    """
    host = "HLA-A*01:01;HLA-B*13:02;HLA-B*39:06;HLA-C*12:03"
    allele_set, prov, n = expand_allele_set("HLA class I", host, mhc_class="I")
    assert prov == "sample_allele_match"
    assert n == 4
    assert allele_set == "HLA-A*01:01;HLA-B*13:02;HLA-B*39:06;HLA-C*12:03"


def test_expand_allele_set_class_only_with_sample_mhc_class_filter():
    """Sample's typed alleles include both class I and class II; the row's
    class filter must drop the wrong-class entries."""
    host = "HLA-A*02:01;HLA-DRB1*15:01"
    set_i, _, n_i = expand_allele_set("HLA class I", host, mhc_class="I")
    assert set_i == "HLA-A*02:01"
    assert n_i == 1
    set_ii, _, n_ii = expand_allele_set("HLA class II", host, mhc_class="II")
    assert set_ii == "HLA-DRB1*15:01"
    assert n_ii == 1


def test_expand_allele_set_class_only_falls_back_to_pmid_pool():
    """No sample mhc → PMID pool from curated hla_alleles.  Uses PMID
    28832583 (Bassani-Sternberg 2017) which has dict-of-lists hla_alleles."""
    allele_set, prov, n = expand_allele_set(
        "HLA class I", host_mhc_types="", pmid=28832583, mhc_class="I"
    )
    assert prov == "pmid_class_pool"
    assert n > 0
    # All alleles in the set are class I (no HLA-D*).
    assert all(not a.startswith("HLA-D") for a in allele_set.split(";"))
    # Spot-check: CD165's alleles should be in the pool.
    assert "HLA-A*02:05" in allele_set
    assert "HLA-B*15:01" in allele_set


def test_expand_allele_set_class_only_no_curation_is_unmatched():
    """class_only with neither sample MHC nor PMID curation → unmatched."""
    allele_set, prov, n = expand_allele_set(
        "HLA class I", host_mhc_types="", pmid=99999999, mhc_class="I"
    )
    assert allele_set == ""
    assert prov == "unmatched"
    assert n == 0


def test_expand_allele_set_two_digit_is_unmatched():
    """Two-digit / serological / unresolved restrictions are emitted as
    unmatched until catalog-based expansion lands (planned follow-up)."""
    for restriction in ("HLA-A*02", "HLA-A2", "SLA-1*04", ""):
        allele_set, prov, n_alleles = expand_allele_set(restriction)
        assert allele_set == ""
        assert prov == "unmatched"
        assert n_alleles == 0


def test_expand_allele_set_haplotype_allele_is_exact():
    """#597: a haplotype-designated allele already names its candidate set.

    ``expand_allele_set`` refuses every resolution other than ``four_digit``
    and ``class_only``, so mislabelling ``H2-Kb`` as truncated emptied the
    candidate set for 163,979 observation rows and 15,378 binding rows --
    15.5% of the corpus' unmatched mass, and 84.5% of its unmatched *mouse*
    rows, measured on the 1.63.7 replay of ``observations.parquet`` /
    ``binding.parquet``. The set needs no inference: the restriction names one
    molecule, so it *is* the set.
    """
    for restriction, expected in (
        ("H2-K*b", "H2-K*b"),
        ("H2-Kb", "H2-K*b"),
        ("H-2Kb", "H2-K*b"),
        ("H2-D*b", "H2-D*b"),
        ("H2-AA*b/AB*b", "H2-AA*b/AB*b"),
        ("RT1-Bb*l", "RT1-Bb*l"),
    ):
        allele_set, prov, n_alleles = expand_allele_set(restriction)
        assert (allele_set, prov, n_alleles) == (expected, "exact", 1), restriction


def test_expand_allele_set_pmid_with_only_free_text_alleles():
    """PMID 33858848 (HLA Ligand Atlas) has hla_alleles as dict-of-strings
    free-text descriptions ('51 HLA-I allotypes') with no parseable allele
    strings.  The flatten helper must return an empty pool, and a class_only
    row falls through to unmatched rather than crashing."""
    allele_set, prov, n = expand_allele_set(
        "HLA class I", host_mhc_types="", pmid=33858848, mhc_class="I"
    )
    assert allele_set == ""
    assert prov == "unmatched"
    assert n == 0


def test_expand_allele_set_sample_match_wins_over_pmid_pool():
    """When both sample MHC and PMID pool are available, sample wins
    (more specific provenance)."""
    allele_set, prov, n = expand_allele_set(
        "HLA class I",
        host_mhc_types="HLA-A*02:01",
        pmid=28832583,  # has a 32-allele PMID pool
        mhc_class="I",
    )
    assert prov == "sample_allele_match"
    assert allele_set == "HLA-A*02:01"
    assert n == 1


# ── v1.30.14: _flatten_hla_alleles tokenizes space-separated genotypes ──


def test_flatten_hla_alleles_splits_space_separated_genotype_string():
    """v1.30.14: ~32% of ms_samples in pmid_overrides.yaml encode a
    donor's full genotype as one space-separated string in the
    ``mhc:`` field. ``_flatten_hla_alleles`` must split these into
    individual alleles so qc cross_reference / curation_plan don't
    report the whole genotype as a single phantom 'allele'."""
    from hitlist.curation import _flatten_hla_alleles

    out = _flatten_hla_alleles(
        "HLA-A*01:01 HLA-A*23:01 HLA-B*07:02 HLA-B*15:01 HLA-C*12:03 HLA-C*14:02"
    )
    assert out == {
        "HLA-A*01:01",
        "HLA-A*23:01",
        "HLA-B*07:02",
        "HLA-B*15:01",
        "HLA-C*12:03",
        "HLA-C*14:02",
    }


def test_flatten_hla_alleles_single_allele_string_still_works():
    """Don't regress the single-allele string case while fixing the
    multi-allele case."""
    from hitlist.curation import _flatten_hla_alleles

    assert _flatten_hla_alleles("HLA-A*02:01") == {"HLA-A*02:01"}


def test_flatten_hla_alleles_multi_allele_drops_noise_tokens():
    """Free-text noise tokens (e.g. ``or``, commas) inside a
    multi-allele string fail the syntactic check and are dropped
    rather than mistaken for alleles."""
    from hitlist.curation import _flatten_hla_alleles

    out = _flatten_hla_alleles("HLA-A*02:01 or HLA-B*07:02")
    assert out == {"HLA-A*02:01", "HLA-B*07:02"}


# ── is_chimeric_system ───────────────────────────────────────────────────


def test_is_chimeric_hla_transgenic_rat():
    """HLA-B27-transgenic Lewis rat (PMID 28188227) is the canonical
    engineered chimeric system: rat proteome, human MHC."""
    from hitlist.curation import is_chimeric_system

    assert is_chimeric_system("Rattus norvegicus", "Homo sapiens") is True


def test_is_chimeric_human_peptides_on_mouse_mhc():
    """NetH2pan-style training data (PMID 29615400) — synthetic human
    peptides tested against mouse MHC. Different genus → chimeric."""
    from hitlist.curation import is_chimeric_system

    assert is_chimeric_system("Homo sapiens", "Mus musculus") is True


def test_is_chimeric_substrain_collapses_to_species():
    """``Mus musculus C57BL/6`` is the same species as ``Mus musculus``.
    Substrain labels must NOT trigger the flag."""
    from hitlist.curation import is_chimeric_system

    assert is_chimeric_system("Mus musculus C57BL/6", "Mus musculus") is False
    assert is_chimeric_system("Canis lupus familiaris", "Canis sp.") is False
    assert is_chimeric_system("Sus scrofa", "Sus sp.") is False


def test_is_chimeric_pathogen_source_is_not_chimeric():
    """Viral / bacterial / parasite peptides on a host MHC are
    ordinary infection biology, not engineered cross-species systems.
    Returning ``True`` here would silently misroute every infection
    study into the chimeric bucket."""
    from hitlist.curation import is_chimeric_system

    for src in (
        "Severe acute respiratory syndrome coronavirus 2",
        "Hepatitis B virus",
        "Mycobacterium tuberculosis",
        "Mycobacterium tuberculosis H37Rv",
        "Influenza A virus",
        "Human betaherpesvirus 5",
        "human gammaherpesvirus 4",
        "Fusobacterium nucleatum",
        "Hepacivirus hominis",
        "Eikenella corrodens",
        "Plasmodium falciparum",
        "adeno-associated virus 2",
        "Vaccinia virus WR",
        "SARS-CoV1",
    ):
        assert is_chimeric_system(src, "Homo sapiens") is False, (
            f"pathogen source {src!r} flagged as chimeric"
        )


def test_is_chimeric_unknown_or_empty_is_not_chimeric():
    """Chimerism is a positive claim — if we don't have both halves
    of the proteome/MHC pair, the flag stays False rather than
    guessing."""
    from hitlist.curation import is_chimeric_system

    assert is_chimeric_system("", "Homo sapiens") is False
    assert is_chimeric_system("Homo sapiens", "") is False
    assert is_chimeric_system("unidentified", "Homo sapiens") is False
    assert is_chimeric_system("   ", "Homo sapiens") is False


def test_is_chimeric_same_species_is_not_chimeric():
    """The vast majority of rows: human peptides on human MHC, mouse
    on mouse, etc. Flag must stay False."""
    from hitlist.curation import is_chimeric_system

    assert is_chimeric_system("Homo sapiens", "Homo sapiens") is False
    assert is_chimeric_system("Mus musculus", "Mus musculus") is False


def test_is_chimeric_xenogeneic_animal_systems():
    """Comparative-immunopeptidomics studies that put human peptides
    onto a non-human MHC (canine, primate, equine) — engineered
    cross-species, must flag True."""
    from hitlist.curation import is_chimeric_system

    assert is_chimeric_system("Homo sapiens", "Macaca mulatta") is True
    assert is_chimeric_system("Homo sapiens", "Canis sp.") is True
    assert is_chimeric_system("Mus musculus", "Equus caballus") is True


# ── is_xenograft (#46) ───────────────────────────────────────────────────


def test_is_xenograft_tumor_in_foreign_host():
    """A human or dog tumor grown in a mouse host, displaying its own (non-host)
    MHC, decouples proteome from host species — a xenograft."""
    from hitlist.curation import is_xenograft

    # human tumor in mouse, human (engineered) HLA on the grafted cells
    assert is_xenograft("Homo sapiens", "Mus musculus (mouse)", "Homo sapiens") is True
    # dog tumor in mouse, human HLA
    assert is_xenograft("Canis lupus familiaris", "Mus musculus", "Homo sapiens") is True


def test_is_xenograft_native_host_is_not_xenograft():
    """Same-genus source/host (incl. substrains) is not a xenograft."""
    from hitlist.curation import is_xenograft

    assert is_xenograft("Homo sapiens", "Homo sapiens (human)", "Homo sapiens") is False
    assert is_xenograft("Mus musculus", "Mus musculus C57BL/6", "Mus musculus") is False


def test_is_xenograft_heterologous_antigen_on_native_cells_is_not_xenograft():
    """A foreign antigen presented by the host's OWN native cells (host genus
    == MHC genus) is a heterologous-antigen study, not a xenograft — e.g.
    bovine allergen on a human-MHC human cell."""
    from hitlist.curation import is_xenograft

    assert is_xenograft("Bos taurus", "Homo sapiens (human)", "Homo sapiens") is False
    assert is_xenograft("Equus caballus", "Homo sapiens", "Homo sapiens") is False


def test_is_xenograft_pathogen_source_is_not_xenograft():
    """A viral/bacterial antigen source on an animal host is ordinary
    infection biology (the cells are the host's own), not a xenograft."""
    from hitlist.curation import is_xenograft

    assert (
        is_xenograft(
            "Severe acute respiratory syndrome coronavirus 2", "Homo sapiens", "Homo sapiens"
        )
        is False
    )
    assert is_xenograft("Mycobacterium tuberculosis", "Homo sapiens", "Homo sapiens") is False


def test_is_xenograft_empty_is_false():
    from hitlist.curation import is_xenograft

    assert is_xenograft("", "Mus musculus", "Homo sapiens") is False
    assert is_xenograft("Homo sapiens", "", "Homo sapiens") is False
    assert is_xenograft("Homo sapiens", "Mus musculus", "") is False
    assert is_xenograft("unidentified", "Mus musculus", "Homo sapiens") is False


# ── is_engineered_mhc ────────────────────────────────────────────────────


def test_is_engineered_mhc_hla_transgenic_rat():
    """HLA-B27-Tg rat: rat tissue, rat host, human HLA transgene.
    Host genus matches source genus, MHC is heterologous → engineered."""
    from hitlist.curation import is_engineered_mhc

    assert (
        is_engineered_mhc("Rattus norvegicus", "Homo sapiens", "Rattus norvegicus (brown rat)")
        is True
    )
    # Lewis-strain host string must collapse to rat genus.
    assert is_engineered_mhc("Rattus norvegicus", "Homo sapiens", "Rattus norvegicus Lewis") is True


def test_is_engineered_mhc_neth2pan_training():
    """NetH2pan (PMID 29615400): synthetic human peptides bound by
    mouse MHC, recorded with human host. The MHC is non-native to
    the host → engineered."""
    from hitlist.curation import is_engineered_mhc

    assert is_engineered_mhc("Homo sapiens", "Mus musculus", "Homo sapiens (human)") is True


def test_is_engineered_mhc_lewis_rat_eae_with_gp_mbp_is_not_engineered():
    """The 4 GP-MBP / Lewis-rat EAE rows are heterologous-antigen, NOT
    engineered-MHC. Lewis rats present guinea-pig MBP on their own
    native RT1.B^L MHC. Host genus matches the MHC, not the source —
    the entire point of the engineered-vs-heterologous split (#226)."""
    from hitlist.curation import is_engineered_mhc

    assert (
        is_engineered_mhc("Cavia porcellus", "Rattus sp.", "Rattus norvegicus (brown rat)") is False
    )


def test_is_engineered_mhc_heterologous_allergens_are_not_engineered():
    """Allergen / heterologous-antigen studies (horse Equ c 1 on HLA,
    bovine antigens on human / mouse MHC) present a foreign protein
    on the host's native MHC — must NOT collide with engineered_mhc."""
    from hitlist.curation import is_engineered_mhc

    # PMID 17517108: horse allergen on HLA, human host
    assert is_engineered_mhc("Equus caballus", "Homo sapiens", "Homo sapiens (human)") is False
    # PMID 30573663: bovine antigen on HLA-DO, human host
    assert is_engineered_mhc("Bos taurus", "Homo sapiens", "Homo sapiens (human)") is False
    # PMID 26495903: bovine antigen on mouse MHC-II, mouse host
    assert is_engineered_mhc("Bos taurus", "Mus musculus", "Mus musculus BALB/cAnN") is False


def test_is_engineered_mhc_requires_chimerism():
    """Same-species rows (Hsap/Hsap/Hsap, Mmus/Mmus/Mmus) are not
    chimeric and therefore never engineered_mhc. The function must
    short-circuit cheaply on the common case."""
    from hitlist.curation import is_engineered_mhc

    assert is_engineered_mhc("Homo sapiens", "Homo sapiens", "Homo sapiens (human)") is False
    assert is_engineered_mhc("Mus musculus", "Mus musculus", "Mus musculus C57BL/6") is False


def test_is_engineered_mhc_missing_host_is_conservative_false():
    """Without a host signal the engineered-vs-heterologous distinction
    cannot be made. Default to False rather than guess — the broader
    is_chimeric flag still surfaces these rows for downstream consumers
    that want the union."""
    from hitlist.curation import is_engineered_mhc

    assert is_engineered_mhc("Rattus norvegicus", "Homo sapiens", "") is False
    assert is_engineered_mhc("Rattus norvegicus", "Homo sapiens", "   ") is False
    assert is_engineered_mhc("Rattus norvegicus", "Homo sapiens", "unidentified") is False


def test_is_engineered_mhc_pathogen_source_is_not_engineered():
    """Pathogen sources are never chimeric (gated by the host-genus
    whitelist) and therefore never engineered_mhc, regardless of what
    host is recorded."""
    from hitlist.curation import is_engineered_mhc

    assert (
        is_engineered_mhc(
            "Severe acute respiratory syndrome coronavirus 2",
            "Homo sapiens",
            "Homo sapiens (human)",
        )
        is False
    )


# ── is_non_peptide_ligand (#228) ─────────────────────────────────────────


def test_is_non_peptide_ligand_cd1_family():
    """CD1a/b/c/d/e present lipids and glycolipids to NKT and CD1-restricted
    T cells. IEDB curates these rows with chemical names in the peptide
    column (e.g. sulfatide, mycolic acid) — must flag True."""
    from hitlist.curation import is_non_peptide_ligand

    for s in (
        "human-CD1a",
        "human-CD1b",
        "human-CD1c",
        "human-CD1d",
        "mouse-CD1d",
        "cattle-CD1d",
    ):
        assert is_non_peptide_ligand(s) is True, f"{s!r} should flag"


def test_is_non_peptide_ligand_cd1_subtype_digits_and_dash():
    """IEDB curates a few CD1 paralogues with numeric subtype suffixes
    (mouse-CD1d1, mouse-CD1d2, cattle-CD1b3) and chicken-CD1-2 in
    dash-numeric form. The naive ``\\bCD1[abcd]?\\b`` regex from the
    issue would miss these — the implemented regex must catch them all."""
    from hitlist.curation import is_non_peptide_ligand

    for s in ("mouse-CD1d1", "mouse-CD1d2", "cattle-CD1b3", "chicken-CD1-2"):
        assert is_non_peptide_ligand(s) is True, f"{s!r} should flag"


def test_is_non_peptide_ligand_mr1_and_mutants():
    """MR1 presents riboflavin-derived metabolites to MAIT cells.
    Mutant strings (``human-MR1 K43A mutant``) must still flag —
    regex anchors on the gene token, not the trailing annotation."""
    from hitlist.curation import is_non_peptide_ligand

    assert is_non_peptide_ligand("human-MR1") is True
    assert is_non_peptide_ligand("cattle-MR1") is True
    assert is_non_peptide_ligand("human-MR1 K43A mutant") is True
    assert is_non_peptide_ligand("human-MR1 R9H mutant") is True
    assert is_non_peptide_ligand("mouse-CD1d Y73H mutant") is True


def test_is_non_peptide_ligand_mic_ulbp_raet1_nkg2_hfe():
    """MIC{A,B}, RAET1*, ULBP* are stress ligands for the NKG2D NK
    receptor — not peptide presenters. NKG2[A-C] and HFE round out the
    non-peptide-presenting whitelist from the issue."""
    from hitlist.curation import is_non_peptide_ligand

    for s in ("MICA", "MICB", "RAET1L", "ULBP1", "ULBP3", "NKG2A", "NKG2C", "HFE"):
        assert is_non_peptide_ligand(s) is True, f"{s!r} should flag"


def test_is_non_peptide_ligand_classical_mhc_does_not_flag():
    """Classical class I/II and class-Ib peptide presenters (HLA-A/B/C/E/F/G,
    H2-K/D/L/Q/T, Patr-AL, BoLA-*, SLA-*, DLA-*) all present peptides —
    none must be flagged. H2-M3 is class Ib but presents N-formyl peptides
    and is intentionally excluded from the non-peptide regex (see #228)."""
    from hitlist.curation import is_non_peptide_ligand

    for s in (
        "HLA-A*02:01",
        "HLA-B*07:02",
        "HLA-C*07:01",
        "HLA-DRB1*04:01",
        "HLA-DPB1*04:01",
        "HLA-E*01:03",
        "HLA-F*01:01",
        "HLA-G*01:01",
        "H2-Kb",
        "H2-Db",
        "H2-Q1",
        "H2-T23*a",
        "H2-M3",  # class Ib, N-formyl peptides — NOT a non-peptide presenter
        "Patr-AL",
        "BoLA-1*02301",
        "SLA-1*02:01",
    ):
        assert is_non_peptide_ligand(s) is False, f"{s!r} must not flag"


def test_is_non_peptide_ligand_empty_input():
    """Empty / missing restriction strings cannot be classified — return
    False rather than guessing (matches is_chimeric_system convention)."""
    from hitlist.curation import is_non_peptide_ligand

    assert is_non_peptide_ligand("") is False
    assert is_non_peptide_ligand(None) is False  # type: ignore[arg-type]


@pytest.mark.parametrize(
    "restriction",
    ["HLA-BTN3A1", "human-BTN3A2", "BTN3A3 R351H mutant", "BTN2A1", "btn3a1"],
)
def test_phosphoantigen_butyrophilins_are_not_peptide_mhc(restriction):
    from hitlist.curation import is_non_peptide_ligand

    assert is_non_peptide_ligand(restriction)


@pytest.mark.parametrize("restriction", ["BTN3A10", "BTN3A4", "BTN2A2", "BTN1A1", "XBTN3A1"])
def test_butyrophilin_rule_does_not_guess_from_family_prefix(restriction):
    from hitlist.curation import is_non_peptide_ligand

    assert not is_non_peptide_ligand(restriction)


# ── Per-sample attribution / donor-set promotion (#45) ───────────────────


def test_parse_sample_mhc_field_bare_format():
    """Patient ms_samples entries store the donor genotype as a bare
    space-joined string (``"A*02:01 A*24:02 ..."``).  The parser must
    canonicalize each token to ``"HLA-A*02:01"`` form via mhcgnomes
    so the set matches what set expansion expects."""
    from hitlist.curation import _parse_sample_mhc_field

    out = _parse_sample_mhc_field("A*02:01 A*24:02 B*15:01 B*44:02 C*05:01 C*07:02")
    assert out == frozenset(
        {
            "HLA-A*02:01",
            "HLA-A*24:02",
            "HLA-B*15:01",
            "HLA-B*44:02",
            "HLA-C*05:01",
            "HLA-C*07:02",
        }
    )


def test_parse_sample_mhc_field_prefixed_format():
    """ms_samples on the 721.221 mono-allelic entries store HLA-prefixed
    single alleles. Same parser must accept both shapes interchangeably."""
    from hitlist.curation import _parse_sample_mhc_field

    assert _parse_sample_mhc_field("HLA-A*02:01") == frozenset({"HLA-A*02:01"})
    assert _parse_sample_mhc_field("") == frozenset()
    assert _parse_sample_mhc_field(None) == frozenset()


def test_parse_sample_mhc_field_homozygous():
    """Homozygous donor (e.g. MEL2: A*01:01 / A*01:01) collapses to a
    single allele in the set — ``frozenset`` deduplicates by design."""
    from hitlist.curation import _parse_sample_mhc_field

    out = _parse_sample_mhc_field("A*01:01 A*01:01 B*38:01 B*56:01 C*01:02 C*06:02")
    # A*01:01 collapses; set size 5 (not 6).
    assert "HLA-A*01:01" in out
    assert len(out) == 5


def test_classify_allele_resolution_donor_set():
    """Multi-allele set strings (semicolon-joined 4-digit alleles) classify
    as ``donor_set`` — strictly more specific than ``class_only``, less
    specific than ``four_digit``.  Order in ALLELE_RESOLUTION_ORDER puts
    ``donor_set`` between ``four_digit`` and ``two_digit``."""
    from hitlist.curation import (
        ALLELE_RESOLUTION_ORDER,
        allele_resolution_rank,
        classify_allele_resolution,
    )

    assert classify_allele_resolution("HLA-A*02:01;HLA-A*03:01") == "donor_set"
    assert (
        classify_allele_resolution("HLA-A*01:01;HLA-A*32:01;HLA-B*15:01;HLA-C*03:03;HLA-C*03:04")
        == "donor_set"
    )
    # Single allele still resolves to four_digit.
    assert classify_allele_resolution("HLA-A*02:01") == "four_digit"
    # Class label still resolves to class_only.
    assert classify_allele_resolution("HLA class I") == "class_only"
    # Trailing semicolon with single allele is not a set.
    assert classify_allele_resolution("HLA-A*02:01;") != "donor_set"
    # Rank ordering: donor_set is between four_digit and two_digit.
    assert (
        allele_resolution_rank("four_digit")
        < allele_resolution_rank("donor_set")
        < allele_resolution_rank("two_digit")
        < allele_resolution_rank("class_only")
    )
    assert "donor_set" in ALLELE_RESOLUTION_ORDER


def test_expand_allele_set_attributed_alleles_narrows():
    """``attributed_alleles`` (per-peptide attribution from #45) takes
    priority over ``host_mhc_types`` and the PMID pool, narrowing the
    set to that specific subset of donor alleles.  Provenance becomes
    ``peptide_attribution``."""
    from hitlist.curation import expand_allele_set

    # Disease-wide host_mhc_types (18-allele MEL union)
    disease_union = (
        "HLA-A*01:01;HLA-A*02:01;HLA-A*02:02;HLA-A*03:01;HLA-A*24:02;"
        "HLA-B*13:02;HLA-B*15:01;HLA-B*27:05;HLA-B*38:01;HLA-B*40:02;"
        "HLA-B*44:02;HLA-B*47:01;HLA-B*56:01;HLA-C*01:02;HLA-C*02:02;"
        "HLA-C*05:01;HLA-C*06:02;HLA-C*07:02"
    )
    # Per-peptide attribution narrows to MEL2's 5-allele genotype.
    mel2 = frozenset({"HLA-A*01:01", "HLA-B*38:01", "HLA-B*56:01", "HLA-C*01:02", "HLA-C*06:02"})

    out_set, prov, size = expand_allele_set("HLA class I", disease_union, 31844290, "I", mel2)
    assert prov == "peptide_attribution"
    assert size == 5
    assert set(out_set.split(";")) == set(mel2)


def test_expand_allele_set_no_attribution_falls_back_to_sample_match():
    """Without attribution, a class-only row falls back to the
    ``sample_allele_match`` path (donor's typed alleles from
    ``host_mhc_types``).  Same row, different provenance and broader set."""
    from hitlist.curation import expand_allele_set

    disease_union = "HLA-A*01:01;HLA-A*02:01;HLA-B*38:01;HLA-B*56:01;HLA-C*01:02;HLA-C*06:02"
    _, prov, size = expand_allele_set("HLA class I", disease_union, 31844290, "I", frozenset())
    assert prov == "sample_allele_match"
    assert size == 6


def test_attribute_peptide_to_sample_alleles_known_sarkizova_peptide():
    """End-to-end: a known Sarkizova MEL2 peptide pulls back MEL2's
    typed-allele set (from the ms_samples mhc field via
    _pmid_sample_alleles, after the bare-format normalization fix)."""
    from hitlist.curation import attribute_peptide_to_sample_alleles

    # AAAAAAAAAAAAAAPAP is uniquely attributed to MEL2 in the Sup_Data2 CSV
    out = attribute_peptide_to_sample_alleles(31844290, "AAAAAAAAAAAAAAPAP")
    # MEL2 genotype is A*01:01 / A*01:01 / B*38:01 / B*56:01 / C*01:02 / C*06:02
    # — 5 alleles after homozygous-A collapse.
    assert out == frozenset(
        {"HLA-A*01:01", "HLA-B*38:01", "HLA-B*56:01", "HLA-C*01:02", "HLA-C*06:02"}
    )


@pytest.mark.parametrize("peptide", ["SEIDVKDVL", "SEVAVSAMGPL", "REYATDVDLEFV"])
def test_bola_prediction_attribution_keeps_measured_a19_genotype(peptide):
    """#414: a predicted restriction is not the animal's measured genotype."""
    from hitlist.curation import attribute_peptide_to_per_sample_typings

    assert attribute_peptide_to_per_sample_typings(36423003, peptide) == (
        (
            "2824TP (T. parva-infected, BoLA-I A19)",
            frozenset({"BoLA-2*016:01", "BoLA-6*014:02"}),
        ),
    )


def test_attribute_peptide_to_sample_alleles_unknown_peptide_returns_empty():
    """Peptides not in the attribution CSV (or PMIDs without an
    attribution registered) return the empty frozenset — caller falls
    back to ``host_mhc_types`` / pmid pool via expand_allele_set."""
    from hitlist.curation import attribute_peptide_to_sample_alleles

    assert attribute_peptide_to_sample_alleles(31844290, "ZZZZZZZZZZ") == frozenset()
    assert attribute_peptide_to_sample_alleles(0, "ANYTHING") == frozenset()
    assert attribute_peptide_to_sample_alleles(31844290, "") == frozenset()


def test_attribute_peptide_to_per_sample_typings_single_donor():
    """Single-donor attribution returns one (label, alleles) pair."""
    from hitlist.curation import attribute_peptide_to_per_sample_typings

    out = attribute_peptide_to_per_sample_typings(31844290, "AAAAAAAAAAAAAAPAP")
    assert len(out) == 1
    label, alleles = out[0]
    assert label == "MEL2 (13240-005)"
    assert alleles == frozenset(
        {"HLA-A*01:01", "HLA-B*38:01", "HLA-B*56:01", "HLA-C*01:02", "HLA-C*06:02"}
    )


def test_attribute_peptide_to_per_sample_typings_multi_donor():
    """SLLQHLIGL is attributed to 3 Sarkizova patient samples (MEL3,
    MEL15, OV1).  The new helper preserves per-donor identity instead
    of merging into a 15-allele union (issue #236), so the scanner can
    emit one observation row per matched donor.

    Returned tuples are sorted by ``sample_label`` for deterministic
    emission order.
    """
    from hitlist.curation import attribute_peptide_to_per_sample_typings

    out = attribute_peptide_to_per_sample_typings(31844290, "SLLQHLIGL")
    assert len(out) == 3
    labels = [label for label, _ in out]
    assert labels == sorted(labels)
    assert set(labels) == {"MEL3 (13240-006)", "MEL15 (13240-015)", "OV1 (CP-594_v1)"}

    by_label = dict(out)
    assert by_label["MEL3 (13240-006)"] == frozenset(
        {"HLA-A*02:01", "HLA-A*03:01", "HLA-B*27:05", "HLA-B*47:01", "HLA-C*01:02", "HLA-C*06:02"}
    )
    assert by_label["MEL15 (13240-015)"] == frozenset(
        {"HLA-A*02:01", "HLA-A*02:02", "HLA-B*13:02", "HLA-B*40:02", "HLA-C*02:02", "HLA-C*06:02"}
    )
    assert by_label["OV1 (CP-594_v1)"] == frozenset(
        {"HLA-A*02:01", "HLA-A*24:02", "HLA-B*35:03", "HLA-B*44:02", "HLA-C*05:01", "HLA-C*12:03"}
    )


def test_attribute_peptide_to_per_sample_typings_empty_cases():
    """Unknown peptide / unknown PMID / empty peptide → empty tuple."""
    from hitlist.curation import attribute_peptide_to_per_sample_typings

    assert attribute_peptide_to_per_sample_typings(31844290, "ZZZZZZZZZZ") == ()
    assert attribute_peptide_to_per_sample_typings(0, "ANYTHING") == ()
    assert attribute_peptide_to_per_sample_typings(31844290, "") == ()


def test_attribute_peptide_to_per_sample_typings_all_donors_lack_typing(monkeypatch):
    """If a peptide is attributed to N donors but ALL of them have empty
    curated typings (e.g. partially-curated pmid_overrides entry), the
    helper drops the peptide entirely and returns ``()`` — the scanner
    then falls through to the standard non-attributed single-row path
    instead of emitting zero rows."""
    from hitlist import curation

    monkeypatch.setattr(
        curation,
        "_pmid_peptide_attributions",
        lambda pmid_int: {"FAKEPEP": frozenset({"ghost_donor_a", "ghost_donor_b"})},
    )
    monkeypatch.setattr(
        curation,
        "_pmid_sample_alleles",
        lambda pmid_int: {},  # neither ghost donor has a typing
    )
    curation.peptide_typings_for_pmid.cache_clear()
    try:
        assert curation.attribute_peptide_to_per_sample_typings(99999, "FAKEPEP") == ()
    finally:
        curation.peptide_typings_for_pmid.cache_clear()


def test_curated_monoallelic_batch1_33b():
    """#33b/#35 batch 1: four mono-allelic cell-line / soluble-HLA studies
    classify as mono-allelic cell-line samples with the expected host."""
    cases = [
        (26360328, "B cell", "HLA-B*51:01", "721.221"),
        (20112406, "Epithelial cell", "HLA-B*27:05", None),  # soluble HLA (method)
        (26929215, "C1R cells-B cell", "HLA-B*27:09", "C1R"),
    ]
    for pmid, cell_name, allele, host in cases:
        flags = classify_ms_row(
            "", "", "Cell Line / Clone", cell_name=cell_name, pmid=pmid, mhc_restriction=allele
        )
        assert flags["src_cell_line"] is True, pmid
        assert flags["is_monoallelic"] is True, pmid
        if host is not None:
            assert flags["monoallelic_host"] == host, pmid


def test_ebv_lcl_mono_host_is_not_cancer():
    """Systemic fix: mono-allelic data on a known EBV-LCL host (721.221, C1R)
    classifies as ebv_lcl (src_cancer=False) regardless of how IEDB tagged the
    culture condition — auto-correcting all 721.221/C1R studies without
    per-PMID overrides.  Host resolved either from cell_name directly or via a
    PMID mono_allelic_host override."""
    cases = [
        # cell_name resolves the host directly (no PMID needed → systemic).
        ("721.221", "", "HLA-A*02:01"),
        ("C1R cells-B cell", "", "HLA-B*27:05"),
        # PMID mono_allelic_host override resolves the host (marquee studies
        # whose IEDB cell_name is the imprecise "B cell").
        ("B cell", 31844290, "HLA-A*02:01"),  # Sarkizova 2020 (721.221)
        ("B cell", 28228285, "HLA-A*02:01"),  # Abelin 2017 (721.221)
    ]
    for cell_name, pmid, allele in cases:
        flags = classify_ms_row(
            "", "", "Cell Line / Clone", cell_name=cell_name, pmid=pmid, mhc_restriction=allele
        )
        assert flags["is_monoallelic"] is True, (cell_name, pmid)
        assert flags["src_ebv_lcl"] is True, (cell_name, pmid)
        assert flags["src_cancer"] is False, (cell_name, pmid)


def test_k562_mono_host_stays_cancer():
    """K562 is a CML leukemia line (genuinely malignant) used as a mono-allelic
    host — it must NOT be swept into the ebv_lcl reclassification."""
    flags = classify_ms_row(
        "", "", "Cell Line / Clone", cell_name="K562 cells", mhc_restriction="HLA-A*24:02"
    )
    assert flags["is_monoallelic"] is True
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cancer"] is True


def test_pmid_source_organism_curation():
    """#307: per-PMID source-organism curation returns (source_organism, species)
    for explicitly-curated self-peptidome PMIDs, and ('', '') otherwise."""
    from hitlist.curation import pmid_source_organism

    # Curated animal self-peptidomes.
    assert pmid_source_organism(33460454) == ("Sarcophilus harrisii", "Sarcophilus harrisii")
    assert pmid_source_organism(28188227) == ("Rattus norvegicus", "Rattus norvegicus")
    # Human HCC tumour self-peptidome (IEDB left source_organism blank on 4/5 rows).
    assert pmid_source_organism(31887370) == ("Homo sapiens", "Homo sapiens")
    # No source_organism key -> no backfill (the scanner gates on the first
    # element, so a random-library assay like the pig SLA-I study stays blank).
    assert pmid_source_organism(35296092)[0] == ""
    # Unknown / empty PMID.
    assert pmid_source_organism(999999999) == ("", "")
    assert pmid_source_organism("") == ("", "")


def test_source_organism_override_no_classification_side_effects():
    """#307: the source-organism-only override entries (33460454 devil, 28188227
    transgenic rat) carry no `override`/`rules`, so they must NOT change
    classification — a row from those PMIDs classifies as if it had no entry."""
    from hitlist.curation import classify_ms_row

    flags = classify_ms_row("No immunization", "", "", "", "", pmid=33460454)
    assert flags["src_cancer"] is False
    assert flags["src_ebv_lcl"] is False
    assert flags["src_cell_line"] is False


def test_pmid_provenance_other_celltype_lineage_fills():
    """Per-paper-verified lineage fills for IEDB "Other"-cell_name cell lines
    (so they group by cell type instead of "(unspecified type)"), including
    corrections of IEDB mislabels (18991276 is B-LCLs, not the recorded melanoma)."""
    from hitlist.curation import pmid_provenance

    expect = {
        22872234: "Pancreatic beta cell",
        22869377: "Melanocyte",
        25428507: "Fibroblast",
        29475511: "Macrophage",
        18991276: "B-cell",  # IEDB "skin melanoma" label is wrong — B-LCLs
        31921104: "Melanocyte",
        33372950: "Epithelial cell",
        29176828: "Glial cell",
    }
    for pmid, cell_type in expect.items():
        assert pmid_provenance(pmid).get("cell_name") == cell_type, pmid


def test_pmid_provenance_31575892_blood_aml_cell_line():
    """#314: per-PMID provenance fills source_tissue / disease / culture_condition
    for the Nyambura 2019 myeloid-leukemia study (MUTZ-3 + THP-1) that IEDB left
    blank.  With culture_condition filled, the rows classify as a cancer cell
    line rather than landing in the '(unspecified)' bucket."""
    from hitlist.curation import classify_ms_row, pmid_provenance

    prov = pmid_provenance(31575892)
    assert prov["source_tissue"] == "Blood"
    assert prov["disease"] == "acute myeloid leukemia"
    assert prov["culture_condition"] == "Cell Line / Clone"
    flags = classify_ms_row(
        "No immunization",
        prov["disease"],
        prov["culture_condition"],
        prov["source_tissue"],
        "",
        pmid=31575892,
    )
    assert flags["src_cancer"] is True
    assert flags["src_cell_line"] is True


def test_pmid_provenance_other_coded_cell_lines_get_cell_name():
    """#36 "Other": IEDB logged these papers' cells as the "Other" sentinel.
    Per-PMID provenance curates a real cell_name so they no longer roll up into
    the "(unspecified type)" bucket — melanoma lines to the Melanocyte lineage,
    SaOS-2 to its named osteosarcoma line."""
    from hitlist.curation import pmid_provenance

    assert pmid_provenance(25645385)["cell_name"] == "Melanocyte"  # Pritchard 3 melanoma lines
    assert pmid_provenance(34290406)["cell_name"] == "Melanocyte"  # Oliveira pdMel-CLs
    assert pmid_provenance(36010968)["cell_name"] == "SaOS-2"  # Vadakekolathu osteosarcoma


def test_scanner_treats_other_cell_name_as_fillable():
    """The scanner counts IEDB's "Other"/"unknown"/blank sentinels as unresolved
    so a curated cell_name replaces them (not just truly-empty values)."""
    from hitlist.cell_name_parser import _UNINFORMATIVE_CELL_NAMES

    assert {"", "other", "unknown", "unknown/unspecified"} <= _UNINFORMATIVE_CELL_NAMES


# ── mhcgnomes-derived MHC class / allele parsing (#363) ────────────────


def test_mhc_class_of_separates_classical_from_non_classical():
    """mhcgnomes' fine taxonomy (Ia / Ib / Id / IIa) maps onto the three
    tokens the corpus uses.  Folding Ib into I would make --mhc-class I
    silently sweep up HLA-E rows."""
    from hitlist.curation import mhc_class_of

    assert mhc_class_of("HLA-A*02:01") == "I"
    assert mhc_class_of("H2-K*b") == "I"
    assert mhc_class_of("HLA-DRB1*15:01") == "II"
    assert mhc_class_of("HLA-E*01:03") == "non-classical"
    assert mhc_class_of("HLA-G*01:01") == "non-classical"
    assert mhc_class_of("H2-Q1") == "non-classical"
    assert mhc_class_of("MR1") == "non-classical"
    assert mhc_class_of("") == ""


def test_mhc_class_of_resolves_donor_sets_only_when_consistent():
    """Semicolon-joined donor sets (#45) resolve from their components,
    and stay unknown when the components disagree."""
    from hitlist.curation import mhc_class_of

    assert mhc_class_of("HLA-DQB1*03:01;HLA-DRB1*15:01") == "II"
    assert mhc_class_of("HLA-A*02:01;HLA-B*15:01") == "I"
    assert mhc_class_of("HLA-A*02:01;HLA-DRB1*15:01") == ""


def test_mhc_class_of_does_not_derive_from_class_or_serotype_labels():
    """#376: only molecule-level designations can replace source class.

    A class sentinel or serotype carries useful coarse information but is
    not an independently identified molecule, so its class remains source
    reported rather than claiming derived provenance.
    """
    from hitlist.curation import mhc_class_of

    assert mhc_class_of("HLA class I") == ""
    assert mhc_class_of("HLA-A2") == ""


def test_resolve_mhc_annotation_uses_context_without_overriding_explicit_species():
    """#382: context refines ambiguity but explicit chimeric MHC survives."""
    from hitlist.curation import resolve_mhc_annotation

    contextual = resolve_mhc_annotation("class I", "I", "Bos taurus")
    assert contextual.mhc_species == "Bos taurus"
    assert contextual.mhc_species_source == "context"
    assert contextual.mhc_species_context_disagrees is True
    assert contextual.mhc_class == "I"
    assert contextual.mhc_class_source == "export"

    refined = resolve_mhc_annotation("BoLA class I", "I", "Bos taurus")
    assert refined.mhc_species == "Bos taurus"
    assert refined.mhc_species_source == "context"
    # Bos sp. and Bos taurus are compatible, so refinement is not a conflict.
    assert refined.mhc_species_context_disagrees is False

    engineered = resolve_mhc_annotation("HLA-A*02:01", "I", "Mus musculus")
    assert engineered.mhc_species == "Homo sapiens"
    assert engineered.mhc_species_source == "explicit"
    assert engineered.mhc_species_context_disagrees is False


def test_resolve_mhc_annotation_derives_class_and_preserves_reported_value():
    """#376: molecule truth wins, with the source assertion still visible."""
    from hitlist.curation import resolve_mhc_annotation

    caja = resolve_mhc_annotation("Caja-E", "I", "Callithrix jacchus")
    assert caja.mhc_class == "non-classical"
    assert caja.mhc_class_reported == "I"
    assert caja.mhc_class_source == "derived"
    assert caja.mhc_class_corrected is True

    fallback = resolve_mhc_annotation("HLA-B23", "I", "Homo sapiens")
    assert fallback.mhc_class == "I"
    assert fallback.mhc_class_source == "export"
    assert fallback.mhc_class_corrected is False


def test_resolve_mhc_annotation_derives_consistent_donor_sets():
    from hitlist.curation import resolve_mhc_annotation

    same = resolve_mhc_annotation(
        "HLA-DQB1*03:01;HLA-DRB1*15:01",
        "II",
        "Homo sapiens",
    )
    assert same.mhc_class == "II"
    assert same.mhc_class_source == "donor_set"
    assert same.mhc_species == "Homo sapiens"
    assert same.allele_resolution == "donor_set"

    mixed = resolve_mhc_annotation(
        "HLA-A*02:01;HLA-DRB1*15:01",
        "I",
        "Homo sapiens",
    )
    assert mixed.mhc_class == "I"
    assert mixed.mhc_class_source == "export"


def test_normalize_mhc_class_token_bridges_the_spelling_split():
    """The YAML writes 'non-classical', the IEDB export writes 'non
    classical'; they could never compare equal (#363)."""
    from hitlist.curation import normalize_mhc_class_token

    assert normalize_mhc_class_token("non classical") == "non-classical"
    assert normalize_mhc_class_token("non-classical") == "non-classical"
    assert normalize_mhc_class_token("I+II") == "I+II"
    assert normalize_mhc_class_token("") == ""


def test_extract_allele_tokens_is_species_agnostic():
    """The old regex encoded HLA's digit syntax and returned nothing for
    every non-human genotype."""
    from hitlist.curation import extract_allele_tokens

    assert extract_allele_tokens("H-2Kb H-2Db") == ["H2-K*b", "H2-D*b"]
    assert extract_allele_tokens("A*02:01 B*15:01") == ["HLA-A*02:01", "HLA-B*15:01"]
    assert extract_allele_tokens("Patr-AL") == ["Patr-AL"]


def test_extract_allele_tokens_rejects_free_text():
    """mhcgnomes resolves 'n/a' to the rat haplotype RT1-n/A, so accepting
    anything that merely parses would inject junk from prose fields."""
    from hitlist.curation import extract_allele_tokens

    assert extract_allele_tokens("51 HLA-I allotypes (see paper)") == []
    assert extract_allele_tokens("n/a") == []
    assert extract_allele_tokens("not typed") == []


def test_expand_allele_components_splits_pairs_via_mhcgnomes():
    from hitlist.curation import expand_allele_components

    out = expand_allele_components("HLA-DPB1*06:01/DPA1*01:03")
    assert out[0] == "HLA-DPB1*06:01/DPA1*01:03"
    assert "HLA-DPB1*06:01" in out
    assert "HLA-DPA1*01:03" in out
    # Class-I alleles pass through unchanged.
    assert expand_allele_components("HLA-A*02:01") == ["HLA-A*02:01"]


def test_is_class_only_token_recognizes_sentinels():
    from hitlist.curation import is_class_only_token

    assert is_class_only_token("HLA class I") is True
    assert is_class_only_token("MHC class II") is True
    assert is_class_only_token("unknown") is True
    assert is_class_only_token("HLA-A*02:01") is False


# ── Curated ms_samples self-consistency guards (#372, #374, #375) ──────


#: Samples whose declared mhc_class still contradicts their own alleles.
#: Tracked in #374; pinned here so *new* contradictions fail the build.
#:   - The "I+II" entries list only class-I alleles; their class-II
#:     genotype has to be read out of each paper's Methods.
def species_compatible(a: str, b: str) -> bool:
    """Test-side shim over :meth:`mhcgnomes.Species.compatible_with`."""
    import mhcgnomes

    resolved = mhcgnomes.Species.get(a)
    return resolved is not None and resolved.compatible_with(b)


#: Samples whose declared ``mhc_class`` is knowingly at odds with the
#: class derived from their own alleles.
#:
#: Empty, and worth keeping that way.  The eleven entries this held were
#: all #374 group 2: samples declaring ``I+II`` while listing only
#: class-I alleles.  None was a real contradiction — each study did
#: profile both classes, and the class-II alleles were simply missing
#: from the curation.  They came from the papers' own typing tables
#: (Nicholas 2022 S1 Table; Olsson 2021 Methods; Ghosh 2020 Results),
#: so the fix was to finish the typing rather than to weaken the
#: declaration.
_KNOWN_CLASS_MISMATCHES: set = set()


#: mhcgnomes result types that name a real MHC designation.  Alleles,
#: genes and pairs reach the allele join; serotypes and class-II loci are
#: valid curation but do not (#380).
#: ``Haplotype`` is deliberately absent: ``parse("I")`` resolves to one,
#: so admitting it would let a bare roman numeral pass as a curated
#: genotype.  ``Species`` is absent for the same reason (``parse("-")``).
_MHC_DESIGNATION_TYPES = frozenset(
    {"Allele", "Gene", "Pair", "Serotype", "Class2Locus", "MhcClass"}
)


def test_every_curated_mhc_token_names_an_mhc_designation():
    """#375: a typo in a curated ``mhc`` value silently produced an empty
    allele set — the sample then dropped out of the allele-level join and
    of _pmid_sample_alleles with no warning.  ``BL2*02`` (should be
    ``BLB2*02``), ``SLA-I`` and ``BoLA-I`` all did this.

    This is the *typo* half of that invariant; whether a well-formed
    value actually reaches the allele join is checked separately by
    :func:`test_curated_mhc_values_reach_the_allele_join`."""
    from hitlist.curation import _cached_parse, is_class_only_token
    from hitlist.export import generate_ms_samples_table

    empty = []
    for _, row in generate_ms_samples_table().iterrows():
        mhc = str(row.get("mhc") or "").strip()
        if not mhc or is_class_only_token(mhc):
            continue
        # Typo guard only.  ``_cached_parse(tok) is not None`` alone is
        # too weak — ``parse("I")`` yields a Haplotype and ``parse("SLA")``
        # a Species, neither of which is an MHC designation — so require
        # a real designation.  Whether the sample reaches the *allele*
        # join is a separate invariant, checked below.
        # Class-only components can accompany typed molecules: a study may
        # report class-I ligands without typing them and explicitly type DR.
        # Preserve each semicolon-delimited designation before word splitting.
        for component in mhc.split(";"):
            if is_class_only_token(component):
                continue
            for token in re.split(r"[\s,]+", component):
                if not token:
                    continue
                parsed = _cached_parse(token)
                if type(parsed).__name__ not in _MHC_DESIGNATION_TYPES:
                    empty.append((row["pmid"], row["sample_label"], token))
    assert not empty, f"curated mhc tokens that name nothing in the MHC ontology: {empty}"


def test_declared_mhc_class_agrees_with_the_sample_alleles():
    """#374: a sample's declared class must not contradict the class of
    its own alleles — three HLA-G transfectants were declared classical
    ``I`` and so were returned by ``--mhc-class I``."""
    from hitlist.curation import (
        _cached_parse,
        extract_allele_tokens,
        is_class_only_token,
        mhc_class_of,
        normalize_mhc_class_token,
    )
    from hitlist.export import generate_ms_samples_table

    unexpected: list = []
    flagged: set = set()
    for _, row in generate_ms_samples_table().iterrows():
        declared = normalize_mhc_class_token(str(row.get("mhc_class") or ""))
        mhc = str(row.get("mhc") or "")
        tokens = extract_allele_tokens(mhc)
        if not declared:
            continue
        derived = {mhc_class_of(t) for t in tokens} - {""}
        derived.update(
            normalize_mhc_class_token(str(getattr(_cached_parse(part.strip()), "mhc_class", "")))
            for part in mhc.split(";")
            if is_class_only_token(part)
        )
        derived.discard("")
        if derived and derived != set(declared.split("+")):
            key = (int(row["pmid"]), str(row["sample_label"]))
            flagged.add(key)
            if key not in _KNOWN_CLASS_MISMATCHES:
                unexpected.append((*key, declared, "+".join(sorted(derived))))
    assert not unexpected, f"new declared-vs-derived class contradictions: {unexpected}"
    # An allowlist entry that no longer contradicts must be removed, or it
    # becomes a permanent blanket exemption for that sample.
    stale = _KNOWN_CLASS_MISMATCHES - flagged
    assert not stale, f"resolved contradictions still allowlisted — remove them: {sorted(stale)}"


def test_hla_g_transfectants_are_non_classical():
    """Pin the #374 fix: HLA-G is class Ib, and the corpus already
    curates the sibling HLA-E / HLA-F / C1R HLA-G samples that way."""
    from hitlist.export import generate_ms_samples_table

    samples = generate_ms_samples_table()
    hla_g = samples[samples["sample_label"].astype(str).str.startswith("721.221-HLA-G")]
    assert len(hla_g) >= 3
    assert set(hla_g["mhc_class"]) == {"non-classical"}


#: Samples where the MHC species deliberately differs from the source
#: proteome species — engineered chimeric systems (#46), not errors.
_KNOWN_CHIMERIC_SAMPLES = {
    (26740625, "DCs from lymph nodes (HLA-DR1 transgenic mouse)"),
    # Human C1R cells presenting macaque Mamu-B*008:01. The sibling HLA-B27
    # arm is human on both axes and therefore does not belong here (#630).
    (26811146, "cell line expressing Mamu-B*008:01"),
    # Barnea 2017 (MCP): HLA-B*27 + human beta2m transgenic RAT spleen, in
    # vivo.  Host and eluted proteome are rat, the restricting molecule is a
    # human transgene — the textbook chimera.  Both arms became visible only
    # when the duplicate 28188227 blocks were consolidated (#438); before
    # that the entry carrying these samples was silently discarded at load.
    (28188227, "HLA-B27 transgenic rat spleen (WT)"),
    (28188227, "HLA-B27 transgenic rat spleen (ERAP1 KO)"),
    # Yair-Sabag 2018 also contains rat spleens carrying human HLA-B27;
    # these must stay separate from the paper's human HeLa/C1R transfectants.
    (29393594, "HLA-B27 transgenic rat spleens"),
    # PMID 42199926, Figure 1 and STAR Methods: human HLA-I KO cells
    # transduced with canine DLA; independently registered per condition.
    (42199926, "HCT116 DLA-88*003:02"),
    (42199926, "HCT116 DLA-88*012:01"),
    (42199926, "HCT116 DLA-88*501:01"),
}


def test_sample_mhc_species_matches_its_source_species():
    """Per-sample species validation, via the exported column.

    ``species`` is the *source proteome* axis and ``mhc_species`` is
    derived from the allele, so the two legitimately differ for
    engineered chimeras (a human HLA transgene in a mouse).  Everywhere
    else they must be compatible — PMID 41459947 is a Prussian carp
    study whose sample carried ``mhc: HLA class II``, i.e. human MHC on
    a fish, and nothing flagged it.

    This asserts on ``species_axes_agreement`` rather than re-deriving
    the comparison, so the column consumers read and the guard CI runs
    are the same implementation.  They were briefly two, and disagreed
    on 19 serotype/locus rows.
    """
    from hitlist.export import generate_ms_samples_table

    mismatches, flagged = [], set()
    for _, row in generate_ms_samples_table().iterrows():
        if row["species_axes_agreement"] != "false":
            continue
        key = (int(row["pmid"]), str(row["sample_label"]))
        flagged.add(key)
        if key not in _KNOWN_CHIMERIC_SAMPLES:
            mismatches.append((*key, row["species"], row["mhc_species"]))
    assert not mismatches, f"MHC species does not match source species: {mismatches}"
    stale = _KNOWN_CHIMERIC_SAMPLES - flagged
    assert not stale, f"samples no longer chimeric but still allowlisted: {sorted(stale)}"


def test_no_curated_mhc_token_has_an_inferred_species():
    """Curated genotypes must name their species, not let it be guessed.

    mhcgnomes reports how it decided (#116): ``explicit`` when the input
    named the species, ``default`` when it fell back to HLA for a bare
    human allele, ``inferred`` when it picked one by ranking candidates
    across species.  Only ``inferred`` is a hazard — it is what silently
    resolved ``BLB2*02`` to Japanese quail before mhcgnomes 3.39.0, and
    it would do the same for any future ambiguous symbol.

    ``default`` is fine and conventional: a bare ``A*03:01`` means the
    human allele, and 69 curated tokens rely on that.

    This replaces a set of assertions that pinned the *wrong* answers
    (``assert classify_mhc_species("BLB2*02") == "Coturnix japonica"``)
    purely so an upstream fix would fail loudly.  Now the rule is stated
    directly and does not need revisiting when upstream changes.
    """
    from hitlist.curation import _cached_parse, is_class_only_token
    from hitlist.export import generate_ms_samples_table

    inferred: list = []
    seen_sources: set = set()
    for _, row in generate_ms_samples_table().iterrows():
        mhc = str(row.get("mhc") or "").strip()
        if not mhc:
            continue
        tokens = [mhc] if is_class_only_token(mhc) else re.split(r"[\s;,]+", mhc)
        for token in tokens:
            if not token:
                continue
            parsed = _cached_parse(token)
            if parsed is None:
                continue
            # Read the attribute directly: a getattr(..., None) probe
            # would turn an upstream rename into an unconditional pass,
            # and this test would report green while curated tokens went
            # back to guessed species.
            source = parsed.species_source
            seen_sources.add(source)
            if source == "inferred":
                inferred.append((int(row["pmid"]), str(row["sample_label"]), token))
    assert not inferred, f"curated mhc tokens whose species was guessed: {inferred}"
    # The probe itself must be exercised, or the loop above proves nothing.
    assert "explicit" in seen_sources, f"species_source never reported 'explicit': {seen_sources}"


#: Samples whose curated ``mhc`` names a real MHC designation but not an
#: allele, so they never reach the allele-level join.  Serotypes
#: (``HLA-DR15``, ``HLA-DQ8``) and class-II loci (``SLA-DR``,
#: ``BoLA-DR``) are legitimate curation; tracked in #380.
_KNOWN_NON_ALLELE_SAMPLES = {
    (28467828, "HLA-DR15 immunopeptidome component"),
    (32796065, "BMDCs (PRRSV-infected)"),
    (32796065, "PAMs (PRRSV-infected)"),
    (32796065, "hilar lymph node (PRRSV-infected piglets)"),
    (33789985, "bovine cell lines (BoLA-DR)"),
    (34433824, "HLA-DQ8 immunopeptidome component"),
    (36423003, "T. parva-infected bovine lymphocyte lines (BoLA-DR)"),
}


def test_curated_mhc_values_reach_the_allele_join():
    """The #375 failure mode proper: a sample that yields no alleles drops
    out of ``_pmid_sample_alleles`` and the allele-level join silently.

    Distinct from the typo guard above — ``HLA-DR15`` parses perfectly
    well and still yields nothing.  Known non-participants are listed
    explicitly so the gap is visible rather than absorbed by a widened
    type filter.
    """
    from hitlist.curation import extract_allele_tokens, is_class_only_token
    from hitlist.export import generate_ms_samples_table

    no_alleles, flagged = [], set()
    for _, row in generate_ms_samples_table().iterrows():
        mhc = str(row.get("mhc") or "").strip()
        if not mhc or is_class_only_token(mhc):
            continue
        if extract_allele_tokens(mhc):
            continue
        key = (int(row["pmid"]), str(row["sample_label"]))
        flagged.add(key)
        if key not in _KNOWN_NON_ALLELE_SAMPLES:
            no_alleles.append((*key, mhc))
    assert not no_alleles, f"samples that silently yield no alleles: {no_alleles}"
    stale = _KNOWN_NON_ALLELE_SAMPLES - flagged
    assert not stale, f"samples now reaching the join but still allowlisted: {sorted(stale)}"


def test_mhcgnomes_species_compatibility_semantics():
    """Genus-string comparison is both too weak and too strong."""
    # Less specific, not contradictory — a direct ancestor.
    assert species_compatible("Bos taurus", "Bos sp.")
    assert species_compatible("Sus scrofa", "Sus sp.")
    assert species_compatible("Coturnix japonica", "Galliformes sp.")  # above genus
    # Siblings are rejected — deliberately.  These DO share an internal
    # node (Macaca mulatta and M. fascicularis are both children of
    # "Macaca sp."), but Mamu and Mafa are distinct MHC systems with
    # distinct prefixes and non-interchangeable allele sets, so an allele
    # from one on a sample curated as the other is a mislabel, not a
    # coarser description.  Only a direct ancestor/descendant relation
    # counts as compatible.
    assert not species_compatible("Macaca mulatta", "Macaca fascicularis")
    # Same rule.  Bubalus sits under Bos sp.[BoLA] because that node is
    # an MHC-nomenclature grouping rather than a clade — see
    # test_species_tree_is_prefix_scope_not_phylogeny.  These two are
    # still correctly rejected as siblings; a curated "Bos sp." against
    # a Bubu allele would not be.
    assert not species_compatible("Bos taurus", "Bubalus bubalis")
    # Cross-clade: the PMID 41459947 curation error, a fish study whose
    # sample carried the human class-II sentinel.
    assert not species_compatible("Carassius gibelio", "Homo sapiens")
    # Every species roots at Gnathostomata sp., so a shared root must not
    # make everything compatible.
    assert not species_compatible("Homo sapiens", "Gallus gallus")


def test_species_tree_is_prefix_scope_not_phylogeny():
    """Pin the two facts that make ``species_compatible`` interpretable.

    The tree is mostly taxonomic — 18 of the 22 largest internal nodes
    have ``prefix == taxon name`` — but a few are MHC-nomenclature
    groupings carrying a legacy prefix (``Bos sp.[BoLA]``,
    ``Primata sp.[NHP]``, ``Cetacea sp.[CELA]``, ``Rattus sp.[RT1]``,
    ``Mus sp.[MusSp]``).  Membership inside those follows naming
    practice, which is why ``species_compatible`` behaves as it does at
    those two nodes.
    """
    import mhcgnomes

    # Genuine clade nodes are taxonomic and behave as expected — this is
    # the common case, and it is what makes the tree usable here.
    assert mhcgnomes.Species.get("Carassius gibelio").parent.name == "Cyprinidae sp."
    assert species_compatible("Carassius gibelio", "Cyprinidae sp.")

    # Primata sp. was the exception, and upstream resolved it across two
    # releases.  3.40.0 corrected the tree (#122) so Homo sapiens is a
    # child of Primata sp., but simultaneously reimplemented
    # compatible_with in terms of naming scope, which kept the pair
    # incompatible (#125).  3.41.0 restored the ancestry relation
    # (#126), so a curated coarser taxon is now compatible with a more
    # specific allele, as it already was for Bos taurus / Bos sp.
    assert mhcgnomes.Species.get("Homo sapiens").parent.name == "Primata sp."
    assert species_compatible("Homo sapiens", "Primata sp.")

    # Bubalus is a different genus from Bos (different subtribe, even),
    # yet sits under Bos sp.[BoLA] because buffalo alleles are assigned
    # to BoLA loci by trans-species polymorphism.  Consequence: a Bubu
    # allele IS accepted against a curated "Bos sp.".  No corpus sample
    # hits this; pinned so the behaviour is deliberate, not a surprise.
    assert mhcgnomes.Species.get("Bubalus bubalis").parent.name == "Bos sp."
    assert species_compatible("Bos sp.", "Bubalus bubalis")
    # The specific-vs-specific comparison is still correctly rejected.
    assert not species_compatible("Bos taurus", "Bubalus bubalis")


def test_class_only_typed_samples_are_declared_not_incidental():
    """A class-only ``mhc`` skips the allele-join guard, so switching a
    sample to a sentinel silently removes it from that check.

    Rather than enumerate all 100 class-only samples, pin the ones #375
    converted, so the conversion stays deliberate.

    PMID 36423003 used to be pinned here too.  It was a genuine downgrade
    — IEDB carries real 4-digit BoLA alleles for it (#381) — and the pin
    said "until those are curated".  They now are: the study is split
    into one sample per cell line, each carrying that animal's haplotype,
    so no class-only sentinel remains to pin.
    """
    from hitlist.curation import extract_allele_tokens, is_class_only_token
    from hitlist.export import generate_ms_samples_table

    samples = generate_ms_samples_table().set_index(["pmid", "sample_label"])
    for key, mhc in (
        ((36146698, "SLA-I Lr-Hp 35.0/24 mod (porcine cell line, PRRSV-infected)"), "SLA class I"),
    ):
        value = str(samples.loc[key, "mhc"])
        assert value == mhc, f"{key} mhc changed: {value!r}"
        assert is_class_only_token(value), key
        assert extract_allele_tokens(value) == [], key


def test_mhc_species_of_resolves_every_designation_kind():
    """Serotypes and class-II loci name a species perfectly well, so the
    derivation must not filter to Allele/Gene/Pair — that reported ``""``
    for 19 curated rows whose species was never in doubt."""
    from hitlist.curation import mhc_species_of

    assert mhc_species_of("HLA-A*02:01 HLA-B*07:02") == "Homo sapiens"
    assert mhc_species_of("HLA-DR15") == "Homo sapiens"  # Serotype
    assert mhc_species_of("BoLA-DR") == "Bos sp."  # Class2Locus
    assert mhc_species_of("SLA class I") == "Sus sp."  # class-only sentinel
    assert mhc_species_of("Gaga-BLB2*02") == "Gallus gallus"
    assert mhc_species_of("") == ""


def test_mhc_species_of_keeps_a_multi_species_genotype_visible():
    """Collapsing a mixed genotype to "" would blank the chimera signal
    on exactly the rows it exists for."""
    from hitlist.curation import mhc_species_of

    assert mhc_species_of("HLA-A*02:01 H-2Kb") == "Homo sapiens;Mus musculus"


def test_species_axes_agreement_is_tri_state_and_symmetric():
    """An unresolvable name on either side is unknown, not a
    contradiction.  ``Species.compatible_with`` returns False both for
    "these differ" and for "that is not a species", so the guard has to
    be applied to both arguments."""
    from hitlist.curation import species_axes_agreement

    assert species_axes_agreement("Homo sapiens", "Homo sapiens") == "true"
    assert species_axes_agreement("Bos taurus (cattle)", "Bos sp.") == "true"
    assert species_axes_agreement("Carassius gibelio", "Homo sapiens") == "false"
    # Unresolvable on either side -> undeterminable, both directions.
    assert species_axes_agreement("Homo sapiens", "Blargh sp.") == ""
    assert species_axes_agreement("Blargh sp.", "Homo sapiens") == ""
    assert species_axes_agreement("", "Homo sapiens") == ""
    # A chimeric genotype agrees with either of its species.
    assert species_axes_agreement("Mus musculus", "Homo sapiens;Mus musculus") == "true"


def test_species_axes_agreement_is_not_predicate_shaped():
    """It returns a tri-state string, so ``bool("false")`` is True — the
    name must not read as a question or the first caller inverts their
    branch on a genuine chimera."""
    from hitlist import curation

    assert not hasattr(curation, "species_axes_agree")
    assert curation.species_axes_agreement("Mus musculus", "Homo sapiens") == "false"


#: Samples whose curated ``mhc`` is knowingly a cross-donor union rather
#: than one genotype.  Empty, and it should stay that way: the audit in
#: tasks/per_sample_allele_curation_audit.md calls attributing peptides
#: against a pooled allele set "a meaningless operation", and its fix is
#: to split the entry into one per donor / transfectant — which is how
#: Sarkizova's 95, Abelin's 16, Di Marco's 15 and Abelin MAPTAC's 8 were
#: resolved in 1.7.3.
_KNOWN_POOLED_ALLELE_SAMPLES: set = set()

#: Limits from that audit for a real per-sample genotype.
#:
#: Class II is twelve, not the audit's original ten: a fully heterozygous
#: diploid class-II genotype is DRB1 x2, DRB3/4/5 x2, DQA1 x2, DQB1 x2,
#: DPA1 x2 and DPB1 x2, and the original count left DRB3/4/5 out. Ten held
#: only because no sample carried a complete class-II typing until #565.
#: Writing DP and DQ as alpha/beta heterodimers caps at the same twelve:
#: four DP pairs, four DQ pairs and the four DR chains.
_MAX_ALLELES_PER_SAMPLE = {"I": 6, "II": 12}


def test_no_sample_carries_a_pooled_allele_union():
    """A per-sample ``mhc`` must be one donor's genotype, not a pool.

    tasks/per_sample_allele_curation_audit.md fixes the limits: 6 alleles
    for class I (heterozygous A/B/C), 12 for class II (DRB1 x2, DRB3/4/5 x2,
    DQA1 x2, DQB1 x2, DPA1 x2, DPB1 x2; the audit's original 10 left DRB3/4/5
    out, and held only while no sample carried a complete class-II typing).  Above that the
    value is a union across donors, the sample-metadata join attributes
    every peptide against alleles no single animal carries, and
    ``predict.max_alleles_per_sample`` exists to skip such samples as
    "misleading best-allele calls".

    The corpus was at zero violations and nothing enforced it, so a
    13-allele bovine union passed the whole suite.  This is that guard.
    """
    from hitlist.curation import extract_allele_tokens
    from hitlist.export import generate_ms_samples_table

    pooled, flagged = [], set()
    for _, row in generate_ms_samples_table().iterrows():
        limit = _MAX_ALLELES_PER_SAMPLE.get(str(row.get("mhc_class") or ""))
        if limit is None:
            continue
        n_alleles = len(extract_allele_tokens(str(row.get("mhc") or "")))
        if n_alleles <= limit:
            continue
        key = (int(row["pmid"]), str(row["sample_label"]))
        flagged.add(key)
        if key not in _KNOWN_POOLED_ALLELE_SAMPLES:
            pooled.append((*key, row["mhc_class"], n_alleles, limit))
    assert not pooled, (
        "curated mhc is a pooled union, not a genotype — split it per donor "
        f"(see tasks/per_sample_allele_curation_audit.md): {pooled}"
    )
    stale = _KNOWN_POOLED_ALLELE_SAMPLES - flagged
    assert not stale, f"no longer pooled but still allowlisted: {sorted(stale)}"


# ── Public per-peptide donor evidence API ─────────────────────────────


def test_peptide_alleles_for_pmid_narrows_below_the_cohort_union():
    """The curated per-peptide attributions (#45) are the only thing that
    narrows a peptide's candidate alleles below the study-wide set.

    Asserting the map is merely large does not test that: a regression
    mapping all 28,031 peptides to the full cohort union would keep the
    size and lose the entire point.  So compare against the union.
    """
    from hitlist.curation import peptide_alleles_for_pmid

    alleles = peptide_alleles_for_pmid(31844290)
    assert len(alleles) == 28031

    cohort_union = frozenset().union(*alleles.values())
    widest = max(len(candidates) for candidates in alleles.values())
    typical = sorted(len(candidates) for candidates in alleles.values())[len(alleles) // 2]
    assert widest < len(cohort_union), "no peptide may span the whole cohort"
    assert typical <= 8, (
        f"median candidate set is {typical} alleles; narrowing has regressed "
        f"toward the {len(cohort_union)}-allele cohort union"
    )

    candidates = alleles["AAAAAAAAAAAAAAPAP"]
    assert isinstance(candidates, frozenset)
    # One donor's whole class-I genotype -- not one presenting allele.
    assert sorted(candidates) == [
        "HLA-A*01:01",
        "HLA-B*38:01",
        "HLA-B*56:01",
        "HLA-C*01:02",
        "HLA-C*06:02",
    ]


def test_peptide_maps_are_read_only():
    """The map is a shared cache entry, and `peptide_typings_for_pmid`
    feeds the scanner's per-donor row emission (#236).

    A caller pruning it in place would silently change which observation
    rows the next build emits, with no error anywhere -- so the returned
    view refuses mutation rather than relying on a docstring asking
    nicely.
    """
    from hitlist.curation import peptide_alleles_for_pmid, peptide_typings_for_pmid

    for lookup in (peptide_alleles_for_pmid, peptide_typings_for_pmid):
        view = lookup(31844290)
        with pytest.raises(TypeError):
            view["AAAAAAAAAAAAAAPAP"] = frozenset()
        with pytest.raises(AttributeError):
            view.pop("AAAAAAAAAAAAAAPAP")


def test_peptide_lookups_accept_a_string_pmid():
    """PMIDs arrive as ints from YAML and as strings from dataframes.

    Returning an empty map for the string form would be read, correctly
    per the docstring, as "this study deposited no attributions" -- the
    exact wrong conclusion these functions warn against.
    """
    from hitlist.curation import (
        attribute_peptide_to_sample_alleles,
        peptide_alleles_for_pmid,
        peptide_typings_for_pmid,
    )

    assert dict(peptide_alleles_for_pmid("31844290")) == dict(peptide_alleles_for_pmid(31844290))
    assert dict(peptide_typings_for_pmid("31844290")) == dict(peptide_typings_for_pmid(31844290))
    assert attribute_peptide_to_sample_alleles(
        "31844290", "AAAAAAAAAAAAAAPAP"
    ) == attribute_peptide_to_sample_alleles(31844290, "AAAAAAAAAAAAAAPAP")
    # A PMID that is not a number at all is "no attributions", not a crash.
    assert peptide_alleles_for_pmid("not-a-pmid") == {}


def test_registered_pmids_with_peptide_attributions_match_documentation():
    """The public docstring names every study with a peptide-attribution CSV.

    The mechanism is generic, so a curator can add another at any time. This
    pins the claim so the docstring fails loudly instead of quietly becoming
    false to everyone reading `help()`.
    """
    from hitlist.curation import load_pmid_overrides

    with_attributions = {
        pmid for pmid, entry in load_pmid_overrides().items() if entry.get("peptide_attributions")
    }
    assert with_attributions == {31844290, 36423003}, (
        "update the caveat in peptide_alleles_for_pmid / peptide_typings_for_pmid"
    )


def test_peptide_alleles_for_pmid_is_empty_without_attributions():
    """Empty is the normal answer, not an error: it needs a
    peptide_attributions CSV, which only a handful of studies have.  A
    caller must read ``{}`` as "not narrowed", never as "no alleles"."""
    from hitlist.curation import peptide_alleles_for_pmid

    # Two serotype-typed studies with no attribution CSV.
    assert peptide_alleles_for_pmid(28467828) == {}
    assert peptide_alleles_for_pmid(34433824) == {}


def test_peptide_typings_for_pmid_keeps_donor_identity():
    """Same evidence as peptide_alleles_for_pmid, unmerged, so the
    scanner can emit one row per donor (#236)."""
    from hitlist.curation import peptide_alleles_for_pmid, peptide_typings_for_pmid

    typings = peptide_typings_for_pmid(31844290)
    merged = peptide_alleles_for_pmid(31844290)
    assert set(typings) == set(merged)

    peptide, per_donor = next(iter(typings.items()))
    labels = [label for label, _ in per_donor]
    assert labels == sorted(labels), "emission order must be deterministic"
    # Merging the per-donor sets reproduces the merged view.
    union = frozenset().union(*(alleles for _, alleles in per_donor))
    assert union == merged[peptide]


def test_cache_clear_drops_the_whole_derived_chain():
    """`peptide_alleles_for_pmid` is derived from `peptide_typings_for_pmid`,
    so clearing one layer alone leaves the other stale.

    Tests that monkeypatch the underlying loaders rely on `cache_clear`
    to isolate themselves; a partial clear reintroduces exactly the
    cross-test contamination it is called to prevent.
    """
    from hitlist import curation

    # Other tests share these caches, so assert the transition rather than
    # an absolute size.
    curation.peptide_typings_for_pmid.cache_clear()
    curation.peptide_alleles_for_pmid(31844290)
    curation.peptide_typings_for_pmid(31844290)
    assert curation._peptide_alleles_by_pmid.cache_info().currsize > 0
    assert curation._peptide_typings_by_pmid.cache_info().currsize > 0

    # Reachable from either public name, and clears both either way.
    curation.peptide_alleles_for_pmid.cache_clear()
    assert curation._peptide_alleles_by_pmid.cache_info().currsize == 0
    assert curation._peptide_typings_by_pmid.cache_info().currsize == 0


# ── Sample-MHC attribution candidates (#380) ───────────────────────────────


def test_sample_mhc_candidates_keeps_the_three_precisions_apart():
    """Exact / serotype / imprecise must not be merged.

    Merging serotype members into ``exact`` is the specific error worth
    guarding: it turns "this donor is DR15" into "this peptide was seen
    on DRB1*15:01".
    """
    from hitlist.curation import sample_mhc_candidates

    exact = sample_mhc_candidates("HLA-A*02:01 HLA-B*07:02")
    assert exact.exact == frozenset({"HLA-A*02:01", "HLA-B*07:02"})
    assert exact.serotypes == () and exact.imprecise == ()

    sero = sample_mhc_candidates("HLA-DQ8")
    assert sero.exact == frozenset()
    assert sero.serotypes == ("HLA-DQ8",)
    assert sero.serotype_alleles, "a known serotype must expand to members"
    assert sero.join_alleles == sero.serotype_alleles

    locus = sample_mhc_candidates("BoLA-DR")
    assert locus.imprecise == ("BoLA-DR",)
    assert locus.join_alleles == frozenset(), "a locus names no allele to join on"
    assert not locus.is_empty, "imprecise is faithful curation, not an empty parse"


@pytest.mark.parametrize(
    ("raw", "canonical"),
    [
        ("DQ8", "HLA-DQ8"),
        ("dr15", "HLA-DR15"),
        ("hla-dq8", "HLA-DQ8"),
    ],
)
def test_sample_mhc_candidates_canonicalizes_serotype_spellings(raw, canonical):
    """Every spelling accepted by mhcgnomes must reach the catalog."""
    from hitlist.curation import sample_mhc_candidates, serotype_to_alleles

    got = sample_mhc_candidates(raw)

    assert got.serotypes == (canonical,)
    assert got.serotype_alleles == frozenset(serotype_to_alleles(canonical))
    assert got.serotype_alleles


def test_sample_mhc_candidates_canonicalizes_serotype_inside_mixed_field():
    """Tokenized mixed exact/serotype fields use the same canonical path."""
    from hitlist.curation import sample_mhc_candidates, serotype_to_alleles

    got = sample_mhc_candidates("HLA-A*02:01 dq8")

    assert got.exact == frozenset({"HLA-A*02:01"})
    assert got.serotypes == ("HLA-DQ8",)
    assert got.serotype_alleles == frozenset(serotype_to_alleles("HLA-DQ8"))


def test_sample_mhc_candidates_survives_a_multiword_class_sentinel():
    """``Bos taurus class I`` must not be shredded by the token split.

    Splitting on whitespace first yields "Bos"/"taurus"/"class"/"I",
    none of which parses, reporting a faithfully curated sentinel as an
    empty parse — i.e. as a curation typo.
    """
    from hitlist.curation import sample_mhc_candidates

    for sentinel in ("Bos taurus class I", "HLA class I", "MHC class II"):
        got = sample_mhc_candidates(sentinel)
        assert got.imprecise == (sentinel,), sentinel
        assert not got.is_empty, sentinel


def test_sample_mhc_candidates_still_rejects_the_na_haplotype():
    """mhcgnomes resolves "n/a" to the rat haplotype RT1-n/A, so a
    free-text field must never be accepted on "it parsed" alone."""
    from hitlist.curation import sample_mhc_candidates

    for junk in ("n/a", "", None, 42):
        assert sample_mhc_candidates(junk).is_empty, junk


def test_sample_mhc_candidates_exact_matches_the_pre_380_extraction():
    """``exact`` must stay byte-identical to the old allele extraction,
    so centralizing the parse cannot silently renormalize a genotype."""
    from hitlist.curation import extract_allele_tokens, sample_mhc_candidates

    for field in (
        "A*02:01 A*24:02 B*15:01 B*44:02 C*05:01 C*07:02",
        "HLA-A*02:01",
        "H2-K*b H2-D*b",
        "Patr-AL",
        "HLA-DPB1*06:01/DPA1*01:03",
    ):
        assert sample_mhc_candidates(field).exact == frozenset(extract_allele_tokens(field)), field


def test_allele_locus_is_species_qualified():
    """HLA-DRB3 and BoLA-DRB3 share a gene name but are different loci;
    bucketing on the bare name would merge two species' alleles."""
    from hitlist.curation import allele_locus

    assert allele_locus("HLA-DRB3*01:01") == "HLA-DRB3"
    assert allele_locus("BoLA-DRB3*011:01") == "BoLA-DRB3"
    assert allele_locus("HLA-A*02:01") == "HLA-A"
    assert allele_locus("BoLA-6*013:01") == "BoLA-6"
    # No single locus: a serotype, a class-II locus token, a heterodimer.
    for spanning in ("HLA-DR15", "BoLA-DR", "HLA-DPB1*06:01/DPA1*01:03", "", "n/a"):
        assert allele_locus(spanning) == "", spanning


def test_sample_alleles_for_pmid_is_public_and_omits_imprecise_samples():
    """The sample-level map is a real contract and must be reachable
    without touching a private name (it was ``_pmid_sample_alleles``)."""
    import hitlist
    from hitlist.curation import sample_alleles_for_pmid

    assert hitlist.sample_alleles_for_pmid is sample_alleles_for_pmid
    assert "sample_alleles_for_pmid" in hitlist.__all__

    per_line = sample_alleles_for_pmid(36423003)
    assert len(per_line) == 8, "one sample per T. parva-infected cell line"
    assert per_line["641TP (T. parva-infected, BoLA-I A18)"] == frozenset({"BoLA-6*013:01"})
    assert per_line["2824TP (T. parva-infected, BoLA-I A19)"] == frozenset(
        {"BoLA-2*016:01", "BoLA-6*014:02"}
    )
    # The class-II sample is locus-typed, so it names no allele and is omitted.
    assert not any("BoLA-DR)" in label for label in per_line)

    assert sample_alleles_for_pmid("36423003") == per_line, "str and int PMIDs agree"
    assert sample_alleles_for_pmid(1) == {}, "unknown PMID is empty, not an error"


def test_thp1_typing_is_study_specific():
    """#416: a shared cell-line identity does not imply one universal HLA genotype."""
    from hitlist.curation import sample_alleles_for_pmid

    nicholas = sample_alleles_for_pmid(35051231)
    thp1_labels = {
        "THP-1 macrophage — UV mock (uninfected)",
        "THP-1 macrophage — Wisconsin-infected",
        "THP-1 macrophage — X31-infected",
    }
    assert thp1_labels <= nicholas.keys()
    for label in thp1_labels:
        alleles = nicholas[label]
        assert {"HLA-A*02:01", "HLA-B*15:11", "HLA-C*03:03"} <= alleles
        assert alleles.isdisjoint({"HLA-A*24:02", "HLA-B*35:01"})

    ghosh = sample_alleles_for_pmid(33392160)["THP-1 + biomaterial contact"]
    assert {
        "HLA-A*02:01",
        "HLA-A*24:02",
        "HLA-B*15:11",
        "HLA-B*35:01",
        "HLA-C*03:03",
    } <= ghosh


def test_every_serotype_table_entry_is_reachable():
    """#455: the reverse map and its lookup must agree on how alleles are keyed.

    mhcgnomes' table spells alleles two ways -- 915 entries as ``C*0304`` and
    11 as ``C*15:02``, the hand-curated rows its generator cannot reproduce
    (mhcgnomes#156).  Keying the map by whatever the table held made those rows
    unreachable, silently removing Cw12, Cw14, Cw15, Cw16, Cw17 and Cw18 from
    every annotation in the index.  This asserts the whole vocabulary stays
    reachable, so a format change upstream fails here instead of quietly
    dropping a locus.

    It asserts each entry resolves to *its own* serotype rather than merely
    to something.  A non-empty check passes a regression that maps an allele
    to the wrong specificity, which is the same silently-wrong-value class
    #455 was about — the annotation would still be there, and still be
    incorrect.
    """
    from mhcgnomes.data import serotypes

    wrong = []
    for prefix, table in serotypes.items():
        for sero_name, allele_list in table.items():
            for allele in allele_list:
                found = allele_to_all_serotypes(f"{prefix}-{allele}")
                if f"{prefix}-{sero_name}" not in found:
                    wrong.append(f"{prefix}-{sero_name} -> {allele} (got {found})")
    assert wrong == [], (
        f"{len(wrong)} table entries do not resolve to their own serotype:\n  "
        + "\n  ".join(wrong[:15])
    )


@pytest.mark.parametrize(
    "allele",
    [
        "Patr-A*02:01",
        "Gogo-A*01:02",
        "DLA-A*02:01",
        "Patr-B*13:01",
        "Mamu-DRB1*04:06",
        "SLA-DRB1*10:01",
    ],
)
def test_nonhuman_alleles_do_not_collect_human_serotypes(allele):
    assert allele_to_all_serotypes(allele) == ()


@pytest.mark.parametrize("serotype", ["Patr-DR1", "Mamu-DR1B", "DLA-A2", "BoLA-A18"])
def test_reported_serotypes_preserve_their_species(serotype):
    from hitlist.curation import resolve_mhc_annotation

    assert allele_to_all_serotypes(serotype) == (serotype,)
    annotation = resolve_mhc_annotation(serotype)
    assert annotation.serotypes == serotype
    assert annotation.serotype_source == "reported"


def test_cattle_serotype_memberships_work_in_both_directions():
    for allele in ("BoLA-6*013:01", "BoLA-6*013:02"):
        assert allele_to_all_serotypes(allele) == ("BoLA-A18",)
    assert allele_to_all_serotypes("BoLA-N*018:01") == ("BoLA-A11",)
    for spelling in ("BoLA-A18", "bola-a18"):
        assert serotype_to_alleles(spelling) == ("BoLA-6*013:01", "BoLA-6*013:02")
    # A named serotype does not imply that the catalog has molecular members.
    assert serotype_to_alleles("Patr-DR1") == ()


def test_nonhuman_donor_bag_retains_species_and_candidate_provenance():
    from hitlist.curation import resolve_mhc_annotation

    annotation = resolve_mhc_annotation("BoLA-6*013:01;BoLA-6*013:02")
    assert annotation.serotypes == "BoLA-A18"
    assert annotation.serotype_source == "donor_set"


@pytest.mark.parametrize("spelling", ["HLA-A2", "hla-a2", "A2", "a2"])
def test_serotype_expansion_accepts_parsed_spellings(spelling):
    assert serotype_to_alleles(spelling) == serotype_to_alleles("HLA-A2")
    assert "HLA-A*02:01" in serotype_to_alleles(spelling)


@pytest.mark.parametrize(
    ("query", "expected"),
    [
        ("a2", "HLA-A2"),
        ("hla-dr15", "HLA-DR15"),
        ("bw4", "HLA-Bw4"),
        ("hla-cw16", "HLA-Cw16"),
        ("bola-a18", "BoLA-A18"),
        ("patr-dr1", "Patr-DR1"),
        ("a99", "HLA-A99"),
        ("", ""),
    ],
)
def test_public_serotype_normalizer_is_shared_by_loaders_and_exports(query, expected):
    import hitlist
    from hitlist import export, observations

    assert hitlist.normalize_serotype_query(query) == expected
    assert observations._normalize_serotype_query is hitlist.normalize_serotype_query
    assert export._normalize_serotype_query is hitlist.normalize_serotype_query
    assert "normalize_serotype_query" in hitlist.__all__


def test_allele_to_all_serotypes_reaches_curated_c_locus_specificities():
    """The colon-spelled curated rows, named individually.

    Cw16 is the one that matters most: WHO's ``hla_nom.txt`` records
    ``Cw;16;20260128;;;``, assigned and never deleted, and mhcgnomes curated it
    in deliberately (mhcgnomes#153) because the IPD dictionary its generator
    reads predates the assignment.  A key-format mismatch here discarded that
    work.
    """
    assert allele_to_all_serotypes("HLA-C*16:01") == ("HLA-Cw16",)
    assert allele_to_all_serotypes("HLA-C*16:02") == ("HLA-Cw16",)
    assert allele_to_all_serotypes("HLA-C*15:02") == ("HLA-Cw15",)
    assert allele_to_all_serotypes("HLA-C*12:03") == ("HLA-Cw12",)
    assert allele_to_all_serotypes("HLA-C*14:02") == ("HLA-Cw14",)
    assert allele_to_all_serotypes("HLA-C*17:01") == ("HLA-Cw17",)
    assert allele_to_all_serotypes("HLA-C*18:01") == ("HLA-Cw18",)
    # The C locus skips two numbers, for two different reasons, and neither is
    # a bug here: wmda/hla_nom.txt records Cw11 as assigned in 1987 and deleted
    # in 1991 for "Sequence error", while Cw13 has no line at all and was never
    # assigned. Recorded as a comment rather than an assertion on purpose --
    # `"Cw13" not in serotypes["HLA"]` would test the dependency's data, and
    # this very PR exists because WHO assigned six new C serotypes in 2026, so
    # "these absences are permanent" is a premise already falsified once.


def test_serotype_source_separates_reported_from_computed():
    """#458: a measured serological typing and a projection are not the same fact.

    A study that typed serologically reports ``HLA-A2`` and measured no
    molecule -- the serotype *is* the observation.  A study that sequenced
    ``HLA-A*02:01`` yields the same ``serotypes`` cell computed from mhcgnomes'
    membership table.  Without this column the two are indistinguishable.
    """
    from hitlist.curation import SEROTYPE_SOURCE_VALUES, resolve_mhc_annotation

    reported = resolve_mhc_annotation("HLA-A2")
    assert reported.serotype_source == "reported"
    assert reported.allele_resolution == "serological"
    assert reported.serotypes == "HLA-A2"

    derived = resolve_mhc_annotation("HLA-A*02:01")
    assert derived.serotype_source == "derived"
    assert derived.serotypes == "HLA-A2;HLA-A2.1"

    # A donor bag's serotypes are a union over the donor's typed alleles, so
    # the serotype is a candidate rather than the restriction's identity.
    donor_set = resolve_mhc_annotation("HLA-A*01:01;HLA-A*02:01")
    assert donor_set.serotype_source == "donor_set"
    assert donor_set.allele_resolution == "donor_set"

    # No serotype, no source: class-only rows and alleles serology never typed.
    assert resolve_mhc_annotation("HLA class I").serotype_source == ""
    assert resolve_mhc_annotation("HLA-DQA1*01:02").serotype_source == ""

    assert set(SEROTYPE_SOURCE_VALUES) == {"reported", "derived", "donor_set"}


def test_serotype_source_is_persisted_with_the_annotation():
    """The scanner writes ``as_record_fields`` atomically; the source rides along."""
    from hitlist.curation import resolve_mhc_annotation

    fields = resolve_mhc_annotation("HLA-A*24:02").as_record_fields()
    assert fields["serotype_source"] == "derived"
    assert fields["serotypes"] == "HLA-A24;HLA-Bw4"
