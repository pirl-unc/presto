# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Peptide-to-source-protein mapping with flanking sequence extraction.

Builds an efficient k-mer index from a protein sequence database (pyensembl
or FASTA) and maps observed peptides to their source protein(s) with
N-terminal and C-terminal flanking context.

The index is built once per proteome and cached. Lookups are O(1) per
peptide via a dict-based inverted index mapping each unique k-mer to
the set of (protein_id, position) occurrences.

``ProteomeIndex.from_fasta`` additionally caches indexes by resolved
``(path, size, mtime, lengths, gene_name, gene_id)`` across calls in the
same process, so repeated flanking passes against FASTAs shared by
multiple canonical species names (common for viral-strain fallbacks)
pay the indexing cost once. Invalidates automatically when the FASTA
on disk changes (size or mtime).

Memory representation (v1.13.4+):
  The k-mer index ``self.index`` stores **packed int64** postings, not
  ``list[tuple[str, int]]``. Each posting is ``(prot_idx << 32) | pos``
  where ``prot_idx`` refers to ``self._protein_ids``. Single-hit k-mers
  (the vast majority) store a scalar ``int`` directly; multi-hit k-mers
  store a ``numpy.ndarray`` of int64. Callers should use ``lookup()`` or
  ``map_peptides()`` rather than accessing ``self.index`` directly — the
  raw values will not be the ``(protein_id, position)`` tuples they used
  to be. This cuts human-proteome (8/9/10/11-mer) peak RSS from ~13 GB
  to ~2-3 GB and makes full-rebuild feasible on 8-16 GB machines.

Typical usage::

    from hitlist.proteome import ProteomeIndex

    idx = ProteomeIndex.from_ensembl(release=112)
    hits = idx.map_peptides(["SLYNTVATL", "GILGFVFTL"])
"""

from __future__ import annotations

import contextlib
import hashlib
import os
import pickle
import tempfile
import warnings
from collections import OrderedDict
from collections.abc import Iterable
from dataclasses import dataclass, field
from functools import cached_property, lru_cache
from itertools import pairwise
from pathlib import Path

import numpy as np
import pandas as pd

# Packing for (prot_idx, pos) → int64: 32 bits for each.
# 32 bits prot_idx: up to 4B proteins (far more than any realistic merged index).
# 32 bits pos: up to 4B residues (titin, the longest human protein, is 35K aa).
_PROT_BITS = 32
_POS_MASK = (1 << _PROT_BITS) - 1


def _pack(prot_idx: int, pos: int) -> int:
    return (prot_idx << _PROT_BITS) | pos


def _unpack(packed: int) -> tuple[int, int]:
    return (packed >> _PROT_BITS, packed & _POS_MASK)


# ── Int-encoded columnar k-mer index (#250 / #248 / #176) ────────────────────
#
# Replaces the ``dict[str, int | np.ndarray]`` k-mer index.  Each k-mer is
# packed into a single uint64 *code* (``bits`` per residue), so the index can
# be stored as code-sorted numpy arrays per length and queried with
# ``np.searchsorted`` — no Python str dict to build on warm load (#248) and no
# 100M-iteration ``dict.get`` hot loop on cold build (#176/#250; build is
# vectorized + one sort instead).
#
# ``bits`` is the residue budget; a k-mer of length k needs ``bits*k`` bits, so
# this exact encoding only applies while ``bits*max(lengths) <= 63``.  For the
# shipped config (alphabet ≤ 32 residues → 5 bits, lengths 8..11 → ≤ 55 bits)
# it always does; anything outside that budget falls back to the legacy dict.
_KMER_CODE_BITS = 63

# ── Seed length + flank width (#398) ─────────────────────────────────────────
#
# The index stores k-mers at ONE length -- the *seed*.  Any peptide of length
# >= SEED_KMER_LENGTH is found by looking up its first ``k`` residues and
# verifying that the protein continues with the rest, so peptide length and
# index length are no longer the same knob.  Indexing four lengths bought
# nothing: measured on Ensembl 112 human (89,610 proteins, 40.2 M residues),
# seed selectivity is essentially flat in k because multiplicity is driven by
# *isoforms*, not by sequence repetition --
#
#     k=7   mean 3.74 hits/seed   p99 20   28.6% unique
#     k=8   mean 3.60             p99 19   29.6% unique
#     k=11  mean 3.49             p99 19   30.4% unique
#
# -- while each indexed length costs the same ~492 MB (39.5 M postings
# regardless of k).  So four lengths cost ~1.97 GB to buy a 3% improvement in
# mean candidate count and nothing at all at p99.
#
# 7 rather than 8 because it is the shortest seed that is still selective
# (k=6 mean 4.76, k=5 mean 16.63 / max 10,022 -- a cliff), and it makes
# length-7 peptides mappable: 14,459 corpus rows that no 8-mer seed can reach.
SEED_KMER_LENGTH = 7

# Residues of flanking context stored on each side of a mapped peptide.
# Flanks are sliced from the source sequence after the position is known, so
# this is independent of the index; the cost is output size only.
DEFAULT_FLANK = 15

# Ensembl deliberately classifies translated immunoglobulin and T-cell-receptor
# germline segments separately from ordinary ``protein_coding`` genes. They
# are real protein sources, while the similarly named ``*_pseudogene``
# biotypes are not. Keep the complete inclusion policy in one public constant
# so mapping, transcript-origin lookup, cache metadata, and downstream callers
# cannot drift apart (#399).
ENSEMBL_CODING_GENE_BIOTYPES = (
    "protein_coding",
    "IG_V_gene",
    "IG_D_gene",
    "IG_J_gene",
    "IG_C_gene",
    "TR_V_gene",
    "TR_D_gene",
    "TR_J_gene",
    "TR_C_gene",
)


def _normalize_ensembl_gene_biotypes(
    gene_biotypes: str | Iterable[str] | None,
) -> tuple[str, ...]:
    """Return a validated, order-independent Ensembl gene-biotype policy.

    ``None`` selects :data:`ENSEMBL_CODING_GENE_BIOTYPES`. A string is
    treated as one biotype rather than an iterable of characters, preserving
    the historical ``biotype="protein_coding"`` API. Sorting makes equivalent
    caller inputs share the same disk-cache key.
    """
    if gene_biotypes is None:
        values = ENSEMBL_CODING_GENE_BIOTYPES
    elif isinstance(gene_biotypes, str):
        values = (gene_biotypes,)
    else:
        values = tuple(gene_biotypes)
    normalized = tuple(sorted({str(value).strip() for value in values if str(value).strip()}))
    if not normalized:
        raise ValueError("At least one Ensembl gene biotype is required")
    return normalized


@dataclass
class _PackedIndex:
    """Per-length columnar k-mer index (code-sorted uint64 arrays).

    For each indexed length ``k``:
      ``codes[k]``   uint64[n]   unique k-mer codes, ascending
      ``offsets[k]`` int64[n+1]  postings slice bounds
      ``values[k]``  int64[m]    packed ``(prot_idx<<32)|pos``, grouped by code

    ``alphabet`` maps residue → small int (a residue's code is its index in the
    string); ``bits`` per residue.  A k-mer's code is
    ``Σ alphabet.index(c_i) << bits*(k-1-i)``.
    """

    codes: dict[int, np.ndarray] = field(repr=False)
    offsets: dict[int, np.ndarray] = field(repr=False)
    values: dict[int, np.ndarray] = field(repr=False)
    alphabet: str
    bits: int
    lengths: tuple[int, ...]

    @staticmethod
    def encodable(alphabet_size: int, lengths: tuple[int, ...]) -> tuple[bool, int]:
        """``(can_encode, bits)`` for an alphabet size + lengths under the budget."""
        if alphabet_size <= 0 or not lengths:
            return False, 0
        bits = max(1, (alphabet_size - 1).bit_length())
        return bits * max(lengths) <= _KMER_CODE_BITS, bits

    @classmethod
    def build(
        cls,
        proteins: dict[str, str],
        prot_to_idx: dict[str, int],
        lengths: tuple[int, ...],
    ) -> _PackedIndex | None:
        """Vectorized columnar build, or ``None`` if the data can't be encoded.

        Returns ``None`` (→ caller uses the legacy dict build) when the
        alphabet x max-length exceeds the uint64 budget, or a sequence
        contains a non-ASCII residue.  For real proteomes (≤32 residues,
        k ≤ 11) the fast path always applies.
        """
        alpha = set()
        for seq in proteins.values():
            alpha.update(seq)
        alphabet = "".join(sorted(alpha))
        ok, bits = cls.encodable(len(alphabet), lengths)
        if not alphabet or not ok:
            return None

        # 256-entry residue LUT; 255 marks out-of-alphabet (alphabet ≤ 32, so
        # 255 is never a valid code).
        lut = np.full(256, 255, dtype=np.uint64)
        for code, ch in enumerate(alphabet):
            o = ord(ch)
            if o > 255:
                return None  # non-ASCII residue → legacy path
            lut[o] = code

        bits_u = np.uint64(bits)
        prot_shift = np.uint64(_PROT_BITS)
        code_chunks: dict[int, list[np.ndarray]] = {k: [] for k in lengths}
        val_chunks: dict[int, list[np.ndarray]] = {k: [] for k in lengths}

        for prot_id, seq in proteins.items():
            b = np.frombuffer(seq.encode("ascii", "replace"), dtype=np.uint8)
            c = lut[b]  # per-residue codes (uint64); out-of-alphabet → 255
            if (c == 255).any():
                return None  # unexpected residue → legacy path
            length = c.size
            pidx = np.uint64(prot_to_idx[prot_id])
            for k in lengths:
                if length < k:
                    continue
                m = length - k + 1
                # Rolling pack: k vectorized shifts over the window array.
                kc = np.zeros(m, dtype=np.uint64)
                for j in range(k):
                    kc = (kc << bits_u) | c[j : j + m]
                packed = (pidx << prot_shift) | np.arange(m, dtype=np.uint64)
                code_chunks[k].append(kc)
                val_chunks[k].append(packed.astype(np.int64))

        codes: dict[int, np.ndarray] = {}
        offsets: dict[int, np.ndarray] = {}
        values: dict[int, np.ndarray] = {}
        for k in lengths:
            if not code_chunks[k]:
                codes[k] = np.empty(0, dtype=np.uint64)
                offsets[k] = np.zeros(1, dtype=np.int64)
                values[k] = np.empty(0, dtype=np.int64)
                continue
            all_c = np.concatenate(code_chunks[k])
            all_v = np.concatenate(val_chunks[k])
            order = np.argsort(all_c, kind="stable")
            all_c = all_c[order]
            all_v = all_v[order]
            # ``all_c`` is now sorted; find group boundaries directly instead
            # of ``np.unique(return_counts=True)``, which would redundantly
            # re-sort (~30% of the grouping cost — #250).  Group i occupies
            # ``all_v[start[i]:start[i+1]]``.
            boundary = np.ones(all_c.size, dtype=bool)
            np.not_equal(all_c[1:], all_c[:-1], out=boundary[1:])
            start = np.flatnonzero(boundary)
            off = np.empty(start.size + 1, dtype=np.int64)
            off[:-1] = start
            off[-1] = all_c.size
            codes[k] = all_c[start]
            offsets[k] = off
            values[k] = all_v

        return cls(
            codes=codes,
            offsets=offsets,
            values=values,
            alphabet=alphabet,
            bits=bits,
            lengths=tuple(lengths),
        )

    @cached_property
    def _char_to_code(self) -> dict[str, int]:
        return {ch: i for i, ch in enumerate(self.alphabet)}

    def encode(self, kmer: str) -> int | None:
        """Pack a k-mer into its uint64 code, or ``None`` if any residue is
        outside the index's alphabet (→ guaranteed absent)."""
        lut = self._char_to_code
        bits = self.bits
        code = 0
        for ch in kmer:
            c = lut.get(ch)
            if c is None:
                return None
            code = (code << bits) | c
        return code

    def get_postings(self, peptide: str) -> np.ndarray | None:
        """Packed-int64 postings for ``peptide`` (code-matched), or ``None``."""
        codes = self.codes.get(len(peptide))
        if codes is None or codes.size == 0:
            return None
        code = self.encode(peptide)
        if code is None:
            return None
        code = np.uint64(code)
        i = int(np.searchsorted(codes, code))
        if i >= codes.size or codes[i] != code:
            return None
        off = self.offsets[len(peptide)]
        return self.values[len(peptide)][off[i] : off[i + 1]]

    def iter_kmers(self):
        """Yield every indexed k-mer string (decode each code). Rare/cold path."""
        alphabet = self.alphabet
        bits = self.bits
        mask = (1 << bits) - 1
        for k in self.lengths:
            codes = self.codes.get(k)
            if codes is None:
                continue
            for code in codes.tolist():
                chars = []
                for _ in range(k):
                    chars.append(alphabet[code & mask])
                    code >>= bits
                yield "".join(reversed(chars))

    @property
    def n_kmers(self) -> int:
        return sum(int(c.size) for c in self.codes.values())

    def __len__(self) -> int:
        """Number of unique k-mers — matches ``len()`` of the legacy dict."""
        return self.n_kmers

    def __contains__(self, kmer: str) -> bool:
        return self.get_postings(kmer) is not None


# Bounded LRU cache for ``from_fasta``.  Keyed on the resolved absolute
# path plus (size, mtime) of the file, plus the index-configuration inputs
# (``lengths``, ``gene_name``, ``gene_id``).  Size + mtime invalidate the
# entry automatically when the FASTA is replaced (e.g. by
# ``fetch_species_proteome`` downloading a newer build).
#
# Issue #109: prior to v1.19.2 this was an *unbounded* dict, which made
# the full-build flanking pass accumulate every species' ProteomeIndex
# in RAM (the human index alone is ~10 GB; ~525 canonicals iterated by
# ``_add_flanking`` push peak RSS into 16-32 GB territory and the OS
# starts OOM-killing the build).  An ``OrderedDict``-backed LRU caps
# resident size while still capturing the common case — strain-variant
# canonicals appear close together in the build order, so an LRU of 4
# keeps every cache-hit path that motivated #86.
_FASTA_INDEX_CACHE_MAXSIZE: int = 4
_FASTA_INDEX_CACHE: OrderedDict[tuple, ProteomeIndex] = OrderedDict()


def set_fasta_index_cache_maxsize(maxsize: int) -> None:
    """Adjust the bounded cache size used by :meth:`ProteomeIndex.from_fasta`.

    The default ``4`` is enough to capture the strain-variant cache hits
    motivating #86 (e.g. multiple SARS-CoV-2 / EBV canonicals resolve to
    the same FASTA in close succession).  Tests use this to drive the
    LRU eviction path with a small chain of distinct FASTAs.

    Reducing ``maxsize`` evicts entries beyond the new bound immediately.
    Setting it to ``0`` disables caching entirely (every call re-indexes).
    """
    global _FASTA_INDEX_CACHE_MAXSIZE
    if maxsize < 0:
        raise ValueError("maxsize must be non-negative")
    _FASTA_INDEX_CACHE_MAXSIZE = int(maxsize)
    while len(_FASTA_INDEX_CACHE) > _FASTA_INDEX_CACHE_MAXSIZE:
        _FASTA_INDEX_CACHE.popitem(last=False)


def clear_fasta_index_cache() -> None:
    """Drop all cached ``from_fasta`` indexes.

    Useful in tests that write fresh FASTA files with reused filenames
    within the same process. Production code should let the built-in
    size/mtime invalidation handle it.
    """
    _FASTA_INDEX_CACHE.clear()


# ── On-disk persistent cache for built ProteomeIndexes (#246) ─────────────
#
# Built indexes are pickled to a per-host cache directory keyed by the
# same shape used by the in-memory ``_FASTA_INDEX_CACHE`` plus a format
# version.  Subsequent runs that see the same FASTA on disk (size +
# mtime unchanged) skip the ~minute-scale ``_build`` k-mer pass and load
# the pickle in ~1-3s on SSD.
#
# The dominant build-time stage on cold machines is ``peptide_mappings``
# (#176): cProfile shows 159 ``_build`` calls (40 species x 4 lengths)
# adding to ~67% of total wall.  When IEDB CSVs change but FASTAs don't
# (the common deploy pattern), this cache turns subsequent rebuilds
# into near-no-ops for the mappings stage.

# Bump on any breaking change to ``_build``'s output schema (the dict
# layout, the int64 packing, etc.).  Stale-format files are skipped
# (treated as cache misses) and eventually evicted by the cap policy.
_INDEX_FORMAT_VERSION: int = 1


def default_proteome_index_cache_dir() -> Path:
    """Pickled indexes under the currently resolved hitlist data directory.

    Resolution is silent and creates nothing. Existing unconfigured installs
    retain their populated legacy directory through ``downloads.data_dir()``.
    """
    from .downloads import data_dir

    return data_dir() / "proteome_index_cache"


_PROTEOME_INDEX_DISK_CACHE_DIR: Path | None = None


def proteome_index_cache_dir() -> Path:
    """Directory currently holding the pickled proteome indexes (``*.pkl``).

    An explicit :func:`set_disk_cache_dir` override wins. Otherwise follow
    :func:`hitlist.downloads.data_dir` on each call, including changes made
    after import through ``HITLIST_DATA_DIR`` or ``set_data_dir()`` (#591).
    Selecting a different directory never moves or deletes the old cache.
    """
    if _PROTEOME_INDEX_DISK_CACHE_DIR is not None:
        return _PROTEOME_INDEX_DISK_CACHE_DIR
    return default_proteome_index_cache_dir()


def _resolve_disk_cache_max_gb() -> float:
    """Read the disk-cache cap (GB) from ``HITLIST_PROTEOME_INDEX_CACHE_GB``
    each call so tests can override via :func:`os.environ`.

    Returns ``0.0`` to disable caching entirely.  Default 50 GB caps the
    cache below typical free-space watermarks while accommodating the
    full Homo sapiens index (~12 GB across 4 lengths) plus the largest
    non-human proteomes (mouse, dog, chimp, macaque, pig, cow each
    ~5-10 GB across 4 lengths).
    """
    raw = os.environ.get("HITLIST_PROTEOME_INDEX_CACHE_GB", "50")
    try:
        return max(0.0, float(raw))
    except ValueError:
        return 50.0


def set_disk_cache_dir(path: Path | str | None) -> None:
    """Override the on-disk proteome-index cache directory.

    Pass ``None`` to follow :func:`default_proteome_index_cache_dir` dynamically.
    Tests use this to point at a tmp_path so they don't pollute the
    real cache and aren't affected by it.
    """
    global _PROTEOME_INDEX_DISK_CACHE_DIR
    _PROTEOME_INDEX_DISK_CACHE_DIR = None if path is None else Path(path)


def clear_disk_cache() -> None:
    """Delete every cached index + leftover ``.tmp`` partial-write on disk.

    Cleans both ``*.pkl`` (cached indexes) and ``*.tmp`` (in-flight or
    crashed atomic-write tempfiles) so the cache dir comes back to a
    clean state for tests + manual reset.  No-op when the cache dir
    doesn't exist yet.
    """
    cache_dir = proteome_index_cache_dir()
    if cache_dir.exists():
        for pattern in ("*.pkl", "*.tmp"):
            for f in cache_dir.glob(pattern):
                with contextlib.suppress(FileNotFoundError):
                    f.unlink()


def _disk_cache_filename(cache_key: tuple) -> str:
    """Deterministic filename for a cache key.

    The first 16 hex chars of a sha256 of ``repr(cache_key)`` give us a
    collision-proof handle; we prefix with the FASTA basename + lengths
    so files are human-debuggable from ``ls``.  The format-version
    prefix lets us evolve ``_build``'s output shape without
    contaminating new builds with stale-format pickles.

    Two cache-key shapes are recognized via the first-element discriminant:

    * ``("ensembl", release, species, gene_biotypes, lengths, gtf_size, gtf_mtime)``
      — emitted by :meth:`ProteomeIndex.from_ensembl` (#251).
    * ``(path_str, size, mtime, lengths, gene_name, gene_id)`` — emitted by
      :meth:`ProteomeIndex.from_fasta` (#246).  This is the legacy shape;
      no leading discriminant tag.

    Coupling note: adding/reordering fields in either tuple shape
    requires updating the matching unpacking branch below — the hash
    suffix would silently change for the same logical key otherwise.
    """
    if len(cache_key) > 0 and cache_key[0] == "ensembl":
        _tag, release, species, gene_biotypes, lengths, _size, _mtime = cache_key
        species_slug = str(species).lower().replace(" ", "_")
        if set(gene_biotypes) == set(ENSEMBL_CODING_GENE_BIOTYPES):
            biotype_label = "coding"
        elif len(gene_biotypes) == 1:
            biotype_label = gene_biotypes[0]
        else:
            biotype_label = f"{len(gene_biotypes)}-biotypes"
        basename = f"ensembl_{species_slug}_r{release}_{biotype_label}"
    else:
        path_str, _size, _mtime, lengths, _gn, _gid = cache_key
        basename = Path(path_str).stem.lower().replace(" ", "_")
    lengths_str = "-".join(str(L) for L in lengths)
    h = hashlib.sha256(repr(cache_key).encode()).hexdigest()[:16]
    return f"v{_INDEX_FORMAT_VERSION}_{basename}_L{lengths_str}_{h}.pkl"


def _hit_in_memory_cache(cache_key: tuple, label: str, verbose: bool) -> ProteomeIndex | None:
    """Return the in-memory cached entry (if any) and update LRU position."""
    cached = _FASTA_INDEX_CACHE.get(cache_key)
    if cached is None:
        return None
    _FASTA_INDEX_CACHE.move_to_end(cache_key)
    if verbose:
        print(f"  ProteomeIndex cache hit for {label}")
    return cached


def _hit_disk_cache(cache_key: tuple, label: str, verbose: bool) -> ProteomeIndex | None:
    """Return the on-disk cached entry (if any) and promote it into the
    in-memory cache so subsequent same-process calls hit the fast path.
    """
    disk_cached = _load_index_from_disk(cache_key)
    if disk_cached is None:
        return None
    if verbose:
        print(f"  ProteomeIndex disk-cache hit for {label}")
    _populate_in_memory_cache(cache_key, disk_cached)
    return disk_cached


def _populate_in_memory_cache(cache_key: tuple, idx: ProteomeIndex) -> None:
    """Insert (or refresh) an entry in the in-memory LRU and evict overflow.

    Each eviction releases the evicted proteome's ~GB-scale arrays so the
    build loop's peak RSS stays bounded by ``maxsize x largest proteome``
    rather than the sum of all proteomes seen so far (issue #109).
    """
    if _FASTA_INDEX_CACHE_MAXSIZE <= 0:
        return
    _FASTA_INDEX_CACHE[cache_key] = idx
    _FASTA_INDEX_CACHE.move_to_end(cache_key)
    while len(_FASTA_INDEX_CACHE) > _FASTA_INDEX_CACHE_MAXSIZE:
        _FASTA_INDEX_CACHE.popitem(last=False)


def _populate_caches(cache_key: tuple, idx: ProteomeIndex) -> None:
    """Populate both caches with a freshly-built index.

    Used by ``from_fasta`` / ``from_ensembl`` after a cold ``_build``
    completes.  Disk-cache writes are best-effort (warns + returns on
    failure rather than crashing the build).
    """
    _populate_in_memory_cache(cache_key, idx)
    _write_index_to_disk(cache_key, idx)


def _resolve_ensembl_gtf_path(ensembl) -> Path | None:
    """Find the local GTF file for a pyensembl release, or return None.

    pyensembl's public surface for this is a moving target across
    versions — newer releases expose ``gtf_path``; older ones nest it
    under ``Genome.requires_gtf`` / ``GenomeSource``.  We probe a small
    sequence of common attribute names and fall back to ``None`` (which
    disables caching for that release) rather than crash.

    Tests with synthetic ``EnsemblRelease`` fakes naturally land here —
    they don't expose any of these attributes — so caching is silently
    skipped and the existing cold-path behavior is preserved.
    """
    for attr in ("gtf_path", "_gtf_path", "gtf"):
        try:
            val = getattr(ensembl, attr)
        except Exception:
            # Includes AttributeError (attr missing) plus property-getter
            # exceptions like OSError when the local GTF hasn't been
            # downloaded yet.  Either way, skip this attr and try the next.
            continue
        if val is None:
            continue
        # Some attrs are properties returning a path string; others are
        # bound methods.  Try call-then-fall-back.
        if callable(val):
            try:
                val = val()
            except Exception:
                continue
        try:
            p = Path(str(val))
        except Exception:
            continue
        if p.is_file():
            return p
    return None


def _build_ensembl_cache_key(
    ensembl,
    release: int,
    species: str,
    gene_biotypes: tuple[str, ...],
    lengths: tuple[int, ...],
) -> tuple | None:
    """Construct the cache key tuple used by ``from_ensembl``.

    Returns ``None`` when pyensembl can't expose a usable GTF path
    (signals "skip caching for this release").
    """
    gtf_path = _resolve_ensembl_gtf_path(ensembl)
    if gtf_path is None:
        return None
    try:
        stat = gtf_path.stat()
    except OSError:
        return None
    return (
        "ensembl",
        int(release),
        str(species),
        tuple(gene_biotypes),
        tuple(lengths),
        stat.st_size,
        stat.st_mtime_ns,
    )


def _load_index_from_disk(cache_key: tuple) -> ProteomeIndex | None:
    """Return a cached index if a fresh-format pickle exists, else None.

    On hit, touches the file's mtime so the LRU eviction sees recent use.
    On any I/O / unpickling failure (corrupt file, partial write, schema
    drift slipping past the version prefix), returns None and removes
    the bad file so the caller can rebuild + re-cache.
    """
    if _resolve_disk_cache_max_gb() <= 0:
        return None
    cache_path = proteome_index_cache_dir() / _disk_cache_filename(cache_key)
    if not cache_path.is_file():
        return None
    try:
        with open(cache_path, "rb") as f:
            idx = pickle.load(f)
    except Exception:
        # Corrupt / partial / wrong-format cache file — drop it so the
        # rebuild path runs and writes a fresh pickle.
        with contextlib.suppress(FileNotFoundError):
            cache_path.unlink()
        return None
    # Touch the file so this hit promotes it in the LRU.  Skip ENOENT
    # races (file evicted between load and touch).
    with contextlib.suppress(FileNotFoundError):
        os.utime(cache_path, None)
    return idx


def _write_index_to_disk(cache_key: tuple, idx: ProteomeIndex) -> None:
    """Persist an index to disk via atomic ``.tmp + rename``.

    Failures are logged via ``warnings.warn`` and otherwise swallowed —
    the in-memory cache + a future cold rebuild are sufficient
    fallbacks; we'd rather not crash a multi-hour build because the
    cache dir filled up.
    """
    if _resolve_disk_cache_max_gb() <= 0:
        return
    cache_dir = proteome_index_cache_dir()
    cache_path = cache_dir / _disk_cache_filename(cache_key)
    # Bind tmp_path before the try so the failure path's cleanup can
    # safely reference it.  Without this, an exception raised by
    # ``mkdir()`` (permission denied, disk full) before the
    # NamedTemporaryFile ever opens would NameError out of the except
    # clause and crash the build.
    tmp_path: Path | None = None
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        # NamedTemporaryFile in same dir → ``os.replace`` is atomic on
        # POSIX (same filesystem guaranteed).  Don't use ``delete=True``
        # because we want the rename, not auto-cleanup.
        with tempfile.NamedTemporaryFile(
            dir=cache_dir,
            prefix=cache_path.name + ".",
            suffix=".tmp",
            delete=False,
        ) as tmp:
            tmp_path = Path(tmp.name)
            pickle.dump(idx, tmp, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(tmp_path, cache_path)
    except Exception as exc:
        warnings.warn(
            f"Failed to write proteome index cache {cache_path}: {exc}",
            stacklevel=2,
        )
        if tmp_path is not None:
            with contextlib.suppress(FileNotFoundError):
                tmp_path.unlink()
        return
    _evict_disk_cache_if_over_cap(protected_path=cache_path)


def _evict_disk_cache_if_over_cap(*, protected_path: Path | None = None) -> None:
    """Evict oldest-mtime cache files until total size ≤ cap.

    Called after every successful write with the exact path just written.
    Uses file mtime as the LRU proxy — ``_load_index_from_disk`` touches
    mtime on every hit, so
    it's a recency-of-use signal even though it doubles as the
    last-modified timestamp.

    A protected entry is never deleted by this pass, even if it alone exceeds
    the cap. Other entries are evicted oldest-first until the cap is met or
    only the protected entry remains. Protection uses the path, not mtime:
    another cache hit can have a later mtime than the write. Prune that path's
    directory so a concurrent root change cannot redirect the write's cleanup.
    Without a protected path, strictly prune the currently selected directory.
    """
    cap_bytes = int(_resolve_disk_cache_max_gb() * 1024**3)
    if cap_bytes <= 0:
        return
    cache_dir = protected_path.parent if protected_path is not None else proteome_index_cache_dir()
    if not cache_dir.is_dir():
        return
    files = []
    total = 0
    for f in cache_dir.glob("*.pkl"):
        try:
            stat = f.stat()
        except FileNotFoundError:
            continue
        files.append((stat.st_mtime, stat.st_size, f))
        total += stat.st_size
    if total <= cap_bytes:
        return
    # Oldest first.
    files.sort(key=lambda t: t[0])
    for _mtime, size, f in files:
        if total <= cap_bytes:
            break
        if f == protected_path:
            continue
        with contextlib.suppress(FileNotFoundError):
            f.unlink()
            total -= size


try:
    from tqdm.auto import tqdm as _tqdm
except ImportError:
    _tqdm = None


@dataclass
class ProteinSource:
    """A source protein occurrence for a peptide."""

    protein_id: str
    gene_name: str
    gene_id: str
    gene_biotype: str
    position: int  # 0-based start in protein
    n_flank: str
    c_flank: str


@dataclass
class ProteomeIndex:
    """Inverted index mapping peptide sequences to source proteins.

    Attributes
    ----------
    proteins : dict[str, str]
        Mapping from protein_id to amino acid sequence.
    protein_meta : dict[str, dict]
        Mapping from protein_id to metadata (gene_name, gene_id,
        gene_biotype, transcript_id, is_canonical_transcript).
    index : _PackedIndex | dict[str, int | np.ndarray]
        Inverted index: peptide -> packed postings. Normally a
        :class:`_PackedIndex` (int-encoded columnar arrays, #250); a legacy
        ``dict[str, int | np.ndarray]`` only for inputs the encoding can't
        represent. Either way, packed postings encode ``(prot_idx<<32)|pos``.
        Use :meth:`lookup` or :meth:`map_peptides` — do not decode
        ``self.index`` directly in callers.
    lengths : tuple[int, ...]
        Peptide lengths that were indexed.
    """

    proteins: dict[str, str] = field(repr=False)
    protein_meta: dict[str, dict] = field(repr=False)
    index: _PackedIndex | dict[str, int | np.ndarray] = field(repr=False)
    lengths: tuple[int, ...]
    # Internal reverse lookup: int prot_idx → protein_id string.
    # Populated in _build; kept in insertion order matching ``proteins``.
    _protein_ids: list[str] = field(default_factory=list, repr=False)

    @classmethod
    def from_ensembl(
        cls,
        release: int = 112,
        lengths: tuple[int, ...] = (SEED_KMER_LENGTH,),
        biotype: str | None = None,
        verbose: bool = True,
        species: str = "human",
        *,
        gene_biotypes: Iterable[str] | None = None,
    ) -> ProteomeIndex:
        """Build an index from translated Ensembl gene records.

        Parameters
        ----------
        release
            Ensembl release number.
        lengths
            Peptide lengths to index.
        biotype
            Backward-compatible single-biotype filter. For example,
            ``biotype="protein_coding"`` reproduces the pre-1.55.8 narrow
            index. Mutually exclusive with ``gene_biotypes``.
        verbose
            Print progress messages.
        species
            pyensembl species key (``"human"``, ``"mouse"``, ``"rat"``, ...).
        gene_biotypes
            Gene biotypes to include. By default, includes ordinary
            ``protein_coding`` genes plus the eight translated IG/TR germline
            biotypes in :data:`ENSEMBL_CODING_GENE_BIOTYPES`. Pseudogene
            biotypes are deliberately excluded. Ensembl contains germline
            V/D/J/C segments, not donor-specific rearranged receptors, so
            peptides spanning a V(D)J junction remain outside this index.

        Returns
        -------
        ProteomeIndex

        Notes
        -----
        Caching (#251): both the in-memory ``_FASTA_INDEX_CACHE`` and the
        on-disk pickle cache from ``from_fasta`` are reused here.  The
        cache key is keyed off pyensembl's local GTF file size + mtime —
        when pyensembl's release data hasn't changed, repeated calls
        skip the multi-second per-gene iteration + ``_build`` k-mer pass.

        This matters most for downstream invokers (e.g. tsarina) that
        spawn a fresh process per patient.  hitlist's process-wide
        ``lru_cache`` is irrelevant across process boundaries; the disk
        cache amortizes there.

        When pyensembl can't expose a usable GTF path (synthetic mocks
        in tests, or patched releases without a local GTF), caching is
        silently disabled and the cold path runs as before.
        """
        from pyensembl import EnsemblRelease

        if biotype is not None and gene_biotypes is not None:
            raise ValueError("Pass either biotype or gene_biotypes, not both")
        selected_biotypes = _normalize_ensembl_gene_biotypes(
            biotype if biotype is not None else gene_biotypes
        )
        selected_biotype_set = set(selected_biotypes)

        ensembl = EnsemblRelease(release, species=species)

        # Build the cache key off pyensembl's local GTF (size + mtime).
        # When unresolvable (test fakes, missing local GTF), skip caching.
        cache_key = _build_ensembl_cache_key(ensembl, release, species, selected_biotypes, lengths)
        if cache_key is not None:
            label = f"ensembl {species} r{release}"
            hit = _hit_in_memory_cache(cache_key, label, verbose)
            if hit is None:
                hit = _hit_disk_cache(cache_key, label, verbose)
            if hit is not None:
                return hit

        proteins: dict[str, str] = {}
        meta: dict[str, dict] = {}

        genes = list(ensembl.genes())
        gene_iter = (
            _tqdm(genes, desc="Loading proteins", leave=False) if (_tqdm and verbose) else genes
        )

        for gene in gene_iter:
            gene_biotype = str(gene.biotype)
            if gene_biotype not in selected_biotype_set:
                continue
            # Issue #141: index every translated selected transcript per gene
            # rather than collapsing each gene to its longest transcript.
            # The canonical transcript is identified post-hoc as the
            # longest valid translation (a stable, pyensembl-version-
            # independent definition), and every transcript is recorded
            # with its own ``transcript_id`` so downstream consumers can
            # distinguish gene-level ambiguity from transcript-isoform
            # ambiguity in mapping rows.
            transcript_records: list[tuple[str, str, str]] = []
            for t in gene.transcripts:
                if getattr(t, "biotype", "") not in selected_biotype_set:
                    continue
                try:
                    seq = t.protein_sequence
                except Exception:
                    continue
                if not seq:
                    continue
                # Prefer the stable Ensembl protein/translation ID (ENSP)
                # as the index key.  When pyensembl can't surface it,
                # fall back to the transcript ID (ENST) so the proteome
                # still indexes — but the ``transcript_id`` meta column
                # always carries the ENST.
                protein_key = getattr(t, "protein_id", None) or t.id
                transcript_records.append((protein_key, t.id, seq))

            if not transcript_records:
                continue

            canonical_protein_key = max(transcript_records, key=lambda r: len(r[2]))[0]

            for protein_key, transcript_id, seq in transcript_records:
                if protein_key in proteins:
                    # Same ENSP shared by multiple transcripts (rare but
                    # possible when alternative ENSTs translate identically).
                    # Skip duplicates — the meta we already have is correct.
                    continue
                proteins[protein_key] = seq
                meta[protein_key] = {
                    "gene_name": gene.name,
                    "gene_id": gene.id,
                    "gene_biotype": gene_biotype,
                    "transcript_id": transcript_id,
                    "is_canonical_transcript": protein_key == canonical_protein_key,
                }

        idx = cls._build(proteins, meta, lengths, verbose)
        if cache_key is not None:
            _populate_caches(cache_key, idx)
        return idx

    @classmethod
    def from_fasta(
        cls,
        path: str | Path,
        lengths: tuple[int, ...] = (SEED_KMER_LENGTH,),
        gene_name: str = "",
        gene_id: str = "",
        verbose: bool = True,
    ) -> ProteomeIndex:
        """Build index from a FASTA file.

        Memoized by ``(resolved_path, size, mtime, lengths, gene_name,
        gene_id)`` for the lifetime of the process. Repeated calls with
        the same inputs return the same ``ProteomeIndex`` instance
        without re-parsing the FASTA — important during flanking passes
        where multiple canonical species names (e.g. several LCMV or
        SARS-CoV-2 strain variants) fall back to one shared cached
        FASTA. The (size, mtime) part of the key invalidates the entry
        automatically if the on-disk file changes.

        Parameters
        ----------
        path
            Path to FASTA file.
        lengths
            Peptide lengths to index.
        gene_name, gene_id
            Default gene name/ID for all proteins (overridden by FASTA headers).
        verbose
            Print progress.

        Returns
        -------
        ProteomeIndex
        """
        resolved = Path(path).resolve()
        try:
            stat = resolved.stat()
            cache_key: tuple | None = (
                str(resolved),
                stat.st_size,
                stat.st_mtime_ns,
                tuple(lengths),
                gene_name,
                gene_id,
            )
        except OSError:
            # If the FASTA moved/was deleted between resolution and stat,
            # fall through to the uncached path — the open() below will
            # raise with a more actionable FileNotFoundError.
            cache_key = None

        if cache_key is not None:
            label = resolved.name
            hit = _hit_in_memory_cache(cache_key, label, verbose)
            if hit is None:
                # In-memory miss → check the on-disk cache (#246).
                hit = _hit_disk_cache(cache_key, label, verbose)
            if hit is not None:
                return hit

        proteins: dict[str, str] = {}
        meta: dict[str, dict] = {}
        current_id = ""
        current_seq: list[str] = []
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line.startswith(">"):
                    if current_id:
                        proteins[current_id] = "".join(current_seq)
                    header = line[1:].strip()
                    current_id = header.split()[0] if header else header
                    # Try to parse gene name from header (UniProt format: GN=GENENAME)
                    gn = gene_name
                    if "GN=" in header:
                        gn = header.split("GN=")[1].split()[0]
                    # FASTA-backed entries don't carry transcript identity,
                    # but emitting the keys keeps the meta schema uniform
                    # with the Ensembl path so map_peptides output has
                    # consistent columns regardless of backend (#141).
                    meta[current_id] = {
                        "gene_name": gn,
                        "gene_id": gene_id,
                        # UniProt/custom FASTAs do not expose an Ensembl gene
                        # biotype. Empty means unavailable, not protein_coding.
                        "gene_biotype": "",
                        "transcript_id": "",
                        "is_canonical_transcript": False,
                    }
                    current_seq = []
                else:
                    current_seq.append(line)
        if current_id:
            proteins[current_id] = "".join(current_seq)
        idx = cls._build(proteins, meta, lengths, verbose)
        if cache_key is not None:
            _populate_caches(cache_key, idx)
        return idx

    @classmethod
    def _build(
        cls,
        proteins: dict[str, str],
        meta: dict[str, dict],
        lengths: tuple[int, ...],
        verbose: bool,
    ) -> ProteomeIndex:
        """Build the k-mer index.

        Fast path (#250): vectorized int-encoded columnar build via
        :meth:`_PackedIndex.build` — k-mers pack into uint64 codes, so the
        inner work is numpy shifts + one sort per length instead of ~100M
        Python ``dict.get`` ops.  Falls back to the legacy string-dict build
        when the data can't be encoded (alphabet x length over budget, or a
        non-standard residue).
        """
        protein_ids: list[str] = list(proteins.keys())
        prot_to_idx: dict[str, int] = {pid: i for i, pid in enumerate(protein_ids)}

        packed = _PackedIndex.build(proteins, prot_to_idx, lengths)
        if packed is not None:
            if verbose:
                n_single = sum(int((np.diff(packed.offsets[k]) == 1).sum()) for k in packed.lengths)
                print(
                    f"ProteomeIndex: {len(proteins):,} proteins, "
                    f"{packed.n_kmers:,} unique k-mers ({'/'.join(str(k) for k in lengths)}-mers, "
                    f"{n_single:,} single-hit / {packed.n_kmers - n_single:,} multi-hit)"
                )
            return cls(
                proteins=proteins,
                protein_meta=meta,
                index=packed,
                lengths=tuple(lengths),
                _protein_ids=protein_ids,
            )
        return cls._build_legacy(proteins, meta, lengths, verbose, protein_ids, prot_to_idx)

    @classmethod
    def _build_legacy(
        cls,
        proteins: dict[str, str],
        meta: dict[str, dict],
        lengths: tuple[int, ...],
        verbose: bool,
        protein_ids: list[str],
        prot_to_idx: dict[str, int],
    ) -> ProteomeIndex:
        """Legacy string-keyed dict build — correctness fallback for inputs
        the int encoding can't represent (see :meth:`_PackedIndex.build`)."""
        # Phase 1: collect raw packed postings per k-mer.
        #
        # Hot loop: cProfile (#176) showed 1.13B ``_pack`` calls dominating
        # runtime — pure Python function-call overhead since ``_pack`` does
        # only a shift+OR. We inline the pack op and hoist the per-protein
        # shift out of the inner loop; the per-kmer cost drops to a string
        # slice + dict lookup + OR + list op. Tried ``setdefault`` here and
        # it benchmarked ~10% slower because the default ``[]`` is built
        # on every call even on the common existing-key path.
        raw: dict[str, list[int]] = {}
        items = list(proteins.items())
        prot_iter = (
            _tqdm(items, desc="Building index", leave=False) if (_tqdm and verbose) else items
        )
        for prot_id, seq in prot_iter:
            pi_shifted = prot_to_idx[prot_id] << _PROT_BITS
            seq_len = len(seq)
            for k in lengths:
                end = seq_len - k + 1
                for i in range(end):
                    kmer = seq[i : i + k]
                    packed = pi_shifted | i
                    posting = raw.get(kmer)
                    if posting is None:
                        raw[kmer] = [packed]
                    else:
                        posting.append(packed)

        # Phase 2: compact — singletons → scalar int, multis → np.ndarray.
        index: dict[str, int | np.ndarray] = {}
        for kmer, postings in raw.items():
            if len(postings) == 1:
                index[kmer] = postings[0]
            else:
                index[kmer] = np.asarray(postings, dtype=np.int64)
        del raw  # release the list-of-list backing store before return

        if verbose:
            n_single = sum(1 for v in index.values() if isinstance(v, int))
            print(
                f"ProteomeIndex: {len(proteins):,} proteins, "
                f"{len(index):,} unique k-mers ({'/'.join(str(k) for k in lengths)}-mers, "
                f"{n_single:,} single-hit / {len(index) - n_single:,} multi-hit)"
            )
        return cls(
            proteins=proteins,
            protein_meta=meta,
            index=index,
            lengths=lengths,
            _protein_ids=protein_ids,
        )

    def merge(self, other: ProteomeIndex) -> ProteomeIndex:
        """Merge another index into this one.

        Combines proteins, metadata, and k-mer index entries from both.
        Useful for combining human + viral proteome indices. Rebuilds the
        compact posting representation — the simplest correct path since
        protein indices in ``self`` and ``other`` refer to disjoint ID
        spaces and have to be renumbered against the merged protein list.

        Parameters
        ----------
        other
            Another ProteomeIndex to merge in.

        Returns
        -------
        ProteomeIndex
            New merged index (does not modify self or other).
        """
        proteins = {**self.proteins, **other.proteins}
        meta = {**self.protein_meta, **other.protein_meta}
        lengths = tuple(sorted(set(self.lengths) | set(other.lengths)))
        # Cheapest correct merge: rebuild from scratch against the unioned
        # protein dict. For the typical use case (human + a handful of
        # viral FASTAs) this is only a few percent of the original build
        # cost since viral proteomes are tiny.
        return self.__class__._build(proteins, meta, lengths, verbose=False)

    @classmethod
    def from_ensembl_plus_fastas(
        cls,
        fasta_paths: list[str | Path] | None = None,
        release: int = 112,
        lengths: tuple[int, ...] = (SEED_KMER_LENGTH,),
        verbose: bool = True,
    ) -> ProteomeIndex:
        """Build a combined human + viral/custom proteome index.

        Parameters
        ----------
        fasta_paths
            List of FASTA files to include (e.g. viral proteomes).
        release
            Ensembl release for human proteome.
        lengths
            Peptide lengths to index.
        verbose
            Print progress.

        Returns
        -------
        ProteomeIndex
            Merged index covering human and all provided FASTA proteomes.
        """
        idx = cls.from_ensembl(release=release, lengths=lengths, verbose=verbose)
        for fasta in fasta_paths or []:
            viral_idx = cls.from_fasta(fasta, lengths=lengths, verbose=verbose)
            idx = idx.merge(viral_idx)
        return idx

    @cached_property
    def all_kmers(self) -> frozenset[str]:
        """Every unique k-mer (at ``self.lengths``) across all indexed proteins.

        Cached on first access. Typical sizes:

        - Human at one seed length: ~11 M k-mers, ~492 MB packed.
        - Human at (9,): ~10 M k-mers, ~250 MB.

        The primitive that downstream packages (tsarina, perseus, topiary,
        notebook scripts) use for self-peptide subtraction. See also the
        module-level :func:`proteome_kmer_set` if the caller doesn't need
        the full :class:`ProteomeIndex` object.
        """
        if isinstance(self.index, _PackedIndex):
            return frozenset(self.index.iter_kmers())
        return frozenset(self.index.keys())

    def kmers_for_genes(self, gene_ids: frozenset[str]) -> frozenset[str]:
        """K-mers restricted to proteins with these Ensembl gene IDs.

        Walks the proteins table rather than the k-mer index because the
        compact posting representation stores prot_idx ints, not gene_ids
        — filtering the index directly would be slower than re-extracting
        k-mers from the selected protein sequences.

        Parameters
        ----------
        gene_ids
            Set of Ensembl gene IDs to include. Must be a frozenset for
            hashability (the module-level :func:`proteome_kmer_set` wraps
            callers so they can pass a regular set too).

        Returns
        -------
        frozenset[str]
            Unique k-mers at ``self.lengths`` from proteins whose
            ``protein_meta[...].gene_id`` is in ``gene_ids``.
        """
        if not gene_ids:
            return frozenset()
        out: set[str] = set()
        for prot_id, seq in self.proteins.items():
            gid = self.protein_meta.get(prot_id, {}).get("gene_id", "")
            if gid not in gene_ids:
                continue
            for k in self.lengths:
                for i in range(len(seq) - k + 1):
                    out.add(seq[i : i + k])
        return frozenset(out)

    def lookup(self, peptide: str) -> list[tuple[str, int]]:
        """Locate a peptide, at any length at or above the seed.

        Returns a list of ``(protein_id, position)`` tuples.

        **Seed and verify.**  The packed index encodes each k-mer into one
        63-bit integer, so it can only carry lengths where ``bits * k <= 63``
        -- 12 residues at 5 bits.  Treating that ceiling as the set of
        *peptide* lengths we could map is what silently excluded every class
        II peptide: they run 12-25 residues, so none were ever mapped and none
        received flanks, position, gene or protein annotation (#394).

        Widening the indexed lengths is not the fix, and was never going to
        be.  Above the bit budget :meth:`_PackedIndex.build` returns ``None``
        and the caller falls back to the legacy dict index -- the ~10 GB per
        length build that #109 removed -- and even at the ceiling of 12 it
        would reach only 12% of class II rows.

        Instead the index stores one *seed* length and the peptide's own
        length stops mattering: look up the first ``k`` residues, then keep
        only the hits where the protein really does continue with the
        remaining ``L - k``.  Exact, because every candidate is checked
        against the source sequence; cheap, because a protein k-mer at
        ``k >= 7`` is near-unique (mean 3.7 candidates, p99 20 on human), so
        verification is a handful of string comparisons.

        A peptide shorter than the seed cannot be seeded and returns ``[]``.
        With ``SEED_KMER_LENGTH = 7`` that is only length 2-6 -- 2,826 corpus
        rows, none of them plausible MHC ligands.  Lowering the seed to cover
        them is not worth it: at k=5 the mean candidate count is 16.6 and the
        worst seed hits 10,022 positions.
        """
        if not peptide or not self.lengths:
            return []
        seeds = [L for L in self.lengths if len(peptide) >= L]
        if not seeds:
            return []
        k = max(seeds)
        if isinstance(self.index, _PackedIndex):
            postings = self.index.get_postings(peptide[:k])
        else:
            postings = self.index.get(peptide[:k])
        if postings is None:
            return []
        if isinstance(postings, (int, np.integer)):
            postings = [postings]
        out: list[tuple[str, int]] = []
        span = len(peptide)
        for packed in postings:
            prot_idx, pos = _unpack(int(packed))
            prot_id = self._protein_ids[prot_idx]
            # Verification is what makes this exact rather than a prefix
            # match.  For an exact-length peptide (L == k) it is trivially
            # true, so one code path serves both cases.
            if self.proteins[prot_id][pos : pos + span] == peptide:
                out.append((prot_id, pos))
        return out

    def map_peptides(
        self,
        peptides: list[str] | set[str],
        flank: int = DEFAULT_FLANK,
        verbose: bool = True,
    ) -> pd.DataFrame:
        """Map peptides to source proteins with flanking context.

        Parameters
        ----------
        peptides
            Peptide sequences to map.
        flank
            Number of flanking residues to extract on each side
            (default :data:`DEFAULT_FLANK`).  Flanks are truncated at protein
            termini, so a flank shorter than this means the peptide sits
            within ``flank`` residues of an end -- not that context is
            missing.  Every row in the returned frame is a real mapping.
        verbose
            Show progress bar.

        Returns
        -------
        pd.DataFrame
            One row per (peptide, source protein) occurrence. Columns:
            ``peptide``, ``protein_id``, ``gene_name``, ``gene_id``,
            ``gene_biotype``, ``position`` (0-based), ``n_flank``, ``c_flank``,
            ``n_sources`` (total source count for this peptide),
            ``unique_nflank`` (set if all sources have same n_flank, else ""),
            ``unique_cflank`` (same for c_flank).
        """
        peptide_list = list(set(peptides))
        pep_iter = (
            _tqdm(peptide_list, desc="Mapping peptides", leave=False)
            if (_tqdm and verbose)
            else peptide_list
        )

        rows: list[dict] = []
        for pep in pep_iter:
            hits = self.lookup(pep)
            for prot_id, pos in hits:
                seq = self.proteins[prot_id]
                m = self.protein_meta.get(prot_id, {})
                n_flank = seq[max(0, pos - flank) : pos]
                c_flank = seq[pos + len(pep) : pos + len(pep) + flank]
                rows.append(
                    {
                        "peptide": pep,
                        "protein_id": prot_id,
                        "gene_name": m.get("gene_name", ""),
                        "gene_id": m.get("gene_id", ""),
                        "gene_biotype": m.get("gene_biotype", ""),
                        # Issue #141: transcript_id is now a first-class
                        # column distinct from protein_id.  For Ensembl-
                        # backed indexes it carries the ENST; for FASTA-
                        # backed indexes it's "".  is_canonical_transcript
                        # marks the longest translated selected transcript per
                        # gene (the Ensembl-canonical proxy).
                        "transcript_id": m.get("transcript_id", ""),
                        "is_canonical_transcript": bool(m.get("is_canonical_transcript", False)),
                        "position": pos,
                        "n_flank": n_flank,
                        "c_flank": c_flank,
                    }
                )

        if not rows:
            return pd.DataFrame(
                columns=[
                    "peptide",
                    "protein_id",
                    "gene_name",
                    "gene_id",
                    "gene_biotype",
                    "transcript_id",
                    "is_canonical_transcript",
                    "position",
                    "n_flank",
                    "c_flank",
                    "n_sources",
                    "unique_nflank",
                    "unique_cflank",
                ]
            )

        df = pd.DataFrame(rows)

        # Compute per-peptide source counts and unique flank indicators
        source_counts = df.groupby("peptide")["protein_id"].nunique().rename("n_sources")
        df = df.merge(source_counts, on="peptide", how="left")

        # Unique flank: if all sources have the same flank, store it; else ""
        for side in ["n_flank", "c_flank"]:
            unique_col = f"unique_{side}"
            unique_map: dict[str, str] = {}
            for pep, group in df.groupby("peptide"):
                flanks = set(group[side])
                unique_map[str(pep)] = next(iter(flanks)) if len(flanks) == 1 else ""
            df[unique_col] = df["peptide"].map(unique_map)

        return df


# ---------------------------------------------------------------------------
# Module-level k-mer primitive for cross-package caching (#99).
# ---------------------------------------------------------------------------
#
# Shared by tsarina (self-peptide subtraction), perseus, topiary, and any
# future consumer that wants "every translated coding k-mer at lengths X,
# optionally restricted to a gene subset." Delegates to ProteomeIndex
# but caches the frozenset so repeated calls with the same arguments are
# sub-millisecond.
#
# Note that the cache composes with ``ProteomeIndex.from_ensembl``'s own
# cost: the first call to ``proteome_kmer_set(release, lengths)`` pays
# the ProteomeIndex build (~45 s for human at all 4 MHC-I lengths),
# subsequent identical calls return the cached frozenset in <1 ms.


@lru_cache(maxsize=8)
def _proteome_kmer_set_cached(
    release: int,
    lengths: tuple[int, ...],
    species: str,
    gene_ids_frozen: frozenset[str] | None,
) -> frozenset[str]:
    """Cache backend for :func:`proteome_kmer_set`.

    ``gene_ids_frozen`` must be hashable (``frozenset`` or ``None``) so
    the ``@lru_cache`` key is stable across callers that pass equivalent
    sets in different orders.
    """
    idx = ProteomeIndex.from_ensembl(
        release=release,
        lengths=lengths,
        species=species,
        verbose=False,
    )
    if gene_ids_frozen is None:
        return idx.all_kmers
    return idx.kmers_for_genes(gene_ids_frozen)


def proteome_kmer_set(
    release: int = 112,
    lengths: tuple[int, ...] = (SEED_KMER_LENGTH,),
    gene_ids: frozenset[str] | set[str] | None = None,
    species: str = "human",
) -> frozenset[str]:
    """Every translated coding k-mer in the proteome, cached across calls.

    The canonical primitive for self-peptide subtraction, vaccine /
    neoantigen candidate filtering, and any other workflow that needs a
    fast "is this sequence a human k-mer?" membership test. Replaces
    per-package local implementations in tsarina, perseus, etc.

    Parameters
    ----------
    release
        Ensembl release. Default 112.
    lengths
        Peptide lengths to include. Must be a tuple (hashable) so the
        cache key is stable. Default ``(SEED_KMER_LENGTH,)`` -- one seed
        length; peptides of any length >= it are found by seed-and-verify.
    gene_ids
        Optional set of Ensembl gene IDs to restrict to. When ``None``
        (default), returns the full proteome's k-mer set. Accepts ``set``
        for convenience — internally frozen for the cache key.
    species
        pyensembl species key. Default ``"human"``.

    Returns
    -------
    frozenset[str]
        Unique peptide sequences at the specified lengths.

    Notes
    -----
    - The default Ensembl index includes conventional protein-coding genes and
      coding IG/TR germline segments, but not pseudogenes or donor-specific
      rearranged V(D)J junctions.
    - First call: ~10-60 s (ProteomeIndex build + iteration). Memory
      peak during the call is bounded by the ProteomeIndex
      representation (v1.14.0+: ~3 GB for human at all 4 lengths).
    - Subsequent calls with identical arguments: <1 ms (cached frozenset).
    - Gene subset calls walk protein sequences filtered by gene_id
      rather than the k-mer index, because the compact packed-int64
      posting representation doesn't carry gene IDs.
    - Cache size is 8. If you need more distinct ``(release, lengths,
      gene_ids)`` combinations live at once, call
      :meth:`ProteomeIndex.kmers_for_genes` directly on a longer-lived
      ProteomeIndex instance instead.
    """
    gene_ids_frozen = frozenset(gene_ids) if gene_ids is not None else None
    return _proteome_kmer_set_cached(release, tuple(lengths), species, gene_ids_frozen)


# ---------------------------------------------------------------------------
# In-silico protease digest (#104).
# ---------------------------------------------------------------------------
#
# MaxQuant/Andromeda specificity pairs, verified against Cox Lab's own table:
# https://github.com/cox-labs/PluginTutorial/blob/25bdb094d6b23c1f4c3e07aa4c766e43fa4bee5b/PluginTutorial/conf/enzymes.xml
# (cleavage residues, excluded following residues, required following residues).
_ENZYME_RULES = {
    "Trypsin": ("KR", "P", ""),
    "Trypsin/P": ("KR", "", ""),
    "Chymotrypsin": ("FWY", "", ""),
    "Chymotrypsin+": ("FWYLM", "", ""),
    "GluC": ("E", "", ""),
    "D.P": ("D", "", "P"),
    "LysC": ("K", "P", ""),
    "LysC/P": ("K", "", ""),
}
_ENZYME_ALIASES = {name.lower(): name for name in _ENZYME_RULES}
_ENZYME_ALIASES["chymo"] = "Chymotrypsin+"


def canonical_search_enzyme(enzyme: str) -> str:
    """Resolve exact search definitions, including unions such as GluC;D.P.

    Biological digest labels in older bulk tables are not search definitions.
    In particular, Trypsin and Trypsin/P have different proline specificity.
    """
    if not isinstance(enzyme, str):
        raise TypeError("enzyme must be a search-enzyme name")
    names = []
    for component in enzyme.split(";"):
        canonical = _ENZYME_ALIASES.get(component.strip().lower())
        if canonical is None:
            raise ValueError(
                f"Unknown enzyme {enzyme!r}. Use an exact search definition: "
                f"{sorted(_ENZYME_RULES)}, or a semicolon-separated union. "
                "The legacy 'Trypsin/P (cleaves K/R except before P)' label is "
                "contradictory: choose Trypsin or Trypsin/P explicitly."
            )
        if canonical not in names:
            names.append(canonical)
    return ";".join(sorted(names))


@dataclass(frozen=True)
class DigestedPeptide:
    """One occurrence; positions are 1-based, inclusive, like MaxQuant exports."""

    peptide: str
    start_position: int
    end_position: int
    n_missed_cleavages: int


def digest_occurrences(
    seq: str,
    enzyme: str = "Trypsin/P",
    min_len: int = 7,
    max_len: int = 30,
    max_missed: int = 2,
):
    """Yield theoretical fully specific peptide occurrences, preserving repeats.

    Uses MaxQuant's exact enzyme definitions. Trypsin excludes K/R-P cleavage;
    Trypsin/P permits it. Chymotrypsin+ includes F/W/Y/L/M and permits cleavage
    before P. GluC cleaves after E (including E-P); GluC;D.P additionally cleaves
    D-P pairs, not every D. LysC excludes K-P; LysC/P permits it.

    A theoretical digest alone cannot label an unobserved peptide as a valid
    negative: the actual search database/settings, protein observation and
    acquisition scope also have to match. ``max_missed=2`` is a caller-selected
    default, not a claim about any study's search settings (#654).
    """
    from numbers import Integral

    if not isinstance(seq, str):
        raise TypeError("seq must be a protein sequence string")
    for name, value, minimum in (
        ("min_len", min_len, 1),
        ("max_len", max_len, 1),
        ("max_missed", max_missed, 0),
    ):
        if isinstance(value, bool) or not isinstance(value, Integral) or value < minimum:
            raise ValueError(f"{name} must be an integer >= {minimum}")
    if min_len > max_len:
        raise ValueError("min_len cannot exceed max_len")
    rules = [_ENZYME_RULES[name] for name in canonical_search_enzyme(enzyme).split(";")]
    cuts = [0]
    for position, (left, right) in enumerate(pairwise(seq), start=1):
        if any(
            left in residues and right not in excluded and (not required or right in required)
            for residues, excluded, required in rules
        ):
            cuts.append(position)
    cuts.append(len(seq))
    for first in range(len(cuts) - 1):
        for last in range(first + 1, min(first + max_missed + 2, len(cuts))):
            start, end = cuts[first], cuts[last]
            if end - start > max_len:
                break
            if min_len <= end - start <= max_len:
                yield DigestedPeptide(seq[start:end], start + 1, end, last - first - 1)


def digest(
    seq: str,
    enzyme: str = "Trypsin/P",
    min_len: int = 7,
    max_len: int = 30,
    max_missed: int = 2,
) -> set[str]:
    """Return unique sequences from :func:`digest_occurrences`.

    Search enzymes follow MaxQuant definitions, including the distinction between
    classical Trypsin and Trypsin/P. For training, use occurrence-preserving
    candidates plus the actual search-space, protein and acquisition controls;
    set subtraction alone does not establish valid absence labels.
    """
    return {row.peptide for row in digest_occurrences(seq, enzyme, min_len, max_len, max_missed)}
