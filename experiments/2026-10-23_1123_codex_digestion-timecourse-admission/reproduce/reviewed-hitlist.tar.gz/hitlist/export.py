# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Export curated study metadata and model-facing pMHC tables.

Reads ``pmid_overrides.yaml`` and generates per-sample, per-species,
and allele-validation reports from the ``ms_samples`` and ``hla_alleles``
metadata fields.

The main MS artifact is :func:`generate_ms_observations_table`, with
:func:`generate_observations_table` retained as a backward-compatible alias.
That join
per-peptide observations (from IEDB/CEDAR) with per-sample metadata
(from ``ms_samples``), and :func:`generate_training_table`, which
composes the built MS, binding, and peptide-mapping indexes into a
unified export surface for downstream training workflows.
"""

from __future__ import annotations

import re
from typing import NamedTuple
from urllib.parse import quote

import numpy as np
import pandas as pd

from .conditions import (
    ARM_SPECIFIC_CONDITION_COLUMNS,
    CONDITION_COLUMNS,
    condition_columns_for_sample,
    empty_condition_columns,
    engineered_material_mask,
)
from .curation import (
    MHC_GENOTYPE_COLUMNS,
    MHC_TYPING_COLUMNS,
    allele_to_all_serotypes,
    allele_to_serotype,
    expand_allele_components,
    load_pmid_overrides,
    mhc_class_of,
    mhc_species_of,
    normalize_allele,
    normalize_mhc_class_token,
    normalize_species,
    reported_mhc_fields_overlap,
    sample_mhc_candidates,
    sample_mhc_metadata,
    serotype_to_alleles,
    species_axes_agreement,
)
from .curation import normalize_serotype_query as _normalize_serotype_query
from .dataset import dataset_snapshot
from .pandas_utils import fillna_scalar_safe as _fillna_scalar_safe
from .species_contexts import (
    ARM_SPECIFIC_SPECIES_CONTEXT_COLUMNS,
    SPECIES_CONTEXT_COLUMNS,
    empty_species_context_columns,
    species_context_for_sample,
)

# MS acquisition metadata fields.  Each may appear at the PMID level
# (study-wide default) or on individual ``ms_samples`` entries.
# Per-sample values override PMID-level defaults.
_ACQUISITION_FIELDS = (
    "ip_antibody",
    "acquisition_mode",
    "instrument",
    "fragmentation",
    "labeling",
    "search_engine",
    "fdr",
)

# Low-cardinality metadata columns that ``generate_observations_table``
# brings in via the ``ms_samples`` join / PMID dict-lookups (so they arrive
# as plain object/string dtype, not via the dictionary-encoded parquet read
# path).  On a ~4.4M-row table each costs hundreds of MB of per-worker
# Python ``str`` overhead; as Categoricals they shrink ~30x and round-trip
# through Arrow IPC as dictionary-encoded columns that pytest-xdist workers
# can mmap-share zero-copy (companion to #262).  See #263.
#
# Names are the *pre-rename* obs column names ("mhc", not "sample_mhc") —
# the conversion runs before the mhc→sample_mhc rename, which preserves the
# categorical dtype.  Genuinely high-cardinality columns (peptide,
# peptide_extended, *_iri, free-text comments) and semicolon-joined
# multi-value columns (serotypes, mhc_allele_set, host_mhc_types,
# apm_genes_perturbed) are intentionally excluded.  The ``mhc_genotype*``
# block below is the documented exception and not a loosening of that rule:
# those columns are multi-value and one is free text, but every value comes
# from one of ~120 curated samples, so the category set is bounded by curation
# rather than by the corpus -- which is the property the rule is really about
# (#564) — mirrors
# ``builder._CATEGORICAL_BUILD_COLUMNS``.  Audited cardinalities are all
# < 0.03% of rows; the biggest memory wins are mhc (479 MB),
# mhc_class_label_severity (227 MB) and mhc_restriction (224 MB).
_CATEGORICAL_EXPORT_METADATA_COLS: tuple[str, ...] = (
    # ms_samples join metadata
    "mhc",  # → sample_mhc after rename
    *MHC_TYPING_COLUMNS,
    "instrument",
    "instrument_type",
    "acquisition_mode",
    "fragmentation",
    "labeling",
    "ip_antibody",
    "search_engine",
    "fdr",
    # NB: ``sample_label`` is deliberately NOT categoricalized — it's a
    # sample-identity column that consumers compare element-wise against
    # ``cell_name`` (itself already categorical), and two categoricals with
    # different category sets cannot be compared.  Keeping it string-typed
    # preserves categorical-vs-string value comparison.
    "sample_match_type",
    "sample_mhc_origin",
    "perturbation",
    "condition_category",
    # ms_samples provenance (#373): three curated values and a note that is
    # populated on a handful of samples, so both are tiny category sets.
    "effective_override",
    "effective_override_origin",
    "note",
    "sample_group",
    "arm_resolution",
    # The flat condition block (#450).  Every value is derived from one of
    # 761 curated arms, so each column's cardinality is bounded by that —
    # small enough for int8/int16 codes on a 4.4M-row table.  Multi-value
    # cells stay categorical here (unlike apm_genes_perturbed) because they
    # are sorted and canonical, so equal cells really are one category.
    *CONDITION_COLUMNS,
    # Independently reviewed literature contexts are also bounded by the
    # curation registry, including the free-text scope and citation fields.
    *SPECIES_CONTEXT_COLUMNS,
    # PMID-level / derived low-cardinality metadata
    "quantification_method",
    "mhc_class_label_severity",
    "monoallelic_host",
    "attributed_sample_label",
    "submission_id",
    "supplementary_file",
    # parquet columns that *should* be categorical but arrive as string on
    # this load path
    "mhc_restriction",
    "cell_line_name",
    # Measured, not assumed (#450).  "free-text comments" were excluded on the
    # theory that they are high-cardinality; on the current corpus they are
    # not, because they are written per study and repeated across every row of
    # it.  Distinct values over 4,439,321 rows, with the memory each column
    # costs as plain strings:
    #
    #   reference_title              2,285   0.05%   498 MB
    #   antigen_processing_comments  2,618   0.06%   377 MB
    #   assay_comments               7,341   0.17%   192 MB
    #   sample_attribution              11       -    75 MB
    #   apm_perturbed                    3       -    48 MB
    #   is_control_arm                   3       -    46 MB
    #
    # Together ~1.24 GB of a 3.6 GB frame, for ~30 MB of codes. The genuinely
    # high-cardinality columns stay out and are worth naming so the next
    # audit does not re-derive them: assay_iri is 99.5% distinct (one per
    # row), reference_iri 12.1%, peptide 30.2%, peptide_extended 27.9%.
    "reference_title",
    "antigen_processing_comments",
    "assay_comments",
    "sample_attribution",
    "apm_perturbed",
    "is_control_arm",
)

# Map specific instrument models → category.  Keys are matched as
# case-insensitive substrings against the ``instrument`` field.
_INSTRUMENT_TYPE_MAP = [
    ("timstof", "timsTOF"),
    ("tims tof", "timsTOF"),
    ("lumos", "Orbitrap"),
    ("fusion", "Orbitrap"),
    ("exploris", "Orbitrap"),
    ("astral", "Orbitrap"),
    ("eclipse", "Orbitrap"),
    ("q exactive", "Orbitrap"),
    ("qe ", "Orbitrap"),
    ("qe+", "Orbitrap"),
    ("orbitrap", "Orbitrap"),
    ("ltq", "Orbitrap"),
    ("velos", "Orbitrap"),
    ("elite", "Orbitrap"),
    ("triple tof", "TOF"),
    ("tripletof", "TOF"),
    ("sciex", "TOF"),
    ("synapt", "TOF"),
    ("xevo", "TOF"),
    ("qtof", "TOF"),
    ("tsq", "QqQ"),
    ("triple quad", "QqQ"),
    ("altis", "QqQ"),
    ("quantiva", "QqQ"),
    ("endura", "QqQ"),
    ("xevo tq", "QqQ"),
    ("maldi", "MALDI"),
    ("fticr", "FTICR"),
]

_TRAINING_MAPPING_COLUMNS = (
    "protein_id",
    "gene_name",
    "gene_id",
    "gene_biotype",
    # Issue #141: transcript identity is now a first-class training-export
    # column.  ``protein_id`` carries the ENSP for Ensembl-backed mappings
    # (was ENST pre-#141); ``transcript_id`` is the ENST.  FASTA-backed
    # rows have ``transcript_id=""`` and ``is_canonical_transcript=False``.
    "transcript_id",
    "is_canonical_transcript",
    "position",
    "n_flank",
    "c_flank",
    "proteome",
    "proteome_source",
)

#: Every value ``sample_match_type`` can take.
#:
#: How the row's *sample* was reached, which is a different axis from
#: ``sample_attribution`` (how its arm was): a row can be ``metadata_match``
#: here and ``group_ambiguous`` there.  Pinned to a constant because a test
#: hardcoded the old four-value set and ``metadata_match`` broke it — the same
#: drift ``SAMPLE_ATTRIBUTION_VALUES`` below exists to prevent.
SAMPLE_MATCH_TYPE_VALUES = (
    "allele_match",
    "single_sample_fallback",
    "pmid_class_pool",
    # Attributed from curated metadata rather than an allele: the study's
    # ms_samples carry no ``mhc``, so no allele path could reach them, but a
    # discriminator or the group stage named the sample anyway (#359).
    "metadata_match",
    "unmatched",
    # Binding rows, which have no MS sample to match.
    "not_applicable",
    "",
)

#: Every value ``sample_attribution`` can take, most specific first.
#:
#: The docstring used to enumerate these inline and drifted — ``group_ambiguous``
#: shipped without being listed, so a consumer validating against the documented
#: set would have dropped every grouped row.  One constant, the way
#: :data:`hitlist.curation.MHC_ALLELE_PROVENANCE_VALUES` does it for that
#: vocabulary.
#: Every value :func:`generate_observations_table` can put in
#: ``sample_mhc_origin``, pinned for the same reason as the two sets below: a
#: consumer validating against a documented set breaks on an unlisted value.
#: ``not_applicable`` is the training table's default for a binding row, which
#: has no sample and so no candidate provenance.
SAMPLE_MHC_ORIGIN_VALUES = ("sample", "class_pool", "not_applicable", "")

SAMPLE_ATTRIBUTION_VALUES = (
    "curated_sample_label",
    "elution_conditions",
    # A mapped statement that excludes the arm the allele join picked: the
    # row reaches no arm and takes the class pool (#565).
    "elution_conditions_excluded",
    "allele_exact",
    "serotype_expansion",
    "discriminated",
    "class_pool",
    "single_sample_pmid",
    "group_ambiguous",
    "pmid_ambiguous",
    "",
)

_TRAINING_DEFAULTS = {
    "sample_label": "",
    "perturbation": "",
    "sample_mhc": "",
    **dict.fromkeys(MHC_TYPING_COLUMNS, ""),
    "sample_note": "",
    "sample_group": "",
    "arm_resolution": "",
    "effective_override": "",
    "effective_override_origin": "",
    "instrument": "",
    "instrument_type": "",
    "acquisition_mode": "",
    "fragmentation": "",
    "labeling": "",
    "ip_antibody": "",
    "search_engine": "",
    "fdr": "",
    "quantification_method": "",
    # Binding evidence has no MS sample, so it has no experimental condition
    # to report.  "" says exactly that; any other default would assert an
    # untreated arm for every predicted binder in the training table (#450).
    **empty_condition_columns(),
    **empty_species_context_columns(),
    "sample_match_type": "not_applicable",
    "sample_mhc_origin": "not_applicable",
    "matched_sample_count": 0,
    "is_chimeric": False,
    "is_engineered_mhc": False,
    "is_non_peptide_ligand": False,
}


def _fillna_series_safe(primary: pd.Series, fallback: pd.Series) -> pd.Series:
    """``primary.fillna(fallback)`` that tolerates Categorical dtype on either side.

    ``Series.fillna(Series)`` between two Categoricals demands *identical*
    category sets and raises ``TypeError: Cannot set a Categorical with another,
    without identical categories`` otherwise.  The block-wise
    ``DataFrame.fillna(DataFrame)`` that the per-column coalesce replaced (#566)
    upcast instead and succeeded, so casting either side out of ``category``
    first is what keeps the two forms equivalent -- the same move
    :func:`_fillna_safe_for_categoricals` makes for the scalar-fill idiom.

    Unreachable from ``generate_ms_samples_table()`` today, which hands the join
    no categorical columns, so on the current corpus both branches are no-ops.
    It is not unreachable in principle: ``_CATEGORICAL_EXPORT_METADATA_COLS``
    already names ``condition_id``, ``mhc``, ``perturbation`` and ``note``, and
    a column narrowed there beside a ``_fb`` shadow narrowed to the *subset* of
    values the single-sample studies use is precisely the mismatched pair.
    """
    if isinstance(primary.dtype, pd.CategoricalDtype):
        primary = primary.astype("string")
    if isinstance(fallback.dtype, pd.CategoricalDtype):
        fallback = fallback.astype("string")
    return primary.fillna(fallback)


def _fillna_safe_for_categoricals(df: pd.DataFrame, value: str = "") -> pd.DataFrame:
    """Cast categorical columns to ``StringDtype`` before ``fillna(value)``.

    Categorical fillna with an out-of-category value raises ``TypeError``.
    Post-#137 several string columns in the observations frame are stored
    as ``category`` for memory; this helper lets the export pipeline keep
    its ``fillna("")`` idiom without crashing when those columns are in
    the slice.  Returns a new frame (input is not mutated).
    """
    cat_cols = [c for c in df.columns if isinstance(df[c].dtype, pd.CategoricalDtype)]
    if cat_cols:
        df = df.astype(dict.fromkeys(cat_cols, "string"))
    return df.fillna(value)


# Meta columns that carry booleans rather than strings.  They need
# ``False`` (not ``""``) as their blank, otherwise pyarrow rejects the
# mixed bool/str column on parquet write.
#
# Empty since #392: ``apm_perturbed`` became a tri-state string so an
# unresolved arm reads as unknown rather than as a WT control, and
# ``study_apm_perturbed`` moved to the PMID-level join where it is
# always known.  Kept as the seam rather than deleted — the coalesce
# below still needs to know which meta columns are not strings, and the
# next bool one should not have to rediscover the pyarrow constraint.
_BOOL_META_COLS: frozenset[str] = frozenset()


# IEDB records, on some studies, exactly which experimental conditions a
# peptide was eluted from: "The epitope was eluted from the following
# experimental condition(s): untreated LM-MEL-44; treated LM-MEL-44."
# Unlike the surrounding narrative that names every arm of the study on
# every row, this is a per-peptide enumeration and is the one reliable
# arm discriminator IEDB offers.  168k observation rows carry it.
_ELUTION_CONDITIONS_RE = re.compile(
    r"eluted (?:from|with|in) the following experimental conditions?\(?s?\)?\s*:\s*(.+)",
    re.IGNORECASE,
)

# Markers identifying a *control* condition inside that enumeration.
# Word-boundary anchored so "treated" does not match inside
# "untreated" — the two differ by exactly that boundary, and getting it
# wrong flips every control peptide into the treated arm.
_CONTROL_CONDITION_RE = re.compile(
    r"\b(?:untreated|uninfected|unperturbed|unstimulated|mock|control|parental|naive)\b"
    r"|\bwild[- ]?type\b|\bWT\b",
    re.IGNORECASE,
)


def _arms_in_elution_conditions(assay_comments: str) -> set[str]:
    """Which arms an IEDB elution-condition enumeration names.

    Returns a subset of ``{"control", "perturbed"}`` — empty when the
    row does not carry the construct at all.  A peptide listed under
    both arms yields both, which is genuine ambiguity rather than a
    failure to parse: it really was eluted from each.
    """
    if not assay_comments:
        return set()
    match = _ELUTION_CONDITIONS_RE.search(str(assay_comments))
    if not match:
        return set()
    arms: set[str] = set()
    for fragment in re.split(r"[;,]", match.group(1)):
        fragment = fragment.strip(" .")
        if not fragment:
            continue
        arms.add("control" if _CONTROL_CONDITION_RE.search(fragment) else "perturbed")
    return arms


def _select_by_elution_conditions(
    candidates: list[tuple[str, str, dict]],
    assay_comments: str,
    *,
    curated_condition_ids: dict[str, list[str]] | None = None,
) -> dict | None:
    """Resolve an arm from IEDB's elution-condition enumeration.

    Returns the matching candidate's meta dict, or ``None`` when the
    construct is absent, names more than one arm, or does not single
    out exactly one curated candidate.

    A source-verified exact statement map can select declared condition IDs,
    including distinct doses of one drug. Unmapped statements retain the
    existing generic enumeration rules; arbitrary narrative is not admitted.
    """
    targets = (curated_condition_ids or {}).get(str(assay_comments).strip())
    if targets is not None:
        matching = [c for c in candidates if c[2].get("condition_id") in targets]
    else:
        arms = _arms_in_elution_conditions(assay_comments)
        if len(arms) != 1:
            return None
        want_control = arms == {"control"}
        matching = [
            c
            for c in candidates
            if (str((c[2] or {}).get("condition_category", "")) == "unperturbed") == want_control
        ]
    if len(matching) != 1:
        return None
    return matching[0][2]


class StatementMap(NamedTuple):
    """One study's curated elution-statement map, with its derived arm set.

    Built once per PMID, and the single place a deposited statement is
    normalised.  Both narrowing stages and the refusal resolution ask it the
    same question through :meth:`allowed`, so none of them can disagree about
    which arms a row's statement names -- a key set passed between them had to
    be normalised identically at three sites, and was not: it stored the raw
    ``assay_comments`` while the resolution looked up the stripped form, so a
    padded statement fell through both and exported no attribution at all
    (#584 review 3).
    """

    targets: dict[str, list[str]]
    #: ``condition_id`` -> the class tokens that arm is curated for, so a row
    #: can ask whether any arm its statement names could have presented it.
    arm_classes: dict[str, frozenset[str]]

    def allowed(self, assay_comments: str) -> list[str] | None:
        """The arms this statement names, or ``None`` if it is unmapped."""
        return self.targets.get(str(assay_comments).strip())

    def allows_class(self, allowed: list[str], mhc_class: str) -> bool:
        """Whether any named arm is curated for ``mhc_class``."""
        return any(mhc_class in self.arm_classes.get(arm, frozenset()) for arm in allowed)


def _statement_maps(overrides: dict[int, dict], samples: pd.DataFrame) -> dict[int, StatementMap]:
    """One :class:`StatementMap` per study that curates a statement map."""
    maps: dict[int, StatementMap] = {}
    for pmid, entry in overrides.items():
        targets = entry.get("elution_condition_ids")
        if not targets:
            continue
        study = samples[samples["pmid"].astype(int) == int(pmid)]
        maps[int(pmid)] = StatementMap(
            targets=targets,
            arm_classes={
                str(row.get("condition_id", "") or ""): frozenset(_sample_class_tokens(row))
                for _, row in study.iterrows()
            },
        )
    return maps


def _statement_allowed_candidates(
    candidates: list[tuple[str, str, dict]],
    assay_comments: str,
    statement_map: StatementMap | None,
) -> list[tuple[str, str, dict]] | None:
    """Narrow candidates to the arms the row's own elution statement allows.

    Where a study curates an explicit statement map, the deposited statement
    is per-row evidence about which sample the peptide came off, so an arm it
    excludes is a collision rather than a match.  Applying that here — before
    the group stage, the scorer and :func:`_consensus_meta` — is what makes it
    hold: a post-hoc check on the winner's ``condition_id`` cannot see an
    excluded arm whose metadata arrived through consensus, which blanks the
    identifying columns and leaves the typing, the cell and the candidate list
    behind (#584 review).  Two curated class-II arms per line is all it takes
    for every key to become ambiguous and take that path.

    Returns the arms the statement names, or ``None`` when it names none of
    these candidates — the refusal, which the resolution pass settles.

    The rule, stated exactly (#512, settled in #584 review 2 and 3):

    * A statement the map does not mention narrows nothing.  That is what keeps
      a partial map a tie-breaker rather than an exhaustive allow-list, and it
      is why PMID 32488085's four DMSO arms and MDA-MB-231 — reached only by
      statements absent from its map — are untouched by any of this.
    * Under a statement that *is* mapped, an arm the map never names is never
      the sole source of a row.  It may still be attributed, but only alongside
      an arm the statement names; on its own it is refused.  The statement says
      the peptide came off one of the arms it names, so an arm it does not name
      is not a better answer merely because the map is silent about it.
    * The same rule applies to an arm a row was *assigned* without passing
      through here, which is how a unique (pmid, allele) key reaches an arm.
      An assigned arm the statement does not name is refused too; otherwise the
      rule would hold only for rows that happened to take the ambiguous path.

    Letting unmapped arms survive alongside named ones put the choice back in
    the hands of the group stage and the scorer, which picked an unmapped arm
    often enough for the resolution pass to then refuse a row that had a named
    arm carrying its allele all along (#584 review 3).
    """
    if statement_map is None:
        return candidates
    targets = statement_map.allowed(assay_comments)
    if targets is None:
        return candidates
    return [c for c in candidates if c[2].get("condition_id") in targets] or None


def _blank_arm_identity(meta: dict) -> dict:
    """Drop everything that names one arm or claims its MHC typing.

    The single definition of "arm-specific", and self-contained: the arm's
    label, its system, its condition identity and annotation, its candidate
    list, its cellular typing and the basis of that typing.  Callers used to
    have to remember to blank ``condition_id`` and the arm-specific condition
    columns themselves, which is the kind of split definition that drifts
    (#584 review 4).

    Everything *not* listed here is a fact about the deposit — which antibody,
    which instrument, which acquisition mode, what the material was — and a row
    that reached no arm still carries it when the arms it could have come from
    agree on it, exactly as ``conditions.py`` requires: a fact shared by every
    arm is not withheld (#584 review 3).
    """
    for col in (
        "sample_label",
        "sample_group",
        "condition_id",
        "mhc",
        "mhc_basis",
        *ARM_SPECIFIC_CONDITION_COLUMNS,
        *ARM_SPECIFIC_SPECIES_CONTEXT_COLUMNS,
        *MHC_GENOTYPE_COLUMNS,
    ):
        if col in meta:
            meta[col] = False if col in _BOOL_META_COLS else ""
    # ``group_ambiguous`` means "the system is known, only the arm is not", and
    # it is read off ``sample_group`` — which has just gone, so the claim can
    # no longer be true (#584 review 4).
    if meta.get("sample_attribution") == "group_ambiguous":
        meta["sample_attribution"] = "pmid_ambiguous"
    # A sample-origin override names an arm as surely as a label does. ``none``
    # is a curated value, not an absence, so it is left alone -- the same rule
    # ``_consensus_meta`` applies.
    if meta.get("effective_override_origin") in ("sample", "sample_null"):
        meta["effective_override"] = ""
        meta["effective_override_origin"] = ""
    return meta


def _statement_excluded_meta(
    study_samples: pd.DataFrame,
    meta_cols: list[str],
    mhc_class: str = "",
) -> dict:
    """The one metadata record every statement-excluded row gets.

    A refused row reached no arm, so its label, its condition identity, its
    candidate list and its cellular typing are gone.  What is left is what the
    study's own records agree on, which is a property of the deposit rather
    than of any arm: ``ip_antibody``, the instrument and acquisition mode, the
    material and culture, the arm-resolution verdict, a study-origin override.

    Scoped to the row's own class, because a study's classes routinely disagree
    on exactly those facts: PMID 33592498 pulls class I with HB95/W6/32 and
    class II with HB245/IVA12, so a consensus over the whole study blanks
    ``ip_antibody`` on a refused class-II row -- the very loss this record
    exists to prevent (#584 review 4). An unknown class falls back to the
    study, which is the widest set the row could have come from.

    Blanking those too -- which is what the previous version did, keeping only
    three named columns -- silently dropped refused rows out of every
    ``--instrument-type`` and ``--acquisition-mode`` filter (#584 review 3).
    Consensus is the right tool for that half and the wrong one for the other:
    arms that happen to agree, or a class with exactly one arm, make it hand
    back the very typing the refusal rejected (#581), so the arm-specific half
    is blanked outright rather than left to agreement.
    """

    def _rows_of(frame):
        return [
            ("", "", {col: row.get(col, "") for col in meta_cols}) for _, row in frame.iterrows()
        ]

    candidates = (
        _rows_of(
            study_samples[
                [mhc_class in _sample_class_tokens(r) for _, r in study_samples.iterrows()]
            ]
        )
        if mhc_class and not study_samples.empty
        else _rows_of(study_samples)
    )
    # A class the study curates no arm for still gets the study's own facts:
    # the deposit's verdict and provenance belong to the row whatever its class
    # (#584 review 4).
    if not candidates:
        candidates = _rows_of(study_samples)
    if candidates:
        meta = _consensus_meta(candidates, meta_cols)
    else:
        meta = {col: (False if col in _BOOL_META_COLS else "") for col in meta_cols}
    meta = _blank_arm_identity(meta)
    meta["sample_attribution"] = "elution_conditions_excluded"
    return meta


def _candidate_arm_identity(meta: dict | None) -> str:
    """Which arm a candidate is, for tie and disagreement tests.

    ``condition_id`` is the curated identity and is what an attributed
    observation reports, so it is what "same arm" has to mean.  The
    fallback to ``condition_category`` keeps two callers working: an
    uncurated arm, and :func:`_select_group`'s pseudo-candidates, which
    carry a group name in that field precisely so they reuse this guard.
    """
    meta = meta or {}
    for key in ("condition_id", "condition_category"):
        value = meta.get(key)
        # `or` alone is wrong here: a pandas NaN is truthy, so a NaN
        # ``condition_id`` would short-circuit the fallback and every candidate
        # would read "nan" — one identity, tie accepted, first-pick restored.
        if value is None or value != value:
            continue
        text = str(value)
        if text:
            return text
    return ""


def _candidates_disagree_on_arm(candidates: list[tuple[str, str, dict]]) -> bool:
    """True when the candidates span more than one experimental arm.

    "Arm" is ``condition_category`` — the coarse perturbation bucket —
    so KO-vs-WT and treated-vs-untreated count as disagreement while
    two tissue samples of one untreated study do not.  Callers use this
    to withhold the narrative IEDB fields from the scorer.

    The bucket is the right test *here*, and deliberately not the finer
    ``condition_id`` (#450).  The question this gate asks is whether the
    candidates differ **by treatment**, because that is the axis the
    narrative fields are unreliable on — naming a *system* is what they do
    well (#359).  Keying it on identity instead withholds them from exactly
    the studies they resolve correctly: PMID 27920218's rows carry "The
    peptidome associated to HLA-B*40 from the C1R-B*40 cell line", a real
    per-row discriminator, and its three mono-allelic arms have distinct
    ids but one category.  Refusing that text sends 7,629 correctly
    discriminated rows to ``pmid_ambiguous``.

    Identity is the right test for the *tie* one stage later, where the
    question is whether scoring actually singled out one arm — see
    :func:`_select_best_candidate`.
    """
    return len({str((c[2] or {}).get("condition_category", "")) for c in candidates}) > 1


def _identifier_tokens(text: str) -> frozenset[str]:
    """Numeric tokens and other tokens of length >= 2, for identifier matching.

    The arm scorer drops tokens under three characters, which is exactly
    the part of a line name that distinguishes it — ``LM-MEL-44`` and
    ``LM-MEL-33`` both reduce to ``mel`` and tie.  Keeping two-character
    tokens recovers the digits. Single-digit numbers are also identifiers:
    dropping them conflates SK-MEL-2 and SK-MEL-5 (#511).

    Tokens rather than a concatenated key: a key like
    ``melanomatumorinfiltratinglymphocytestils`` only matches when the
    observation repeats those words contiguously in that order, so it
    never fired for any multi-word group; and a short key like ``til``
    matched inside ``until``.  Comparing token *sets* is order-insensitive
    and boundary-respecting, which is what both cases need.
    """
    return frozenset(
        t for t in re.split(r"[^a-z0-9]+", str(text or "").lower()) if len(t) >= 2 or t.isdecimal()
    )


def _select_group(
    candidates: list[tuple[str, str, dict]],
    cell_name: str,
    source_tissue: str,
    antigen_processing_comments: str,
    assay_comments: str,
) -> str | None:
    """Which curated sample *system* an observation row came from (#359).

    The arm scorer deliberately refuses IEDB's narrative fields whenever
    candidate arms disagree, because those fields describe the study and
    name every arm on every row — scoring them is what produced the #354
    collapse.  But that reasoning is about the *treatment* axis only.  On
    the system axis the same fields are reliable: ``eluted from the ovarian
    cancer cell line UWB.1289`` identifies the system exactly and says
    nothing about whether that sample saw IFN-gamma.

    So the fields are admitted here, where the only question is which
    system, and stay blocked one stage later, where the question is which
    arm.  Groups are scored as pseudo-candidates whose ``condition_category``
    is the group name, so a tie between two systems trips the existing
    cross-arm tie guard and returns ``None`` rather than guessing.

    Returns the winning group name, or ``None`` when the row does not
    identify one.
    """
    # ``sample_group`` is always a str here: generate_ms_samples_table writes
    # ``sample.get("sample_group", "") or ""`` and the meta dicts copy it with
    # a "" default, so no None/NaN coalesce is needed — and one would be
    # wrong anyway, since ``float("nan") or ""`` is nan, which would str() to
    # the bogus group name "nan".  Callers guard the empty-candidate case, so
    # ``groups`` is never empty either.
    groups = sorted({str(c[2].get("sample_group", "")) for c in candidates})
    if "" in groups:
        # Grouping is all-or-nothing per study (enforced at load); an
        # ungrouped candidate here means this study opted out.
        return None
    if len(groups) < 2:
        # A study with a single system: naming it says no more than naming
        # the PMID, so returning it would relabel genuinely arm-ambiguous
        # rows from ``pmid_ambiguous`` to ``group_ambiguous`` on no evidence
        # and break any consumer partitioning on the former.
        return None

    # Identifier match first: a group whose every token appears in the row's
    # text names that system outright, and no scoring is needed.
    #
    # Per-row factual fields are tried before narrative ones, because
    # cell_name states which system this row came from while a narrative may
    # enumerate every system the peptide was seen in.  Two or more matches
    # *declines* rather than falling through — an ambiguous per-row fact must
    # not hand the decision to study-level prose.
    for fields in ((cell_name, source_tissue), (antigen_processing_comments, assay_comments)):
        haystack = _identifier_tokens(" ".join(fields))
        if not haystack:
            continue
        hits = [g for g in groups if _identifier_tokens(g) and _identifier_tokens(g) <= haystack]
        if len(hits) == 1:
            return hits[0]
        if len(hits) > 1:
            return None

    # Carry each group's consensus experimental typing into the pseudo-candidate so the
    # scorer's allele term can fire.  It reads ``mhc`` off the candidate and
    # scores raw locus substrings against the row text, which is the most
    # reliable way to separate two cell lines — without it the term is dead
    # in this stage and LM-MEL-44 vs LM-MEL-33 falls back to a "mel" tie.
    group_mhc: dict[str, set[str]] = {}
    for c in candidates:
        group_mhc.setdefault(str(c[2].get("sample_group", "")), set()).add(
            str(c[2].get("mhc", "") or "")
        )
    pseudo = [
        (
            group,
            "",
            {
                # Both, so the arm guard reads its primary key here like
                # anywhere else instead of relying on the category fallback
                # (#450).  The two concerns stay independently editable.
                "condition_id": group,
                "condition_category": group,
                # Only when the group's arms agree: typing that differs
                # between arms is not a property of the system.
                "mhc": next(iter(group_mhc[group])) if len(group_mhc[group]) == 1 else "",
            },
        )
        for group in groups
    ]
    best = _select_best_candidate(
        pseudo, cell_name, source_tissue, antigen_processing_comments, assay_comments
    )
    if best is None:
        return None
    return str(best.get("condition_category", "")) or None


def _consensus_meta(
    candidates: list[tuple[str, str, dict]],
    meta_cols: list[str],
) -> dict:
    """Metadata every candidate arm agrees on; disagreements blanked.

    Used when several curated ``ms_samples`` share a join key and no
    observation-level discriminator separates them (issue #354).  The
    previous behavior picked ``candidates[0]`` arbitrarily, which
    silently routed an entire multi-arm study onto one arm — e.g. all
    10,319 rows of PMID 31530632 landed on ``C1R HLA-B*40:02 (ERAP2
    KO)`` and none on the WT arm, with no column marking the guess.

    Keeping only the consensus preserves what is genuinely known (the
    arms usually share instrument, acquisition mode and MHC genotype)
    while refusing to assert the fields that distinguish them
    (``sample_label``, ``perturbation``, ``condition_category``, the
    APM block).  A filter on ``perturbation`` then excludes these rows
    instead of silently returning the wrong half of the study.

    When the arms happen to agree on a field it is kept — several KO
    arms of different genes still share ``is_control_arm == "false"``,
    so "not a control" survives even when "which knockout" does not.
    """
    out: dict = {}
    for col in meta_cols:
        values = {c[2].get(col, "") for c in candidates}
        if len(values) == 1:
            out[col] = next(iter(values))
        else:
            out[col] = False if col in _BOOL_META_COLS else ""

    # A cellular typing belongs to one cell/donor and one source. Never keep
    # completeness or provenance from one candidate beside another's alleles.
    typings = {tuple(c[2].get(col, "") for col in MHC_GENOTYPE_COLUMNS) for c in candidates}
    if len(typings) > 1:
        out.update(dict.fromkeys(MHC_GENOTYPE_COLUMNS, ""))

    # Agreement is not enough for a claim that names an arm.  Several arms of
    # one study routinely share a sample-level ``override`` — PMID 34129938
    # marks all six ``cell_line`` — so the consensus rule above would keep
    # ``effective_override_origin == "sample"`` on a row whose ``sample_label``
    # it just blanked: a statement about a specific arm attached to evidence
    # with no arm.  A study-origin value is a property of the deposit and
    # survives; a sample-origin one cannot (#373).
    if out.get("effective_override_origin") in ("sample", "sample_null"):
        out["effective_override"] = ""
        out["effective_override_origin"] = ""
    # Free text describing one arm is arm-specific whether or not the arms
    # happen to share it.
    out["sample_note"] = ""
    out["note"] = ""
    # Condition columns describing one arm's own record cannot outlive the arm
    # (#450).  ``condition_id`` names it; ``condition_status`` /
    # ``condition_evidence`` / ``condition_reference`` describe the annotation
    # of it.  Those agree across candidates routinely — all 12 Shapiro HAP1
    # arms are `annotated` from the same `primary_source` reference — so the
    # consensus rule above keeps them while blanking the agent columns the arms
    # disagree on, and the row exports "fully annotated from the paper, no
    # knockout".  That is the ""-means-absence conflation.  Facts about the
    # material (culture, material state, MHC context) are not arm records and
    # do survive, which is the point of consensusing at all.
    for _arm_col in ARM_SPECIFIC_CONDITION_COLUMNS:
        out[_arm_col] = ""
    for _arm_col in ARM_SPECIFIC_SPECIES_CONTEXT_COLUMNS:
        out[_arm_col] = ""

    # If every surviving candidate belongs to one sample system, the system is
    # known and only the arm is not — say so, whichever stage narrowed them.
    # The group stage is one way to get here; an allele key only one system's
    # arms carry is another, and a row reached that way reported
    # ``pmid_ambiguous`` while carrying a ``sample_group``, which reads as a
    # contradiction (#359).
    out["sample_attribution"] = (
        "group_ambiguous" if str(out.get("sample_group", "") or "") else "pmid_ambiguous"
    )
    return out


#: Distinguishes "the winner dict has no such key" from "it has the key and its
#: value is None/NaN", which ``dict.get(col)`` alone conflates.  The #245
#: semantics turn on exactly that difference.
_ABSENT = object()


def _winner_positions(
    obs: pd.DataFrame,
    mask: pd.Series,
    tiebreak_cols: list[str],
    winners: dict[tuple, dict],
) -> np.ndarray:
    """Position in ``winners`` for each row of ``obs[mask]``; ``-1`` where none.

    This is the lookup ``DataFrame.reindex`` performs internally for a unique
    index -- ``winners``' keys are unique by construction -- without
    materializing the reindexed frames.  The two multi-row-count indexes it
    builds are scoped to this function so they are released on return rather
    than living for the whole of :func:`apply_winners_vectorized`.
    """
    winner_index = pd.MultiIndex.from_tuples(list(winners), names=tiebreak_cols)
    # Categorical-safe fillna so missing entries don't blow up index construction.
    sub = _fillna_safe_for_categoricals(obs.loc[mask, tiebreak_cols])
    sub_idx = pd.MultiIndex.from_arrays([sub[c] for c in tiebreak_cols], names=tiebreak_cols)
    return winner_index.get_indexer(sub_idx)


def apply_winners_vectorized(
    obs: pd.DataFrame,
    mask: pd.Series,
    tiebreak_cols: list[str],
    winners: dict[tuple, dict],
    meta_cols: list[str],
) -> None:
    """Apply per-key winner metadata back onto rows of ``obs``.

    Vectorized replacement (#244) for the per-row ``obs.at[idx, col]``
    update pattern that the per-PMID discriminator-scoring path used to
    drive.  Mutates ``obs`` in place.

    Semantics — strictly equivalent to the prior loop:

        obs.loc[mask, col] = [
            winners.get(k, {}).get(col, obs.at[idx, col])
            for k, idx in zip(keys, sub.index)
        ]

    For each row in ``obs[mask]`` whose ``tiebreak_cols`` tuple is a key
    in ``winners``:

    * If the winner dict has ``col`` as an explicit key, overwrite
      ``obs[col]`` with the winner's value — *including* when that
      value is ``None`` / ``NaN`` / ``""``.  This matches the prior
      loop's ``dict.get(col, fallback)`` behavior, which only fell
      back when the key was missing entirely, not when its value was
      null.
    * If the winner dict is missing ``col``, ``obs[col]`` is preserved.

    Rows whose key is not in ``winners`` are likewise preserved.

    The strict-equivalence guarantee requires tracking **presence**
    separately from the values — ``~pd.isna(joined[col])`` would
    conflate "key absent" with "key present, value is NaN" and silently
    skip the latter.  See PR #245 review.

    Replaces ~13M Python-level ``obs.at`` lookups with one vectorized
    ``MultiIndex.get_indexer`` over the rows.  The per-column loops below are
    over ``winners`` (~800 entries), not over rows.

    Memory shape (#566): the values and the presence flags are held on the
    ``winners`` side, at one row per winner, and joined to the masked rows
    through a single array of integer *positions*.  Reindexing them onto the
    masked rows instead — one ``len(obs[mask]) x len(meta_cols)`` object frame
    of values plus a parallel bool frame — was the join's second-largest
    transient on the 4.4M-row corpus: 1.94 GB for the values frame, 1.27 GB of
    per-column ``to_numpy`` copies off it and 0.90 GB for the key frame, all to
    carry the same information as one 35 MB ``int64`` array.

    Correctness note (#602): the two-frame form also had to overwrite the
    presence frame's index with the values frame's, and
    ``DataFrame.from_dict(orient="index")`` **reorders** its index when the
    winner dicts have heterogeneous key sets — it groups rows by key-set
    signature.  The two frames then disagreed about which winner each row
    belonged to, and a row could be handed the presence flags of an unrelated
    winner, writing ``NaN`` over a value the contract says to preserve.  Both
    real call sites pass heterogeneous key sets (``_consensus_meta`` carries
    keys ``_select_best_candidate`` does not), so the precondition is live;
    the reordering happens not to trigger on the current corpus, which is why
    this rewrite leaves the export byte-identical.  Positions cannot desync
    because there is only one of them.  See
    ``test_heterogeneous_winner_key_sets_do_not_misalign_presence``.
    """
    if not winners:
        return

    positions = _winner_positions(obs, mask, tiebreak_cols, winners)
    if not (positions >= 0).any():
        return
    winner_dicts = list(winners.values())
    # ``get_indexer`` returns -1 for an unmatched row and NumPy resolves -1 to
    # the last element, so one sentinel slot at the end of each per-winner
    # array makes unmatched rows gather "absent" without a separate mask: the
    # whole column becomes one take instead of a ``matched.copy()`` plus two
    # fancy-index passes per meta col.
    sentinel = len(winner_dicts)

    # Per-col fill at NumPy level: copy current obs values for the masked
    # slice, overwrite at positions where the winner had ``col``
    # explicitly set, assign back in one pass.  Staying in NumPy
    # preserves the destination column's dtype (avoids the pandas
    # "Setting an item of incompatible dtype" FutureWarning that
    # ``.where()`` triggers on bool / numeric meta_cols when the
    # intermediate falls through object dtype).
    for col in meta_cols:
        # Presence is a fact about the winner dict, not about the row: ``True``
        # iff that dict had ``col`` as an explicit key.  Distinguishes "winner
        # had col=NaN" (write NaN through) from "winner didn't carry col at
        # all" (keep obs), so it is tracked per winner rather than inferred
        # from the joined value -- hence the ``_ABSENT`` sentinel rather than
        # ``dict.get(col)``, which cannot tell a missing key from a null value.
        values_by_winner = np.empty(sentinel + 1, dtype=object)
        present_by_winner = np.zeros(sentinel + 1, dtype=bool)
        any_present = False
        for i, winner in enumerate(winner_dicts):
            value = winner.get(col, _ABSENT)
            if value is not _ABSENT:
                values_by_winner[i] = value
                present_by_winner[i] = True
                any_present = True
        if not any_present:
            continue
        present_arr = present_by_winner[positions]
        if not present_arr.any():
            continue
        cur_arr = obs.loc[mask, col].to_numpy().copy()
        cur_arr[present_arr] = values_by_winner[positions[present_arr]]
        obs.loc[mask, col] = cur_arr


def _classify_instrument(instrument: str) -> str:
    """Return a broad instrument category from a specific model string."""
    if not instrument:
        return ""
    low = instrument.lower()
    for pattern, category in _INSTRUMENT_TYPE_MAP:
        if pattern in low:
            return category
    return instrument  # return raw value if no match


def _serialize_reference_proteomes(proteomes) -> str:
    """Serialize a list of ``reference_proteomes`` entries as a stable string.

    Format: ``"<uniprot_id>:<label>;..."`` with empty labels rendered as
    just the UniProt ID.  Tolerates entries that are already strings (older
    YAML curation) or that omit either field.
    """
    if not proteomes:
        return ""
    if isinstance(proteomes, str):
        return proteomes
    out: list[str] = []
    for p in proteomes:
        if isinstance(p, str):
            out.append(p)
            continue
        if not isinstance(p, dict):
            continue
        upid = str(p.get("uniprot") or "").strip()
        label = str(p.get("proteome_label") or "").strip()
        if upid and label:
            out.append(f"{upid}:{label}")
        elif upid:
            out.append(upid)
        elif label:
            out.append(label)
    return ";".join(out)


_UNPERTURBED_PREFIX = "unperturbed"


def simplify_condition(condition: str | None) -> str:
    """Reduce a curated ``condition`` string to its perturbation, or ``""``.

    This is the single normalization behind ``perturbation``,
    ``condition_category`` and the ``apm_*`` block.  They used to be
    derived from two different strings — ``condition_category`` from
    the simplified condition, the APM flags from the raw one — which
    let a sample report ``condition_category == "unperturbed"`` and
    ``apm_erap2_perturbed == True`` at the same time (issue #355).

    Curator convention for ``unperturbed``-prefixed conditions:

    * ``unperturbed + X`` — a treatment *was* applied on top of the
      otherwise-unperturbed baseline, so ``X`` is the perturbation.
      Blanking these mislabelled the 7 ``unperturbed + IFN-gamma
      (2000 U/mL, 3d)`` tumor samples as controls.
    * ``unperturbed — X`` / ``unperturbed (X)`` — ``X`` annotates the
      baseline (culture medium, IP antibody, ``natural ERAP2
      genotype``, ``direct ex vivo``) rather than naming a treatment,
      so the perturbation is empty.  314 samples use this form.

    The raw ``condition`` column is exported unchanged, so the
    annotation text stays available for audit.
    """
    text = (condition or "").strip()
    if not text or text == "—" or text.startswith("NOT "):
        return ""
    if text.startswith(_UNPERTURBED_PREFIX):
        rest = text[len(_UNPERTURBED_PREFIX) :].strip()
        if rest.startswith("+"):
            return rest[1:].strip()
        return ""
    return text


def _empty_ms_samples_columns() -> list[str]:
    """Column list for an ms_samples table that matched nothing.

    Mirrors the row dict built in :func:`generate_ms_samples_table`, so a
    zero-match filter returns an empty-but-well-formed frame.
    """
    from .apm import apm_columns_for_sample

    base = [
        "species",
        "sample_label",
        "condition",
        "perturbation",
        "pmid",
        "study_label",
        "mhc_class",
        "n_samples",
        "profiled",
        "source",
        "peptides",
        "reference_proteomes",
        "notes",
        "note",
        "classification",
        "reason",
        "sample_group",
        "arm_resolution",
        "sample_override",
        "effective_override",
        "effective_override_origin",
        "mhc",
        *MHC_TYPING_COLUMNS,
        *_ACQUISITION_FIELDS,
        "instrument_type",
    ]
    return [
        *base,
        *CONDITION_COLUMNS,
        *SPECIES_CONTEXT_COLUMNS,
        *apm_columns_for_sample(""),
        "condition_category",
        "is_control_arm",
        "mhc_species",
        "species_axes_agreement",
    ]


@dataset_snapshot()
def generate_ms_samples_table(
    mhc_class: str | None = None,
    apm_only: bool = False,
) -> pd.DataFrame:
    """Export all ms_samples entries as a flat DataFrame.

    Parameters
    ----------
    mhc_class
        Filter to ``"I"`` or ``"II"``.  Entries with ``"I+II"`` match
        either filter.  ``None`` returns all rows.
    apm_only
        Filter to rows where any antigen-processing-machinery gene
        was perturbed (``apm_perturbed=True``).  See
        :mod:`hitlist.apm` for the gene vocabulary.

    Returns
    -------
    pd.DataFrame
        Provenance columns now preserved in addition to the legacy ones
        (issue pirl-unc/hitlist#149):
        - ``condition`` — original ``condition`` string from the YAML.
        - ``perturbation`` — the simplified non-unperturbed condition.
        - ``source`` — original ``source`` field (e.g. tissue source,
          biopsy notes, donor description).
        - ``profiled`` — ``"true"`` / ``"false"`` / ``""`` (uncurated).
          Explicitly unprofiled arms (``profiled: false`` or
          ``n_samples: 0``) are exported as metadata rows with
          ``n_samples == 0`` and are excluded from observation
          attribution, so restoring them cannot manufacture evidence
          (#437).
        - ``peptides`` — curated peptide count when present.
        - ``reference_proteomes`` — semicolon-joined ``UPID:label`` pairs
          for any per-sample viral / parasite proteome references.

        Plus one ``apm_<gene>_perturbed`` boolean column per APM gene
        (B2M, TAP1, TAP2, TAPBP, ERAP1/2, PDIA3, CALR, CANX, IRF2,
        GANAB, SPPL3, NLRC5, CIITA, HLA-DM, HLA-DO, CD74, cathepsin,
        RFX, bare-lymphocyte-syndrome), an ``apm_perturbed`` union
        flag, and ``apm_genes_perturbed`` semicolon-joined list of
        matched genes (#202).  These describe the sample's **own**
        condition; ``study_apm_perturbed`` / ``study_apm_genes`` carry
        the parent study's panel-level perturbation list (#353).

        ``apm_perturbed`` is a tri-state string (``"true"`` /
        ``"false"`` / ``""``) rather than a bool, so that the
        observation-level export can say "arm unresolved" instead of
        asserting a WT control (#392).  Every row of *this* table is a
        sample, so it is never blank here.

        ``is_control_arm`` is ``"true"`` for unperturbed arms and
        ``"false"`` otherwise (#354).

        ``mhc_species`` is derived from the sample's own alleles and
        ``species_axes_agreement`` compares it against the curated
        ``species`` (the source proteome).  ``"false"`` is not
        automatically an error — engineered chimeras legitimately differ
        (#46) — but it is the signal that caught a Prussian carp sample
        curated with human MHC.
    """
    from .apm import apm_columns_for_sample

    overrides = load_pmid_overrides()
    rows: list[dict] = []

    for pmid_int, entry in sorted(overrides.items()):
        study_label = entry.get("study_label", "")
        # ``.get(key, default)`` semantics: an explicitly null / blank
        # ``species:`` means "unknown" and must not silently become human.
        study_species = entry.get("species", "Homo sapiens (human)")
        ms_samples = entry.get("ms_samples", [])
        study_perturbations = entry.get("perturbations") or []

        for sample in ms_samples:
            cls = sample.get("mhc_class", "")
            if mhc_class and not _mhc_class_matches(cls, mhc_class, sample_row=sample):
                continue

            # Species is resolved per sample, not per study (#372).  It
            # used to be computed once outside this loop, so a mixed-
            # species study silently exported its mouse arms as human —
            # the sample-level key existed in the YAML and nothing read
            # it.
            species = normalize_species(sample.get("species") or study_species)

            condition = sample.get("condition", "") or ""
            perturbation = simplify_condition(condition)

            n_samples = sample.get("n_samples", "")
            # ``profiled: false`` and ``n_samples: 0`` state the same curated
            # fact — the arm exists in the paper and carries no MS data — so
            # both export as ``profiled="false"`` and one column answers join
            # eligibility.  These rows used to be dropped outright, which
            # deleted exactly the records the ``profiled`` column exists to
            # distinguish from uncurated ones (#437).
            profiled_field = sample.get("profiled")
            if profiled_field is None:
                profiled = "false" if n_samples == 0 else ""
            else:
                profiled = "true" if profiled_field else "false"

            # Provenance override, resolved with the distinction the YAML
            # draws (#373).  ``override:`` present with a value is this
            # sample's own claim; present but null is the curator saying
            # "deliberately none here", which is NOT the same as omitting the
            # key and inheriting the study's.  Collapsing the two would erase
            # the only record that the question was considered.
            if "override" in sample:
                sample_override = sample["override"] or ""
                effective_override = sample_override
                override_origin = "sample" if sample_override else "sample_null"
            else:
                sample_override = ""
                effective_override = entry.get("override") or ""
                # ``rules`` are row-conditional: they match IEDB fields on the
                # individual observation, so whether one supersedes the study
                # default is not knowable from the sample.  Saying "study" here
                # would assert a value the build contradicts — PMID 27846572
                # inherits ``cell_line`` while its rule routes every Direct Ex
                # Vivo fibroblast row to ``healthy``.  ``study_conditional``
                # says: this is the default, and a rule may supersede it.
                if effective_override and entry.get("rules"):
                    override_origin = "study_conditional"
                elif effective_override:
                    override_origin = "study"
                else:
                    override_origin = "none"

            row = {
                "species": species,
                "sample_label": sample.get("sample_label", ""),
                # Issue #149: keep the simplified ``perturbation`` for
                # backward compat AND the raw ``condition`` for audit.
                "condition": condition,
                "perturbation": perturbation,
                "pmid": pmid_int,
                "study_label": study_label,
                "mhc_class": cls,
                "n_samples": n_samples if n_samples != "" else None,
                "profiled": profiled,
                "source": sample.get("source", "") or "",
                # Cast peptides count to str so the column dtype stays
                # ``object``-uniform across rows where it's present (int)
                # vs absent (""); pyarrow rejects mixed int/str otherwise.
                "peptides": str(sample.get("peptides", "") or ""),
                "reference_proteomes": _serialize_reference_proteomes(
                    sample.get("reference_proteomes") or entry.get("reference_proteomes")
                ),
                # ``notes`` keeps its exact legacy meaning — classification
                # if present, else reason — while the three underlying fields
                # become addressable.  ``note`` reached no consumer at all
                # before #373; it carries analytic caveats about samples that
                # are in the corpus.
                "notes": sample.get("classification", sample.get("reason", "")) or "",
                "note": sample.get("note", "") or "",
                "classification": sample.get("classification", "") or "",
                "reason": sample.get("reason", "") or "",
                "sample_group": sample.get("sample_group", "") or "",
                # Study-level, denormalized onto the sample so an ambiguous row
                # carries its own explanation instead of sending a reader back
                # to the YAML (#366).
                "arm_resolution": entry.get("arm_resolution", "") or "",
                "sample_override": sample_override,
                "effective_override": effective_override,
                "effective_override_origin": override_origin,
                "mhc": sample.get("mhc") or "",
                **sample_mhc_metadata(sample),
            }
            for field in _ACQUISITION_FIELDS:
                row[field] = sample.get(field) or entry.get(field) or ""
            row["instrument_type"] = _classify_instrument(row["instrument"])
            # The flat condition block (#450).  Read straight off the curated
            # record — never derived from the ``condition`` prose, because a
            # guess would be indistinguishable from curation in every export,
            # and telling those apart is the whole point of the block.  The
            # legacy ``perturbation`` / ``condition_category`` / ``apm_*``
            # classifiers below keep their documented meanings alongside.
            row.update(condition_columns_for_sample(sample))
            # The literature registry is separate from the mismatch-derived
            # flags and links only through a stable curated arm identity.
            row.update(
                species_context_for_sample(
                    pmid_int,
                    str(sample.get("condition_id") or ""),
                )
            )
            # APM perturbation block — one boolean per gene + union
            # (#202).  Per-gene flags come from this sample's own
            # condition; the study's panel-level list is reported in the
            # separate ``study_apm_*`` columns (#353).
            row.update(
                apm_columns_for_sample(
                    condition=perturbation,
                    study_perturbations=study_perturbations,
                )
            )
            # Coarse condition category for downstream model training:
            # "ERAP1 deletion" / "ERAP1 CRISPR/Cas9 knockout" / "ERAP1
            # shRNA knockdown" all collapse to "ERAP1_perturbation"
            # so a single one-hot covers the biology regardless of
            # phrasing. See hitlist.condition_categories.
            from .condition_categories import categorize_condition

            row["condition_category"] = categorize_condition(perturbation)
            # Explicit control-arm flag so the KO-vs-WT contrast is a
            # first-class query (#354).  Tri-state string (matching the
            # ``profiled`` convention) because the observation-level
            # join leaves it ``""`` when the arm can't be determined.
            row["is_control_arm"] = (
                "true" if row["condition_category"] == "unperturbed" else "false"
            )
            # Species axes (docs/source-classification.md).  ``species``
            # is the source proteome; ``mhc_species`` is derived from the
            # sample's own alleles.  Exposing both means a contradiction
            # — PMID 41459947's Prussian carp sample carrying human MHC —
            # is visible in the exported table instead of only to a test.
            row["mhc_species"] = mhc_species_of(row["mhc"])
            row["species_axes_agreement"] = species_axes_agreement(
                row["species"], row["mhc_species"]
            )
            rows.append(row)

    df = pd.DataFrame(rows)
    if df.empty:
        # A filter matching zero samples used to produce a column-less
        # frame, so every downstream ``samples.groupby("pmid")`` raised
        # KeyError instead of simply returning nothing.
        df = pd.DataFrame(columns=_empty_ms_samples_columns())
    if apm_only and not df.empty:
        df = df[df["apm_perturbed"] == "true"].reset_index(drop=True)
    return df


def _observation_eligible_samples(samples: pd.DataFrame) -> pd.DataFrame:
    """Curated samples that may be matched to an observation.

    Drops the explicitly unprofiled arms (``profiled: false`` /
    ``n_samples: 0``) that :func:`generate_ms_samples_table` exports as
    metadata.  Those arms exist in the paper but were never run on the
    instrument, so attributing a peptide to one would assert evidence
    that does not exist (#437).
    """
    if samples.empty:
        return samples
    return samples[samples["profiled"] != "false"].reset_index(drop=True)


@dataset_snapshot()
def generate_observations_table(
    mhc_class: str | None = None,
    species: str | None = None,
    source: str | None = None,
    instrument_type: str | None = None,
    acquisition_mode: str | None = None,
    is_mono_allelic: bool | None = None,
    min_allele_resolution: str | None = None,
    mhc_allele: str | list[str] | None = None,
    mhc_allele_in_set: str | list[str] | None = None,
    mhc_allele_provenance: str | list[str] | None = None,
    restriction_evidence: str | list[str] | None = None,
    serotype_source: str | list[str] | None = None,
    gene: str | list[str] | None = None,
    gene_name: str | list[str] | None = None,
    gene_id: str | list[str] | None = None,
    peptide: str | list[str] | None = None,
    serotype: str | list[str] | None = None,
    length_min: int | None = None,
    length_max: int | None = None,
    exclude_class_label_suspect: bool = False,
    exclude_class_label_implausible: bool = False,
    exclude_non_peptide_ligand: bool = True,
    apm_only: bool = False,
    columns: list[str] | None = None,
    *,
    source_species: str | list[str] | None = None,
    host_species: str | list[str] | None = None,
    exclude_chimeric: bool = False,
) -> pd.DataFrame:
    """Join per-peptide observations with per-sample metadata.

    Loads the built ``observations.parquet`` and enriches each row with
    sample-level metadata (instrument, conditions, experimental MHC candidates
    and independent cellular typing)
    from ``ms_samples`` in the YAML overrides.

    The join logic matches each peptide's ``mhc_restriction`` to the
    ``mhc`` field on ``ms_samples`` entries within the same PMID:

    - Mono-allelic samples: exact allele match
    - Multi-allelic samples: peptide allele appears in the experimental candidates
    - Fallback: PMID-only match when no allele-level match is possible

    Parameters
    ----------
    mhc_class
        Filter to ``"I"`` or ``"II"``.
    species
        Filter by MHC species (e.g. ``"Homo sapiens"``).
    source_species, host_species
        Filter independently by peptide-source proteome and host-cell species.
        Accept the same species aliases and lists as the raw loaders.
    exclude_chimeric
        Exclude rows flagged as chimeric by the raw loader. Defaults to False.
    instrument_type
        Filter by instrument category (e.g. ``"Orbitrap"``).
    acquisition_mode
        Filter by acquisition mode (e.g. ``"DDA"``).
    is_mono_allelic
        Filter to mono-allelic (True) or multi-allelic (False) samples.
    min_allele_resolution
        Minimum allele resolution (e.g. ``"four_digit"``).
    restriction_evidence
        Filter by how the named peptide-to-MHC restriction was established:
        ``"experimental"``, ``"monoallelic"``, ``"predicted"``, or
        ``"unknown"``. This is independent of ``mhc_allele_provenance``.
    serotype_source
        Filter by whether the serotype is primary data (``"reported"``), this
        library's projection of a named molecule (``"derived"``), or a union
        over a donor's typed alleles (``"donor_set"``).
    columns
        Return only these columns.

    Returns
    -------
    pd.DataFrame
        One row per peptide observation, enriched with sample metadata.

        Arm provenance (#354):

        - ``sample_attribution`` — how the row reached its sample:
          ``allele_exact`` (unique pmid+allele), ``elution_conditions``
          (IEDB named the exact condition the peptide was eluted
          from), ``discriminated`` (resolved by scoring the row's
          ``cell_name`` / ``source_tissue``), ``class_pool``,
          ``single_sample_pmid``, ``class_pool``, ``group_ambiguous``
          (the sample *system* is known and the arm within it is not, #359),
          ``pmid_ambiguous`` (arm undetermined) or ``""`` (no sample
          matched).  ``serotype_expansion`` and ``curated_sample_label``
          also appear; the authoritative list is
          :data:`SAMPLE_ATTRIBUTION_VALUES`.
        - ``sample_group`` — the curated sample system (#359), populated
          on grouped studies and blank elsewhere.
        - ``arm_resolution`` — why an ambiguous row has no arm (#366); see
          :data:`hitlist.curation.ARM_RESOLUTION_VALUES`.
        - ``is_control_arm`` — ``"true"`` / ``"false"``, or ``""``
          when the arm could not be determined.

        On ``pmid_ambiguous`` **and** ``group_ambiguous`` rows the fields
        that distinguish the candidate arms (``sample_label``,
        ``perturbation``, ``condition_category``, the ``apm_*`` block) are
        blank rather than guessed, so filtering on them never returns rows
        from an undetermined arm.  Fields the arms agree on are preserved —
        on a grouped row that includes ``sample_group``, which is the point.

    Raises
    ------
    FileNotFoundError
        If the observations table has not been built yet.
    """
    from .observations import (
        _load_attribution_context,
        _source_organism_with_fallback,
        load_observations,
    )

    # --- Resolve gene query (may require HGNC lookup) up front ---
    resolved_gene_names, resolved_gene_ids = _resolve_gene_filters(gene, gene_name, gene_id)

    # --- Load observations with as many filters pushed to parquet as possible ---
    obs_filters: dict = {
        "source_species": source_species,
        "host_species": host_species,
        "exclude_chimeric": exclude_chimeric,
    }
    if mhc_class:
        obs_filters["mhc_class"] = mhc_class
    if species:
        obs_filters["species"] = normalize_species(species)
    if source:
        obs_filters["source"] = source
    if mhc_allele is not None:
        obs_filters["mhc_restriction"] = mhc_allele
    if mhc_allele_in_set is not None:
        obs_filters["mhc_allele_in_set"] = _to_list(mhc_allele_in_set)
    if mhc_allele_provenance is not None:
        obs_filters["mhc_allele_provenance"] = _to_list(mhc_allele_provenance)
    obs_filters.update(_gene_observation_filters(resolved_gene_names, resolved_gene_ids, peptide))
    if restriction_evidence is not None:
        obs_filters["restriction_evidence"] = restriction_evidence
    if serotype_source is not None:
        obs_filters["serotype_source"] = _to_list(serotype_source)
    if serotype is not None:
        obs_filters["serotype"] = _to_list(serotype)
    if length_min is not None:
        obs_filters["length_min"] = length_min
    if length_max is not None:
        obs_filters["length_max"] = length_max
    if exclude_class_label_suspect:
        obs_filters["exclude_class_label_suspect"] = True
    if exclude_class_label_implausible:
        obs_filters["exclude_class_label_implausible"] = True
    obs_filters["exclude_non_peptide_ligand"] = exclude_non_peptide_ligand
    obs = load_observations(**obs_filters)

    # ── Backstop: ensure ``""`` is a valid category on every categorical
    # column (#236-followup, v1.30.44).  The build pipeline now pre-adds
    # ``""`` via ``_compress_categoricals``, but parquets built before
    # v1.30.44 lack that, and several downstream paths in this function
    # use the ``fillna("")`` idiom on these columns (the
    # ``_compute_is_chimeric`` / ``_compute_has_peptide_level_allele``
    # pair, and the per-PMID discriminator path's ``_tiebreak_cols``
    # slice).  Without this, those calls raise ``TypeError: Cannot
    # setitem on a Categorical with a new category ()`` against any
    # parquet that hasn't been rebuilt since the systemic build-side fix.
    for _col in obs.columns:
        _dtype = obs[_col].dtype
        if isinstance(_dtype, pd.CategoricalDtype) and "" not in _dtype.categories:
            obs[_col] = obs[_col].cat.add_categories([""])

    if min_allele_resolution:
        from .curation import allele_resolution_rank, classify_allele_resolution

        min_rank = allele_resolution_rank(min_allele_resolution)
        obs = obs[
            obs["mhc_restriction"].map(
                lambda a: allele_resolution_rank(classify_allele_resolution(a)) <= min_rank
            )
        ]

    # --- Load sample metadata ---
    # Explicitly unprofiled arms are curated metadata, not evidence: they
    # have no MS data by construction, so they must never become a
    # candidate arm for an observation.  Restoring them to the sample
    # export (#437) is only safe because the join drops them here.
    # Keep study membership independent of the observation class filter:
    # a multi-sample study cannot become a single-sample fallback merely
    # because the caller requested one of its classes (#532).
    samples = _observation_eligible_samples(generate_ms_samples_table())
    # Unrelated studies cannot match these rows. Avoid building their allele,
    # class and discriminator pools, but retain every arm/class of each present
    # study so narrow queries do not change attribution (#532).
    present_pmids = pd.to_numeric(obs["pmid"], errors="coerce").dropna().unique()
    samples = samples[samples["pmid"].isin(present_pmids)]

    # Attribution is a fact about the study, not the rows a caller requests.
    # A narrow query still needs the full study's discriminator variation to
    # distinguish factual fields from constant narrative (#532). The context
    # has distinct annotation patterns only; it is never added to output rows.
    _study_context = None
    _has_row_filters = min_allele_resolution or any(
        value for key, value in obs_filters.items() if key != "exclude_non_peptide_ligand"
    )
    if _has_row_filters and not obs.empty and not samples.empty:
        _sample_counts = samples.groupby("pmid").size()
        _context_pmids = set(_sample_counts[_sample_counts > 1].index).intersection(
            pd.to_numeric(obs["pmid"], errors="coerce").dropna()
        )
        if _context_pmids:
            _study_context = _load_attribution_context(_context_pmids)
            _study_context["_pmid_int"] = pd.to_numeric(_study_context["pmid"], errors="coerce")
            _study_context["_mhc_class_norm"] = _study_context["mhc_class"].map(
                normalize_mhc_class_token
            )

    meta_cols = [
        "sample_label",
        "perturbation",
        "condition_category",
        "mhc",
        *MHC_TYPING_COLUMNS,
        "instrument",
        "instrument_type",
        "acquisition_mode",
        "fragmentation",
        "labeling",
        "ip_antibody",
        "search_engine",
        "fdr",
        # APM perturbation block (#202) — propagated through the join
        # so consumers can filter / pivot on individual genes.  These
        # describe the matched sample's own condition, so they are only
        # knowable where the row reached a sample.  The study-level pair
        # (#353) is deliberately *not* here: it is a property of the
        # deposit, so it joins on PMID instead (#392).
        "apm_perturbed",
        "apm_genes_perturbed",
        # Arm provenance (#354): whether this row's sample is a control
        # arm, and how confidently the row was attributed to a sample.
        "is_control_arm",
        "sample_attribution",
        # The flat condition block (#450).  These describe the matched arm's
        # own experimental condition, so like the APM block they are only
        # knowable where the row reached a sample; ``_consensus_meta`` keeps
        # only what every candidate arm agrees on when it did not.
        *CONDITION_COLUMNS,
        # Primary-literature evidence for cross-species experimental context.
        # Exact arm links attach it; consensus retains only shared biological
        # axes and clears the review record's identity/provenance.
        *SPECIES_CONTEXT_COLUMNS,
        # Curated provenance (#373).  These describe the curation, not the
        # built classification flags, which stay PMID- and rule-driven at
        # build time.
        #
        # A row that reached no arm still carries a *study*-origin value: the
        # ``pmid_ambiguous`` tier knows the deposit even when it cannot name
        # the arm, and 513 of 755 samples inherit their override from the
        # study.  What such a row never carries is a *sample*-origin value —
        # ``_consensus_meta`` clears those, because naming an arm's override
        # on evidence with no arm is a fabrication.
        # ``sample_override`` is deliberately absent: it is derivable from
        # the pair below (equal to ``effective_override`` when the origin is
        # ``sample``, blank otherwise), and a redundant object column costs
        # hundreds of MB across 4.4M rows (#263).  It stays on the samples
        # table, where it is one row per arm.
        "effective_override",
        "effective_override_origin",
        "note",  # → sample_note after rename
        "arm_resolution",
        # The sample *system* (#359).  Survives `_consensus_meta` on purpose:
        # when the arms of one system tie, the system is still known and is
        # the most specific true statement available about the row.
        "sample_group",
    ]

    # ``sample_attribution`` is synthesized by the join rather than read
    # off a sample row, so seed it on the samples frame before the meta
    # dicts are built.  Each join path overwrites it with how that row
    # was actually matched; rows no path reaches keep "" (unattributed).
    samples = samples.copy()
    samples["sample_attribution"] = "allele_exact"

    from .apm import study_apm_columns

    # --- PMID-level metadata ---
    # Facts about the deposit, not about any one sample, so they are
    # knowable for every row of the study whether or not that row could
    # be attributed to an arm.  Routing them through the sample join
    # instead made 221,930 observations inside the APM-perturbed studies
    # report ``study_apm_perturbed=False`` purely because their arm was
    # ambiguous — stating the study ran no perturbation when the deposit
    # plainly says otherwise (#392).
    overrides = load_pmid_overrides()
    # Built once per study: the single place a deposited statement is
    # normalised, and the single source of which arms it names. Both narrowing
    # stages and the refusal resolution below ask it the same question.
    _stmt_maps = _statement_maps(overrides, samples)
    pmid_meta_df = pd.DataFrame(
        [
            {
                "_pmid_int": int(k),
                "quantification_method": v.get("quantification_method", ""),
                **study_apm_columns(v.get("perturbations")),
            }
            for k, v in overrides.items()
        ]
    )
    _PMID_LEVEL_COLS = ["quantification_method", "study_apm_perturbed", "study_apm_genes"]

    # --- Allele-level sample lookup ---
    # Explode each sample's MHC alleles into one row per (pmid, allele)
    # so we can do a vectorized merge instead of row-by-row iteration.
    # Heterodimer tokens like ``HLA-DPB1*06:01/DPA1*01:03`` are expanded
    # into their component alleles (``HLA-DPB1*06:01`` and
    # ``HLA-DPA1*01:03``) so an observation reporting a beta-chain-only
    # restriction still joins to the heterodimer sample — see
    # pirl-unc/hitlist#151 (Abelin MAPTAC DP/DQ rows).
    # Precision comes from ``sample_mhc_candidates`` rather than a raw
    # ``.split()``: a serotype-typed sample (``HLA-DR15``) used to emit the
    # literal token, which matches no IEDB ``mhc_restriction`` and dropped
    # the sample out of the join entirely (#380).  Its member alleles are
    # a legitimate candidate set, so they join — but they are marked
    # ``serotype_expansion`` rather than ``allele_exact``, because the
    # study typed to serotype and the match is an inference from the
    # IPD-IMGT/HLA catalog, not a reported allele.  Locus- and class-only
    # designations (``BoLA-DR``, ``HLA class I``) still contribute
    # nothing, which is correct: they name no allele to match on.
    # Full class-II restrictions also need to reach serotype-typed samples
    # (notably DQ8, whose catalog members are DQB1 chains). Build aliases
    # from each observed pair component back to the exact stored
    # restriction, but only for serotype-expanded candidates. Exact sample
    # molecules keep exact identity: two known pairs that merely share DQA1
    # or DPA1 are not the same molecule.
    _observed_pairs_by_component: dict[str, set[str]] = {}
    _pair_restrictions = set(_fillna_scalar_safe(obs["mhc_restriction"], "").astype(str).unique())
    if _study_context is not None:
        _pair_restrictions.update(_study_context["mhc_restriction"].unique())
    for _restriction in sorted(_pair_restrictions):
        _restriction_components = _normalized_allele_components(_restriction)
        if len(_restriction_components) <= 1:
            continue
        for _component in _restriction_components[1:]:
            _observed_pairs_by_component.setdefault(_component, set()).add(_restriction)

    allele_rows: list[dict] = []
    for sample_index, srow in samples.iterrows():
        pmid = int(srow["pmid"])
        candidates = sample_mhc_candidates(srow.get("mhc", ""))
        if not candidates.join_alleles:
            continue
        meta = {col: srow.get(col, "") for col in meta_cols}
        meta["_pmid_int"] = pmid
        meta["_sample_index"] = sample_index
        expanded = [(allele, False) for allele in sorted(candidates.exact)]
        expanded += [
            (allele, True) for allele in sorted(candidates.serotype_alleles - candidates.exact)
        ]
        for allele, from_serotype in expanded:
            normalized_components = _normalized_allele_components(allele)
            for component in normalized_components:
                row = {**meta, "_allele": component}
                if from_serotype:
                    row["sample_attribution"] = "serotype_expansion"
                allele_rows.append(row)

                # A serotype member can identify a full observed pair
                # through that component. Exact molecules cannot: the full
                # restriction itself must match in that case.
                if from_serotype:
                    for pair_restriction in _observed_pairs_by_component.get(component, ()):
                        allele_rows.append({**row, "_allele": pair_restriction})

    allele_df_full = (
        pd.DataFrame(allele_rows)
        if allele_rows
        else pd.DataFrame(columns=["_pmid_int", "_allele", "_sample_index", *meta_cols])
    )
    allele_df_full = allele_df_full.drop_duplicates(
        subset=["_pmid_int", "_allele", "_sample_index"], keep="first"
    )
    # Identify (pmid, allele) keys hit by multiple curated samples — these
    # need per-obs-row tie-breaking on cell_name / source_tissue / assay
    # comments rather than the arbitrary first-pick the de-duplicated
    # ``allele_df`` would otherwise force.
    if not allele_df_full.empty:
        _ambig_counts = allele_df_full.groupby(["_pmid_int", "_allele"]).size()
        _ambig_keys = set(map(tuple, _ambig_counts[_ambig_counts > 1].index.tolist()))
    else:
        _ambig_keys = set()
    # Fast-path lookup keeps first-pick for unambiguous keys; the
    # ambiguous-key tie-break overwrites those rows in a separate pass
    # below.
    allele_df = allele_df_full.drop_duplicates(subset=["_pmid_int", "_allele"], keep="first")

    # --- Single-sample PMID fallback ---
    # When no allele match is found and a PMID has exactly one sample,
    # use that sample's metadata.
    pmid_sample_counts = samples.groupby("pmid").size()
    single_pmids = pmid_sample_counts[pmid_sample_counts == 1].index
    single_df = samples[samples["pmid"].isin(single_pmids)][["pmid", *meta_cols]].copy()
    single_df["_pmid_int"] = single_df["pmid"].astype(int)
    single_df = single_df[["_pmid_int", *meta_cols]].rename(
        columns={c: c + "_fb" for c in meta_cols}
    )
    if not single_df.empty:
        single_df["sample_attribution_fb"] = "single_sample_pmid"

    # --- Canonical class token per obs row ---
    # The YAML writes ``non-classical``; the IEDB export writes ``non
    # classical``.  They never compared equal, so non-classical samples
    # were unreachable from every class-keyed path below (#363).
    obs["_mhc_class_norm"] = (
        obs["mhc_class"].astype(str).map(normalize_mhc_class_token).astype("object")
    )

    # --- PMID x class reported-MHC pool ---
    # For class-only observations (mhc_restriction = "HLA class I"),
    # collect the union of all reported typings across samples of that class.
    # Keep exact molecules and serotypes distinct here: serotype member alleles
    # are join candidates, not typing claims made by the source.
    _class_pool: dict[tuple[int, str], str] = {}  # (pmid, mhc_class) → reported typings
    for pmid_int_s, group in samples.groupby("pmid"):
        pmid_int_v = int(pmid_int_s)
        _classes_here = set().union(*(_sample_class_tokens(r) for _, r in group.iterrows()))
        for cls in sorted(_classes_here):
            reported_mhc: set[str] = set()
            for _, srow in group.iterrows():
                if cls in _sample_class_tokens(srow):
                    candidates = sample_mhc_candidates(srow.get("mhc", ""))
                    for token in candidates.exact:
                        if any(
                            _mhc_class_matches(mhc_class_of(comp), cls)
                            for comp in _normalized_allele_components(token)
                        ):
                            reported_mhc.add(token)
                    for serotype in candidates.serotypes:
                        if any(
                            _mhc_class_matches(mhc_class_of(member), cls)
                            for member in serotype_to_alleles(serotype)
                        ):
                            reported_mhc.add(serotype)
            reported_mhc.discard("")
            if reported_mhc:
                _class_pool[(pmid_int_v, cls)] = " ".join(sorted(reported_mhc))

    # --- Vectorized join ---
    obs["_pmid_int"] = pd.to_numeric(obs["pmid"], errors="coerce")

    # 1) PMID-level metadata. Use .map() instead of merge — pmid_meta_df
    #    only contributes a single column, so the merge's block-manager
    #    consolidation pass is pure overhead.
    if not pmid_meta_df.empty:
        pmid_lookup = pmid_meta_df.set_index("_pmid_int")
        for col in _PMID_LEVEL_COLS:
            # ``.map`` yields object dtype with NaN for PMIDs absent from
            # the overrides.  Resolve through the nullable dtype rather
            # than ``.fillna`` on the object column, which downcasts
            # silently and is deprecated (#377).
            mapped = obs["_pmid_int"].map(pmid_lookup[col])
            if col == "study_apm_perturbed":
                obs[col] = mapped.astype("boolean").fillna(False).astype(bool)
            else:
                obs[col] = mapped.astype("string").fillna("").astype(str)
    else:
        for col in _PMID_LEVEL_COLS:
            obs[col] = False if col == "study_apm_perturbed" else ""

    # 2) Allele-level match: obs.mhc_restriction == allele_df._allele
    #    within same PMID. Observation-pair aliases were added to allele_df
    #    above where a sample genuinely names one component. Use
    #    MultiIndex.reindex instead of merge —
    #    issue #30. The merge path was 60% block-manager consolidation
    #    (numpy.copy + _merge_blocks) on the 4.3M-row x ~50-col obs
    #    DataFrame; reindex assigns metas in-place and skips that pass
    #    entirely. ~3.7x faster on this branch.
    if not allele_df.empty:
        allele_lookup = allele_df.set_index(["_pmid_int", "_allele"])[meta_cols]
        allele_keys = pd.MultiIndex.from_arrays(
            [obs["_pmid_int"].to_numpy(), obs["mhc_restriction"].to_numpy()]
        )
        allele_matched_df = allele_lookup.reindex(allele_keys)
        allele_matched_df.index = obs.index
        obs[meta_cols] = allele_matched_df
        # The assigned columns own their buffers now. Keeping this frame alive
        # retains the original strings after attribution replaces them on obs.
        del allele_matched_df
    else:
        for col in meta_cols:
            obs[col] = pd.NA

    # 2b) Tie-break ambiguous (pmid, allele) keys per obs row.
    #
    # When the curated YAML has multiple samples sharing an (pmid, allele)
    # — e.g. WT vs KO of the same cell line, or hepatocyte / spleen / skin
    # samples in a mouse study that all carry H-2Kb — the first-pick
    # ``allele_df`` above arbitrarily collapses them onto one sample.
    # This pass rescues IEDB metadata: cell_name, source_tissue, and the
    # assay-comment fields commonly carry the discriminator (e.g.
    # "Hepatocyte" vs "Splenocyte"; "IFNg-treated" vs untreated).
    # We score each candidate against those obs fields and pick the
    # highest-scoring sample per row. Ties fall back to the first-pick
    # already in place.
    _winner_meta: dict[tuple, dict] = {}
    if _ambig_keys and not allele_df_full.empty:
        # Build per-key candidate list once: (pmid, allele) → list of
        # (sample_label, perturbation, meta_dict) tuples.
        _candidates_by_key: dict[tuple, list[tuple[str, str, dict]]] = {}
        for (pmid_v, allele_v), grp in allele_df_full.groupby(["_pmid_int", "_allele"]):
            if (pmid_v, allele_v) not in _ambig_keys:
                continue
            cands: list[tuple[str, str, dict]] = []
            for _, r in grp.iterrows():
                cands.append(
                    (
                        str(r.get("sample_label", "") or ""),
                        str(r.get("perturbation", "") or ""),
                        {c: r.get(c, "") for c in meta_cols},
                    )
                )
            _candidates_by_key[(pmid_v, allele_v)] = cands

        # Identify obs rows whose key is ambiguous.
        _ambig_index = pd.MultiIndex.from_tuples(_ambig_keys)
        _obs_keys_idx = pd.MultiIndex.from_arrays([obs["_pmid_int"], obs["mhc_restriction"]])
        _ambig_mask = pd.Series(_obs_keys_idx.isin(_ambig_index), index=obs.index)

        if _ambig_mask.any() or _study_context is not None:
            # Cache per (pmid, allele, cell_name, source_tissue,
            # antigen_processing_comments, assay_comments) — distinct
            # tuples are bounded by IEDB's annotation cardinality, so
            # caching keeps the per-row Python work bounded.
            _tiebreak_cols = [
                "_pmid_int",
                "mhc_restriction",
                "cell_name",
                "source_tissue",
                "antigen_processing_comments",
                "assay_comments",
            ]
            for col in (
                "cell_name",
                "source_tissue",
                "antigen_processing_comments",
                "assay_comments",
            ):
                if col not in obs.columns:
                    obs[col] = ""
            _ambig_obs = _fillna_safe_for_categoricals(obs.loc[_ambig_mask, _tiebreak_cols])
            if _study_context is not None:
                _context_keys = pd.MultiIndex.from_frame(
                    _study_context[["_pmid_int", "mhc_restriction"]]
                )
                _ambig_obs = _study_context.loc[_context_keys.isin(_ambig_index), _tiebreak_cols]
            _unique_ambig = _ambig_obs.drop_duplicates()
            # Which discriminator fields actually vary per (pmid, allele).
            # The class-pool path computes this to stop study-level
            # boilerplate from deciding a per-row fact; the group stage below
            # needs the same protection, since a constant narrative naming
            # several systems would otherwise hand every row of the study to
            # whichever one it scores highest — the #354 collapse moved onto
            # the system axis.
            _ambig_varying: dict[tuple, set[str]] = {}
            _disc_fields = (
                "cell_name",
                "source_tissue",
                "antigen_processing_comments",
                "assay_comments",
            )
            for _key_g, _grp_g in _ambig_obs.groupby(["_pmid_int", "mhc_restriction"]):
                _ambig_varying[_key_g] = {c for c in _disc_fields if _grp_g[c].nunique() > 1}

            for _, r in _unique_ambig.iterrows():
                key = (r["_pmid_int"], r["mhc_restriction"])
                cands = _candidates_by_key.get(key)
                if not cands:
                    continue
                # The deposited statement narrows the candidates before any
                # other stage reads them (#584 review). Every candidate here
                # carries the row's allele by construction, so a statement
                # that excludes all of them excludes the allele evidence too.
                # Leave the metadata alone: the merge's first pick stands, and
                # the resolution pass below sees an arm the statement does not
                # name and settles the row. Nothing has to be carried between
                # the two (#584 review 3).
                _allowed = _statement_allowed_candidates(
                    cands, r["assay_comments"], _stmt_maps.get(int(r["_pmid_int"]))
                )
                if _allowed is None:
                    continue
                # Kept so the attribution can name the stage that decided: the
                # statement did when it removed a sibling from within the
                # winner's own group, and the group stage did when it only
                # removed arms of other systems (#584 review 3).
                _pre_stmt = cands
                cands = _allowed
                # When the candidates span different arms, score only
                # the per-row factual fields.  ``antigen_processing_
                # comments`` / ``assay_comments`` are narrative and
                # describe the study as a whole, so they name *every*
                # arm on *every* row — PMID 31530632 opens all 10,319
                # of its rows with "The HLA-B*40:02 peptidomes from
                # wild-type and ERAP2-KO cells were compared...", and
                # PMID 33633747 says "Cells were either untreated, or
                # treated with Flucloxacillin".  Scoring that prose
                # handed one arm a win on every row of the study,
                # including peptides found only in the other arm
                # (#354).  Absence of evidence in a narrative field is
                # not evidence, so those fields never decide an arm.
                # Group stage (#359), opt-in per study.  Runs before the
                # arm logic for the same reason it does on the class-pool
                # path: narrative fields identify the *system* reliably and
                # say nothing about treatment, so admitting them here and
                # blocking them below splits a question the scorer could
                # not otherwise separate.
                _vary = _ambig_varying.get(key, set(_disc_fields))
                _group = _select_group(
                    cands,
                    r["cell_name"] if "cell_name" in _vary else "",
                    r["source_tissue"] if "source_tissue" in _vary else "",
                    r["antigen_processing_comments"]
                    if "antigen_processing_comments" in _vary
                    else "",
                    r["assay_comments"] if "assay_comments" in _vary else "",
                )
                if _group is not None:
                    cands = [c for c in cands if str(c[2].get("sample_group", "") or "") == _group]
                    if len(cands) == 1:
                        # The system resolved to a single-arm system, so the
                        # arm is determined — a row-level discriminator picked
                        # it.  Falling through would report group_ambiguous
                        # while naming that arm, contradicting the value.
                        _winner_meta[
                            (
                                r["_pmid_int"],
                                r["mhc_restriction"],
                                r["cell_name"],
                                r["source_tissue"],
                                r["antigen_processing_comments"],
                                r["assay_comments"],
                            )
                        ] = {
                            **cands[0][2],
                            "sample_attribution": (
                                "elution_conditions"
                                if len(
                                    [
                                        _c
                                        for _c in _pre_stmt
                                        if str(_c[2].get("sample_group", "") or "") == _group
                                    ]
                                )
                                > 1
                                else "discriminated"
                            ),
                        }
                        continue
                _arm_split = _candidates_disagree_on_arm(cands)
                # IEDB's per-peptide elution-condition enumeration is
                # the one reliable arm discriminator it offers, so it
                # outranks token scoring when present.
                _smap_row = _stmt_maps.get(int(r["_pmid_int"]))
                best = _select_by_elution_conditions(
                    cands,
                    r["assay_comments"],
                    curated_condition_ids=_smap_row.targets if _smap_row else {},
                )
                _attr = "elution_conditions"
                _mapped = (
                    _smap_row is not None and _smap_row.allowed(r["assay_comments"]) is not None
                )
                if best is None and not _mapped:
                    _attr = "discriminated"
                    best = _select_best_candidate(
                        cands,
                        r["cell_name"],
                        r["source_tissue"],
                        "" if _arm_split else r["antigen_processing_comments"],
                        "" if _arm_split else r["assay_comments"],
                    )
                # When no candidate scores, the arm is genuinely
                # undetermined.  Fall back to what every candidate
                # agrees on rather than first-picking one arm (#354).
                if best is None:
                    # _consensus_meta reports group_ambiguous by itself when
                    # the survivors share a system.
                    best = _consensus_meta(cands, meta_cols)
                else:
                    best = {**best, "sample_attribution": _attr}
                _winner_meta[
                    (
                        r["_pmid_int"],
                        r["mhc_restriction"],
                        r["cell_name"],
                        r["source_tissue"],
                        r["antigen_processing_comments"],
                        r["assay_comments"],
                    )
                ] = best

            # Apply winners back to obs (vectorized — see #244).
            apply_winners_vectorized(obs, _ambig_mask, _tiebreak_cols, _winner_meta, meta_cols)

    # 3) Single-PMID fallback. Same pattern, single-level index on PMID.
    #
    # ``meta_cols`` is splatted together from three constants maintained in
    # other modules, so a name landing in two of them would create one shadow
    # column and have the coalesce below ``pop`` it twice — a ``KeyError``
    # thrown from a loop 30 lines away from the cause.  Say it here instead.
    if len(set(meta_cols)) != len(meta_cols):
        duplicated = sorted({c for c in meta_cols if meta_cols.count(c) > 1})
        raise ValueError(
            "meta_cols must be unique; each entry gets exactly one '_fb' shadow "
            f"column and the coalesce consumes it once. Duplicated: {duplicated}"
        )
    fb_cols = [c + "_fb" for c in meta_cols]
    if not single_df.empty:
        single_lookup = single_df.set_index("_pmid_int")[fb_cols]
        single_keys = obs["_pmid_int"].to_numpy()
        single_matched_df = single_lookup.reindex(single_keys)
        single_matched_df.index = obs.index
        obs[fb_cols] = single_matched_df
        # Otherwise popping the fallback columns below cannot free their buffers:
        # this local would keep every shadow alive until the entire export returns.
        del single_matched_df
    # With no single-PMID sample, every fallback value would be missing.
    # Skip those full-length shadow columns and coalesce directly below.

    # Coalesce: allele match > single-PMID fallback > "" (or False for
    # bool meta cols), one column at a time, consuming each ``_fb`` shadow
    # with ``pop`` as it is read.
    #
    # #30 did this block-wise to cut consolidation passes, and on the 4.4M-row
    # corpus that was the export's single largest allocation — 4.29 GB (#566,
    # #572).  ``obs[str_meta_cols]`` and ``obs[str_fb_cols]`` each copy ~40
    # object columns into a consolidated block, and the chained ``fillna``
    # builds two more, so four 4.4M x 40 pointer blocks are live at once
    # alongside both sets still on ``obs``.  Column-wise the transient is one
    # 4.4M array, and popping the shadow returns its memory here rather than at
    # the batched drop ~60% of the build later, so the ~40 dead object columns
    # no longer ride through the class-pool, curated-label and statement
    # stages.
    str_meta_cols = [c for c in meta_cols if c not in _BOOL_META_COLS]
    bool_meta_cols = [c for c in meta_cols if c in _BOOL_META_COLS]

    for col in str_meta_cols:
        # Both fills go through the categorical-safe helpers: the block form
        # this replaced upcast a Categorical/Categorical pair, where the
        # column-wise ``Series.fillna(Series)`` would demand identical category
        # sets and raise.
        coalesced = (
            _fillna_series_safe(obs[col], obs.pop(col + "_fb")) if not single_df.empty else obs[col]
        )
        obs[col] = _fillna_scalar_safe(coalesced, "")

    # Bool meta columns (e.g. apm_perturbed) need ``False`` not ``""`` —
    # otherwise pyarrow rejects the mixed bool/str column on parquet
    # write. Tiny loop (typically 1 column), per-col is fine.
    for col in bool_meta_cols:
        if not single_df.empty:
            bool_fb = obs.pop(col + "_fb")
            obs[col] = obs[col].where(obs[col].notna(), bool_fb)
        obs[col] = obs[col].astype("boolean").fillna(False).astype(bool)

    # 3b) Class-pool tie-break: for obs rows whose mhc_restriction is a
    # class-only sentinel ("HLA class I" / "Saha class I" / etc.) or
    # otherwise didn't allele-match, try to assign a specific sample by
    # scoring each candidate sample (within the same PMID + class)
    # against the obs row's cell_name / source_tissue / assay comments.
    # When a candidate scores >0, propagate its full meta block —
    # otherwise leave the row for the existing class-pool sample_mhc
    # fill below.
    still_empty_pre_pool = obs["mhc"] == ""
    if still_empty_pre_pool.any() and len(samples) > 0:
        # Build per-(pmid, class) candidate sample list once.
        _class_candidates: dict[tuple[int, str], list[tuple[str, str, dict]]] = {}
        for _pmid_v_s, _grp in samples.groupby("pmid"):
            _pmid_v = int(_pmid_v_s)
            _grp_classes = set().union(*(_sample_class_tokens(r) for _, r in _grp.iterrows()))
            for _cls in sorted(_grp_classes):
                _cands_cls: list[tuple[str, str, dict]] = []
                for _, _r in _grp.iterrows():
                    if _cls in _sample_class_tokens(_r):
                        _meta = {c: _r.get(c, "") for c in meta_cols}
                        _cands_cls.append(
                            (
                                str(_r.get("sample_label", "") or ""),
                                str(_r.get("perturbation", "") or ""),
                                _meta,
                            )
                        )
                # Register the class-pool candidates whenever the PMID
                # has at least one sample matching this class.  Multi-
                # sample groups need tie-breaking; single-sample groups
                # still benefit from this path so a class-II obs row in
                # a study with mixed class-I+II samples still picks up
                # the matching class-II sample's metadata (the
                # single_PMID_fallback above only fires when the PMID
                # has exactly one sample total).
                if _cands_cls:
                    _class_candidates[(_pmid_v, _cls)] = _cands_cls

        if _class_candidates:
            # Restrict obs to the rows whose (pmid, mhc_class) has a
            # multi-sample candidate pool — this is where the previous
            # logic gave up and left sample_label empty.
            _eligible_keys = {(float(p), c) for p, c in _class_candidates}
            _obs_pc_idx = pd.MultiIndex.from_arrays([obs["_pmid_int"], obs["_mhc_class_norm"]])
            _obs_pc_in_pool = pd.Series(
                _obs_pc_idx.isin(pd.MultiIndex.from_tuples(_eligible_keys)),
                index=obs.index,
            )
            _eligible_mask = still_empty_pre_pool & _obs_pc_in_pool
            if _eligible_mask.any():
                # The four IEDB metadata columns we score against.
                # Antigen-processing-comments are usually a study-level
                # note (constant across all rows of the PMID), so only
                # "varying" fields actually discriminate samples — see
                # the per-(pmid, class) variance check below. cell_name
                # and assay_comments tend to be per-row discriminators
                # in the studies that need this fix.
                _disc_cols_all = [
                    "cell_name",
                    "source_tissue",
                    "antigen_processing_comments",
                    "assay_comments",
                ]
                for col in _disc_cols_all:
                    if col not in obs.columns:
                        obs[col] = ""
                _tb_cols = [
                    "_pmid_int",
                    "_mhc_class_norm",
                    "mhc_restriction",
                    *_disc_cols_all,
                ]
                if "restriction_evidence" in obs.columns:
                    _tb_cols.append("restriction_evidence")
                _eligible_df = _fillna_safe_for_categoricals(obs.loc[_eligible_mask, _tb_cols])
                # Whether a field distinguishes systems is a property of
                # the whole study, not of the rows still awaiting a match.
                # Dropping exact-allele matches here made SU-DHL-6 appear
                # constant after DB and SU-DHL-4 left the pool (#556).
                # Duplicate peptide rows add no variation; compact before
                # retaining a second corpus-sized frame (#562).
                _variance_df = (
                    _study_context
                    if _study_context is not None
                    else _fillna_safe_for_categoricals(
                        obs.loc[
                            _obs_pc_in_pool, ["_pmid_int", "_mhc_class_norm", *_disc_cols_all]
                        ].drop_duplicates()
                    )
                )
                # Per (pmid, class), drop discriminator columns whose
                # value is identical across all study rows — those
                # can't differentiate samples and would otherwise inflate
                # rarity-weighted scores with study-level boilerplate.
                _varying_cols_per_key: dict[tuple, list[str]] = {}
                for (_pmid_v_g, _cls_g), _grp in _variance_df.groupby(
                    ["_pmid_int", "_mhc_class_norm"]
                ):
                    _varying = [c for c in _disc_cols_all if _grp[c].nunique() > 1]
                    _varying_cols_per_key[(_pmid_v_g, _cls_g)] = _varying
                _unique_tb = _eligible_df.drop_duplicates()

                # Does cell_name vary *within* each group, as opposed to
                # between groups?  The two-pass gate below needs the former.
                _grp_cell_varies_within: dict[str, bool] = {}
                for (_pmid_g, _cls_g), _grp_rows in _eligible_df.groupby(
                    ["_pmid_int", "_mhc_class_norm"]
                ):
                    for _c in _class_candidates.get((int(_pmid_g), str(_cls_g)), []):
                        _g = str(_c[2].get("sample_group", ""))
                        if _g:
                            _grp_cell_varies_within.setdefault(_g, False)

                _tb_winner: dict[tuple, dict] = {}
                for _, _r in _unique_tb.iterrows():
                    _key = (int(_r["_pmid_int"]), str(_r["_mhc_class_norm"]))
                    _cands = _class_candidates.get(_key)
                    if not _cands:
                        continue
                    _pool_cands = _cands
                    _reported_restriction = (
                        ""
                        if _r.get("restriction_evidence") == "predicted"
                        else _r["mhc_restriction"]
                    )
                    # ── statement stage (#565, reworked in #584) ───────
                    # The deposited statement is per-row evidence about which
                    # sample the peptide came off, so it narrows the pool
                    # before the group stage, the scorer and the consensus
                    # fallback can read an arm it excludes.
                    _smap_pool = _stmt_maps.get(int(_r["_pmid_int"]))
                    _stmt_mapped = (
                        _smap_pool is not None
                        and _smap_pool.allowed(_r["assay_comments"]) is not None
                    )
                    _allowed_pool = _statement_allowed_candidates(
                        _cands, _r["assay_comments"], _smap_pool
                    )
                    if _allowed_pool is None:
                        # No arm the statement names is in this pool. Leave the
                        # metadata alone; the resolution pass below reaches the
                        # same verdict from the row's own statement and class,
                        # with nothing carried between the two (#584 review 3).
                        continue
                    # Kept so the attribution can say which stage actually
                    # made the choice. The statement decided it when it removed
                    # a candidate from *within* the group the winner belongs
                    # to; if it only removed arms of other systems and the
                    # group stage picked among the ones it named, the group
                    # stage decided. Crediting the statement for any narrowing
                    # at all got that backwards (#584 review 3).
                    _pre_stmt_cands = _cands
                    _cands = _allowed_pool
                    _pool_cands = _allowed_pool
                    # ── group stage (#359) ─────────────────────────────
                    # Opt-in: only studies that curate ``sample_group``.
                    # Narrowing to one system before the arm scorer runs
                    # is what makes a single-arm system attributable at
                    # all, and stops extra identifying words on one arm of
                    # a pair from deciding the pair.
                    # Same _varying filter the arm stage applies below: a
                    # field constant across the whole (pmid, class) pool is
                    # study-level boilerplate and cannot decide a per-row
                    # fact, whichever stage reads it.
                    _grp_vary = _varying_cols_per_key.get(
                        (_r["_pmid_int"], _r["_mhc_class_norm"]), _disc_cols_all
                    )
                    _group = _select_group(
                        _cands,
                        _r["cell_name"] if "cell_name" in _grp_vary else "",
                        _r["source_tissue"] if "source_tissue" in _grp_vary else "",
                        _r["antigen_processing_comments"]
                        if "antigen_processing_comments" in _grp_vary
                        else "",
                        _r["assay_comments"] if "assay_comments" in _grp_vary else "",
                    )
                    _grouped = _group is not None
                    if _grouped:
                        _cands = [
                            c for c in _cands if str(c[2].get("sample_group", "") or "") == _group
                        ]
                    # A group that narrows to one arm was picked by a
                    # row-level discriminator, so say so rather than reporting
                    # that the class pool assigned it.
                    _pool_attr = "discriminated" if _grouped else "class_pool"
                    if len(_cands) == 1:
                        # Single-class candidate inside a multi-sample
                        # PMID — assign without scoring (no ambiguity).
                        _best_meta: dict | None = _cands[0][2]
                        _group_before = [
                            _c
                            for _c in _pre_stmt_cands
                            if _group is None or str(_c[2].get("sample_group", "") or "") == _group
                        ]
                        if len(_group_before) > 1:
                            # The statement is what left one candidate, so the
                            # attribution names it rather than the stage that
                            # picked the survivor up. Each label says which
                            # evidence actually made the choice: the statement
                            # here, the group stage or the scorer below.
                            _pool_attr = "elution_conditions"
                    elif (
                        not _stmt_mapped
                        and (
                            _elution := _select_by_elution_conditions(
                                _cands,
                                _r["assay_comments"],
                                curated_condition_ids=_smap_pool.targets if _smap_pool else {},
                            )
                        )
                        is not None
                    ):
                        # The generic enumeration resolver: IEDB's own
                        # "untreated X; treated X" wording, which needs no
                        # curated map and is how PMID 32938616 and 33968037
                        # reach their arms. Only a *mapped* statement makes it
                        # unreachable, because narrowing has already kept
                        # exactly the arms that statement names -- removing the
                        # branch outright cost those two studies 46,247 arms
                        # (#584 review 4).
                        _best_meta = _elution
                        _pool_attr = "elution_conditions"
                    elif _stmt_mapped:
                        # Narrowing above already kept only the arms the
                        # statement names, so asking it to single one out again
                        # could never succeed -- more than one survivor *is* the
                        # authoritative ambiguity, and not permission to guess
                        # again from narrative token scores (#555/#556,
                        # #584 review 4).
                        _best_meta = _consensus_meta(_cands, meta_cols)
                        _pool_attr = str(_best_meta["sample_attribution"])
                    else:
                        _varying = _varying_cols_per_key.get(
                            (_r["_pmid_int"], _r["_mhc_class_norm"]), _disc_cols_all
                        )
                        if _grouped:
                            # Variance was measured across the whole
                            # (pmid, class) pool, but the group filter has
                            # since removed most of it.  A field that varied
                            # only *between* systems is constant within the
                            # surviving one, so judging the two-pass gate on
                            # the pre-narrowing answer blocks the fallback
                            # for exactly the rows the narrowing helped.
                            _varying = [
                                c
                                for c in _varying
                                if c != "cell_name" or _grp_cell_varies_within.get(_group, False)
                            ]
                        # Two-pass scoring:
                        # Pass 1: cell_name + source_tissue only — these
                        # are reliable per-row discriminators when they
                        # vary across the group.
                        # Pass 2: fall back to APC + AC only if pass 1
                        # produces no winner. APC / AC are narrative
                        # fields that often mention the cell line being
                        # processed even on rows from a *different*
                        # sample (e.g. Liepe 2016 GR-LCL rows whose AC
                        # describes "GR lymphoblastoid cell line"
                        # otherwise pulled "lymphoblastoid" matches that
                        # belong to the C1R-parental sample). Only use
                        # them when cell_name doesn't differentiate.
                        _best_meta = _select_best_candidate(
                            _cands,
                            _r["cell_name"] if "cell_name" in _varying else "",
                            _r["source_tissue"] if "source_tissue" in _varying else "",
                            "",
                            "",
                        )
                        if (
                            _best_meta is None
                            and "cell_name" not in _varying
                            and not _candidates_disagree_on_arm(_cands)
                            and (
                                "antigen_processing_comments" in _varying
                                or "assay_comments" in _varying
                            )
                        ):
                            # Only fall back to APC / AC when cell_name
                            # itself was constant across the group — if
                            # cell_name varied but no candidate's label
                            # matched the obs cell_name, that's a real
                            # gap (e.g. Liepe 2016 has "B cell" / "T2"
                            # cell_names that no curated sample names);
                            # adding APC / AC there would cherry-pick
                            # via narrative cell-line mentions rather
                            # than per-row truth.
                            _best_meta = _select_best_candidate(
                                _cands,
                                "",
                                _r["source_tissue"] if "source_tissue" in _varying else "",
                                _r["antigen_processing_comments"]
                                if "antigen_processing_comments" in _varying
                                else "",
                                _r["assay_comments"] if "assay_comments" in _varying else "",
                            )
                        if _best_meta is not None:
                            # A row-level discriminator selected one sample
                            # from the class pool.  Keep ``sample_match_type``
                            # as ``pmid_class_pool`` (the restriction itself
                            # was not an exact allele match), but report how
                            # the sample metadata was actually attributed.
                            _pool_attr = "discriminated"
                        else:
                            # No winner: fall back to what every candidate
                            # agrees on, exactly as the allele path does.
                            # ``_consensus_meta`` reports ``group_ambiguous``
                            # when the survivors share a system and
                            # ``pmid_ambiguous`` when they do not.
                            #
                            # This ran only for grouped studies until #451, so
                            # an ungrouped one wrote no entry at all and the
                            # row stayed blank — indistinguishable from a row
                            # that matched no sample, while discarding the
                            # metadata every candidate agreed on.
                            _best_meta = _consensus_meta(_cands, meta_cols)
                            _pool_attr = str(_best_meta["sample_attribution"])
                    # Validate the proposed winner without changing text
                    # scoring weights (#514). Unknown typing cannot win by
                    # merely surviving the exclusion of known genotypes.
                    _compatible_cands = []
                    for _candidate in _pool_cands:
                        _overlap = reported_mhc_fields_overlap(
                            _reported_restriction, _candidate[2].get("mhc", "")
                        )
                        if _overlap is not False:
                            _compatible_cands.append((_candidate, _overlap))
                    if len(_compatible_cands) == 1 and _compatible_cands[0][1] is True:
                        _genotype_meta = _compatible_cands[0][0][2]
                        if _best_meta is None or _best_meta.get(
                            "sample_label"
                        ) != _genotype_meta.get("sample_label"):
                            _best_meta = _genotype_meta
                            # Name the evidence that chose, as the paths beside
                            # this one do. The pool here is what the statement
                            # left, so when the statement is what removed the
                            # other compatible arms it -- not the typing check
                            # -- is what singled this one out (#584 review 4).
                            _pool_attr = (
                                "elution_conditions"
                                if _stmt_mapped and len(_pre_stmt_cands) > len(_pool_cands)
                                else "discriminated"
                            )
                    elif (
                        _best_meta is not None
                        and _best_meta.get("sample_label")
                        and reported_mhc_fields_overlap(
                            _reported_restriction, _best_meta.get("mhc", "")
                        )
                        is False
                    ):
                        # A rejected guess does not erase the study-level
                        # consensus or make the row look uncurated (#556).
                        # It must not lend its own name back, either: with one
                        # surviving candidate, "consensus" is that candidate,
                        # so the arm whose typing just contradicted the row's
                        # restriction returned as its label and candidate list
                        # beside a blank condition_id -- the #581 shape, via
                        # the statement stage this time (#584 review 3).
                        _best_meta = _consensus_meta(_pool_cands, meta_cols)
                        if _stmt_mapped:
                            # With the pool narrowed to the arms the statement
                            # names, one survivor means "consensus" *is* the arm
                            # whose typing the row just contradicted, so it must
                            # not lend its label back (#581). Unmapped rows keep
                            # the #556 behaviour untouched: this branch runs for
                            # every study, and blanking there would change
                            # attribution corpus-wide (#584 review 4).
                            _best_meta = _blank_arm_identity(_best_meta)
                        _pool_attr = str(_best_meta["sample_attribution"])
                    if _best_meta is not None:
                        _best_meta = {**_best_meta, "sample_attribution": _pool_attr}
                        _tb_winner[tuple(_r[column] for column in _tb_cols)] = _best_meta

                if _tb_winner:
                    # Vectorized winner application (#244) — same shape as
                    # the per-PMID discriminator path above.
                    apply_winners_vectorized(obs, _eligible_mask, _tb_cols, _tb_winner, meta_cols)

    # 3c) Curated per-row sample label — the highest-confidence
    # evidence there is, so it overrides every heuristic above.
    #
    # Some IEDB rows carry ``attributed_sample_label``, a curated
    # per-observation donor / sample identifier.  For PMID 31844290 all
    # 11 of its labels ("MEL15 (13240-015)", "GBM11 (H4512 BT145)",
    # "CLL C (DFCI-5283)", ...) match a curated ``ms_samples`` entry
    # exactly, yet the join ignored the column entirely and left those
    # 54,682 rows unattributed while heuristics fought over the
    # study's 107 mono-allelic transfectant samples.
    if "attributed_sample_label" in obs.columns and len(samples) > 0:
        _label_rows: list[dict] = []
        for _, _srow in samples.iterrows():
            _lbl = str(_srow.get("sample_label", "") or "").strip()
            if not _lbl:
                continue
            _lmeta = {c: _srow.get(c, "") for c in meta_cols}
            _lmeta["sample_attribution"] = "curated_sample_label"
            _label_rows.append({"_pmid_int": float(_srow["pmid"]), "_label": _lbl, **_lmeta})
        if _label_rows:
            _label_df = pd.DataFrame(_label_rows).drop_duplicates(
                subset=["_pmid_int", "_label"], keep="first"
            )
            _obs_label = obs["attributed_sample_label"].astype("string").fillna("").str.strip()
            _obs_label = _obs_label.where(~_obs_label.isin(("nan", "None")), "")
            if _obs_label.ne("").any():
                _label_matched = _label_df.set_index(["_pmid_int", "_label"])[meta_cols].reindex(
                    pd.MultiIndex.from_arrays([obs["_pmid_int"].to_numpy(), _obs_label.to_numpy()])
                )
                _label_matched.index = obs.index
                _label_hit = _label_matched["sample_label"].notna()
                if _label_hit.any():
                    # Column-wise so the bool meta columns keep their
                    # dtype — a bulk .loc assignment pushes object/NaN
                    # into them and pandas warns (soon errors).
                    for _lcol in meta_cols:
                        _lvals = _label_matched[_lcol]
                        if _lcol in _BOOL_META_COLS:
                            _lvals = _lvals.astype("boolean").fillna(False).astype(bool)
                        else:
                            _lvals = _lvals.fillna("")
                        obs[_lcol] = obs[_lcol].where(~_label_hit, _lvals)
                # The coalesce owns its output; do not retain the full-length
                # metadata shadow through later annotation and categorization.
                del _label_matched

    # 3d) Resolve every statement-excluded row, once and from row data alone.
    #
    # A row is refused exactly when no arm its statement names could have
    # presented it. That is decidable here, from the row's own statement,
    # class and assigned arm, which is why nothing has to be passed down from
    # the stages that narrow: an earlier version carried a key set between
    # three sites that each had to normalise the statement identically, and
    # re-derived refusal here under a second rule that disagreed with it
    # (#584 review 3).
    #
    # Two shapes reach this point. A row *assigned* an arm the statement does
    # not name: either a narrowing stage refused and the merge's first pick
    # stood, or the key was unique and never went through a candidate list at
    # all, or stage 3c's curated label named it. That label is overridden
    # deliberately -- both are per-row deposit evidence, and a label naming an
    # arm the statement excludes is a contradiction in the deposit rather than
    # a better guess. And a row that reached *no* arm whose statement names no
    # arm of its class: nothing could have presented it, whereas a blank arm
    # with a named arm of its class available is the ordinary ambiguity a
    # statement naming several arms produces.
    _statement_vetoed = pd.Series(False, index=obs.index)
    if _stmt_maps and "assay_comments" in obs.columns and "condition_id" in obs.columns:
        # Everything here stays scoped to the rows of a study that curates a
        # map, and the metadata rewrite touches only the refused rows. The
        # frame-wide shape of this cost more than the veto is worth: converting
        # ``assay_comments`` (a declared categorical, ~190 MB as strings) over
        # 4.4M rows, then building one Python list per meta column to rewrite
        # 492 of them, is several hundred MB of transients -- enough to lose the
        # 3.11 integration job, which runs with under a gigabyte to spare (#566).
        for _pmid, _smap in _stmt_maps.items():
            _in_study = (obs["_pmid_int"] == float(_pmid)).fillna(False)
            if not _in_study.any():
                continue
            _rows = obs.index[_in_study.to_numpy()]
            _stmts = obs.loc[_rows, "assay_comments"].astype("string").fillna("")
            _assigned = obs.loc[_rows, "condition_id"].astype("string").fillna("")
            _classes = obs.loc[_rows, "_mhc_class_norm"].astype("string").fillna("")
            _labels = obs.loc[_rows, "sample_label"].astype("string").fillna("")
            # All five sequences come from the same row selection and align.
            _by_class: dict[str, list] = {}
            for _idx, _stmt, _arm, _cls, _label in zip(
                _rows,
                _stmts.tolist(),
                _assigned.tolist(),
                _classes.tolist(),
                _labels.tolist(),
            ):
                # One normalisation, in ``StatementMap`` and nowhere else.
                _allowed = _smap.allowed(_stmt)
                if _allowed is None:
                    # An unmapped statement is evidence about nothing, so it
                    # narrows nothing and refuses nothing. This is what keeps a
                    # partial map a tie-breaker (#512).
                    continue
                # Refuse only on positive evidence. An arm the statement does
                # not name is that evidence. A row with no arm is only evidence
                # when its class is known *and* names no allowed arm -- an
                # unknown class, or an arm reached through a path that carries
                # no ``condition_id`` (stage 3c's curated label, the
                # single-sample fallback), is missing data, and missing data is
                # not a reason to refuse a row (#584 review 4).
                if _arm:
                    _refused = _arm not in _allowed
                else:
                    _refused = not _label and bool(_cls) and not _smap.allows_class(_allowed, _cls)
                if _refused:
                    _by_class.setdefault(_cls, []).append(_idx)
            _study_rows = samples[samples["pmid"].astype(int) == _pmid]
            for _cls, _idxs in _by_class.items():
                _meta = _statement_excluded_meta(_study_rows, meta_cols, _cls)
                for _col in meta_cols:
                    obs.loc[_idxs, _col] = _meta[_col]
                _statement_vetoed.loc[_idxs] = True

    # 4) Class-pool fallback: for still-unmatched rows, fill sample_mhc
    #    with the union of all alleles from samples of the same class.
    still_empty = obs["mhc"] == ""
    if still_empty.any() and _class_pool:
        # Vectorized lookup via MultiIndex.reindex (issue #173). The
        # `_class_pool` keys store ``_pmid_int`` as Python int while
        # ``obs["_pmid_int"]`` is float64 (NaN for unparseable PMIDs);
        # cast pool keys to float so the MultiIndex matcher pairs them
        # correctly and NaN keys naturally fall through to "".
        pool_lookup = pd.Series(
            list(_class_pool.values()),
            index=pd.MultiIndex.from_tuples(
                [(float(p), c) for p, c in _class_pool],
                names=["_pmid_int", "mhc_class"],
            ),
        )
        sub_idx = pd.MultiIndex.from_arrays(
            [obs.loc[still_empty, "_pmid_int"], obs.loc[still_empty, "_mhc_class_norm"]]
        )
        obs.loc[still_empty, "mhc"] = pool_lookup.reindex(sub_idx).fillna("").to_numpy()

    # Where ``sample_mhc`` came from, which is not recoverable from
    # ``sample_match_type`` (#564).  That column says whether the study *has* a
    # class pool, not whether this row took it, so a row attributed to one arm
    # by the discriminator reads ``pmid_class_pool`` while carrying that arm's
    # own candidates.  Measured on the corpus: 14,532 class-only rows have a
    # resolved arm and its own candidate list while labelled ``pmid_class_pool``,
    # and none carry a cross-arm union -- so a consumer using the match type to
    # mean "these candidates are one sample's" drops all of the former to catch
    # none of the latter.  ``predict`` did exactly that.
    #
    # Also the missing half of blank ``mhc_basis``: the field registry defines
    # blank as "unreviewed", and the blanking below overloads it with "the claim
    # was dropped because these are not the arm's candidates". With this column
    # the two are distinguishable.
    # Built once: a bulk ``.loc`` setitem on this 4.4M-row frame consolidates
    # blocks and copies it (#173, #244), and the second of the two would have
    # been a strict-subset rewrite of the first.
    _has_candidates = obs["mhc"].ne("")
    obs["sample_mhc_origin"] = (
        _has_candidates.map({True: "sample", False: ""})
        .where(~(still_empty & _has_candidates), "class_pool")
        .astype(str)
    )

    # ``mhc_basis`` describes a sample's *own* reported candidates, which is
    # why the load-time contract refuses it without them (#520).  A row whose
    # curated ``mhc`` did not survive to here carries something else: either
    # ``_consensus_meta`` blanked it because the arms disagreed, or the union
    # above replaced it with the study's class pool.  Both leave a column the
    # basis cannot describe -- two arms' selected restrictions joined into one
    # string are not a selected restriction -- so the claim goes with them.
    # Column-wise, like the label join above: a bulk ``.loc`` setitem on this
    # 4.4M-row frame consolidates blocks and copies it (#173, #244).
    obs["mhc_basis"] = obs["mhc_basis"].where(~still_empty, "")

    # --- Provenance: how was each row matched? ---
    # Count samples per PMID for context. Single-column join → use .map()
    # to skip the merge's block-manager consolidation overhead.
    _pmid_counts = samples.groupby("pmid").size()
    _pmid_counts.index = _pmid_counts.index.astype(int)
    obs["matched_sample_count"] = obs["_pmid_int"].map(_pmid_counts).fillna(0).astype(int)

    # Determine match type — all three membership checks use vectorized
    # MultiIndex.isin so the per-row Python loops they replaced (issue #173)
    # don't scale linearly with the index size. ``_pmid_int`` in the lookup
    # sets is Python int but the ``obs`` column is float64; cast lookup
    # keys to float so dtype mismatch doesn't silently miss matches.
    obs["sample_match_type"] = "unmatched"

    obs_pmid_allele_idx = pd.MultiIndex.from_arrays([obs["_pmid_int"], obs["mhc_restriction"]])
    if not allele_df.empty:
        matched_idx = pd.MultiIndex.from_arrays(
            [allele_df["_pmid_int"].astype(float), allele_df["_allele"]]
        )
        allele_matched = pd.Series(obs_pmid_allele_idx.isin(matched_idx), index=obs.index)
        obs.loc[allele_matched, "sample_match_type"] = "allele_match"
    else:
        allele_matched = pd.Series(False, index=obs.index)

    _single_pmid_floats = (
        {float(p) for p in single_df["_pmid_int"]} if not single_df.empty else set()
    )
    fallback_matched = ~allele_matched & obs["_pmid_int"].isin(_single_pmid_floats)
    obs.loc[fallback_matched, "sample_match_type"] = "single_sample_fallback"

    # Class pool: not allele-matched, not single-sample, but has class pool alleles
    if _class_pool:
        class_pool_idx = pd.MultiIndex.from_tuples([(float(p), c) for p, c in _class_pool])
        obs_pmid_class_idx = pd.MultiIndex.from_arrays([obs["_pmid_int"], obs["_mhc_class_norm"]])
        in_pool = pd.Series(obs_pmid_class_idx.isin(class_pool_idx), index=obs.index)
    else:
        in_pool = pd.Series(False, index=obs.index)
    pool_matched = ~allele_matched & ~fallback_matched & in_pool
    obs.loc[pool_matched, "sample_match_type"] = "pmid_class_pool"

    # The three checks above ask how the row's *allele* was matched, which
    # says nothing about rows attributed from metadata instead — a study
    # whose ms_samples carry no ``mhc`` never enters allele_df or the class
    # pool, so every one of its rows stayed "unmatched" even after the
    # discriminator or group stage named its sample outright.  289,611 rows
    # carried a sample_label or sample_group while reporting "unmatched",
    # and a consumer reading this column as the confidence axis (README, and
    # qc's class_pool_n) saw no match for rows that were in fact attributed.
    _attributed = pd.Series(False, index=obs.index)
    for _col in ("sample_label", "sample_group"):
        if _col in obs.columns:
            _attributed |= obs[_col].astype(str).str.strip().ne("")
    obs.loc[(obs["sample_match_type"] == "unmatched") & _attributed, "sample_match_type"] = (
        "metadata_match"
    )

    # A statement-refused row reached no arm, so whatever its allele matched is
    # an arm the deposit excludes. The allele checks above only ask whether
    # *some* sample's candidates contain the row's restriction, and for these
    # rows one does -- the very arm the statement rules out -- so they would
    # otherwise report ``allele_match`` over a candidate set that is not
    # theirs. ``predict``'s ``!= "pmid_class_pool"`` guard exists to refuse
    # exactly that shape.
    #
    # ``sample_mhc_origin`` follows the candidates rather than the refusal: it
    # says ``class_pool`` when the class pool actually supplied them, and stays
    # blank when the row's class has no pool, because blank is how that column
    # says nothing reached the row (#584 review 3). ``.ne("")`` rather than
    # ``.astype(str) != ""``: ``mhc`` is a declared categorical and rebuilding
    # its object array costs hundreds of MB here.
    # ``pmid_class_pool`` claims the row's candidates are the class pool's
    # union, so it only holds where such a union exists; with no pool for the
    # row's class there is nothing it could describe, and ``unmatched`` is what
    # the column says then (#584 review 4). ``sample_mhc_origin`` already
    # follows the candidates from the fill above, so it needs no second pass.
    obs.loc[_statement_vetoed & obs["mhc"].ne(""), "sample_match_type"] = "pmid_class_pool"
    obs.loc[_statement_vetoed & obs["mhc"].eq(""), "sample_match_type"] = "unmatched"

    # --- Peptide-level allele evidence flag ---
    obs["has_peptide_level_allele"] = _compute_has_peptide_level_allele(
        obs["mhc_restriction"],
        obs["allele_resolution"] if "allele_resolution" in obs.columns else None,
    )

    # --- Chimeric experimental system flag (#46 down-payment) ---
    source_organism = _source_organism_with_fallback(obs)
    if "mhc_species" in obs.columns:
        obs["is_chimeric"] = _compute_is_chimeric(source_organism, obs["mhc_species"])
    else:
        obs["is_chimeric"] = False

    # --- Engineered-MHC flag (#226): narrows is_chimeric to rows where the
    # MHC is heterologous to the host cells, vs heterologous-antigen rows
    # that present a foreign protein on the host's native MHC. ---
    if "mhc_species" in obs.columns and "host" in obs.columns:
        obs["is_engineered_mhc"] = _compute_is_engineered_mhc(
            source_organism, obs["mhc_species"], obs["host"]
        )
    else:
        obs["is_engineered_mhc"] = False

    # The ``_fb`` shadows are gone already: the coalesce above consumes each
    # one with ``pop`` so ~40 object columns no longer ride from there to here
    # just to be dropped (#566).  Only the two join keys are left.
    obs.drop(columns=["_pmid_int", "_mhc_class_norm"], inplace=True)

    # "No shadow reaches the export" used to be enforced by that single drop
    # naming ``fb_cols``; the coalesce's ``pop`` calls now enforce it 48 times
    # over, and a stage that adds a ``*_fb`` column after the coalesce -- the
    # way ``single_df["sample_attribution_fb"]`` is set ad hoc above -- would
    # ship it into observations.parquet with nothing to catch it.  Restore the
    # chokepoint as a check.
    shadows = [c for c in obs.columns if c.endswith("_fb")]
    if shadows:
        raise AssertionError(
            "single-PMID fallback shadow columns must be consumed by the coalesce, "
            f"not exported: {sorted(shadows)}"
        )
    result = obs

    # --- Tighten dtypes: low-cardinality metadata → categorical (#263) ---
    # Done on ``obs`` (the owned frame, pre-rename) so the assignment never
    # hits a SettingWithCopy slice.  ``""`` is pre-added to the category set
    # so the export pipeline's ``fillna("")`` idioms don't raise the
    # out-of-category ``TypeError`` (same pattern as builder._compress_categoricals).
    for col in _CATEGORICAL_EXPORT_METADATA_COLS:
        if col not in obs.columns:
            continue
        if isinstance(obs[col].dtype, pd.CategoricalDtype):
            continue
        if not pd.api.types.is_string_dtype(obs[col]):
            continue
        cat = obs[col].astype("category")
        if "" not in cat.cat.categories:
            cat = cat.cat.add_categories([""])
        obs[col] = cat

    # --- Post-join filters ---
    if instrument_type and "instrument_type" in result.columns:
        result = result[result["instrument_type"] == instrument_type]
    if acquisition_mode and "acquisition_mode" in result.columns:
        result = result[result["acquisition_mode"] == acquisition_mode]
    if is_mono_allelic is not None and "is_monoallelic" in result.columns:
        result = result[result["is_monoallelic"] == is_mono_allelic]
    if apm_only and "apm_perturbed" in result.columns:
        # Only ``"true"`` selects.  ``""`` means the arm was never
        # resolved, which is not evidence of a perturbation (#392).
        result = result[result["apm_perturbed"] == "true"]

    # Rename 'mhc' (from ms_samples join) to 'sample_mhc' to distinguish
    # from the IEDB mhc_restriction field (which may be "HLA class I").
    if "mhc" in result.columns:
        result = result.rename(columns={"mhc": "sample_mhc", "note": "sample_note"})

    if columns:
        available = [c for c in columns if c in result.columns]
        result = result[available]

    return result


@dataset_snapshot()
def generate_ms_observations_table(
    mhc_class: str | None = None,
    species: str | None = None,
    source: str | None = None,
    instrument_type: str | None = None,
    acquisition_mode: str | None = None,
    is_mono_allelic: bool | None = None,
    min_allele_resolution: str | None = None,
    mhc_allele: str | list[str] | None = None,
    mhc_allele_in_set: str | list[str] | None = None,
    mhc_allele_provenance: str | list[str] | None = None,
    restriction_evidence: str | list[str] | None = None,
    serotype_source: str | list[str] | None = None,
    gene: str | list[str] | None = None,
    gene_name: str | list[str] | None = None,
    gene_id: str | list[str] | None = None,
    peptide: str | list[str] | None = None,
    serotype: str | list[str] | None = None,
    length_min: int | None = None,
    length_max: int | None = None,
    exclude_class_label_suspect: bool = False,
    exclude_class_label_implausible: bool = False,
    exclude_non_peptide_ligand: bool = True,
    apm_only: bool = False,
    columns: list[str] | None = None,
    *,
    source_species: str | list[str] | None = None,
    host_species: str | list[str] | None = None,
    exclude_chimeric: bool = False,
) -> pd.DataFrame:
    """MS observations table: per-peptide rows joined with per-sample metadata.

    The canonical MS-export entry point (the name disambiguates MS from
    binding). Loads ``observations.parquet``, applies the filters below, and
    enriches each row with sample-level metadata. This is a thin pass-through to
    :func:`generate_observations_table` — see that function for the full
    parameter reference (``source``, ``peptide``, ``length_min``/``length_max``,
    and the ``exclude_*`` flags are all forwarded).
    """
    return generate_observations_table(
        mhc_class=mhc_class,
        species=species,
        source_species=source_species,
        host_species=host_species,
        exclude_chimeric=exclude_chimeric,
        source=source,
        instrument_type=instrument_type,
        acquisition_mode=acquisition_mode,
        is_mono_allelic=is_mono_allelic,
        min_allele_resolution=min_allele_resolution,
        mhc_allele=mhc_allele,
        mhc_allele_in_set=mhc_allele_in_set,
        mhc_allele_provenance=mhc_allele_provenance,
        restriction_evidence=restriction_evidence,
        serotype_source=serotype_source,
        gene=gene,
        gene_name=gene_name,
        gene_id=gene_id,
        peptide=peptide,
        serotype=serotype,
        length_min=length_min,
        length_max=length_max,
        exclude_class_label_suspect=exclude_class_label_suspect,
        exclude_class_label_implausible=exclude_class_label_implausible,
        exclude_non_peptide_ligand=exclude_non_peptide_ligand,
        apm_only=apm_only,
        columns=columns,
    )


@dataset_snapshot()
def generate_binding_table(
    mhc_class: str | None = None,
    species: str | None = None,
    min_allele_resolution: str | None = None,
    mhc_allele: str | list[str] | None = None,
    mhc_allele_in_set: str | list[str] | None = None,
    mhc_allele_provenance: str | list[str] | None = None,
    restriction_evidence: str | list[str] | None = None,
    serotype_source: str | list[str] | None = None,
    gene: str | list[str] | None = None,
    gene_name: str | list[str] | None = None,
    gene_id: str | list[str] | None = None,
    peptide: str | list[str] | None = None,
    serotype: str | list[str] | None = None,
    length_min: int | None = None,
    length_max: int | None = None,
    source: str | None = None,
    assay_method: str | list[str] | None = None,
    response_measured: str | list[str] | None = None,
    measurement_units: str | list[str] | None = None,
    quantitative_value_max: float | None = None,
    quantitative_value_min: float | None = None,
    has_quantitative_value: bool | None = None,
    exclude_non_peptide_ligand: bool = True,
    columns: list[str] | None = None,
    *,
    exclude_class_label_suspect: bool = False,
    exclude_class_label_implausible: bool = False,
    source_species: str | list[str] | None = None,
    host_species: str | list[str] | None = None,
    exclude_chimeric: bool = False,
) -> pd.DataFrame:
    """Load the binding-assay index with optional filters.

    Returns binding-assay rows (peptide microarray, refolding, MEDi,
    and quantitative-tier measurements).  No sample-metadata join is
    performed — binding assays do not carry MS sample context
    (instrument, acquisition mode, tissue), so the row schema is the
    raw binding index plus gene annotations.

    Filters parallel :func:`generate_observations_table` but omit the
    MS-only options (``--mono-allelic``, ``--instrument-type``,
    ``--acquisition-mode``) and add quantitative-assay filters:

    Parameters
    ----------
    assay_method
        Filter to one or more IEDB/CEDAR assay methods (e.g.
        ``"purified MHC/direct/fluorescence"``, ``"cellular MHC/direct"``).
        Case-insensitive **substring** match (matches "purified" against
        "purified MHC/direct/fluorescence").
    response_measured
        Filter to one or more IEDB/CEDAR ``Assay | Response measured``
        values.  Case-insensitive **exact** match — unlike
        ``assay_method`` (which is substring), Response-measured values
        are short and standardized so exact matching catches typos.

        The actual IEDB vocabulary as of this build (descending row
        count) is::

            'ligand presentation'                          (MS elution)
            'MHC binding'                                  (broad bucket)
            'qualitative binding'
            'dissociation constant KD (~IC50)'
            'half maximal inhibitory concentration (IC50)'
            'dissociation constant KD (~EC50)'
            'dissociation constant KD'
            'half life'
            'half maximal effective concentration (EC50)'
            '3D structure'
            '50% dissociation temperature'
            'off rate' / 'on rate' / 'association constant KA'

        Inspect ``df['response_measured'].value_counts()`` on a real
        build before relying on a specific string — IEDB curators
        occasionally introduce new values.

        Combine ``response_measured`` with ``assay_method`` and
        ``measurement_units`` to identify a measurement type — e.g.
        ``"half maximal inhibitory concentration (IC50)"`` + ``"nM"``
        is an IC50; ``"dissociation constant KD"`` + ``"nM"`` is a Kd;
        ``"half life"`` + ``"min"`` is t_half; ``"50% dissociation
        temperature"`` + ``"celsius"`` is a Tm.
    measurement_units
        Filter to rows reporting in these units (e.g. ``"nM"``,
        ``"log10(IC50)"``).  Useful before applying a numeric
        threshold because IC50 at ``nM`` and ``log10(nM)`` are not
        directly comparable.
    quantitative_value_min, quantitative_value_max
        Inclusive bounds on ``quantitative_value`` (the float cast of
        IEDB's ``Quantitative measurement`` column).  Rows with NaN are
        excluded when either bound is set.  Pair with
        ``measurement_units`` to avoid mixing unit systems.
    has_quantitative_value
        When True, keep only rows with a non-NaN ``quantitative_value``
        regardless of endpoint or units. When False, keep rows without
        a numeric value. ``None`` leaves the axis unfiltered. Numeric
        presence alone does not identify affinity measurements.
    mhc_allele_in_set
        Filter to rows whose ``mhc_allele_set`` (issue #137 expanded
        candidate-allele set) contains any of the listed alleles.  Use
        this when you want to recover coarse / class-only restrictions
        that the curated PMID pool or donor's MHC types resolve to a
        specific allele of interest, e.g. ``mhc_allele_in_set="HLA-A*02:01"``
        captures both four-digit ``HLA-A*02:01`` rows AND multi-allele
        rows whose donor genotype includes A*02:01.  ``mhc_allele=`` (the
        existing arg) only matches the literal ``mhc_restriction`` value.
    mhc_allele_provenance
        Filter by how a row's allele set was obtained: ``"exact"`` (4-digit
        passthrough), ``"sample_allele_match"`` (donor's MHC Types Present
        carried the typed alleles), ``"pmid_class_pool"`` (fell back to
        per-PMID curated ``hla_alleles``), or ``"unmatched"`` (no
        expansion possible — class-only with no curation, or two-digit /
        serological / unresolved).  Use ``"exact"`` for strict-resolution
        training; use ``["exact", "sample_allele_match"]`` for MIL /
        noisy-OR training where the set is small and trusted.
    restriction_evidence
        Filter independently by how the named restriction was established:
        ``"experimental"``, ``"monoallelic"``, ``"predicted"``, or
        ``"unknown"``.
    serotype_source
        Filter by whether the serotype is primary data (``"reported"``), this
        library's projection of a named molecule (``"derived"``), or a union
        over a donor's typed alleles (``"donor_set"``).
    exclude_class_label_suspect
        Drop rows whose curated MHC class disagrees with the peptide
        length severely enough to be flagged ``suspect`` — the strict
        superset, which includes the ``implausible`` tier.
    exclude_class_label_implausible
        Strict-cleaning variant: drop only the ``implausible`` tier
        (class-I >=18aa or <=7aa, class-II <=4aa or >=45aa), keeping
        borderline and suspect rows.
    """
    from .observations import load_binding

    resolved_gene_names, resolved_gene_ids = _resolve_gene_filters(gene, gene_name, gene_id)

    bind_filters: dict = {
        "source_species": source_species,
        "host_species": host_species,
        "exclude_chimeric": exclude_chimeric,
    }
    if mhc_class:
        bind_filters["mhc_class"] = mhc_class
    if species:
        bind_filters["species"] = normalize_species(species)
    if source:
        bind_filters["source"] = source
    if mhc_allele is not None:
        bind_filters["mhc_restriction"] = mhc_allele
    if mhc_allele_in_set is not None:
        bind_filters["mhc_allele_in_set"] = _to_list(mhc_allele_in_set)
    if mhc_allele_provenance is not None:
        bind_filters["mhc_allele_provenance"] = _to_list(mhc_allele_provenance)
    bind_filters.update(_gene_observation_filters(resolved_gene_names, resolved_gene_ids, peptide))
    if restriction_evidence is not None:
        bind_filters["restriction_evidence"] = restriction_evidence
    if serotype_source is not None:
        bind_filters["serotype_source"] = _to_list(serotype_source)
    if serotype is not None:
        bind_filters["serotype"] = _to_list(serotype)
    if length_min is not None:
        bind_filters["length_min"] = length_min
    if length_max is not None:
        bind_filters["length_max"] = length_max
    # load_binding has supported these all along; generate_binding_table
    # simply never exposed them, so neither it nor generate_training_table
    # could apply a class-label filter to binding evidence.
    if exclude_class_label_suspect:
        bind_filters["exclude_class_label_suspect"] = True
    if exclude_class_label_implausible:
        bind_filters["exclude_class_label_implausible"] = True
    bind_filters["exclude_non_peptide_ligand"] = exclude_non_peptide_ligand

    df = load_binding(**bind_filters)

    if min_allele_resolution:
        from .curation import allele_resolution_rank, classify_allele_resolution

        min_rank = allele_resolution_rank(min_allele_resolution)
        df = df[
            df["mhc_restriction"].map(
                lambda a: allele_resolution_rank(classify_allele_resolution(a)) <= min_rank
            )
        ]

    # Quantitative-assay filters (issue #148, issue #135).  Applied
    # in-memory after the parquet load because these columns are free-text /
    # sparse and don't benefit from pyarrow push-down filters.
    if assay_method is not None and "assay_method" in df.columns:
        wanted = {m.casefold() for m in _to_list(assay_method)}
        method_col = _fillna_scalar_safe(df["assay_method"], "").astype(str).str.casefold()
        df = df[method_col.apply(lambda m: any(w in m for w in wanted))]
    if response_measured is not None and "response_measured" in df.columns:
        wanted_responses = {r.casefold() for r in _to_list(response_measured)}
        response_col = _fillna_scalar_safe(df["response_measured"], "").astype(str).str.casefold()
        df = df[response_col.isin(wanted_responses)]
    if measurement_units is not None and "measurement_units" in df.columns:
        wanted_units = {u.casefold() for u in _to_list(measurement_units)}
        units_col = _fillna_scalar_safe(df["measurement_units"], "").astype(str).str.casefold()
        df = df[units_col.isin(wanted_units)]
    if has_quantitative_value is not None and "quantitative_value" in df.columns:
        if has_quantitative_value:
            df = df[df["quantitative_value"].notna()]
        else:
            df = df[df["quantitative_value"].isna()]
    if quantitative_value_min is not None and "quantitative_value" in df.columns:
        df = df[
            df["quantitative_value"].notna()
            & (df["quantitative_value"] >= float(quantitative_value_min))
        ]
    if quantitative_value_max is not None and "quantitative_value" in df.columns:
        df = df[
            df["quantitative_value"].notna()
            & (df["quantitative_value"] <= float(quantitative_value_max))
        ]

    if columns:
        available = [c for c in columns if c in df.columns]
        df = df[available]

    return df


_SAMPLE_PROVENANCE_COLUMNS = (
    "sample_label",
    "pmid",
    "study_label",
    "mhc_class",
    "condition",
    "perturbation",
    "source",
    "profiled",
    "peptides",
    "n_samples",
    "reference_proteomes",
    "mhc",
    # Species axes (#4 from review).  The anchors variant of the samples
    # export is one CLI flag away from the plain one, so it needs the
    # same flag; without these it silently dropped them.
    "species",
    "mhc_species",
    "species_axes_agreement",
    "condition_category",
    "is_control_arm",
    # The flat condition block (#450), spliced from the registry rather than
    # retyped.  This tuple has already drifted from the plain samples export
    # twice; a hand-copied list of 23 more names would be the third time.
    *CONDITION_COLUMNS,
    *SPECIES_CONTEXT_COLUMNS,
    # Curated provenance (#373).  Omitting these is how one CLI flag used to
    # change which curation a user got back; the comment above says exactly
    # that about the species axes, and the same drift recurred here.
    "note",
    "classification",
    "reason",
    "sample_group",
    "arm_resolution",
    "sample_override",
    "effective_override",
    "effective_override_origin",
)


@dataset_snapshot()
def generate_sample_expression_table(
    mhc_class: str | None = None,
    cancer_type_backend=None,
) -> pd.DataFrame:
    """Per-sample expression-anchor resolution table.

    Carries the sample-provenance columns listed in
    :data:`_SAMPLE_PROVENANCE_COLUMNS` (issue #149) so a single export
    captures sample identity + acquisition context + expression anchor
    in one row.  That is a curated subset of
    :func:`generate_ms_samples_table`, not every column of it — the
    acquisition and APM blocks are deliberately omitted.  Resolves an expression anchor for every sample via
    :func:`hitlist.line_expression.resolve_sample_expression_anchor`
    and emits the flat provenance record downstream callers need to
    distinguish "exact JY RNA" from "generic EBV-LCL stand-in" from
    "melanoma cohort surrogate" (issue #140).

    Parameters
    ----------
    mhc_class
        Forwarded to :func:`generate_ms_samples_table`.
    cancer_type_backend
        Optional callable for tier-4 cancer-type fallback (pirlygenes).

    Returns
    -------
    pd.DataFrame
        One row per sample carrying: every column of
        :func:`generate_ms_samples_table` plus
        ``expression_backend``, ``expression_key``,
        ``expression_match_tier``, ``expression_parent_key``,
        ``expression_source_ids`` (semicolon-joined), ``expression_reason``,
        ``expression_matched_alias``.
    """
    from .line_expression import resolve_sample_expression_anchor

    samples = generate_ms_samples_table(mhc_class=mhc_class)
    expression_cols = [
        "expression_backend",
        "expression_key",
        "expression_match_tier",
        "expression_parent_key",
        "expression_source_ids",
        "expression_reason",
        "expression_matched_alias",
    ]
    if samples.empty:
        return pd.DataFrame(columns=[*_SAMPLE_PROVENANCE_COLUMNS, *expression_cols])

    # Curated engineering decides tier 1 vs tier 2, so it is read from the
    # arm's own condition block rather than guessed from its label (#576).
    engineered = engineered_material_mask(samples)
    rows: list[dict] = []
    for position, (_, s) in enumerate(samples.iterrows()):
        anchor = resolve_sample_expression_anchor(
            str(s.get("sample_label") or ""),
            pmid=int(s["pmid"]) if pd.notna(s.get("pmid")) else None,
            study_label=str(s.get("study_label") or "") or None,
            engineered=bool(engineered.iat[position]),
            cancer_type_backend=cancer_type_backend,
        )
        # Carry the full sample-provenance row through, plus the resolved
        # anchor columns.  pmid stays nullable Int64 at the end.
        row = {col: s.get(col, "") for col in _SAMPLE_PROVENANCE_COLUMNS}
        row["pmid"] = int(s["pmid"]) if pd.notna(s.get("pmid")) else pd.NA
        row.update(
            expression_backend=anchor.expression_backend,
            expression_key=anchor.expression_key,
            expression_match_tier=anchor.expression_match_tier,
            expression_parent_key=anchor.expression_parent_key or "",
            expression_source_ids=";".join(anchor.source_ids),
            expression_reason=anchor.reason,
            expression_matched_alias=anchor.matched_alias or "",
        )
        rows.append(row)
    result = pd.DataFrame(rows)
    result["pmid"] = result["pmid"].astype("Int64")
    return result


_PEPTIDE_ORIGIN_COLUMNS = (
    "peptide_origin_gene",
    "peptide_origin_gene_id",
    "peptide_origin_tpm",
    "peptide_origin_log2_tpm",
    "peptide_origin_dominant_transcript",
    "peptide_origin_n_supporting_transcripts",
    "peptide_origin_resolution",
)

_EXPRESSION_ANCHOR_COLUMNS = (
    "expression_backend",
    "expression_key",
    "expression_match_tier",
    "expression_parent_key",
)

#: Grouping/merge key that carries curated engineering into the resolver
#: inside :func:`_attach_peptide_origin`.  Deleted right after the anchor
#: merge: the fact it encodes reaches consumers as ``expression_match_tier``
#: 2 plus ``expression_parent_key``, which is the provenance contract
#: (#140/#576).
_ENGINEERED_MATERIAL_COLUMN = "_expression_engineered_material"


def _build_transcript_lookup(gene_names: set[str], release: int):
    """Return a ``gene_name -> [(transcript_id, protein_seq)]`` closure.

    Built from the same conventional + IG/TR translated-biotype policy as
    :meth:`hitlist.proteome.ProteomeIndex.from_ensembl`, so peptide-origin
    scoring cannot lose a receptor mapping that exists in the sidecar.
    Returns ``None`` if pyensembl is unavailable (the caller then falls back
    to the gene-only origin path).
    """
    try:
        from pyensembl import EnsemblRelease
    except Exception:
        return None

    try:
        ensembl = EnsemblRelease(release)
    except Exception:
        return None

    from .proteome import ENSEMBL_CODING_GENE_BIOTYPES

    coding_biotypes = set(ENSEMBL_CODING_GENE_BIOTYPES)

    cache: dict[str, list[tuple[str, str]]] = {}

    def _lookup(gene_name: str) -> list[tuple[str, str]]:
        if gene_name in cache:
            return cache[gene_name]
        records: list[tuple[str, str]] = []
        try:
            genes = ensembl.genes_by_name(gene_name)
        except Exception:
            cache[gene_name] = records
            return records
        for gene in genes:
            for t in gene.transcripts:
                if getattr(t, "biotype", "") not in coding_biotypes:
                    continue
                try:
                    seq = t.protein_sequence
                except Exception:
                    seq = None
                if not seq:
                    continue
                records.append((str(t.id), str(seq)))
        cache[gene_name] = records
        return records

    # Warm the cache lazily on first access; no eager population.
    _ = gene_names  # accepted for signature symmetry; used for future prefetch
    return _lookup


def _attach_peptide_origin(
    df: pd.DataFrame,
    cancer_type_backend=None,
    proteome_release: int = 112,
) -> pd.DataFrame:
    """Add per-(peptide, sample) expression anchor + peptide_origin columns."""
    from .line_expression import (
        compute_peptide_origin,
        load_line_expression,
        resolve_sample_expression_anchor,
    )
    from .mappings import load_peptide_mappings

    if df.empty or "peptide" not in df.columns:
        for col in (*_EXPRESSION_ANCHOR_COLUMNS, *_PEPTIDE_ORIGIN_COLUMNS):
            if col not in df.columns:
                df[col] = pd.NA
        return df

    # ------------------------------------------------------------------
    # 1. Resolve the anchor once per unique (sample_label, pmid).
    #
    # Issue #149: pass row-level ``cell_name`` and ``source_tissue`` (when
    # the observations parquet carries them) into the resolver so labels
    # like a bare "JY" with cell_name="EBV-LCL JY" or "tumor biopsy" with
    # source_tissue="lung" can resolve through the anchor registry instead
    # of falling straight to tier 6.  Both fields are optional.
    # ------------------------------------------------------------------
    sample_cols = [c for c in ("sample_label", "pmid", "study_label") if c in df.columns]
    if not sample_cols:
        for col in (*_EXPRESSION_ANCHOR_COLUMNS, *_PEPTIDE_ORIGIN_COLUMNS):
            df[col] = pd.NA
        return df
    extra_resolver_cols = [c for c in ("cell_name", "source_tissue") if c in df.columns]
    df = df.copy()
    # Curated engineering decides tier 1 vs tier 2 (#576), and it joins the
    # grouping key rather than being read once per sample: two rows can share
    # a ``sample_label`` and ``pmid`` while disagreeing about the arm, so the
    # honest anchor differs between them.  A row whose block says engineered
    # is engineered.  Otherwise the resolver asks curation (``engineered=None``)
    # rather than trusting a blank block: a row that reached no arm carries
    # ``_consensus_meta``'s blanked block, which in a study with engineered
    # arms (HAP1's wild type + 11 knockouts) means "unknown", not "wild type".
    df[_ENGINEERED_MATERIAL_COLUMN] = engineered_material_mask(df)
    grouping_cols = [*sample_cols, *extra_resolver_cols, _ENGINEERED_MATERIAL_COLUMN]
    unique_samples = df[grouping_cols].drop_duplicates().reset_index(drop=True)
    anchor_records: list[dict] = []
    for _, s in unique_samples.iterrows():
        anchor = resolve_sample_expression_anchor(
            str(s.get("sample_label") or ""),
            cell_name=str(s.get("cell_name") or "") or None,
            pmid=int(s["pmid"]) if "pmid" in s and pd.notna(s.get("pmid")) else None,
            study_label=str(s.get("study_label") or "") or None,
            engineered=True if s[_ENGINEERED_MATERIAL_COLUMN] else None,
            lineage_tissue=str(s.get("source_tissue") or "") or None,
            cancer_type_backend=cancer_type_backend,
        )
        rec = {c: s.get(c, "") for c in grouping_cols}
        rec.update(
            expression_backend=anchor.expression_backend,
            expression_key=anchor.expression_key,
            expression_match_tier=anchor.expression_match_tier,
            expression_parent_key=anchor.expression_parent_key or "",
        )
        anchor_records.append(rec)
    anchor_df = pd.DataFrame(anchor_records)
    if "pmid" in anchor_df.columns:
        anchor_df["pmid"] = anchor_df["pmid"].astype("Int64")

    if "pmid" in df.columns:
        df["pmid"] = df["pmid"].astype("Int64")
    df = df.merge(anchor_df, on=grouping_cols, how="left")
    # The flag has done its job once it is in the anchor; deleting the column
    # in place avoids a full-frame copy on a multi-million-row export.
    del df[_ENGINEERED_MATERIAL_COLUMN]

    # ------------------------------------------------------------------
    # 2. Preload TPM tables for every distinct line_key.
    # ------------------------------------------------------------------
    line_keys = sorted({str(k) for k in df["expression_key"].dropna().unique() if str(k)})
    tpm_by_line: dict[str, pd.DataFrame] = {}
    for lk in line_keys:
        sub = load_line_expression(line_key=lk)
        tpm_by_line[lk] = sub

    # ------------------------------------------------------------------
    # 3. Load mappings for every peptide we need to score (once).
    # ------------------------------------------------------------------
    wanted_peptides = sorted({str(p) for p in df["peptide"].dropna().unique() if str(p)})
    if wanted_peptides:
        mappings = load_peptide_mappings(
            peptide=wanted_peptides,
            columns=["peptide", "gene_name", "gene_id", "protein_id"],
        )
    else:
        mappings = pd.DataFrame(columns=["peptide", "gene_name", "gene_id", "protein_id"])
    candidates_by_peptide: dict[str, list[dict]] = {}
    if not mappings.empty:
        for pep, group in mappings.groupby("peptide"):
            unique_rows = group[["gene_name", "gene_id"]].drop_duplicates()
            candidates_by_peptide[str(pep)] = [
                {
                    "gene_name": str(r.get("gene_name") or ""),
                    "gene_id": str(r.get("gene_id") or ""),
                }
                for _, r in unique_rows.iterrows()
                if r.get("gene_name")
            ]

    # ------------------------------------------------------------------
    # 4. Set up an optional transcript lookup once.
    # ------------------------------------------------------------------
    has_any_transcript = any(
        (not t.empty) and "granularity" in t.columns and (t["granularity"] == "transcript").any()
        for t in tpm_by_line.values()
    )
    transcript_lookup = None
    if has_any_transcript:
        gene_universe: set[str] = set()
        for cands in candidates_by_peptide.values():
            for c in cands:
                if c["gene_name"]:
                    gene_universe.add(c["gene_name"])
        transcript_lookup = _build_transcript_lookup(gene_universe, proteome_release)

    # ------------------------------------------------------------------
    # 5. Compute peptide-origin per UNIQUE (peptide, expression_key) pair,
    #    then merge the small result table back onto the full frame.
    #    This keeps the per-row cost in pandas merge rather than a Python
    #    iterrows loop — ~N-unique-pairs work instead of ~N-rows.
    # ------------------------------------------------------------------
    # Normalize the merge-key dtypes on ``df`` up front so ``unique_pairs``
    # is derived from already-stringified columns (no double-cast).
    df["peptide"] = df["peptide"].astype(str).fillna("")
    df["expression_key"] = df["expression_key"].astype(str).fillna("")
    unique_pairs = df[["peptide", "expression_key"]].drop_duplicates().reset_index(drop=True)

    empty_origin = {
        "peptide_origin_gene": "",
        "peptide_origin_gene_id": "",
        "peptide_origin_tpm": float("nan"),
        "peptide_origin_log2_tpm": float("nan"),
        "peptide_origin_dominant_transcript": "",
        "peptide_origin_n_supporting_transcripts": 0,
        "peptide_origin_resolution": "no_anchor",
    }

    origin_rows: list[dict] = []
    # ``itertuples`` avoids the iterrows FutureWarning in recent pandas
    # and is ~5x faster on the small unique-pair frame.
    for pair in unique_pairs.itertuples(index=False):
        peptide = pair.peptide
        line_key = pair.expression_key
        if not line_key or line_key not in tpm_by_line or tpm_by_line[line_key].empty:
            scored = dict(empty_origin)
        else:
            scored = compute_peptide_origin(
                peptide=peptide,
                candidate_genes=candidates_by_peptide.get(peptide, []),
                line_expression_df=tpm_by_line[line_key],
                transcript_lookup=transcript_lookup,
            )
        origin_rows.append({"peptide": peptide, "expression_key": line_key, **scored})

    origin_df = pd.DataFrame(
        origin_rows, columns=["peptide", "expression_key", *_PEPTIDE_ORIGIN_COLUMNS]
    )

    df = df.merge(origin_df, on=["peptide", "expression_key"], how="left")

    # Fill the fallback for any (peptide, key) the merge didn't cover
    # — shouldn't happen in practice, but keeps the contract stable.
    for col, default in empty_origin.items():
        if col in df.columns:
            if isinstance(default, str):
                df[col] = df[col].fillna(default)
            elif isinstance(default, float):
                df[col] = df[col].astype(float)
            elif isinstance(default, int):
                df[col] = df[col].fillna(default).astype(int)

    return df


def _attributed_training_ids(df: pd.DataFrame, source_ids: list[str]) -> list[str]:
    """Distinguish explicit source attributions without inferring specimen identity.

    Resolve against the original label, not the export's heuristic/pool metadata.
    The full curation lookup makes keys independent of filters and row order.
    """
    ids = source_ids.copy()
    if "attributed_sample_label" not in df.columns:
        return ids
    labels = df["attributed_sample_label"].astype("string").fillna("")
    positions = np.flatnonzero(labels.str.strip().ne("").to_numpy(dtype=bool))
    if not len(positions):
        return ids

    arms = {}
    for pmid, entry in load_pmid_overrides().items():
        for sample in entry.get("ms_samples", []):
            label = str(sample.get("sample_label") or "").strip()
            key = (str(pmid), label)
            # A repeated label is ambiguous even if one entry has no arm ID.
            arms[key] = "" if key in arms else str(sample.get("condition_id") or "").strip()

    pmids = (
        pd.to_numeric(df["pmid"].iloc[positions], errors="coerce")
        .astype("Int64")
        .astype("string")
        .fillna("")
        if "pmid" in df.columns
        else [""] * len(positions)
    )
    for position, pmid, label in zip(positions, pmids, labels.iloc[positions]):
        arm = arms.get((pmid, label.strip()), "")
        basis, value = ("arm", arm) if arm else ("label", label)
        kind, locator = source_ids[position].split(":", 1)
        # Escape the separators (and literal percent signs) while keeping a
        # source URL readable. This is a compound key, not a content digest.
        ids[position] = (
            f"{kind}:attributed:v1:{quote(locator, safe=':/')}"
            f"|{basis}:{pmid}:{quote(value, safe='')}"
        )
    return ids


def _apply_training_defaults(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize the mixed MS/binding export schema."""
    from .observations import _source_organism_with_fallback

    result = df.copy()

    if "provenance_id" not in result:
        result["provenance_id"] = ""
    result["provenance_id"] = result["provenance_id"].astype("string").fillna("")
    result["provenance_status"] = result["provenance_id"].map(
        lambda value: "indexed" if value else "legacy_missing"
    )

    if "sample_mhc" not in result.columns and "mhc" in result.columns:
        result = result.rename(columns={"mhc": "sample_mhc", "note": "sample_note"})

    for col, default in _TRAINING_DEFAULTS.items():
        if col not in result.columns:
            result[col] = default
            continue
        if isinstance(default, str):
            # Categorical-safe: #263 makes several of these columns
            # category dtype, and a sentinel default like "not_applicable"
            # is an out-of-category value.
            result[col] = _fillna_scalar_safe(result[col], default)
        elif isinstance(default, bool):
            result[col] = result[col].astype("boolean").fillna(default).astype(bool)
        else:
            result[col] = result[col].fillna(default)

    if "mhc_restriction" in result.columns:
        result["has_peptide_level_allele"] = _compute_has_peptide_level_allele(
            result["mhc_restriction"],
            result["allele_resolution"] if "allele_resolution" in result.columns else None,
        )
    elif "has_peptide_level_allele" not in result.columns:
        result["has_peptide_level_allele"] = False

    source_organism = _source_organism_with_fallback(result)
    if "mhc_species" in result.columns:
        result["is_chimeric"] = _compute_is_chimeric(source_organism, result["mhc_species"])
    elif "is_chimeric" not in result.columns:
        result["is_chimeric"] = False

    if "mhc_species" in result.columns and "host" in result.columns:
        result["is_engineered_mhc"] = _compute_is_engineered_mhc(
            source_organism, result["mhc_species"], result["host"]
        )
    elif "is_engineered_mhc" not in result.columns:
        result["is_engineered_mhc"] = False

    # Derive ``is_non_peptide_ligand`` from ``mhc_restriction`` (#228).  Both
    # observations.parquet and binding.parquet carry this column post-#228,
    # and :func:`_load_peptide_index` already materializes it at load time;
    # this third derivation is the deliberate safety net for mixed exports
    # (MS + binding concat) and for any caller that hands us a frame
    # assembled outside the loader path. All three sites share the same
    # ``is_non_peptide_ligand`` helper, so the result is invariant — see
    # the load-time comment in ``observations.py`` for the full rationale.
    if "mhc_restriction" in result.columns:
        from .curation import is_non_peptide_ligand

        uniq = result["mhc_restriction"].dropna().unique()
        if len(uniq):
            flag_map = {str(a): is_non_peptide_ligand(a) for a in uniq}
            result["is_non_peptide_ligand"] = (
                result["mhc_restriction"].map(flag_map).astype("boolean").fillna(False).astype(bool)
            )
        else:
            result["is_non_peptide_ligand"] = False
    elif "is_non_peptide_ligand" not in result.columns:
        result["is_non_peptide_ligand"] = False

    result["matched_sample_count"] = result["matched_sample_count"].astype(int)
    result["has_peptide_level_allele"] = result["has_peptide_level_allele"].astype(bool)
    result["is_chimeric"] = result["is_chimeric"].astype(bool)
    result["is_engineered_mhc"] = result["is_engineered_mhc"].astype(bool)
    result["is_non_peptide_ligand"] = result["is_non_peptide_ligand"].astype(bool)

    # Common source identifier. Prefer ``assay_iri`` (assay-level, from
    # IEDB/CEDAR's "Assay IRI" column or the synthesized supplement string
    # — shared by per-donor observations), then fall back to ``reference_iri``
    # (study-level for IEDB/CEDAR) for older parquets that predate #146,
    # and finally to a positional ``row:{idx}`` sentinel for rows missing
    # both identifiers.  See issue #146.
    assay_series = (
        result["assay_iri"].astype("string").fillna("")
        if "assay_iri" in result.columns
        else pd.Series([""] * len(result), index=result.index)
    )
    ref_series = (
        result["reference_iri"].astype("string").fillna("")
        if "reference_iri" in result.columns
        else pd.Series([""] * len(result), index=result.index)
    )
    if "evidence_kind" in result.columns:
        evidence_kind = result["evidence_kind"].astype("string").fillna("")
        ids: list[str] = []
        for idx, (kind, assay, ref) in enumerate(zip(evidence_kind, assay_series, ref_series)):
            if assay.strip():
                ids.append(f"{kind}:{assay}")
            elif ref.strip():
                ids.append(f"{kind}:{ref}")
            else:
                ids.append(f"{kind}:row:{idx}")
        result["evidence_source_id"] = ids
        result["evidence_row_id"] = _attributed_training_ids(result, ids)

    return result


def _load_gene_union_mappings(
    *,
    gene_name: list[str] | None = None,
    gene_id: list[str] | None = None,
    peptide: list[str] | None = None,
    columns: list[str] | None = None,
) -> pd.DataFrame:
    """Select mapping rows matching either gene identifier axis (#425).

    The low-level loader intentionally ANDs separately supplied column
    filters. An export's gene query instead names alternatives, so mixed
    symbols/IDs need a union. Deduplicate rows that match both identifiers.
    """
    from .mappings import load_peptide_mappings

    if not (gene_name and gene_id):
        return load_peptide_mappings(
            gene_name=gene_name, gene_id=gene_id, peptide=peptide, columns=columns
        )
    by_name = load_peptide_mappings(gene_name=gene_name, peptide=peptide, columns=columns)
    by_id = load_peptide_mappings(gene_id=gene_id, peptide=peptide, columns=columns)
    return pd.concat([by_name, by_id], ignore_index=True).drop_duplicates(ignore_index=True)


def _gene_observation_filters(
    gene_names: set[str], gene_ids: set[str], peptide: str | list[str] | None
) -> dict:
    """Translate the export's gene alternatives to a loader-safe peptide filter."""
    filters: dict = {}
    if gene_names and gene_ids:
        mappings = _load_gene_union_mappings(
            gene_name=sorted(gene_names), gene_id=sorted(gene_ids), columns=["peptide"]
        )
        matches = set(mappings["peptide"].dropna())
        if peptide is not None:
            matches.intersection_update(_to_list(peptide))
        filters["peptide"] = sorted(matches)
    else:
        if gene_names:
            filters["gene_name"] = sorted(gene_names)
        if gene_ids:
            filters["gene_id"] = sorted(gene_ids)
        if peptide is not None:
            filters["peptide"] = peptide
    return filters


def _load_training_mappings_for_peptides(
    peptides: pd.Series | list[str],
    gene_name: list[str] | None = None,
    gene_id: list[str] | None = None,
) -> pd.DataFrame:
    """Load long-form mappings for a selected peptide set.

    Small peptide subsets use parquet push-down filters. Large exports fall
    back to a full mappings scan plus an in-memory peptide filter to avoid
    constructing a huge ``IN (...)`` predicate for pyarrow.
    """
    wanted = sorted({str(p).strip() for p in peptides if str(p).strip()})
    columns = ["peptide", *_TRAINING_MAPPING_COLUMNS]
    if not wanted:
        return pd.DataFrame(columns=columns)

    filter_kwargs = {}
    if gene_name:
        filter_kwargs["gene_name"] = gene_name
    if gene_id:
        filter_kwargs["gene_id"] = gene_id

    if len(wanted) <= 10_000:
        return _load_gene_union_mappings(peptide=wanted, columns=columns, **filter_kwargs)

    mappings = _load_gene_union_mappings(columns=columns, **filter_kwargs)
    return mappings[mappings["peptide"].isin(set(wanted))]


def _project_training_columns(df: pd.DataFrame, columns: list[str] | None) -> pd.DataFrame:
    """Project the training export, always preserving evidence identity."""
    if columns is None:
        return df
    identity_cols = ["evidence_kind"]
    identity_cols.extend(
        c
        for c in (
            "evidence_row_id",
            "evidence_source_id",
            "provenance_id",
            "provenance_status",
            "lineage_context_id",
        )
        if c in df.columns
    )
    requested = list(dict.fromkeys([*columns, *identity_cols]))
    available = [c for c in requested if c in df.columns]
    return df[available]


@dataset_snapshot()
def generate_training_table(
    include_evidence: str = "both",
    mhc_class: str | None = None,
    species: str | None = None,
    source: str | None = None,
    instrument_type: str | None = None,
    acquisition_mode: str | None = None,
    is_mono_allelic: bool | None = None,
    min_allele_resolution: str | None = None,
    mhc_allele: str | list[str] | None = None,
    mhc_allele_in_set: str | list[str] | None = None,
    mhc_allele_provenance: str | list[str] | None = None,
    restriction_evidence: str | list[str] | None = None,
    serotype_source: str | list[str] | None = None,
    gene: str | list[str] | None = None,
    gene_name: str | list[str] | None = None,
    gene_id: str | list[str] | None = None,
    peptide: str | list[str] | None = None,
    serotype: str | list[str] | None = None,
    length_min: int | None = None,
    length_max: int | None = None,
    map_source_proteins: bool = False,
    with_peptide_origin: bool = False,
    cancer_type_backend=None,
    proteome_release: int = 112,
    columns: list[str] | None = None,
    explode_mappings: bool | None = None,
    *,
    assay_method: str | list[str] | None = None,
    response_measured: str | list[str] | None = None,
    measurement_units: str | list[str] | None = None,
    has_quantitative_value: bool | None = None,
    quantitative_value_min: float | None = None,
    quantitative_value_max: float | None = None,
    exclude_class_label_suspect: bool = False,
    exclude_class_label_implausible: bool = False,
    exclude_non_peptide_ligand: bool = True,
    source_species: str | list[str] | None = None,
    host_species: str | list[str] | None = None,
    exclude_chimeric: bool = False,
) -> pd.DataFrame:
    """Export a unified pMHC training table.

    The canonical stored indexes remain unchanged:

    - ``observations.parquet``: MS/elution observations
    - ``binding.parquet``: in-vitro binding evidence
    - ``peptide_mappings.parquet``: long-form peptide→protein mappings

    This function composes those indexes into one downstream-facing export.
    Compact mode preserves one row per evidence row. ``map_source_proteins=True``
    expands the export to one row per ``(evidence row, source-protein mapping)``,
    adding ``protein_id`` / ``gene_name`` / ``gene_id`` / ``gene_biotype`` /
    ``transcript_id`` / ``position`` / ``n_flank`` / ``c_flank`` from
    ``peptide_mappings.parquet``.
    Suitable for flank-aware model pipelines such as Presto.

    ``evidence_row_id`` distinguishes explicit per-donor/sample attributions
    on a shared assay. Attributed IDs use a versioned compound key of the source ID
    and persistent curated arm (PMID + condition_id), or the original label
    scoped to its PMID when no unique curated arm is available. Rows without
    explicit attribution retain their pre-1.63.18 IDs. ``evidence_source_id``
    retains the common, pre-1.63.18 source ID for all rows. Both IDs and
    ``evidence_kind`` survive ``columns`` projection; mapping alternatives
    share them. Neither key establishes specimen identity or independence.
    Legacy indexes without assay IRIs retain reference/positional fallbacks,
    which cannot guarantee unique, filter-stable observation identity.

    .. deprecated:: 1.24.1
       The ``explode_mappings`` kwarg is the previous name for
       ``map_source_proteins`` and emits a ``DeprecationWarning``.  Will
       be removed in 2.0.

    When ``with_peptide_origin=True`` every MS row is additionally
    enriched with a per-sample expression anchor and a peptide-origin
    call (the most-likely source gene, its TPM, and the transcript that
    dominates when the backend is transcript-level).  Provenance columns
    (``expression_backend``, ``expression_key``, ``expression_match_tier``,
    ``expression_parent_key``) are preserved so consumers can distinguish
    exact-line evidence from class / tissue / cancer-type surrogates —
    see issue pirl-unc/hitlist#140.

    .. note::
       Transcript-isoform-aware scoring needs pyensembl translations.
       When transcript-level TPM is present for any resolved sample,
       :func:`_build_transcript_lookup` instantiates ``EnsemblRelease``,
       which will trigger a pyensembl cache download (~GB) on first use
       if the requested ``proteome_release`` has not already been
       materialized. Set ``proteome_release`` to a release you have
       already built observations against to avoid a surprise download.

    Parameters
    ----------
    assay_method, response_measured, measurement_units
        Binding-only filters, with the matching semantics of
        :func:`generate_binding_table`: case-insensitive substring for
        methods, case-insensitive exact membership for endpoints and units.
        In ``both`` mode they leave the MS branch unchanged; in ``ms``
        mode they have no effect. Measurement fields and inequality
        qualifiers are preserved unless explicitly omitted by ``columns``.
    has_quantitative_value
        Binding-only numeric-presence filter: True keeps non-null values,
        False keeps missing values, and None leaves the axis unfiltered.
        A numeric value alone does not identify an affinity measurement;
        select an explicit endpoint allowlist and units as well.
    quantitative_value_min, quantitative_value_max
        Binding-only inclusive bounds on the reported numeric value.
        Missing values are excluded. Bounds do not interpret inequality
        qualifiers or convert units; a reported ``>5000`` remains a
        censored bound, not an exact value of 5000.
    exclude_class_label_suspect
        Drop rows whose curated MHC class disagrees with the peptide
        length severely enough to be flagged ``suspect`` — the strict
        superset, which includes the ``implausible`` tier.
    exclude_class_label_implausible
        Strict-cleaning variant: drop only the ``implausible`` tier
        (class-I >=18aa or <=7aa, class-II <=4aa or >=45aa), keeping
        borderline and suspect rows.
    exclude_non_peptide_ligand
        Exclude CD1 / MR1 / MIC rows whose "peptide" is a chemical name
        rather than a sequence.  Defaults to True.

    All other filter parameters are forwarded unchanged to
    :func:`generate_observations_table` and :func:`generate_binding_table`;
    see those for their meaning.
    """
    if explode_mappings is not None:
        import warnings

        warnings.warn(
            "explode_mappings= is deprecated; use map_source_proteins= instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        map_source_proteins = bool(explode_mappings) or map_source_proteins

    mode = include_evidence.strip().lower()
    if mode not in {"ms", "binding", "both"}:
        raise ValueError("include_evidence must be one of: ms, binding, both")

    resolved_gene_names, resolved_gene_ids = _resolve_gene_filters(gene, gene_name, gene_id)

    shared_kwargs = {
        "mhc_class": mhc_class,
        "species": species,
        "source_species": source_species,
        "host_species": host_species,
        "exclude_chimeric": exclude_chimeric,
        "source": source,
        "min_allele_resolution": min_allele_resolution,
        "mhc_allele": mhc_allele,
        "mhc_allele_in_set": mhc_allele_in_set,
        "mhc_allele_provenance": mhc_allele_provenance,
        "restriction_evidence": restriction_evidence,
        "serotype_source": serotype_source,
        "gene": gene,
        "gene_name": gene_name,
        "gene_id": gene_id,
        "peptide": peptide,
        "serotype": serotype,
        "length_min": length_min,
        "length_max": length_max,
        # Both evidence paths support these; generate_training_table
        # simply never forwarded them, so a caller could not exclude
        # suspect class labels or non-peptide ligands from a training
        # export at all.  Found by the signature-parity test.
        "exclude_class_label_suspect": exclude_class_label_suspect,
        "exclude_class_label_implausible": exclude_class_label_implausible,
        "exclude_non_peptide_ligand": exclude_non_peptide_ligand,
    }

    parts: list[pd.DataFrame] = []

    if mode in {"ms", "both"}:
        ms = generate_observations_table(
            instrument_type=instrument_type,
            acquisition_mode=acquisition_mode,
            is_mono_allelic=is_mono_allelic,
            **shared_kwargs,
        ).copy()
        ms["evidence_kind"] = "ms"
        parts.append(ms)

    if mode in {"binding", "both"}:
        # No defensive .copy() here — generate_binding_table returns a
        # fresh frame already, and on the 5.3M-row training export the
        # extra copy is unnecessary churn. The earlier ms.copy() above
        # is kept since generate_observations_table can return a view
        # of obs from upstream filter chains.
        binding = generate_binding_table(
            assay_method=assay_method,
            response_measured=response_measured,
            measurement_units=measurement_units,
            has_quantitative_value=has_quantitative_value,
            quantitative_value_min=quantitative_value_min,
            quantitative_value_max=quantitative_value_max,
            **shared_kwargs,
        )
        binding["evidence_kind"] = "binding"
        parts.append(binding)

    if not parts:
        result = pd.DataFrame({"evidence_kind": pd.Series(dtype=str)})
    else:
        result = pd.concat(parts, ignore_index=True, sort=False)

    result = _apply_training_defaults(result)
    if result["provenance_id"].ne("").any():
        from .provenance import _contributor_contract

        if _contributor_contract() is None:
            raise ValueError("Provenance metadata missing; rebuild observations")
    from .lineage import attach_lineage

    result = attach_lineage(result, copy=False)

    if map_source_proteins:
        mappings = _load_training_mappings_for_peptides(
            result.get("peptide", pd.Series(dtype=str)),
            gene_name=sorted(resolved_gene_names) or None,
            gene_id=sorted(resolved_gene_ids) or None,
        )
        if mappings.empty:
            for col in _TRAINING_MAPPING_COLUMNS:
                if col not in result.columns:
                    result[col] = pd.Series(dtype=object)
        else:
            result = result.merge(mappings, on="peptide", how="left")

    if with_peptide_origin:
        result = _attach_peptide_origin(
            result,
            cancer_type_backend=cancer_type_backend,
            proteome_release=proteome_release,
        )

    return _project_training_columns(result, columns)


def _to_list(v) -> list[str]:
    """Accept a string or list; split commas in any element so all three
    CLI input shapes flatten to the same flat list:

    - repeated flags:        --gene NRAS --gene KRAS         -> ["NRAS", "KRAS"]
    - space-separated:       --gene NRAS KRAS                -> ["NRAS", "KRAS"]
    - comma-separated:       --gene NRAS,KRAS                -> ["NRAS", "KRAS"]
    - mixed:                 --gene "NRAS,KRAS" HRAS         -> ["NRAS", "KRAS", "HRAS"]
    """
    if isinstance(v, str):
        return [s.strip() for s in v.split(",") if s.strip()]
    out: list[str] = []
    for elem in v:
        if elem is None:
            continue
        if isinstance(elem, str):
            for s in elem.split(","):
                s = s.strip()
                if s:
                    out.append(s)
        elif elem:
            out.append(elem)
    return out


def _resolve_gene_filters(
    gene: str | list[str] | None,
    gene_name: str | list[str] | None,
    gene_id: str | list[str] | None,
) -> tuple[set[str], set[str]]:
    """Resolve user gene filters into exact gene_name / gene_id sets."""
    resolved_gene_names: set[str] = set()
    resolved_gene_ids: set[str] = set()
    if gene is not None:
        from .genes import resolve_gene_query

        for q in _to_list(gene):
            spec = resolve_gene_query(q)
            resolved_gene_names |= spec["names"]
            resolved_gene_ids |= spec["ids"]
    if gene_name is not None:
        resolved_gene_names |= set(_to_list(gene_name))
    if gene_id is not None:
        resolved_gene_ids |= set(_to_list(gene_id))
    return resolved_gene_names, resolved_gene_ids


def _compute_has_peptide_level_allele(
    mhc_restriction: pd.Series,
    allele_resolution: pd.Series | None = None,
) -> pd.Series:
    """True when a row carries peptide-level allele evidence.

    Class-only sentinels and serological restrictions are not allele-level.
    When resolution metadata is present, it overrides the looser string
    heuristic so downstream exports can trust the flag.

    Across the full observations index ``mhc_restriction`` has hundreds of
    unique values out of millions of rows — computing the string
    predicates on the unique set and ``map``-ing them back is ~8x faster
    than running the chained ``.str`` ops over every row directly.
    """
    uniq = pd.Series(mhc_restriction.dropna().unique())
    if uniq.empty:
        per_unique = pd.Series(dtype=bool)
    else:
        stripped = uniq.astype(str).str.strip()
        per_unique = (
            stripped.ne("")
            & ~stripped.str.lower().str.startswith(("hla class", "mhc class"))
            & stripped.str.contains(r"\*", regex=True)
        )
        per_unique.index = uniq
    result = mhc_restriction.map(per_unique).astype("boolean").fillna(False).astype(bool)
    if allele_resolution is not None:
        # ``allele_resolution`` is a small categorical (~5 values), so the
        # full-series ``isin`` is already cheap — skip the unique-map dance.
        # Note: post-v1.30.44, ``_compress_categoricals`` pre-adds ``""`` to
        # every compressed column's categories so this ``fillna("")`` works
        # against the categorical without an out-of-category TypeError.
        result = result & ~_fillna_scalar_safe(allele_resolution, "").isin(
            {"class_only", "serological"}
        )
    return result.astype(bool)


def _compute_is_chimeric(
    source_organism: pd.Series,
    mhc_species: pd.Series,
) -> pd.Series:
    """True when source proteome and MHC come from different vertebrate genera.

    Engineered cross-species systems (HLA-Tg rats, humanized mice, allogeneic
    transduction, NetH2pan-style training data) decouple the proteome species
    from the MHC species. Pathogen-on-host (viral / bacterial peptide on
    human MHC) is ordinary infection biology and is NOT flagged. See
    :func:`hitlist.curation.is_chimeric_system` for the full rule.

    The (source_organism, mhc_species) pair has only a couple hundred unique
    values over millions of rows. We evaluate the per-pair classifier once
    on the unique pairs and broadcast back via ``MultiIndex.reindex`` —
    a C-level lookup that avoids materializing 4.4M Python tuples.
    """
    from .curation import is_chimeric_system

    src = _fillna_scalar_safe(source_organism, "").astype(str).to_numpy()
    mhc = _fillna_scalar_safe(mhc_species, "").astype(str).to_numpy()
    pairs = pd.MultiIndex.from_arrays([src, mhc])
    unique_pairs = pairs.unique()
    decisions = pd.Series(
        [is_chimeric_system(s, m) for s, m in unique_pairs],
        index=unique_pairs,
        dtype=bool,
    )
    return pd.Series(
        decisions.reindex(pairs).to_numpy(),
        index=source_organism.index,
        dtype=bool,
    )


def _compute_is_engineered_mhc(
    source_organism: pd.Series,
    mhc_species: pd.Series,
    host: pd.Series,
) -> pd.Series:
    """True when the MHC is heterologous to the host cells / tissue.

    Narrows :func:`_compute_is_chimeric` to rows where the host genus
    matches the source organism but differs from the MHC species — the
    HLA-Tg-rat / NetH2pan / allogeneic-transfectant pattern. Heterologous-
    antigen rows (foreign protein on host's native MHC) flag is_chimeric
    but NOT is_engineered_mhc. See
    :func:`hitlist.curation.is_engineered_mhc` for the rule.

    The (source, mhc, host) triple has only a couple thousand unique
    values in the corpus; same vectorized broadcast as
    :func:`_compute_is_chimeric`.
    """
    from .curation import is_engineered_mhc

    src = _fillna_scalar_safe(source_organism, "").astype(str).to_numpy()
    mhc = _fillna_scalar_safe(mhc_species, "").astype(str).to_numpy()
    hst = _fillna_scalar_safe(host, "").astype(str).to_numpy()
    triples = pd.MultiIndex.from_arrays([src, mhc, hst])
    unique_triples = triples.unique()
    decisions = pd.Series(
        [is_engineered_mhc(s, m, h) for s, m, h in unique_triples],
        index=unique_triples,
        dtype=bool,
    )
    return pd.Series(
        decisions.reindex(triples).to_numpy(),
        index=source_organism.index,
        dtype=bool,
    )


def _expand_heterodimer_components(allele_token: str) -> list[str]:
    """Return the allele plus its alpha/beta components for class-II pairs.

    Thin wrapper over :func:`hitlist.curation.expand_allele_components`,
    which splits the pair with mhcgnomes instead of string-splitting on
    ``"/"`` and re-attaching whichever prefix the curator happened to
    write.  See pirl-unc/hitlist#151 for why single-chain observations
    need to reach heterodimer samples.
    """
    return expand_allele_components(allele_token)


def _normalized_allele_components(allele_token: str) -> tuple[str, ...]:
    """Canonical full restriction and component chains, in match priority.

    Full-pair identity comes first.  Alpha and beta chains follow in the
    order returned by mhcgnomes, with duplicates and failed/empty parses
    removed.  This is the shared observation/sample symmetry required for
    pair-aware joining and peptide-summary serotype derivation.
    """
    out: list[str] = []
    for component in _expand_heterodimer_components(allele_token):
        normalized = normalize_allele(component)
        if normalized and normalized not in out:
            out.append(normalized)
    return tuple(out)


_TIEBREAK_TOKEN_RE = re.compile(r"[^a-z0-9]+")


def _label_tokens(s: str, min_len: int = 3) -> set[str]:
    """Return lowercase alphanumeric tokens of length ≥``min_len``.

    Used by the sample resolver to score how well a candidate
    ms_sample matches an obs row when multiple samples share an
    ``(pmid, allele)`` key.
    """
    if not s:
        return set()
    return {t for t in _TIEBREAK_TOKEN_RE.split(s.lower()) if len(t) >= min_len}


def _candidate_obs_overlap(
    sample_label: str,
    sample_perturbation: str,
    cell_name: str,
    source_tissue: str,
    antigen_processing_comments: str,
    assay_comments: str,
) -> tuple[set[str], str]:
    """Build the (token_set, joined_text) view of a candidate sample for
    use by :func:`_select_best_candidate`.
    """
    sample_text = f"{sample_label or ''} {sample_perturbation or ''}".strip().lower()
    return _label_tokens(sample_text), sample_text


def _select_best_candidate(
    candidates: list[tuple[str, str, dict]],
    cell_name: str,
    source_tissue: str,
    antigen_processing_comments: str,
    assay_comments: str,
) -> dict | None:
    """Pick the ms_sample whose label/perturbation tokens best match obs metadata.

    Tokens unique to one candidate (not shared by any other candidate
    in the same group) weight the most: a "Hepatocyte" obs row picks
    the hepatocyte sample over the splenocyte sample, and a "4906-Glial
    cell" row picks the DFT1-4906 sample over the DFT2 sample, even
    though both share the generic "cell" token.

    Returns the candidate's full meta dict, or ``None`` when no
    candidate has any positive overlap (so callers can fall back to
    the existing first-pick / class-pool behavior), and also when the
    top score is a tie between candidates from *different* arms — a
    tie is not a discrimination, and silently taking the first one is
    how whole studies used to collapse onto a single arm.
    """
    if not candidates:
        return None
    obs_text = " ".join(
        s for s in (cell_name, source_tissue, antigen_processing_comments, assay_comments) if s
    ).lower()
    obs_tokens = _label_tokens(obs_text)
    if not obs_tokens:
        return None

    # Explicitly naming multiple samples is shared evidence, even if one
    # label earns a larger rarity/length score ("plasma" versus "serum",
    # #556). Compare exact distinguishing label tokens before fuzzy scoring;
    # common words such as "healthy donor" identify neither candidate.
    label_tokens = [_label_tokens(label) for label, _, _ in candidates]
    label_frequency = {
        token: sum(token in tokens for tokens in label_tokens)
        for token in set().union(*label_tokens)
    }
    named_arms = set()
    for tokens, candidate in zip(label_tokens, candidates):
        distinctive = {token for token in tokens if label_frequency[token] == 1}
        if distinctive and distinctive <= obs_tokens:
            named_arms.add(_candidate_arm_identity(candidate[2]))
    if len(named_arms) > 1:
        return None

    import re as _re

    # Per-candidate token sets and concatenated lowercase text.
    cand_views: list[tuple[set[str], str]] = [
        _candidate_obs_overlap(slabel, sperturb, "", "", "", "")
        for slabel, sperturb, _ in candidates
    ]
    n_cands = len(candidates)
    all_scores: list[tuple] = []
    union = set().union(*(ct for ct, _ in cand_views))
    if not union:
        return None
    # Per-token frequency across candidates — tokens unique to one
    # candidate get weight 1.0; tokens shared by every candidate get
    # weight 1/n. (Same-named cell line will be in every candidate;
    # the actual KO label / treatment marker only appears in one.)
    token_freq = {t: sum(1 for ct, _ in cand_views if t in ct) for t in union}

    def _matches_obs_token(cand_tok: str) -> int:
        """Return longest common-prefix length between ``cand_tok`` and
        any obs token, or 0 if no qualifying match.

        A match qualifies when:
        - one token is a complete prefix of the other AND that shared
          prefix is ≥3 chars (catches "ifn" vs "ifng", "spleen" vs
          "splenocytes", "hepatocytes" vs "hepatocyte"); OR
        - the two tokens share a common prefix of ≥4 chars even
          though neither is a complete prefix of the other (catches
          "lymphoblast" vs "lymphoblastoid").

        Without the prefix-completeness rail, pairs like "tapasin" vs
        "tap1" — which share only the 3-char family root "tap" — would
        score the same as "tap1" vs "tap1", routing TAPBP-perturbation
        rows to the TAP1 sample.
        """
        best = 0
        for ot in obs_tokens:
            common = 0
            while common < len(cand_tok) and common < len(ot) and cand_tok[common] == ot[common]:
                common += 1
            if common == 0:
                continue
            is_full_prefix = common == len(cand_tok) or common == len(ot)
            qualifies = (is_full_prefix and common >= 3) or common >= 4
            if qualifies and common > best:
                best = common
        return best

    def _wb_contains(piece: str, text: str) -> bool:
        """Word-boundary containment: ``piece`` appears in ``text`` as a
        whole alphanumeric run (so "treated" doesn't match the "treated"
        suffix of "untreated").
        """
        if len(piece) < 4 or not piece:
            return False
        pat = rf"(?:^|[^a-z0-9]){_re.escape(piece)}(?:[^a-z0-9]|$)"
        return bool(_re.search(pat, text))

    best_score = (0, 0, 0, 0)
    best_idx = -1
    for i, (cand_tokens, cand_text) in enumerate(cand_views):
        if not cand_tokens:
            # Still record a score, because ``all_scores`` is indexed by
            # candidate below.  Skipping the append shifted every later
            # score down a slot, so the cross-arm tie guard read
            # ``condition_category`` off the wrong candidates and
            # first-picked an arm where a genuine KO-vs-WT tie should have
            # declined — silently defeating the #354 protection.  Reachable
            # for any candidate whose whole label tokenizes away, which
            # ``_select_group``'s short system names ("T2", "JY") do.
            all_scores.append((0.0, 0, 0, 0))
            continue
        overlap = 0.0
        prefix_matches = 0
        for ct in cand_tokens:
            common = _matches_obs_token(ct)
            if common == 0:
                continue
            prefix_matches += 1
            freq = token_freq[ct]
            # Rarity weight x match length.
            overlap += (n_cands - freq + 1) / n_cands * common
        # Word-boundary substring matches (handles hyphenated cell-line
        # names like "MDA-MB-231"). Give half-weight relative to token
        # overlap so it tie-breaks rather than dominates.
        sub_score = 0
        for piece in _TIEBREAK_TOKEN_RE.split(cand_text):
            if _wb_contains(piece, obs_text):
                sub_score += 1
        # Allele-token substring contains: short locus+number tokens
        # like "b*40" / "B*39" never tokenize past the min_len=3 cutoff
        # (the regex split yields {hla, b, 40, 02} — all sub-3 except
        # "hla", which all class-I HLA samples share). Extract the
        # post-locus suffix from each candidate's curated ``mhc`` field
        # and test for raw-substring hits in obs_text. Catches Alpizar
        # 2017's APC-driven B*40 vs B*39 split.
        allele_score = 0
        cand_mhc = (candidates[i][2] or {}).get("mhc", "")
        if cand_mhc and obs_text:
            for tok in str(cand_mhc).lower().split():
                # Strip the "hla-" prefix, keep the rest including '*'
                # and ':' so the substring is locus-specific.
                stripped = tok.split("-", 1)[1] if tok.startswith("hla-") else tok
                if len(stripped) >= 3 and stripped in obs_text:
                    allele_score += 1
        score = (overlap, prefix_matches, sub_score, allele_score)
        all_scores.append(score)
        if score > best_score:
            best_score = score
            best_idx = i

    if best_idx < 0 or best_score == (0, 0, 0, 0):
        return None
    # A tie at the top is only a discrimination if the tied candidates
    # belong to the same arm.  When they are different arms the row
    # genuinely cannot be placed, and first-picking would reintroduce the
    # silent collapse (#354).
    #
    # "Same arm" is the curated ``condition_id``, not the coarse category
    # (#450): distinct arms that share a bucket used to pass this guard and
    # be first-picked, which is the collapse again with a category-sized
    # blast radius instead of a study-sized one.
    tied = [i for i, sc in enumerate(all_scores) if sc == best_score]
    if len(tied) > 1:
        arms = {_candidate_arm_identity(candidates[i][2]) for i in tied}
        if len(arms) > 1:
            return None
    return candidates[best_idx][2]


def _tiebreak_score(
    sample_label: str,
    sample_perturbation: str,
    cell_name: str,
    source_tissue: str,
    antigen_processing_comments: str,
    assay_comments: str,
) -> int:
    """Rough single-candidate score; kept for tests/diagnostics.

    Returns the longest common token-prefix length between the sample's
    label/perturbation and the obs row's metadata, with word-boundary
    substring bonuses for hyphenated cell-line names. The actual
    resolver uses :func:`_select_best_candidate`, which compares all
    candidates jointly with rarity weighting.
    """
    cand_tokens, _ = _candidate_obs_overlap(sample_label, sample_perturbation, "", "", "", "")
    obs_text = " ".join(
        s for s in (cell_name, source_tissue, antigen_processing_comments, assay_comments) if s
    ).lower()
    obs_tokens = _label_tokens(obs_text)
    if not cand_tokens or not obs_tokens:
        return 0
    best = 0
    for ct in cand_tokens:
        for ot in obs_tokens:
            common = 0
            while common < len(ct) and common < len(ot) and ct[common] == ot[common]:
                common += 1
            if common >= 3 and common > best:
                best = common
    return best


def _join_unique_text(values) -> str:
    return ";".join(sorted({str(v) for v in values if pd.notna(v) and str(v).strip()}))


def _join_unique_numeric(values) -> str:
    nums: set[int] = set()
    for v in values:
        if pd.isna(v) or str(v).strip() == "":
            continue
        try:
            nums.add(int(v))
        except (TypeError, ValueError):
            continue
    return ";".join(str(x) for x in sorted(nums))


def _truthy(value) -> bool:
    if pd.isna(value):
        return False
    return bool(value)


def _serotype_key(raw: str) -> str:
    s = str(raw).strip()
    if s.upper().startswith("HLA-"):
        s = s[4:]
    return s.lower()


def _query_mhc_class(target_allele: str = "", target_serotype: str = "") -> str:
    """Infer one canonical class from an allele or serotype query."""
    molecules = (
        _normalized_allele_components(target_allele)
        if target_allele
        else tuple(serotype_to_alleles(target_serotype))
    )
    classes: set[str] = set()
    for molecule in molecules:
        mhc_class = normalize_mhc_class_token(mhc_class_of(molecule))
        if mhc_class:
            classes.add(mhc_class)
    return next(iter(classes)) if len(classes) == 1 else ""


def _sample_alleles(sample_mhc: str, mhc_class: str = "") -> list[str]:
    """Molecule designations a sample's MHC field names outright, for one class.

    Module-private: every caller is in this file.  ``predict`` briefly imported
    it, which is why it was public for one commit; it now asks
    :func:`hitlist.curation.class_i_prediction_scope` instead, so there is no
    cross-module contract left to document here (#574).

    What callers in this module rely on:

    - :attr:`~hitlist.curation.SampleMhcCandidates.exact` designations only, so
      a serotype-typed sample never yields a named allele -- "this donor is
      DR15" must not become "this peptide was seen on DRB1*15:01" (#380).  Ask
      :func:`_sample_serotypes` for what such a study actually measured.
    - A class-II pair contributes the pair token *and* both component chains,
      which are part of the reported molecule rather than an inference.
    - With ``mhc_class`` set, designations of the other class -- the other half
      of a mixed ``I+II`` genotype -- are excluded.
    - The result is sorted and deduplicated.

    A returned value does not necessarily identify a single protein.  ``exact``
    means *the source named this outright*, so a locus (``HLA-A``) or a
    one-field allele group (``HLA-A*02``) is returned as-is; that is a faithful
    record of the reported precision, not a defect.  A consumer needing
    protein-level input applies its own rule --
    :func:`hitlist.curation.class_i_prediction_scope` is the one this project
    uses (#574).

    Returns
    -------
    list[str]
        Sorted designations; empty when the field named no molecule.
    """
    alleles = {
        component
        for allele in sample_mhc_candidates(sample_mhc).exact
        for component in _normalized_allele_components(allele)
    }
    if mhc_class:
        alleles = {
            allele for allele in alleles if _mhc_class_matches(mhc_class_of(allele), mhc_class)
        }
    return sorted(alleles)


def _sample_serotypes(sample_mhc: str, mhc_class: str = "") -> tuple[str, ...]:
    """Serotype designations the sample was typed to, as serotypes.

    A study that typed only to ``HLA-DR15`` never named an allele, so the
    serotype is the finest true statement about it.  Kept apart from
    :func:`_sample_alleles` so a serotype match is reported as a serotype
    match (#380).
    """
    serotypes = sample_mhc_candidates(sample_mhc).serotypes
    if not mhc_class:
        return serotypes
    return tuple(
        serotype
        for serotype in serotypes
        if _mhc_class_matches(_query_mhc_class(target_serotype=serotype), mhc_class)
    )


def _source_bucket(row: pd.Series) -> str:
    if _truthy(row.get("src_cancer", False)):
        return "cancer"
    if _truthy(row.get("src_adjacent_to_tumor", False)):
        return "adjacent"
    if (
        _truthy(row.get("src_healthy_tissue", False))
        or _truthy(row.get("src_healthy_thymus", False))
        or _truthy(row.get("src_healthy_reproductive", False))
    ):
        return "healthy"
    return "other"


def _peptide_summary_support_label(row: pd.Series) -> str:
    if _truthy(row.get("mono_exact", False)):
        return "mono_exact"
    if _truthy(row.get("multi_exact", False)):
        return "multi_exact"
    if _truthy(row.get("mono_serotype", False)):
        return "mono_serotype"
    if _truthy(row.get("multi_serotype", False)):
        return "multi_serotype"
    if _truthy(row.get("class_only_sample_allele", False)):
        return "class_only_sample_allele"
    if _truthy(row.get("class_only_sample_serotype", False)):
        return "class_only_sample_serotype"
    if _truthy(row.get("unknown_allele", False)):
        return "unknown_allele"
    return ""


#: Per-peptide support tiers, strongest first.  Drives ``best_support`` and the
#: default sort: a mono-allelic exact-allele elution is the most direct evidence
#: a peptide is presented on the target; an unknown-allele row is the weakest.
_PEPTIDE_SUMMARY_SUPPORT_TIERS = [
    ("n_mono_exact_rows", "mono_exact"),
    ("n_multi_exact_rows", "multi_exact"),
    ("n_mono_serotype_rows", "mono_serotype"),
    ("n_multi_serotype_rows", "multi_serotype"),
    ("n_class_only_sample_allele_rows", "class_only_sample_allele"),
    ("n_class_only_sample_serotype_rows", "class_only_sample_serotype"),
    ("n_unknown_allele_rows", "unknown_allele"),
]


def _best_support_label(summary_row: pd.Series) -> str:
    for col, label in _PEPTIDE_SUMMARY_SUPPORT_TIERS:
        if int(summary_row.get(col, 0) or 0) > 0:
            return label
    return ""


@dataset_snapshot()
def generate_ms_peptide_summary_table(
    mhc_class: str | None = None,
    species: str | None = None,
    source: str | None = None,
    mhc_allele: str | list[str] | None = None,
    serotype: str | list[str] | None = None,
    gene: str | list[str] | None = None,
    gene_name: str | list[str] | None = None,
    gene_id: str | list[str] | None = None,
    peptide: str | list[str] | None = None,
    columns: list[str] | None = None,
    *,
    source_species: str | list[str] | None = None,
    host_species: str | list[str] | None = None,
    exclude_chimeric: bool = False,
) -> pd.DataFrame:
    """Summarize per-peptide MS support for one target allele or serotype.

    Aimed at questions like "which PRAME peptides might be presented on A24
    in cancers?"  Groups the relevant observations one row per peptide and
    splits support into exact-allele, same-serotype, class-only sample-candidate,
    and unknown-allele buckets, plus a cancer/healthy/adjacent source breakdown.

    Exactly one of ``mhc_allele`` / ``serotype`` is required (a single value),
    and at least one gene/peptide filter must be supplied to keep the export
    scoped.  Returns an empty (well-shaped) frame when nothing matches.
    """
    target_alleles = _to_list(mhc_allele) if mhc_allele is not None else []
    target_serotypes = _to_list(serotype) if serotype is not None else []
    if not target_alleles and not target_serotypes:
        raise ValueError("peptide-summary requires exactly one of --mhc-allele or --serotype")
    if target_alleles and target_serotypes:
        raise ValueError("peptide-summary accepts --mhc-allele or --serotype, not both")
    if len(target_alleles) > 1 or len(target_serotypes) > 1:
        raise ValueError("peptide-summary supports only one target allele or serotype at a time")
    if not any(v is not None and _to_list(v) for v in (gene, gene_name, gene_id, peptide)):
        raise ValueError(
            "peptide-summary requires a gene or peptide filter to keep the export scoped"
        )

    target_allele = normalize_allele(target_alleles[0]) if target_alleles else ""
    if target_alleles and not target_allele:
        raise ValueError(f"Could not normalize target allele: {target_alleles[0]!r}")
    target_serotype = (
        _normalize_serotype_query(target_serotypes[0])
        if target_serotypes
        else allele_to_serotype(target_allele)
    )
    target_serotype_key = _serotype_key(target_serotype)
    query_mode = "allele" if target_allele else "serotype"
    target_mhc_class = _query_mhc_class(target_allele, target_serotype)

    df = generate_observations_table(
        mhc_class=mhc_class or target_mhc_class or None,
        species=species,
        source_species=source_species,
        host_species=host_species,
        exclude_chimeric=exclude_chimeric,
        source=source,
        gene=gene,
        gene_name=gene_name,
        gene_id=gene_id,
        peptide=peptide,
    )
    canonical_columns = [
        "query_mode",
        "target_allele",
        "target_serotype",
        "peptide",
        "n_support_rows",
        "n_pmids",
        "pmids",
        "target_peptide_alleles",
        "sample_match_types",
        "support_labels",
        "best_support",
        "n_mono_exact_rows",
        "n_mono_serotype_rows",
        "n_multi_exact_rows",
        "n_multi_serotype_rows",
        "n_class_only_sample_allele_rows",
        "n_class_only_sample_serotype_rows",
        "n_unknown_allele_rows",
        "n_cancer_rows",
        "n_healthy_rows",
        "n_adjacent_rows",
        "n_other_rows",
    ]
    if df.empty:
        result = pd.DataFrame(columns=canonical_columns)
        return result[columns] if columns else result

    work = df.copy()
    if target_mhc_class and "mhc_class" in work.columns:
        same_class = work["mhc_class"].map(
            lambda value: _mhc_class_matches(str(value), target_mhc_class)
        )
        work = work[same_class].copy()
        if work.empty:
            result = pd.DataFrame(columns=canonical_columns)
            return result[columns] if columns else result
    for col, default in {
        "sample_mhc": "",
        "sample_match_type": "",
        "is_monoallelic": False,
        "src_cancer": False,
        "src_adjacent_to_tumor": False,
        "src_healthy_tissue": False,
        "src_healthy_thymus": False,
        "src_healthy_reproductive": False,
    }.items():
        if col not in work.columns:
            work[col] = default
    if "has_peptide_level_allele" not in work.columns:
        work["has_peptide_level_allele"] = _compute_has_peptide_level_allele(
            work["mhc_restriction"],
            work["allele_resolution"] if "allele_resolution" in work.columns else None,
        )
    if "serotypes" not in work.columns:
        work["serotypes"] = work["mhc_restriction"].map(
            lambda a: ";".join(allele_to_all_serotypes(str(a)))
        )

    flags: list[dict] = []
    for _, row in work.iterrows():
        row_alleles = _normalized_allele_components(str(row.get("mhc_restriction", "")))
        row_allele = row_alleles[0] if row_alleles else ""
        row_serotype_keys = {
            _serotype_key(s) for s in str(row.get("serotypes", "")).split(";") if s
        }
        row_serotype_keys.update(
            _serotype_key(serotype)
            for allele in row_alleles
            for serotype in allele_to_all_serotypes(allele)
        )
        sample_mhc_text = str(row.get("sample_mhc", ""))
        sample_allele_list = _sample_alleles(sample_mhc_text, target_mhc_class)
        sample_serotype_keys = {
            _serotype_key(s)
            for allele in sample_allele_list
            for s in allele_to_all_serotypes(allele)
        }
        # A serotype-typed sample names no allele, so it contributes no
        # keys through the loop above; add the curated designation itself
        # or the sample drops out of serotype matching entirely (#380).
        sample_serotype_keys.update(
            _serotype_key(s) for s in _sample_serotypes(sample_mhc_text, target_mhc_class)
        )
        has_peptide_level_allele = _truthy(row.get("has_peptide_level_allele", False))
        mono = _truthy(row.get("is_monoallelic", False))

        exact = bool(target_allele and target_allele in row_alleles)
        sero = bool(target_serotype_key and target_serotype_key in row_serotype_keys)
        class_only_sample_allele = (
            not has_peptide_level_allele
            and bool(target_allele)
            and target_allele in sample_allele_list
        )
        class_only_sample_serotype = (
            not has_peptide_level_allele
            and bool(target_serotype_key)
            and target_serotype_key in sample_serotype_keys
            and not class_only_sample_allele
        )
        unknown = (
            not has_peptide_level_allele
            and not class_only_sample_allele
            and not class_only_sample_serotype
            and not sample_allele_list
            and not sample_serotype_keys
        )
        relevant = (
            exact or sero or class_only_sample_allele or class_only_sample_serotype or unknown
        )
        source_bucket = _source_bucket(row)
        flags.append(
            {
                "relevant_to_target": relevant,
                "target_peptide_allele": row_allele
                if relevant and has_peptide_level_allele and (exact or sero)
                else "",
                "mono_exact": mono and exact,
                "mono_serotype": mono and sero and not exact,
                "multi_exact": (not mono) and exact,
                "multi_serotype": (not mono) and sero and not exact,
                "class_only_sample_allele": class_only_sample_allele,
                "class_only_sample_serotype": class_only_sample_serotype,
                "unknown_allele": unknown,
                "source_bucket": source_bucket if relevant else "",
            }
        )

    flagged = pd.concat([work.reset_index(drop=True), pd.DataFrame(flags)], axis=1)
    flagged = flagged[flagged["relevant_to_target"]].copy()
    if flagged.empty:
        result = pd.DataFrame(columns=canonical_columns)
        return result[columns] if columns else result

    flagged["support_label"] = flagged.apply(_peptide_summary_support_label, axis=1)
    flagged["cancer_row"] = flagged["source_bucket"] == "cancer"
    flagged["healthy_row"] = flagged["source_bucket"] == "healthy"
    flagged["adjacent_row"] = flagged["source_bucket"] == "adjacent"
    flagged["other_row"] = flagged["source_bucket"] == "other"

    result = flagged.groupby("peptide", as_index=False).agg(
        n_support_rows=("peptide", "size"),
        n_pmids=("pmid", lambda x: len({int(v) for v in x if pd.notna(v)})),
        pmids=("pmid", _join_unique_numeric),
        target_peptide_alleles=("target_peptide_allele", _join_unique_text),
        sample_match_types=("sample_match_type", _join_unique_text),
        support_labels=("support_label", _join_unique_text),
        n_mono_exact_rows=("mono_exact", "sum"),
        n_mono_serotype_rows=("mono_serotype", "sum"),
        n_multi_exact_rows=("multi_exact", "sum"),
        n_multi_serotype_rows=("multi_serotype", "sum"),
        n_class_only_sample_allele_rows=("class_only_sample_allele", "sum"),
        n_class_only_sample_serotype_rows=("class_only_sample_serotype", "sum"),
        n_unknown_allele_rows=("unknown_allele", "sum"),
        n_cancer_rows=("cancer_row", "sum"),
        n_healthy_rows=("healthy_row", "sum"),
        n_adjacent_rows=("adjacent_row", "sum"),
        n_other_rows=("other_row", "sum"),
    )
    result.insert(0, "target_serotype", target_serotype)
    result.insert(0, "target_allele", target_allele)
    result.insert(0, "query_mode", query_mode)
    result["best_support"] = result.apply(_best_support_label, axis=1)
    result = result.sort_values(
        [
            "n_mono_exact_rows",
            "n_multi_exact_rows",
            "n_mono_serotype_rows",
            "n_multi_serotype_rows",
            "n_class_only_sample_allele_rows",
            "n_support_rows",
            "peptide",
        ],
        ascending=[False, False, False, False, False, False, True],
    ).reset_index(drop=True)
    if columns:
        available = [c for c in columns if c in result.columns]
        return result[available]
    return result


@dataset_snapshot()
def generate_species_summary(mhc_class: str | None = None) -> pd.DataFrame:
    """Summarize MS-elution data coverage by species and MHC class.

    Reads directly from ``observations.parquet`` — NOT from
    ``pmid_overrides.yaml``. Every species present in the built index
    appears here, including those with zero curated metadata entries.

    Breaking change in v1.15.0 (#117): earlier versions sourced counts
    from ``pmid_overrides.yaml``'s curated ``ms_samples`` entries, which
    undercounted by orders of magnitude on non-human species (mouse had
    2 curated PMIDs vs 388 real; most non-human species were missing
    entirely). The old columns ``n_studies`` / ``n_sample_types`` /
    ``n_samples`` are replaced by ``n_pmids`` / ``n_peptides`` /
    ``n_observations`` sourced from the parquet.

    Parameters
    ----------
    mhc_class
        Optional filter (``"I"``, ``"II"``, or ``"non classical"``).
        Omit for all classes.

    Returns
    -------
    pd.DataFrame
        One row per (species, mhc_class). Columns:

        - ``species``: normalized MHC species from the allele
          (``mhc_species`` column).
        - ``mhc_class``: ``"I"`` / ``"II"`` / ``"non classical"``.
        - ``n_pmids``: unique PMIDs with rows in this (species, class)
          cell.
        - ``n_peptides``: unique peptide sequences.
        - ``n_observations``: total row count (one per assay IRI).
    """
    from .observations import is_built, load_observations

    if not is_built():
        return pd.DataFrame(
            columns=["species", "mhc_class", "n_pmids", "n_peptides", "n_observations"]
        )

    obs = load_observations(
        mhc_class=mhc_class,
        columns=["peptide", "mhc_species", "mhc_class", "pmid"],
    )
    if obs.empty:
        return pd.DataFrame(
            columns=["species", "mhc_class", "n_pmids", "n_peptides", "n_observations"]
        )

    # Drop rows with an empty mhc_species — these are rows where mhcgnomes
    # couldn't resolve the MHC restriction to a species. They'd clutter
    # the summary with an empty-string row. Count is usually small.
    obs = obs[obs["mhc_species"].notna() & (obs["mhc_species"] != "")]

    summary = (
        obs.groupby(["mhc_species", "mhc_class"], dropna=False, observed=True)
        .agg(
            n_pmids=("pmid", "nunique"),
            n_peptides=("peptide", "nunique"),
            n_observations=("peptide", "size"),
        )
        .reset_index()
        .rename(columns={"mhc_species": "species"})
        .sort_values(["species", "mhc_class"])
        .reset_index(drop=True)
    )
    return summary


@dataset_snapshot()
def validate_mhc_alleles() -> pd.DataFrame:
    """Parse all MHC alleles in pmid_overrides with mhcgnomes.

    Returns
    -------
    pd.DataFrame
        Columns: pmid, study_label, allele, parsed_name, parsed_type,
        species, valid.
    """
    try:
        from mhcgnomes import parse
    except ImportError:
        return pd.DataFrame(
            columns=[
                "pmid",
                "study_label",
                "allele",
                "parsed_name",
                "parsed_type",
                "species",
                "valid",
            ]
        )

    overrides = load_pmid_overrides()
    rows: list[dict] = []

    for pmid_int, entry in sorted(overrides.items()):
        study_label = entry.get("study_label", "")
        hla_alleles = entry.get("hla_alleles", {})
        if not hla_alleles:
            continue

        allele_strings = _extract_allele_strings(hla_alleles)
        for allele_str in sorted(set(allele_strings)):
            result = parse(allele_str)
            parsed_name = str(result)
            parsed_type = type(result).__name__
            species_name = ""
            if hasattr(result, "species"):
                species_name = result.species.name

            valid = parsed_type not in ("ParseError", "str")

            rows.append(
                {
                    "pmid": pmid_int,
                    "study_label": study_label,
                    "allele": allele_str,
                    "parsed_name": parsed_name,
                    "parsed_type": parsed_type,
                    "species": species_name,
                    "valid": valid,
                }
            )

    return pd.DataFrame(rows)


def _sample_class_tokens(sample_row) -> set[str]:
    """Canonical MHC class tokens a curated sample belongs to.

    Reads the declared ``mhc_class`` (normalizing the ``non-classical`` /
    ``non classical`` spelling split) and falls back to deriving the class
    from the sample's own alleles via mhcgnomes when it is blank.

    Returning a set rather than testing against a hardcoded ``("I", "II")``
    is what lets non-classical samples participate in the class pool at
    all — HLA-E / HLA-G / HLA-F / MR1 / H2-Q samples were previously
    invisible to it (#363).
    """
    from .curation import mhc_class_of, normalize_mhc_class_token

    declared = normalize_mhc_class_token(str(sample_row.get("mhc_class", "") or ""))
    if declared:
        return {p.strip() for p in declared.split("+") if p.strip()}
    mhc = str(sample_row.get("mhc", "") or "").strip()
    if not mhc:
        return set()
    # Class-only values are multi-word ("Bos taurus class I"), so try the
    # whole string before splitting — per-token derivation returns nothing
    # for every individual word of them.
    whole = mhc_class_of(mhc)
    if whole:
        return {whole}
    derived = {mhc_class_of(tok) for tok in mhc.split() if tok}
    derived.discard("")
    return derived


def _mhc_class_matches(sample_class: str, filter_class: str, sample_row=None) -> bool:
    """Check if a sample's mhc_class matches a filter.

    ``"I"`` matches ``"I"`` and ``"I+II"`` but NOT ``"II"``.  Spellings
    are normalized on both sides, so the YAML's ``non-classical`` and
    the IEDB export's ``non classical`` compare equal (#363).

    When ``sample_row`` is given the class is resolved through
    :func:`_sample_class_tokens`, which falls back to deriving it from
    the sample's own alleles.  Without that, a sample with a blank
    ``mhc_class`` but an unambiguous ``mhc`` was dropped by every class
    filter while the class-pool path in this same module happily derived
    it — two class-resolution paths disagreeing.
    """
    from .curation import normalize_mhc_class_token

    if sample_row is not None:
        parts = _sample_class_tokens(sample_row)
    elif sample_class:
        parts = {p.strip() for p in normalize_mhc_class_token(sample_class).split("+")}
    else:
        return False
    return normalize_mhc_class_token(filter_class) in parts


@dataset_snapshot()
def count_peptides_by_study(
    source: str | None = None,
) -> pd.DataFrame:
    """Count unique peptides per PMID x MHC class x species.

    Uses cached index (built on first call, reused if source CSV
    unchanged). See :mod:`hitlist.indexer`.

    Parameters
    ----------
    source
        ``"iedb"``, ``"cedar"``, ``"merged"`` (default), or ``"all"``.

    Returns
    -------
    pd.DataFrame
        Columns: source, pmid, mhc_class, mhc_species, n_peptides,
        n_observations.
    """
    from .indexer import get_index

    study_df, _allele_df = get_index(source=source or "merged")
    return study_df


@dataset_snapshot()
def collect_alleles_from_data(
    source: str | None = None,
) -> pd.DataFrame:
    """Collect all unique MHC restriction strings and validate with mhcgnomes.

    Uses cached index. See :mod:`hitlist.indexer`.

    Returns
    -------
    pd.DataFrame
        Columns: allele, n_occurrences, parsed_name, parsed_type,
        species, valid.
    """
    from .indexer import get_index, validate_alleles_from_index

    _study_df, allele_df = get_index(source=source or "merged")
    return validate_alleles_from_index(allele_df)


def _extract_allele_strings(hla_alleles: dict | list | str) -> list[str]:
    """Recursively extract allele strings from the hla_alleles field."""
    results: list[str] = []
    if isinstance(hla_alleles, str):
        # Could be a description like "51 HLA-I allotypes ..." — skip non-allele text
        if ("HLA-" in hla_alleles and "*" in hla_alleles) or hla_alleles.startswith("HLA-"):
            results.append(hla_alleles)
    elif isinstance(hla_alleles, list):
        for item in hla_alleles:
            results.extend(_extract_allele_strings(item))
    elif isinstance(hla_alleles, dict):
        for value in hla_alleles.values():
            results.extend(_extract_allele_strings(value))
    return results
