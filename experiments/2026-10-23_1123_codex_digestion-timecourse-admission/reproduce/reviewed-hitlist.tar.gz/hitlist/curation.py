# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Data-driven MS evidence curation for IEDB/CEDAR MHC ligand data.

Classification rules and PMID overrides are loaded from YAML data files,
not hardcoded in Python. This makes the curation logic transparent,
auditable, and easy to extend without code changes.

Source categories (mutually exclusive priority order)::

    cancer              Cancer tissue, cancer patient biofluids, non-EBV cell lines
    adjacent            Tumor-adjacent normal tissue (resection margins)
    activated_apc       Monocyte-derived DCs, macrophages with activation
    healthy_tissue      Direct ex vivo healthy somatic tissue (THE SAFETY SIGNAL)
    healthy_thymus      Direct ex vivo thymus (expected for CTAs)
    healthy_reproductive Direct ex vivo immune-privileged reproductive tissue
                        (testis, epididymis, placenta, embryo; CTA-safe in either sex)
    healthy_reproductive_female Direct ex vivo female reproductive tract / breast
                        (sex-stratified: a safety signal only in female patients)
    healthy_reproductive_male Direct ex vivo male reproductive tract
                        (sex-stratified: a safety signal only in male patients)
    ebv_lcl             EBV-transformed B-cell lines
    cell_line           Other cell lines (tumor / malignant-derived)
    noncancer_cell_line Non-malignant cell lines / clones derived from normal
                        cells — immortalized (hTERT / SV40-LT / engineered, e.g.
                        the ECN90 beta-cell line) or in-vitro-expanded primary
                        clones (e.g. activated CD4+ T-cell clones). IEDB tags
                        these "Cell Line / Clone"; they are a line/clone but NOT
                        cancer.
"""

from __future__ import annotations

import contextlib
import re
from collections import Counter
from collections.abc import Mapping
from dataclasses import dataclass
from functools import cache, lru_cache
from os.path import basename, dirname, join
from types import MappingProxyType

import pandas as pd
from mhcgnomes import Allele, Class2Locus, Gene, Haplotype, MhcClass, Pair, Serotype, Species

from .cell_name_parser import parse_cell_name, registry_verdict
from .conditions import CONDITION_FIELDS, validate_study_conditions

# ``UniqueKeyLoader`` was born here and is re-exported under its original name.
from .curation_yaml import UniqueKeyLoader, load_curation_yaml  # noqa: F401

#: How strongly a row establishes its named MHC restriction. This is
#: deliberately orthogonal to ``mhc_allele_provenance``, which records where
#: the candidate allele *set* came from rather than how the peptide-to-allele
#: claim was established (#415).
RESTRICTION_EVIDENCE_VALUES = (
    "experimental",
    "monoallelic",
    "predicted",
    "unknown",
)

#: Whether a row's serotype is primary data or a computed membership.
#: ``reported`` means the study typed serologically and the restriction *is*
#: the serotype -- no molecule was measured, and the allele columns are empty
#: because of that, not because the row is unresolved. ``derived`` means the
#: study named a molecule and the serotype is this library's projection of it
#: through mhcgnomes' membership table, so it is only as current as the
#: installed mhcgnomes. ``donor_set`` is a union over a donor's typed alleles,
#: which makes the serotype a candidate rather than the restriction's
#: identity. Empty means the row carries no serotype at all (#458).
SEROTYPE_SOURCE_VALUES = (
    "reported",
    "derived",
    "donor_set",
)

#: Every provenance override a PMID entry, a conditional rule, or an
#: ``ms_samples`` entry may declare. ``None`` (YAML ``override:`` with no
#: value) is always allowed and means "no override"; anything outside this
#: tuple is a typo and is rejected at load time. Mirrors the branch chain in
#: :func:`classify_ms_row` — the vocabulary lived only there and in a YAML
#: header comment, so a misspelling silently fell through to default
#: classification (#373).
OVERRIDE_VALUES = (
    "cancer_patient",
    "adjacent",
    "activated_apc",
    "cell_line",
    "noncancer_cell_line",
    "ebv_lcl",
    "healthy",
)

#: Why a study's rows can or cannot be resolved to an experimental arm (#366).
#:
#: 450k+ observation rows sit at ``pmid_ambiguous`` / ``group_ambiguous``, and
#: without a recorded reason each one invites the same investigation again.
#: These values record the answer once. They describe the *deposited evidence*,
#: not the curation's completeness — a study can be perfectly curated and still
#: be unresolvable.
ARM_RESOLUTION_VALUES = (
    # Rows reach a specific arm. Nothing to investigate.
    "resolved",
    # The evidence positively places these peptides in more than one arm — a
    # peptide eluted from both the treated and the untreated sample really was
    # in both. The ambiguity is a fact about the biology, not a missing field.
    "multi_arm_evidence",
    # IEDB carries no per-row field that varies at all. Verified by measuring
    # the distinct-value count of cell_name, source_tissue,
    # antigen_processing_comments and assay_comments across the study's rows.
    "no_row_discriminator",
    # Per-row metadata identifies the sample *system* — and `sample_group`
    # uses it (#359) — but never the arm within that system. Distinct from
    # `no_row_discriminator`: fields here do vary and do carry real
    # information, just not on the axis the arms encode. The rows land at
    # `group_ambiguous` rather than `pmid_ambiguous` for that reason.
    "arm_not_recorded",
    # The curated arms and the recorded metadata are on different axes — arms
    # per donor against evidence per tissue, say. Neither is wrong; they simply
    # do not intersect, and no matcher can bridge them.
    "axis_mismatch",
    # A per-row discriminator does exist and the arms are not yet curated to
    # use it. This is the only value that marks real remaining work.
    "curation_gap",
)

#: Every key a top-level PMID entry may carry, mapped to what reads it.
#:
#: The study-level twin of :data:`MS_SAMPLE_FIELDS`. #373 guarded the sample
#: level and this level was left open, which is how four study-level keys ended
#: up curated and read by nothing. ``exclude_from_ms`` was the costly one: it
#: now has a reader (:func:`ms_excluded_pmids`), and ``donors`` is still unread
#: and still says so (#444).
#:
#: Adding a key means adding it here *and* naming its reader. Where a key is
#: genuinely informational, say so; where it is unread but kept pending a fix,
#: say that and cite the issue rather than describing it as if it worked.
PMID_ENTRY_FIELDS = MappingProxyType(
    {
        "pmid": "study identifier; the key of the returned mapping",
        "submission_id": "identifier for studies with no PMID; classify_ms_row checks both",
        "study_label": "friendly study name, exported on every sample and observation",
        "title": "paper title; informational, for curator orientation",
        "override": "study-wide provenance override applied by classify_ms_row",
        "rules": "condition-matched overrides, checked before the study-wide value",
        "ms_samples": "per-arm enumeration; see MS_SAMPLE_FIELDS",
        "note": "study-level free-text curation rationale",
        "perturbations": "study-level perturbation panel; ORed into the APM gene flags",
        "hla_alleles": "study-wide typing; flattened by the qc token audit",
        "species": "curated source proteome; scanner fills unresolved rows (#307)",
        "source_organism": "curated source organism; scanner fills unresolved rows (#307)",
        "source_tissue": "curated tissue; scanner fills rows IEDB left blank (#314)",
        "cell_name": "curated cell line; scanner fills rows IEDB left blank (#314)",
        "disease": "curated disease; scanner fills rows IEDB left blank (#314)",
        "culture_condition": "curated culture condition; scanner fills blank rows (#314)",
        "mono_allelic_host": "HLA-null host line; validated against monoallelic_lines.yaml",
        "mono_allelic_method": "how mono-allelic presentation was engineered",
        "ip_antibody": "study default IP antibody; per-sample values override it",
        "acquisition_mode": "study default acquisition mode; per-sample values override it",
        "instrument": "study default instrument; per-sample values override it",
        "fragmentation": "study default fragmentation; per-sample values override it",
        "labeling": "study default labeling; per-sample values override it",
        "search_engine": "study default search engine; per-sample values override it",
        "fdr": "study default false discovery rate; per-sample values override it",
        "quantification_method": "targeted quantification approach; exported per observation",
        "reference_proteomes": "study-level viral/parasite proteomes; per-sample values win",
        "restriction_evidence": "study-wide evidence for a named MHC restriction (#415)",
        "restriction_evidence_rules": "condition-matched restriction-evidence overrides (#415)",
        "aliases": "citation provenance (withdrawn_pmid, benchmark dataset names)",
        "peptide_attributions": "relative path to a per-peptide sample-attribution CSV (#360)",
        "peptide_attribution_restrictions": (
            "reported restrictions eligible for the peptide map; scanner and index repair (#534)"
        ),
        "elution_condition_ids": (
            "exact deposited assay comments mapped to supported condition IDs; "
            "export._select_by_elution_conditions reads this (#512)"
        ),
        "tissue_overrides": "per-tissue overrides; rendered by hitlist.report",
        "arm_resolution": (
            "why this study's rows can or cannot reach a specific arm; one of "
            "curation.ARM_RESOLUTION_VALUES, exported per sample and per "
            "observation so an ambiguous row carries its own explanation (#366)"
        ),
        "arm_resolution_note": "the evidence behind arm_resolution, in prose (#366)",
        "n_samples": "curated sample count for the study; informational",
        "n_tissues": "curated tissue count for the study; informational",
        "donors": "UNREAD. Curated on 11 studies, consumed by nothing (#444)",
        "exclude_from_ms": (
            "marks a study as not an MS elution experiment; ms_excluded_pmids() "
            "reads it and build_observations drops those rows from the MS index. "
            "Scoped to MS evidence — binding.parquet keeps them (#444)"
        ),
        "label": "DEPRECATED spelling of study_label (v1.7.0); warned about, never read",
    }
)

#: The cellular-typing sub-registry of :data:`MS_SAMPLE_FIELDS` (#520), spread
#: into it below. Kept above that registry's ``#:`` block on purpose: Sphinx
#: binds a ``#:`` comment to the assignment that follows it, so defining this
#: in between attributed the schema-guard rationale to this five-key subset and
#: left the registry it governs undocumented.
MHC_TYPING_FIELDS = MappingProxyType(
    {
        "mhc_basis": "read by export.generate_observations_table, which blanks it when sample_mhc is not that arm's; selected_restriction or sample_typing, blank means unreviewed on a sample and on an exported row can also mean the claim was dropped -- sample_mhc_origin tells them apart",
        "mhc_genotype": "informational; exported by generate_ms_samples_table/generate_observations_table and scanned by qc.mhc_token_audit/sample_ploidy_audit, never read for attribution -- independently sourced cellular typing at its reported molecular or serological precision",
        "mhc_genotype_cell": "informational; exported only. The single cell line or donor whose typing is recorded, and what _consensus_meta compares to refuse pooling two cells' typing",
        "mhc_genotype_complete_loci": "informational; exported only. Sorted semicolon-separated loci the source states are fully typed, validated against mhc_genotype_reported_loci on load; blank is unknown",
        "mhc_genotype_source": "informational; exported only. Citation and location establishing the typing and its scope, required by sample_mhc_metadata whenever mhc_genotype is set",
    }
)
MHC_TYPING_COLUMNS = (*MHC_TYPING_FIELDS, "mhc_genotype_reported_loci")
MHC_GENOTYPE_COLUMNS = tuple(c for c in MHC_TYPING_COLUMNS if c != "mhc_basis")


#: Every key an ``ms_samples`` entry may carry, mapped to what reads it.
#:
#: This is the schema guard #373 asks for. Three keys — ``override``,
#: ``note``, ``species`` — sat in the YAML for a long time with nothing
#: reading them, and only an audit found them: the exporter iterated the keys
#: it knew and ignored the rest, so adding a field that no consumer reads
#: looked exactly like adding one that works. Loading now rejects a key that
#: is not listed here, which turns the next silently-ignored field into an
#: error at load rather than a discovery.
#:
#: Adding a key means adding it here *and* pointing it at its reader. If a
#: field is genuinely informational, say so in its description rather than
#: leaving it out.
MS_SAMPLE_FIELDS = MappingProxyType(
    {
        "sample_label": "sample identity; the join key for observation attribution",
        "condition": "perturbation text; drives perturbation, APM flags, condition_category",
        "mhc": "reported experimental MHC candidates; may be a selected restriction, not a genotype",
        **MHC_TYPING_FIELDS,
        "mhc_class": "class filter, and the class pool when mhc is blank",
        "n_samples": "replicate count; 0 marks an unprofiled arm (#437)",
        "profiled": "false marks an arm the paper describes but never ran (#437)",
        "source": "free-text sample provenance (tissue source, donor description)",
        "species": "per-sample source proteome; overrides the study-level value (#372)",
        "peptides": "curated peptide count for the arm",
        "reference_proteomes": "per-sample viral / parasite proteome references",
        "sample_group": (
            "the sample *system* this arm belongs to (a cell line, tissue, donor "
            "cohort). Attribution resolves the group first, using IEDB's narrative "
            "fields — they identify the system reliably and say nothing about "
            "treatment — then the arm within it (#359)"
        ),
        "override": (
            "per-sample provenance override, exported as sample_override / "
            "effective_override. Metadata only: classify_ms_row never sees "
            "ms_samples, so an explicit null clears the exported value but NOT "
            "the build-time src_* flags, which stay PMID- and rule-driven (#373)"
        ),
        "note": "free-text analytic caveat about this arm (#373)",
        "classification": "per-sample classification note, exported as `notes`",
        "reason": "rationale for the classification, exported as `notes` when it is absent",
        "ip_antibody": "IP antibody; overrides the study-level value",
        "acquisition_mode": "acquisition mode; overrides the study-level value",
        "instrument": "mass spectrometer; overrides the study-level value",
        "fragmentation": "fragmentation method; overrides the study-level value",
        "labeling": "labeling scheme; overrides the study-level value",
        "search_engine": "search engine; overrides the study-level value",
        "fdr": "false discovery rate; overrides the study-level value",
        "type": "DEPRECATED spelling of sample_label (v1.7.0); warned about, never read",
        # The flat experimental-condition block (#450).  Spliced in from the
        # one registry rather than retyped: these columns are authored on
        # ms_samples, validated at load, and exported under these same names,
        # so a second hand-maintained copy would be a drift site with no
        # upside — which is how _SAMPLE_PROVENANCE_COLUMNS drifted twice.
        **CONDITION_FIELDS,
    }
)


#: How an observation's candidate allele set was obtained. This is the
#: authoritative vocabulary for scanner output, Python filters, and CLI
#: choices; keep those consumers on this one contract (#419).
MHC_ALLELE_PROVENANCE_VALUES = (
    "exact",
    "peptide_attribution",
    "sample_allele_match",
    "pmid_class_pool",
    "peptide_locus_match",
    "sample_locus_match",
    "pmid_locus_pool",
    "peptide_serotype_match",
    "sample_serotype_match",
    "pmid_serotype_pool",
    "haplotype_roster",
    "unmatched",
)


def _data_path(filename: str) -> str:
    return join(dirname(__file__), "data", filename)


def _asset_path(rel_path: str) -> str:
    """Resolve a *registry* data asset, fetching it if it is not installed.

    Mirrors :func:`hitlist.bulk_proteomics._bulk_data_path`.  ``_data_path``
    is a bare join with no fallback, so a registry-known file missing from
    the install raised ``FileNotFoundError`` out of ``pd.read_csv`` instead
    of being fetched from the ``data-assets-v1`` mirror (#348).

    Only for files listed in ``data_assets.yaml``.  The bundled YAML config
    (``pmid_overrides.yaml``, ``tissue_categories.yaml``,
    ``monoallelic_lines.yaml``) is never externalized and keeps using
    :func:`_data_path`.
    """
    from .downloads import packaged_or_fetched

    return str(packaged_or_fetched(_data_path(rel_path), basename(rel_path)))


@lru_cache(maxsize=1)
def load_pmid_overrides() -> dict[int, dict]:
    """Load PMID curation overrides from YAML.

    Validates that every ``mono_allelic_host`` name resolves to an entry
    in ``monoallelic_lines.yaml`` (typos would otherwise silently
    produce rows with a non-existent ``monoallelic_host`` string), and
    that no PMID is declared twice — the returned mapping is keyed by
    PMID, so a duplicate would discard an entire curated study (#438).
    Rejects any top-level or ``ms_samples`` key not declared in
    :data:`PMID_ENTRY_FIELDS` / :data:`MS_SAMPLE_FIELDS`, so a field
    nothing reads fails at load rather than in an audit (#373, #444).
    Warns on legacy YAML keys (``type:``, ``label:``) that were renamed
    to ``sample_label:`` / ``study_label:`` in v1.7.0.

    Returns
    -------
    dict[int, dict]
        Mapping from PMID to override dict with keys: study_label,
        override, note, and optionally tissue_overrides, donors,
        ms_samples, tissues.
    """
    import warnings

    entries = load_curation_yaml(_data_path("pmid_overrides.yaml"))

    known_hosts = {e["name"] for e in load_monoallelic_lines()}
    for e in entries:
        host = e.get("mono_allelic_host")
        if host and host not in known_hosts:
            raise ValueError(
                f"PMID {e.get('pmid')} has mono_allelic_host={host!r} but that "
                f"name is not in monoallelic_lines.yaml (known hosts: "
                f"{sorted(known_hosts)}).  Add the host to monoallelic_lines.yaml "
                f"or fix the typo."
            )
        # Legacy key detection (v1.7.0 rename)
        if "label" in e and "study_label" not in e:
            warnings.warn(
                f"PMID {e.get('pmid')}: YAML key 'label:' is deprecated, "
                f"use 'study_label:' (v1.7.0).  Value ignored.",
                DeprecationWarning,
                stacklevel=2,
            )
        warned_legacy_type = False
        # Accumulated in the one pass over ms_samples that already happens,
        # so the sample_group guards below do not re-walk the same list.
        group_sizes: dict[str, int] = {}
        ungrouped_labels: list[str] = []
        n_samples_in_entry = 0
        for i, sample in enumerate(e.get("ms_samples") or []):
            n_samples_in_entry += 1
            _grp = sample.get("sample_group")
            if _grp:
                group_sizes[str(_grp)] = group_sizes.get(str(_grp), 0) + 1
            else:
                ungrouped_labels.append(sample.get("sample_label", "?"))
            if "type" in sample and "sample_label" not in sample and not warned_legacy_type:
                warnings.warn(
                    f"PMID {e.get('pmid')}: ms_samples entry uses deprecated "
                    f"'type:' key, use 'sample_label:' (v1.7.0).  Value ignored.",
                    DeprecationWarning,
                    stacklevel=2,
                )
                warned_legacy_type = True  # one warning per PMID is enough
            unknown = sorted(set(sample) - set(MS_SAMPLE_FIELDS))
            if unknown:
                raise ValueError(
                    f"PMID {e.get('pmid')}: ms_samples[{i}] has unknown key(s) "
                    f"{unknown}.  Every ms_samples key must be declared in "
                    f"curation.MS_SAMPLE_FIELDS together with what reads it — an "
                    f"undeclared key is silently ignored by every consumer.  Fix the "
                    f"typo, or add the field and its reader."
                )
            sample_override = sample.get("override")
            if sample_override is not None and sample_override not in OVERRIDE_VALUES:
                raise ValueError(
                    f"PMID {e.get('pmid')}: ms_samples[{i}] override="
                    f"{sample_override!r} is invalid; expected null or one of "
                    f"{OVERRIDE_VALUES}"
                )
            try:
                sample_mhc_metadata(sample)
            except ValueError as exc:
                raise ValueError(f"PMID {e.get('pmid')}: ms_samples[{i}]: {exc}") from exc
        unknown_entry_keys = sorted(set(e) - set(PMID_ENTRY_FIELDS))
        if unknown_entry_keys:
            raise ValueError(
                f"PMID {e.get('pmid')}: unknown top-level key(s) {unknown_entry_keys}.  "
                f"Every key must be declared in curation.PMID_ENTRY_FIELDS together with "
                f"what reads it — an undeclared key is silently ignored by every consumer "
                f"(#444).  Fix the typo, or add the field and its reader."
            )
        # The flat condition block: per-record shape, then the study-scoped
        # identity and control-reference rules (#450).
        validate_study_conditions(e)
        attribution_scope = e.get("peptide_attribution_restrictions")
        if attribution_scope is not None and (
            not e.get("peptide_attributions")
            or not isinstance(attribution_scope, list)
            or not attribution_scope
            or any(
                not isinstance(value, str) or not value.strip() or value != value.strip()
                for value in attribution_scope
            )
            or len({value.casefold() for value in attribution_scope}) != len(attribution_scope)
        ):
            raise ValueError(
                f"PMID {e.get('pmid')}: peptide_attribution_restrictions requires a peptide "
                "map and a nonempty list of distinct, stripped restriction strings"
            )
        elution_map = e.get("elution_condition_ids", {})
        if not isinstance(elution_map, dict):
            raise ValueError(f"PMID {e.get('pmid')}: elution_condition_ids must be a mapping")
        condition_ids = {
            sample.get("condition_id")
            for sample in e.get("ms_samples") or []
            if sample.get("profiled", True)
        }
        for statement, targets in elution_map.items():
            if (
                not isinstance(statement, str)
                or not statement.strip()
                or statement != statement.strip()
            ):
                raise ValueError(
                    f"PMID {e.get('pmid')}: elution statement must be nonempty, stripped text"
                )
            if (
                not isinstance(targets, list)
                or not targets
                or any(not isinstance(target, str) or not target for target in targets)
                or len(set(targets)) != len(targets)
                or not set(targets) <= condition_ids
            ):
                raise ValueError(
                    f"PMID {e.get('pmid')}: elution targets must be distinct condition IDs "
                    "of profiled samples in this study"
                )
        if group_sizes and ungrouped_labels:
            raise ValueError(
                f"PMID {e.get('pmid')}: sample_group is curated on "
                f"{sum(group_sizes.values())} of {n_samples_in_entry} ms_samples; it must be "
                f"on all or none.  Missing on {ungrouped_labels}.  A partially grouped study "
                f"falls back to ungrouped attribution, silently losing the grouping (#359)."
            )
        arm_resolution = e.get("arm_resolution")
        if arm_resolution is not None and arm_resolution not in ARM_RESOLUTION_VALUES:
            raise ValueError(
                f"PMID {e.get('pmid')}: arm_resolution={arm_resolution!r} is invalid; "
                f"expected one of {ARM_RESOLUTION_VALUES}"
            )
        if e.get("arm_resolution_note") and not arm_resolution:
            raise ValueError(
                f"PMID {e.get('pmid')}: arm_resolution_note is set without "
                f"arm_resolution.  The note explains the verdict; it is not one."
            )
        if len(group_sizes) > 1 and all(n == 1 for n in group_sizes.values()):
            raise ValueError(
                f"PMID {e.get('pmid')}: every sample_group holds exactly one arm "
                f"({sorted(group_sizes)}).  A one-to-one group/arm mapping makes the "
                f"group stage select an *arm* from narrative fields, which is precisely "
                f"what #354 forbids — narrative names every arm on every row.  Group "
                f"arms that share a sample system, or drop sample_group entirely."
            )
        entry_override = e.get("override")
        if entry_override is not None and entry_override not in OVERRIDE_VALUES:
            raise ValueError(
                f"PMID {e.get('pmid')}: override={entry_override!r} is invalid; "
                f"expected null or one of {OVERRIDE_VALUES}"
            )
        for i, rule in enumerate(e.get("rules") or []):
            rule_override = rule.get("override")
            if rule_override is not None and rule_override not in OVERRIDE_VALUES:
                raise ValueError(
                    f"PMID {e.get('pmid')}: rules[{i}].override={rule_override!r} is "
                    f"invalid; expected null or one of {OVERRIDE_VALUES}"
                )
        evidence = e.get("restriction_evidence")
        if evidence is not None and evidence not in RESTRICTION_EVIDENCE_VALUES:
            raise ValueError(
                f"PMID {e.get('pmid')}: restriction_evidence={evidence!r} is invalid; "
                f"expected one of {RESTRICTION_EVIDENCE_VALUES}"
            )
        for i, rule in enumerate(e.get("restriction_evidence_rules") or []):
            rule_evidence = rule.get("evidence")
            if rule_evidence not in RESTRICTION_EVIDENCE_VALUES:
                raise ValueError(
                    f"PMID {e.get('pmid')}: restriction_evidence_rules[{i}].evidence="
                    f"{rule_evidence!r} is invalid; expected one of "
                    f"{RESTRICTION_EVIDENCE_VALUES}"
                )

    # A PMID curated twice is a silent data loss, not a merge: the dict
    # comprehension below keeps the last entry, so the earlier block's
    # ``ms_samples`` and study metadata vanish with nothing raised.  That
    # is how #307's source-organism blocks displaced two whole studies
    # (five sample records) with no error and no warning (#438).
    # Consolidate a second block into the first instead.
    seen_pmids = Counter(int(e["pmid"]) for e in entries)
    duplicates = sorted(pmid for pmid, count in seen_pmids.items() if count > 1)
    if duplicates:
        raise ValueError(
            f"pmid_overrides.yaml declares {len(duplicates)} PMID(s) more than once: "
            f"{duplicates}.  Merge each into a single entry — a later entry silently "
            f"replaces the earlier one, discarding its ms_samples."
        )

    result = {int(e["pmid"]): e for e in entries}
    # Literature-derived species contexts live in their own registry so the
    # mismatch flags cannot validate themselves.  Validate their arm links
    # here, after every condition_id is known, without making that leaf module
    # import the curation stack and create a cycle.
    from .species_contexts import validate_species_context_condition_links

    validate_species_context_condition_links(result)
    return result


@lru_cache(maxsize=1)
def ms_excluded_pmids() -> frozenset[int]:
    """PMIDs curated as *not* mass-spectrometry elution experiments.

    The reader for the study-level ``exclude_from_ms`` flag.  A curator
    who reads a paper and concludes it is a yeast-display selection, a
    peptide microarray, a computational prediction, or a refolding /
    crystallography experiment sets the flag; :func:`hitlist.builder.
    build_observations` drops those rows from the MS index (#444).

    Scoped to MS evidence on purpose.  These studies still measure real
    peptide-MHC binding, and their rows in ``binding.parquet`` are kept:
    the flag says "this is not an elution experiment", not "distrust this
    publication".  The builder applies it to the MS frame only, so the
    two indexes cannot drift on this point.

    Returns
    -------
    frozenset[int]
        PMIDs to exclude from the MS observation index.

    Raises
    ------
    ValueError
        If any entry sets ``exclude_from_ms`` to a non-boolean value.  YAML
        parses ``1`` as an int and ``"true"`` as a str, and an ``is True``
        check silently treats either as "not excluded" with no error —
        exactly the failure mode this field's own docstring warns about.
        Failing loudly here is cheaper than a study quietly staying in the
        MS corpus because a curator wrote the wrong token.
    """
    entries = load_pmid_overrides()
    bad = sorted(
        pmid
        for pmid, entry in entries.items()
        if "exclude_from_ms" in entry and not isinstance(entry["exclude_from_ms"], bool)
    )
    if bad:
        raise ValueError(
            f"pmid_overrides.yaml sets exclude_from_ms to a non-boolean value for "
            f"PMID(s) {bad}: only `true` / `false` are valid.  A value like `1` or "
            f'`"true"` would silently fail to exclude the study.'
        )
    return frozenset(
        pmid for pmid, entry in entries.items() if entry.get("exclude_from_ms") is True
    )


@lru_cache(maxsize=1)
def load_tissue_categories() -> dict[str, frozenset[str]]:
    """Load tissue category definitions from YAML.

    Returns
    -------
    dict[str, frozenset[str]]
        Keys: ``reproductive``, ``reproductive_female``, ``reproductive_male``,
        ``thymus``, ``activated_apc_cell_names``, ``activated_apc_tissues``.
    """
    data = load_curation_yaml(_data_path("tissue_categories.yaml"))
    return {
        "reproductive": frozenset(data.get("reproductive", [])),
        "reproductive_female": frozenset(data.get("reproductive_female", [])),
        "reproductive_male": frozenset(data.get("reproductive_male", [])),
        "thymus": frozenset(data.get("thymus", [])),
        "activated_apc_cell_names": frozenset(data.get("activated_apc_cell_names", [])),
        "activated_apc_tissues": frozenset(data.get("activated_apc_tissues", [])),
    }


@lru_cache(maxsize=1)
def load_tissue_groups() -> dict[str, tuple[str, ...]]:
    """Anatomical roll-up groups for the ``--by-tissue`` display: ``{umbrella:
    (member organs, ...)}`` (e.g. ``"GI tract" -> ("Esophagus", "Colon", ...)``).

    Display-only; not used for classification.  Member organs (and the umbrella
    term itself) collapse to the umbrella by default.  See ``tissue_categories``.
    """
    data = load_curation_yaml(_data_path("tissue_categories.yaml"))
    return {umb: tuple(members or []) for umb, members in (data.get("tissue_groups") or {}).items()}


#: Provenance fields a PMID override may curate; the scanner fills each ONLY
#: where the IEDB/CEDAR row left it blank/"unidentified" (#307, #314).
_PROVENANCE_FIELDS = (
    "source_organism",
    "species",
    "source_tissue",
    "cell_name",
    "disease",
    "culture_condition",
)


@cache
def pmid_provenance(pmid) -> dict:
    """Per-PMID curated provenance fills for fields IEDB/CEDAR left blank.

    Some datasets omit the source proteome, source tissue, cell line, or disease
    even when the paper states them (self-peptidomes with blank source organism;
    epitope-identification papers with no recorded tissue/cell line). A PMID
    entry in ``pmid_overrides.yaml`` may carry any of ``source_organism`` /
    ``species`` / ``source_tissue`` / ``cell_name`` / ``disease``; the scanner
    fills each PER PAPER, ONLY where the row's value is unresolved (#307, #314).

    This is explicit per-paper curation, never a heuristic — e.g. random-library
    refolding assays (pig SLA-I, possum) deliberately get no ``source_organism``
    so their synthetic source stays blank rather than being mislabeled.

    Returns a dict of the curated fields present (empty if no entry / no fields).
    """
    if not pmid:
        return {}
    try:
        key = int(pmid)
    except (TypeError, ValueError):
        return {}
    entry = load_pmid_overrides().get(key)
    if not entry:
        return {}
    out = {f: str(entry[f]) for f in _PROVENANCE_FIELDS if entry.get(f)}
    if "source_organism" in out and "species" not in out:
        out["species"] = out["source_organism"]
    return out


def pmid_source_organism(pmid) -> tuple[str, str]:
    """Per-PMID curated ``(source_organism, species)`` (#307). Thin wrapper over
    :func:`pmid_provenance`; the scanner fills these where the row is blank."""
    p = pmid_provenance(pmid)
    return p.get("source_organism", ""), p.get("species", "") or p.get("source_organism", "")


@cache
def pmid_mhc_species_context(pmid) -> str:
    """Canonical curated species context for parsing an observation's MHC.

    The context is deliberately limited to explicit PMID curation. Raw source
    organism and host strings are separate biological axes and must not be
    guessed into an MHC species. Explicitly prefixed restrictions still win
    when they describe a legitimate engineered-MHC system.
    """
    provenance = pmid_provenance(pmid)
    return normalize_species(provenance.get("species", ""))


# ── Cached mhcgnomes parse ─────────────────────────────────────────────────


@cache
def _cached_parse(mhc_restriction: str, species_context: str = ""):
    """Cache mhcgnomes parse results.

    The cache key includes ``species_context``: a bare or ambiguous MHC
    designation can resolve differently in cattle, chicken, or the default
    human namespace. Uses an unbounded cache because the distinct
    ``(designation, context)`` vocabulary is small relative to the corpus.
    """
    try:
        from mhcgnomes import parse

        if species_context:
            return parse(mhc_restriction, species=species_context)
        return parse(mhc_restriction)
    except Exception:
        return None


@cache
def species_compatible(a: str, b: str) -> bool:
    """Whether two mhcgnomes species are equal or ancestor-compatible.

    Compatibility is directional only in the ontology implementation, so ask
    both ways. Sibling species remain incompatible even when they share a
    genus-level ancestor; this prevents a specific cattle context from
    accepting a specific buffalo result.
    """
    if not a or not b:
        return False
    left = Species.get(a)
    right = Species.get(b)
    if left is None or right is None:
        return False
    return bool(left.compatible_with(right) or right.compatible_with(left))


@cache
def _parse_with_context(mhc_restriction: str, species_context: str = ""):
    """Return ``(result, used_context, incompatible_guess_replaced)``.

    Parse without context first so an explicit HLA/BoLA/etc. designation can
    survive a legitimate cross-species experiment. If a context is available
    and differs from that result, try the constrained parse. A successful
    constrained result refines generic or inferred nomenclature; a failed one
    falls back to the explicit unconstrained result.
    """
    text = (mhc_restriction or "").strip()
    context = normalize_species(species_context)
    unconstrained = _cached_parse(text)
    if not context:
        return unconstrained, False, False

    unconstrained_species = str(getattr(getattr(unconstrained, "species", None), "name", ""))
    if unconstrained_species == context:
        return unconstrained, False, False

    contextual = _cached_parse(text, context)
    if contextual is None:
        return unconstrained, False, False

    incompatible = bool(
        unconstrained_species and not species_compatible(unconstrained_species, context)
    )
    return contextual, True, incompatible


@dataclass(frozen=True)
class MhcAnnotation:
    """Resolved identity and provenance for one MHC restriction.

    ``mhc_class_source`` is ``derived`` for one molecule, ``donor_set``
    for a consistent semicolon-separated molecule set, or ``export`` when
    the source-reported class must be retained. ``mhc_species_source`` uses
    mhcgnomes' ``explicit``/``default``/``inferred`` vocabulary plus
    ``context``, ``mixed``, and ``unresolved``. Resolution and serotype
    fields come from the same final restriction, so callers can persist
    :meth:`as_record_fields` atomically without metadata drift.
    """

    restriction: str
    mhc_species: str
    mhc_species_source: str
    mhc_species_context_disagrees: bool
    mhc_class: str
    mhc_class_reported: str
    mhc_class_source: str
    mhc_class_corrected: bool
    allele_resolution: str
    serotype: str
    serotypes: str
    serotype_source: str

    def as_record_fields(self) -> dict[str, bool | str]:
        """Return the persisted scanner columns for this annotation."""
        return {
            "mhc_restriction": self.restriction,
            "mhc_species": self.mhc_species,
            "mhc_species_source": self.mhc_species_source,
            "mhc_species_context_disagrees": self.mhc_species_context_disagrees,
            "mhc_class": self.mhc_class,
            "mhc_class_reported": self.mhc_class_reported,
            "mhc_class_source": self.mhc_class_source,
            "mhc_class_corrected": self.mhc_class_corrected,
            "allele_resolution": self.allele_resolution,
            "serotype": self.serotype,
            "serotypes": self.serotypes,
            "serotype_source": self.serotype_source,
        }


def _class_scoped_haplotype(parsed) -> str:
    """Class of a populated haplotype roster, or blank when it is ambiguous."""
    if not isinstance(parsed, Haplotype) or not parsed.alleles:
        return ""
    if parsed.is_class1 and not parsed.is_class2:
        return "I"
    if parsed.is_class2 and not parsed.is_class1:
        return "II"
    return ""


def _molecule_class(parsed) -> str:
    haplotype_class = _class_scoped_haplotype(parsed)
    if haplotype_class:
        return haplotype_class
    if type(parsed).__name__ not in _MHC_MOLECULE_TYPES:
        return ""
    return _FINE_MHC_CLASS_TO_TOKEN.get(str(getattr(parsed, "mhc_class", "")), "")


def _serotype_source(
    component_serotypes: tuple[str, ...], n_parts: int, allele_resolution: str
) -> str:
    """Classify whether a row's serotype is primary data or a projection.

    See :data:`SEROTYPE_SOURCE_VALUES`. The distinction is not recoverable
    from the serotype itself: a serologically typed study reporting ``HLA-A2``
    and a sequenced study reporting ``HLA-A*02:01`` produce the identical
    ``serotypes`` cell, one measured and one computed (#458).
    """
    if not component_serotypes:
        return ""
    if n_parts > 1:
        return "donor_set"
    return "reported" if allele_resolution == "serological" else "derived"


@cache
def resolve_mhc_annotation(
    mhc_restriction: str,
    reported_mhc_class: str = "",
    species_context: str = "",
) -> MhcAnnotation:
    """Resolve a restriction's normalized identity, class, and provenance.

    Parameters
    ----------
    mhc_restriction
        Source restriction or a semicolon-separated donor candidate set.
    reported_mhc_class
        Source-reported class. Preserved verbatim in ``mhc_class_reported``
        and used only when molecule-level derivation is unavailable.
    species_context
        Optional curated study species. It constrains ambiguous parsing but
        never erases an explicit cross-species MHC designation that cannot be
        parsed in that context.

    Returns
    -------
    MhcAnnotation
        Immutable normalized identity, provenance, allele resolution, and
        serotype projection. :meth:`MhcAnnotation.as_record_fields` returns
        the complete set of scanner columns owned by this resolver.
    """
    text = (mhc_restriction or "").strip()
    reported_raw = (reported_mhc_class or "").strip()
    reported = normalize_mhc_class_token(reported_raw)
    parts = [part.strip() for part in text.split(";") if part.strip()] if ";" in text else [text]

    normalized_parts: list[str] = []
    parsed_parts: list = []
    species: set[str] = set()
    species_sources: set[str] = set()
    context_disagrees = False
    for part in parts:
        parsed, used_context, incompatible = _parse_with_context(part, species_context)
        parsed_parts.append(parsed)
        if type(parsed).__name__ in _MHC_MOLECULE_TYPES:
            normalized_parts.append(parsed.to_string())
        else:
            normalized_parts.append(part)
        parsed_species = str(getattr(getattr(parsed, "species", None), "name", ""))
        if parsed_species:
            species.add(parsed_species)
        source = "context" if used_context else str(getattr(parsed, "species_source", "") or "")
        if source:
            species_sources.add(source)
        context_disagrees = context_disagrees or incompatible

    normalized = ";".join(normalized_parts) if len(parts) > 1 else normalized_parts[0]
    resolved_species = ";".join(sorted(species))
    if not species_sources:
        species_source = "unresolved"
    elif len(species_sources) == 1:
        species_source = next(iter(species_sources))
    else:
        species_source = "mixed"

    derived_class = ""
    class_source = "export"
    if len(parts) > 1:
        component_classes = [_molecule_class(parsed) for parsed in parsed_parts]
        if all(component_classes) and len(set(component_classes)) == 1:
            derived_class = component_classes[0]
            class_source = "donor_set"
    elif parsed_parts:
        derived_class = _molecule_class(parsed_parts[0])
        if derived_class:
            class_source = "derived"

    resolved_class = derived_class or reported
    corrected = bool(derived_class and reported and derived_class != reported)
    component_serotypes = tuple(
        dict.fromkeys(
            serotype for part in normalized_parts for serotype in allele_to_all_serotypes(part)
        )
    )
    resolution = classify_allele_resolution(normalized)
    return MhcAnnotation(
        restriction=normalized,
        mhc_species=resolved_species,
        mhc_species_source=species_source,
        mhc_species_context_disagrees=context_disagrees,
        mhc_class=resolved_class,
        mhc_class_reported=reported_raw,
        mhc_class_source=class_source,
        mhc_class_corrected=corrected,
        allele_resolution=resolution,
        serotype=component_serotypes[0] if component_serotypes else "",
        serotypes=";".join(component_serotypes),
        serotype_source=_serotype_source(component_serotypes, len(parts), resolution),
    )


# ── MHC species ────────────────────────────────────────────────────────────


@cache
def classify_mhc_species(mhc_restriction: str, species_context: str = "") -> str:
    """Determine the species of an MHC restriction annotation.

    Uses mhcgnomes when available, falls back to prefix matching.

    Cached by input string: ~100k unique mhc_restriction values across
    millions of IEDB rows, and the mhcgnomes parse + species lookup is
    one of the hottest per-row calls in the scanner.

    Parameters
    ----------
    mhc_restriction
        IEDB "MHC Restriction" field value.

    Returns
    -------
    str
        Species name (e.g. ``"Homo sapiens"``, ``"Mus musculus"``),
        or empty string if undetermined.
    """
    if not mhc_restriction:
        return ""

    result, _, _ = _parse_with_context(mhc_restriction, species_context)
    if result is not None and hasattr(result, "species"):
        return result.species.name

    # Regex fallback
    if mhc_restriction.startswith("HLA"):
        return "Homo sapiens"
    if mhc_restriction.startswith(("H-2", "H2")):
        return "Mus musculus"
    return ""


# ── Species normalization ─────────────────────────────────────────────────

# Hardcoded fallback when mhcgnomes is not installed.
_SPECIES_ALIASES: dict[str, str] = {
    "human": "Homo sapiens",
    "homo sapiens": "Homo sapiens",
    "mouse": "Mus musculus",
    "mus musculus": "Mus musculus",
    "rat": "Rattus norvegicus",
    "rattus norvegicus": "Rattus norvegicus",
    "pig": "Sus scrofa",
    "sus scrofa": "Sus scrofa",
    "cattle": "Bos taurus",
    "cow": "Bos taurus",
    "bos taurus": "Bos taurus",
    "dog": "Canis lupus",
    "canis lupus": "Canis lupus",
    "canis lupus familiaris": "Canis lupus",
    "chicken": "Gallus gallus",
    "gallus gallus": "Gallus gallus",
    "rhesus macaque": "Macaca mulatta",
    "macaca mulatta": "Macaca mulatta",
}


@lru_cache(maxsize=256)
def normalize_species(raw: str) -> str:
    """Normalize a species string to its canonical scientific name.

    Accepts any common format — scientific name, common name,
    underscore-separated, or IEDB parenthetical style — and returns
    a consistent canonical form using ``mhcgnomes`` when available.

    Examples::

        normalize_species("human")                    # "Homo sapiens"
        normalize_species("Homo sapiens (human)")     # "Homo sapiens"
        normalize_species("homo_sapiens")             # "Homo sapiens"
        normalize_species("Mus musculus (mouse)")     # "Mus musculus"

    Parameters
    ----------
    raw
        Species string in any supported format.

    Returns
    -------
    str
        Canonical species name, or the stripped input if unrecognized.
        Empty string for empty input.
    """
    if not raw:
        return ""
    cleaned = raw.strip()
    if not cleaned:
        return ""

    # Try mhcgnomes first — it handles scientific names, common names,
    # underscores, and even parenthetical IEDB format.
    try:
        from mhcgnomes import Species

        result = Species.get(cleaned)
        if result is not None:
            return result.name
    except ImportError:
        pass

    # Fallback: normalize to lowercase with spaces for alias lookup
    key = cleaned.lower().replace("_", " ")

    # Strip parenthetical suffix: "Homo sapiens (human)" → "homo sapiens"
    paren = key.find("(")
    if paren > 0:
        key = key[:paren].strip()

    if key in _SPECIES_ALIASES:
        return _SPECIES_ALIASES[key]

    # Return stripped form (without parenthetical) for unrecognized species
    paren = cleaned.find("(")
    return cleaned[:paren].strip() if paren > 0 else cleaned


# Vertebrate host genera that bear classical MHC molecules. The chimeric
# flag is only meaningful when BOTH the source proteome and the MHC come
# from this set — otherwise we have either ordinary pathogen-on-host
# biology (bacterium/virus/parasite source) or an unrecognized species,
# neither of which constitutes an engineered cross-species system.
#
# This whitelist is small and stable by design: the closed set of
# vertebrate species seen as ``mhc_species`` in the curated index is
# enumerated explicitly so the rule is robust against the long tail of
# bacterial / viral source names that no pattern-based pathogen filter
# can fully cover.
_MHC_BEARING_HOST_GENERA = frozenset(
    {
        "homo",
        "mus",
        "rattus",
        "canis",
        "felis",
        "sus",
        "bos",
        "equus",
        "gallus",
        "anas",
        "macaca",
        "pan",
        "xenopus",
        "sarcophilus",
        "trichosurus",
        "danio",
        "ovis",
        "capra",
        "oryctolagus",
        "mesocricetus",
        "cricetulus",
        "cavia",
    }
)


@cache
def is_chimeric_system(source_organism: str, mhc_species: str) -> bool:
    """True iff source proteome and MHC come from different vertebrate-host genera.

    Engineered chimeric systems deliberately decouple the proteome species
    from the MHC species: HLA-transgenic rats / mice, mono-allelic mouse-MHC
    transfectants in human cells, NetH2pan binding-prediction training data
    (human peptides on mouse MHC), AAV-transduced allogeneic HLA expression,
    etc. Downstream consumers want to filter these out (or keep only these,
    for chimeric-aware training).

    Returns ``False`` when:

    - either side normalizes to empty (``normalize_species`` already
      handles None / empty / whitespace).
    - either side resolves to a genus outside the MHC-bearing vertebrate
      host whitelist — viral / bacterial / parasite source on a host MHC
      is normal infection biology, not an engineered cross-species system,
      and IEDB sentinels like ``"unidentified"`` / ``"unknown"`` fall
      through to the same rejection without an explicit allowlist.
    - normalized genus tokens match — substrains and subspecies
      (``"Mus musculus C57BL/6"`` vs ``"Mus musculus"``;
      ``"Canis lupus familiaris"`` vs ``"Canis sp."``) are not chimeric.

    Cached because the (source_organism, mhc_species) tuple repeats heavily
    across an observations index of millions of rows but resolves to only a
    couple hundred unique pairs.
    """
    src_norm = normalize_species(source_organism)
    mhc_norm = normalize_species(mhc_species)
    if not src_norm or not mhc_norm:
        return False
    src_genus = src_norm.split()[0].lower()
    mhc_genus = mhc_norm.split()[0].lower()
    return (
        src_genus in _MHC_BEARING_HOST_GENERA
        and mhc_genus in _MHC_BEARING_HOST_GENERA
        and src_genus != mhc_genus
    )


@cache
def is_engineered_mhc(source_organism: str, mhc_species: str, host: str) -> bool:
    """True iff the MHC molecule is heterologous to the host cells / tissue.

    Distinguishes engineered-MHC systems (HLA-transgenic rats, NetH2pan
    training, allogeneic HLA transfectants — where the cells live in one
    species but display the MHC of another) from heterologous-antigen
    studies (Lewis-rat EAE with guinea-pig MBP, bovine-allergen on HLA —
    where the cells use their *native* MHC but present a foreign protein).

    Both scenarios trigger :func:`is_chimeric_system` because in both
    ``source_organism != mhc_species``. The discriminator is the IEDB
    ``host`` field: in an engineered-MHC system the host genus matches
    the source proteome (the cells are native, the MHC is transgenic);
    in a heterologous-antigen system the host genus matches the MHC
    species (the cells are native, the antigen is foreign).

    Returns ``False`` when:

    - the row is not chimeric (same source / MHC genus → no question of
      engineered MHC).
    - ``host`` is empty / unrecognized (chimerism cannot be classified
      without the host axis; conservative default).
    - host genus matches the MHC genus (heterologous antigen, not
      engineered MHC).

    Cached on the (source, mhc, host) triple — same call shape and
    cardinality as :func:`is_chimeric_system`.
    """
    if not is_chimeric_system(source_organism, mhc_species):
        return False
    host_norm = normalize_species(host)
    if not host_norm:
        return False
    host_genus = host_norm.split()[0].lower()
    if host_genus not in _MHC_BEARING_HOST_GENERA:
        return False
    src_genus = normalize_species(source_organism).split()[0].lower()
    mhc_genus = normalize_species(mhc_species).split()[0].lower()
    # Engineered MHC: cells are from the source species, MHC differs.
    return host_genus == src_genus and host_genus != mhc_genus


@cache
def is_xenograft(source_organism: str, host: str, mhc_species: str) -> bool:
    """True iff the eluted cells are a different vertebrate genus than the host.

    A xenograft decouples the **proteome species** (the cells the peptide was
    sequenced from) from the **host species** the cells lived in at MS sampling
    — e.g. a human or dog tumor grown in an NSG mouse. This is the host-axis
    counterpart of :func:`is_engineered_mhc`.

    The discriminator that separates a true xenograft from a *heterologous
    antigen* study (a foreign protein presented by the host's own native
    cells — e.g. bovine allergen on a human-MHC human cell) is the same as in
    :func:`is_engineered_mhc`: the IEDB ``host`` field. In a xenograft the
    grafted cells are NOT the host's own, so the displayed MHC is not the
    host's native MHC (``host`` genus differs from both the proteome and the
    MHC). In a heterologous-antigen study the cells are native (``host`` genus
    matches the ``mhc_species`` genus) and only the antigen is foreign.

    Returns ``False`` when any side normalizes to empty, any genus is outside
    the MHC-bearing vertebrate whitelist (a viral / bacterial *antigen* source
    on an animal host is ordinary infection biology, not a xenograft), the
    proteome and host genera match (native cells / substrains), or the host
    genus matches the MHC genus (heterologous antigen on native cells).

    Cached on the (source, host, mhc) triple — same call shape and cardinality
    as :func:`is_engineered_mhc`.
    """
    src_norm = normalize_species(source_organism)
    host_norm = normalize_species(host)
    mhc_norm = normalize_species(mhc_species)
    if not src_norm or not host_norm or not mhc_norm:
        return False
    src_genus = src_norm.split()[0].lower()
    host_genus = host_norm.split()[0].lower()
    mhc_genus = mhc_norm.split()[0].lower()
    return (
        src_genus in _MHC_BEARING_HOST_GENERA
        and host_genus in _MHC_BEARING_HOST_GENERA
        and mhc_genus in _MHC_BEARING_HOST_GENERA
        and src_genus != host_genus
        and host_genus != mhc_genus
    )


# ── Restrictions outside peptide-MHC presentation (#228, #230) ───────────
#
# CD1, MR1, MIC, ULBP, RAET1, NKG2, and HFE are not peptide presenters.
# CD1 (a/b/c/d/e) presents lipids and glycolipids to NKT and CD1-restricted
# T cells; MR1 presents riboflavin-derived small-molecule metabolites to MAIT
# cells; MICA/MICB/RAET1/ULBP are stress-induced ligands for the NKG2D
# activating receptor on NK cells; HFE is involved in iron regulation.
#
# IEDB curates these alongside peptide-MHC rows but populates the
# ``peptide`` column with chemical names ("L-idopyranose 6-monomycolate")
# or compound identifiers ("HS44") rather than amino-acid sequences.
# Downstream consumers iterating ``observations.parquet`` for peptide-level
# work (motif analyses, length distributions, source-protein mapping,
# peptide-prediction models) silently produce nonsense on these rows.
#
# H2-M3 is intentionally excluded — it IS a class Ib peptide presenter
# (N-formyl peptides), so its single row in the corpus carries a real
# peptide sequence.
_NON_PEPTIDE_MHC_RE = re.compile(
    r"\bCD1(?:[a-eA-E]\d?|-\d)?\b"  # CD1, CD1a..e, CD1d2, CD1-2
    r"|\bMR1\b"
    r"|\bMICA\b|\bMICB\b"
    r"|\bRAET1[A-Z]?\b"
    r"|\bULBP\d?\b"
    # NKG2 is a NK-cell *receptor* family, not an MHC molecule — it
    # should never appear in IEDB's MHC-restriction column. Kept
    # defensive in case future curation drift puts it there; matches
    # the issue's stated whitelist.
    r"|\bNKG2[A-C]\b"
    # Yuan et al., Nature 2023, PMID 37674084, DOI 10.1038/s41586-023-06525-3:
    # BTN3A1 senses intracellular phosphoantigens in cooperation with BTN2A1;
    # Figure 1 also implicates BTN3A2/3. These are not peptide-MHC presenters.
    # Enumerate supported genes rather than classify every butyrophilin.
    r"|\bBTN3A[123]\b|\bBTN2A1\b"
    r"|\bHFE\b",
    re.IGNORECASE,
)


@cache
def is_non_peptide_ligand(mhc_restriction: str) -> bool:
    """Whether a restriction belongs to a known non-peptide-MHC system.

    Detects CD1 family, MR1, MIC{A,B}, RAET1*, ULBP*, NKG2[A-C], HFE,
    BTN3A1/2/3 and BTN2A1
    in any normalized restriction string ("mouse-CD1d", "human-MR1",
    "cattle-CD1b3", "chicken-CD1-2", "human-MR1 K43A mutant", etc.).
    Classical and class-Ib peptide presenters (HLA-A/B/C/E/F/G, H2-K/D/L,
    H2-Q*, H2-T*, H2-M3, Patr-AL, BoLA-*) are not flagged.

    Rows flagged here carry lipid, glycolipid, or small-molecule
    identifiers in the ``peptide`` column, not amino-acid sequences.
    Default ``load_observations`` behavior excludes them; opt-in via
    ``exclude_non_peptide_ligand=False``.

    Cached on the unique mhc_restriction vocabulary (~hundreds of values
    across millions of rows).
    """
    if not mhc_restriction:
        return False
    return bool(_NON_PEPTIDE_MHC_RE.search(mhc_restriction))


# ── Allele normalization ──────────────────────────────────────────────────


@lru_cache(maxsize=4096)
def normalize_allele(raw: str, species_context: str = "") -> str:
    """Normalize an MHC allele string to canonical Species-Gene[*allele] form.

    Uses mhcgnomes to parse and re-serialize.  Handles HLA, H-2 (mouse),
    Saha (Tasmanian devil), Mamu (rhesus), SLA (pig), BoLA (cow), DLA
    (dog), Patr (chimp), and any other species mhcgnomes supports.

    Examples::

        normalize_allele("HLA-A*02:01")        # "HLA-A*02:01"
        normalize_allele("H-2Kb")              # "H2-K*b"
        normalize_allele("SLA-1*0201")         # "SLA-1*02:01"
        normalize_allele("Saha-UA")            # "Saha-UA"

    Returns the input stripped for unparseable strings (e.g. "HLA class I").
    """
    if not raw:
        return ""
    cleaned = raw.strip()
    if not cleaned:
        return ""

    result, _, _ = _parse_with_context(cleaned, species_context)
    # Only return normalized form for actual alleles/genes/pairs
    # (not generic Species or Class-only designations like "HLA class I")
    if result is not None and type(result).__name__ in _MHC_MOLECULE_TYPES:
        return result.to_string()

    return cleaned


@cache
def _identity_alias_parser():
    from mhcgnomes.parser import Parser

    return Parser(use_allele_aliases=True)


def _resolve_allele_candidate(parsed):
    from mhcgnomes import Allele, Pair

    if isinstance(parsed, Pair):
        return parsed.copy(
            alpha=_resolve_allele_candidate(parsed.alpha),
            beta=_resolve_allele_candidate(parsed.beta),
        )
    if isinstance(parsed, Allele):
        target = _identity_alias_parser().transform_parse_candidate(parsed)
        if isinstance(target, Allele):
            target = target.restrict_allele_fields(parsed.num_allele_fields)
            if target.gene != parsed.gene or target.allele_fields[:2] != parsed.allele_fields[:2]:
                return target
    return parsed


@lru_cache(maxsize=8192)
def resolve_allele_identity(raw: str, species_context: str = "") -> str:
    """Resolve retired designations for matching, retaining reported precision.

    Unlike :func:`normalize_allele`, this is a derived identity, never a
    replacement for the reported restriction. Only a gene or first-two-field
    rename is applied; alias-table field extensions cannot add typing depth.
    Mutations remain on their original chains (requires mhcgnomes >=3.64.3).
    Semicolon-separated candidate sets are deduplicated in source order.

    IPD-IMGT/HLA's Deleted_alleles.txt records B*4401 as identical to
    B*44:02:01:01 (HLA00317, March 1994). A reported B*44:01 therefore has
    derived identity B*44:02, without claiming four-field typing (#456).
    """
    if not raw or not raw.strip():
        return ""
    if ";" in raw:
        return ";".join(
            dict.fromkeys(
                resolve_allele_identity(part, species_context)
                for part in raw.split(";")
                if part.strip()
            )
        )
    parsed, _, _ = _parse_with_context(raw.strip(), species_context)
    if type(parsed).__name__ in _MHC_MOLECULE_TYPES:
        return _resolve_allele_candidate(parsed).to_string()
    return normalize_allele(raw, species_context)


# ── MHC class (mhcgnomes-derived) ──────────────────────────────────────────

#: mhcgnomes reports a fine-grained class taxonomy.  Map it onto the three
#: tokens this corpus uses.  ``Ib`` / ``Ic`` / ``Id`` are the non-classical
#: class-I families (HLA-E/F/G, H2-Q/T/M, CD1, MR1); folding them into ``I``
#: would make ``--mhc-class I`` silently sweep up HLA-E rows, so they keep
#: their own token.
_FINE_MHC_CLASS_TO_TOKEN: dict[str, str] = {
    "Ia": "I",
    "Ib": "non-classical",
    "Ic": "non-classical",
    "Id": "non-classical",
    "IIa": "II",
    "IIb": "II",
    "I": "I",
    "II": "II",
}

#: mhcgnomes result types that name an actual MHC molecule.  Everything else
#: (``Species``, ``MhcClass``, ``Haplotype``) is either too coarse or a false
#: positive — notably ``parse("n/a")`` returns a *rat haplotype* ``RT1-n/A``,
#: so free-text fields must never be accepted on "it parsed" alone.
_MHC_MOLECULE_TYPES = frozenset({"Allele", "Gene", "Pair"})

#: Curators write ``non-classical``; IEDB exports write ``non classical``.
_MHC_CLASS_TOKEN_ALIASES: dict[str, str] = {
    "i": "I",
    "ii": "II",
    "non classical": "non-classical",
    "non-classical": "non-classical",
    "nonclassical": "non-classical",
}


@cache
def normalize_mhc_class_token(value: str) -> str:
    """Canonicalize a curated / IEDB ``mhc_class`` spelling.

    The YAML and the IEDB export disagree on the non-classical token —
    ``non-classical`` vs ``non classical`` — which meant the two could
    never compare equal and non-classical samples were unreachable from
    the observation join (issue #363).  Compound ``I+II`` values are
    normalized component-wise and rejoined.
    """
    text = (value or "").strip()
    if not text:
        return ""
    parts = [p.strip() for p in text.split("+") if p.strip()]
    out = [_MHC_CLASS_TOKEN_ALIASES.get(p.lower(), p) for p in parts]
    return "+".join(out)


@cache
def mhc_class_spellings(mhc_class: str) -> tuple[str, ...]:
    """Every stored spelling of a class token, for a parquet predicate.

    The corpus and the YAML disagree on the non-classical token, so an
    exact predicate on either one silently returns nothing (#363).
    Derived from :data:`_MHC_CLASS_TOKEN_ALIASES` rather than patched up
    per-case, so a spelling the normalizer already understands cannot be
    missed by the filter.
    """
    wanted = normalize_mhc_class_token(mhc_class)
    out = {mhc_class, wanted}
    out.update(
        alias for alias, canonical in _MHC_CLASS_TOKEN_ALIASES.items() if canonical == wanted
    )
    return tuple(sorted(out))


@cache
def mhc_class_of(mhc_restriction: str, species_context: str = "") -> str:
    """Canonical MHC class for a molecule or class-scoped haplotype.

    Returns ``"I"``, ``"II"``, ``"non-classical"`` or ``""`` (unknown).

    Derived rather than string-matched, so it works for every species
    mhcgnomes knows without a per-species table.  Validated against the
    built corpus: it reproduces the curated class on 2,922,227 observation
    rows and differs on 72, all of which are curation errors in the other
    direction (``Caja-E`` and ``Mamu-E*02:11`` are the marmoset / rhesus
    MHC-E genes and are non-classical, not classical).

    Semicolon-joined donor sets (the ``donor_set`` resolution emitted by
    #45, e.g. ``"HLA-DQB1*03:01;HLA-DRB1*15:01"``) are resolved from their
    components and return a class only when the components agree.
    """
    text = (mhc_restriction or "").strip()
    if not text:
        return ""
    if ";" in text:
        classes = [mhc_class_of(part, species_context) for part in text.split(";") if part.strip()]
        return classes[0] if classes and all(classes) and len(set(classes)) == 1 else ""
    parsed, _, _ = _parse_with_context(text, species_context)
    return _molecule_class(parsed)


@cache
def is_class_only_token(value: str) -> bool:
    """True when a string names a *class* rather than a specific molecule.

    Replaces prefix matching on ``"hla class"`` / ``"mhc class"``: mhcgnomes
    returns an ``MhcClass`` for exactly these, in any species' notation.
    The legacy ``"unknown"`` sentinel is still recognised explicitly since
    it carries the same meaning but does not parse.
    """
    text = (value or "").strip()
    if not text:
        return False
    if text.lower() in ("unknown", "not typed", "n/a", "na"):
        return True
    return type(_cached_parse(text)).__name__ == "MhcClass"


@cache
def mhc_species_of(mhc_field: str) -> str:
    """Species named by a curated ``mhc`` value, semicolon-joined.

    This is the ``mhc_species`` axis from docs/source-classification.md —
    the MHC molecule's species, as distinct from ``source_species`` (the
    proteome the peptide came from) and ``host_organism``.

    Resolves every complete designation through :func:`classify_mhc_species`, not just
    the ones that are alleles.  ``HLA-DR15`` is a Serotype and
    ``BoLA-DR`` a Class2Locus; both name a species perfectly well, and
    filtering to Allele/Gene/Pair would report ``""`` for 19 curated
    rows whose species is not in doubt (#380 is about them not reaching
    the *allele* join, which is a different question).

    A genotype spanning several species — an engineered chimera — is
    joined rather than collapsed, so the signal survives on exactly the
    rows it matters for.  Returns ``""`` only when nothing resolves.
    """
    text = (mhc_field or "").strip()
    if not text:
        return ""
    if is_class_only_token(text):
        return classify_mhc_species(text)
    species = {classify_mhc_species(span) for span, _ in _mhc_field_spans(text)}
    species.discard("")
    return ";".join(sorted(species))


@cache
def species_axes_agreement(source_species: str, mhc_species: str) -> str:
    """Do a sample's source and MHC species axes describe one system?

    Returns ``"true"`` / ``"false"`` / ``""`` (undeterminable), matching
    the tri-state string convention used by ``profiled`` and
    ``is_control_arm``.  Deliberately *not* named as a predicate: it
    returns a string, and ``bool("false")`` is ``True``, so a
    question-shaped name would invert the first caller's branch.

    ``mhc_species`` may name several species (semicolon-joined); the
    axes agree when *any* of them is compatible with the source, which
    is what an engineered chimera looks like from the source side.

    ``"false"`` is not automatically an error — a human HLA transgene in
    a mouse legitimately disagrees (#46).  It means the two axes differ
    and the row deserves a look, which is how PMID 41459947 shipped a
    Prussian carp sample carrying human MHC.

    Compatibility is :meth:`mhcgnomes.Species.compatible_with`: same
    species, or one a direct ancestor of the other.  Both sides are
    resolved first — that method returns ``False`` both for "these
    differ" and for "the other name is not a species at all", so
    without the guard an unresolvable name would be reported as a
    contradiction rather than as unknown.
    """
    if not source_species or not mhc_species:
        return ""
    source = Species.get(source_species)
    if source is None:
        return ""
    derived = [Species.get(part) for part in mhc_species.split(";") if part]
    derived = [d for d in derived if d is not None]
    if not derived:
        return ""
    return "true" if any(source.compatible_with(d) for d in derived) else "false"


def allele_locus(allele_token: str) -> str:
    """The species-qualified locus an allele belongs to (``HLA-A``, ``BoLA-6``).

    Species-qualified on purpose: ``HLA-DRB3`` and ``BoLA-DRB3`` share a
    gene *name* but are different loci, so keying on the bare name would
    merge two species' alleles into one bucket.

    Returns ``""`` for anything with no single locus — an unparseable
    token, a class or serotype designation, or a class-II heterodimer
    pair.  A pair spans two loci by construction; decompose it with
    :func:`expand_allele_components` first and ask about each chain.

    Examples::

        allele_locus("HLA-A*02:01")       # "HLA-A"
        allele_locus("BoLA-6*013:01")     # "BoLA-6"
        allele_locus("HLA-DRB1*15:01")    # "HLA-DRB1"
        allele_locus("HLA-DR15")          # "" — a serotype, not a molecule
    """
    token = (allele_token or "").strip()
    if not token:
        return ""
    parsed = _cached_parse(token)
    if type(parsed).__name__ not in _MHC_MOLECULE_TYPES:
        return ""
    gene = getattr(parsed, "gene", None)
    if gene is None:
        return ""
    return gene.to_string()


def expand_allele_components(allele_token: str) -> list[str]:
    """Return an allele plus, for a class-II pair, its alpha/beta chains.

    ``ms_samples`` curate DP/DQ heterodimers as a paired string
    (``"HLA-DPB1*06:01/DPA1*01:03"``) while many IEDB rows report only one
    chain (``"HLA-DPB1*06:01"``).  Emitting the pair *plus* each chain lets
    a single-chain observation match a heterodimer sample (#151).

    mhcgnomes splits the pair, so the chain strings come back canonical for
    any species rather than depending on where the ``HLA-`` prefix happened
    to sit in the curated text.  Non-pairs pass through unchanged.
    """
    token = resolve_allele_identity(allele_token)
    if not token:
        return []
    out = [token]
    parsed = _cached_parse(token)
    if type(parsed).__name__ == "Pair":
        for chain in (parsed.alpha, parsed.beta):
            text = chain.to_string()
            if text and text not in out:
                out.append(text)
    return out


def extract_allele_tokens(text: str) -> list[str]:
    """Pull MHC molecule tokens out of a free-text ``mhc`` field.

    Replaces an ``(?:HLA-)?[A-Z]+\\d*\\*\\d{2,4}:\\d{2,4}`` regex that
    encoded HLA's digit syntax and therefore silently dropped every
    non-human allele — ``H-2Kb``, ``H2-K*b``, ``H-2Q1`` and ``Patr-AL`` all
    returned nothing. Ask mhcgnomes to identify complete molecules before
    splitting a genotype, so mutation annotations stay with their molecule
    and chain. Unassigned mutation text raises ``ValueError``.

    Only ``Allele`` / ``Gene`` / ``Pair`` results are accepted.  That
    matters: mhcgnomes resolves ``"n/a"`` to the rat haplotype ``RT1-n/A``,
    so accepting anything that merely parses would inject junk from
    free-text curation fields.
    """
    if not text:
        return []
    out: list[str] = []
    for _, parsed in _mhc_field_spans(str(text)):
        if type(parsed).__name__ not in _MHC_MOLECULE_TYPES:
            continue
        canonical = parsed.to_string()
        if canonical and canonical not in out:
            out.append(canonical)
    return out


# ── Allele resolution ──────────────────────────────────────────────────────

#: Resolution tiers, ordered from most to least specific.
#: ``donor_set`` is the multi-allele restriction emitted post-#45 when
#: a row's actual presenting MHC narrows to the donor's typed alleles
#: (or a specific subset via per-peptide attribution) — strictly more
#: specific than ``class_only`` (which is "any allele in this class")
#: but less specific than ``four_digit`` (which is "this exact allele").
#: A tuple, not a list: it is public and is now shared *by reference* into
#: three ``argparse`` ``choices=`` calls, where a caller mutating it would
#: silently reshape the CLI.
ALLELE_RESOLUTION_ORDER: tuple[str, ...] = (
    "four_digit",
    "donor_set",
    "two_digit",
    "serological",
    "class_only",
    "unresolved",
)

#: The tiers that are meaningful as a ``--min-allele-resolution`` floor.
#: ``unresolved`` is the least specific tier, so a floor there admits every
#: row and the filter silently does nothing -- a user who passes it believes
#: they narrowed the export and did not (#597).
ALLELE_RESOLUTION_FLOORS: tuple[str, ...] = tuple(
    r for r in ALLELE_RESOLUTION_ORDER if r != "unresolved"
)

_RESOLUTION_RANK: dict[str, int] = {v: i for i, v in enumerate(ALLELE_RESOLUTION_ORDER)}


def _names_one_molecule(allele: Allele) -> bool:
    """True when a parsed ``mhcgnomes`` allele designates a single molecule.

    Two or more allele fields always do: ``HLA-A*02:01`` is one protein.
    Its one-field form ``HLA-A*02`` does not — that is an IPD allele *group*
    standing for every ``HLA-A*02:xx``, a strictly coarser statement.

    A *lone* field is the complete designation whenever it is not such a
    group. Mouse, rat, pig, chicken and horse MHC nomenclature names an allele
    after a haplotype letter rather than a numeric group: ``H2-Kb`` is the
    H2-K molecule of haplotype ``b``, one sequence, with no finer form to
    resolve to. Counting its fields against HLA's two-field convention
    mislabels it as truncated, and :func:`expand_allele_set` refuses anything
    that is not ``four_digit`` or ``class_only``, so those rows carried an
    empty ``mhc_allele_set`` and ``mhc_allele_provenance == "unmatched"``
    (#597).

    A lone field can name a species haplotype in ``Species.haplotypes`` or a
    gene-specific entry in ``Species.get_known_allele``. Numeric-only catalog
    entries are excluded: ``SahaI*49`` and siblings are parsing components of
    compound labels, not endorsed standalone molecules. A shape test alone is
    not enough, and an earlier revision learned that the hard way:
    "any field that does not start with a digit" accepted ``H2-K*x``,
    ``H2-D*nonsense`` and ``Mamu-A*ab`` as ``four_digit``, so
    :func:`expand_allele_set` returned them as an ``exact`` set of size 1 and a
    mistyped deposit became indistinguishable from a real allele — it even
    passed ``--min-allele-resolution four_digit``. An unattributed row is
    honest; a typo presented as an exact molecule is not.

    The roster answers whether a field names a haplotype of this species;
    the known-allele table covers published, non-roster molecules such as
    ``H2-K*wm7`` and ``AnasPlat-UAA*sd`` (#606). The roster's member lists
    are **not** consulted. They record which allele each gene carries
    **in** a haplotype, not which alleles exist — haplotype ``a`` lists
    ``K*k`` and ``D*d`` because H2-a is a recombinant, so a gene routinely
    carries a letter other than the haplotype's own. Requiring ``gene*field``
    to appear under ``field`` rejects real molecules: measured, it drops
    ``H2-T23*b`` (205 corpus rows), absent from the ``b`` list only because
    that haplotype carries ``Qa1*a``.

    Mutant and wild-derived forms are **not** decomposed into a base
    haplotype. The ``bm`` series and ``wm7`` look similar but have different
    origins; a pattern would also accept invented ``H2-K*bm999``. Only the
    upstream catalog's source-backed, gene-specific names qualify.
    """
    if allele.num_allele_fields != 1:
        return allele.num_allele_fields >= 2
    field = allele.allele_fields[0]
    return field in allele.species.haplotypes or (
        not field.isdigit() and allele.species.get_known_allele(allele.gene.name, field) is not None
    )


def _side_resolution(side) -> str:
    """Resolution tier of one molecule, or of one chain of a class-II pair.

    The single place the tiers are decided, so the standalone-allele path and
    the pair-chain path cannot drift apart. They used to compute the tiers
    separately, and an interim revision of this change left a comment claiming
    they shared a helper when only the ``four_digit`` test did.

    A ``Gene`` -- or anything else that is not an ``Allele`` -- names no allele
    and is ``unresolved``. That is reachable: mhcgnomes parses
    ``"HLA-DPA1*01:03/DPB1"`` into a ``Pair`` with a ``Gene`` beta chain. There
    is deliberately no branch below for an ``Allele`` carrying *zero* fields:
    mhcgnomes returns a ``Gene`` for every gene-only spelling
    (``"HLA-A"``, ``"HLA-A*"``, ``"H2-K*"``, ...), so no such ``Allele``
    exists to handle.
    """
    if not isinstance(side, Allele):
        return "unresolved"
    return "four_digit" if _names_one_molecule(side) else "two_digit"


@cache
def classify_allele_resolution(mhc_restriction: str) -> str:
    """Classify the resolution level of an MHC restriction annotation.

    ``mhcgnomes`` is the authority; a designation it cannot parse is
    ``"unresolved"``. ``"four_digit"`` means "names one molecule", not
    literally "has four digits" — a haplotype-designated allele such as
    ``H2-Kb`` carries a single field and is still exact, because mouse
    nomenclature has no finer form (see :func:`_names_one_molecule`).

    Cached by input string: same vocabulary as ``classify_mhc_species``,
    same argument for caching at the outer layer.

    Parameters
    ----------
    mhc_restriction
        IEDB "MHC Restriction" field value, or a semicolon-joined
        multi-allele set emitted post-#45 (``"HLA-A*02:01;HLA-A*03:01;..."``).

    Returns
    -------
    str
        One of ``"four_digit"``, ``"donor_set"``, ``"two_digit"``,
        ``"serological"``, ``"class_only"``, ``"unresolved"``.
    """
    if not mhc_restriction:
        return "unresolved"

    # Multi-allele set (#45): semicolon-joined 4-digit alleles. Each
    # token must parse as a 4-digit allele; otherwise we fall through.
    if ";" in mhc_restriction:
        tokens = [t.strip() for t in mhc_restriction.split(";") if t.strip()]
        if len(tokens) > 1 and all(_is_exact_allele_candidate(t) for t in tokens):
            return "donor_set"

    # No ``except ImportError`` and no regex fallback behind it. ``mhcgnomes``
    # is a core dependency (``mhcgnomes>=3.64.6``; the ``alleles`` extra is an
    # empty alias kept for compatibility), so the import cannot fail, and the
    # regex only ever ran for strings mhcgnomes *refused* -- where a
    # hand-rolled pattern second-guessing the parser is a silent-wrong-answer
    # machine: it read resolution off the *shape* of a string mhcgnomes had
    # already rejected, calling anything matching ``HLA-...*...:...``
    # ``four_digit`` and anything matching ``HLA-<letter><digits>``
    # ``serological``, both sight unseen.
    #
    # Measured over the 1,474-string vocabulary of both parquet artifacts plus
    # every curated allele token, exactly 5 strings reached it, all with **0
    # corpus rows**. One verdict changes: ``HLA-B23`` went ``serological`` ->
    # ``unresolved``, and ``unresolved`` is the correct answer -- mhcgnomes'
    # serotype table knows ``B21``, ``B22`` and ``B27`` but no ``B23``, so the
    # old answer was the regex inventing a specificity that does not exist.
    # That verdict flows on to ``_is_resolved_allele`` and hence to
    # ``restriction_evidence_for_row`` / ``is_monoallelic``; ``supplement.py``
    # calls those with its own ``mhc_restriction`` values, and none of the 5
    # appears there (its restrictions are well-formed HLA alleles, or blank),
    # so no row's evidence claim moves (#597).
    result = _cached_parse(mhc_restriction)
    if isinstance(result, Allele):
        return _side_resolution(result)
    if isinstance(result, Pair):
        # A pair is only as resolved as its coarser chain, so take the worse of
        # the two ranks. Either side can be a Gene ("HLA-DRA/DRB1",
        # "HLA-DPA1*01:03/DPB1"), which names no allele at all and so pins the
        # whole pair to "unresolved" -- ``_side_resolution`` handles that, which
        # is why there is no isinstance guard here.
        return max(
            (_side_resolution(result.alpha), _side_resolution(result.beta)),
            key=allele_resolution_rank,
        )
    if isinstance(result, Serotype):
        return "serological"
    if isinstance(result, MhcClass):
        return "class_only"
    if _class_scoped_haplotype(result):
        return "class_only"
    return "unresolved"


def allele_resolution_rank(resolution: str) -> int:
    """Integer rank for resolution (lower = more specific)."""
    return _RESOLUTION_RANK.get(resolution, len(ALLELE_RESOLUTION_ORDER))


_LOCUS_SEROTYPE_RE = re.compile(r"^(A|B|C|DR|DQ|DP|DM|DO)\d")
_LOCUS_SEROTYPE_NAME_RE = re.compile(r"^(A|B|C|DR|DQ|DP|DM|DO)(\d+)$")


def _serotype_specificity_rank(name: str) -> int:
    """Lower = more specific / preferred as the canonical serotype.

    0: locus-specific (A24, B57, DR15, ...) — what a clinician usually means
    1: public epitopes (Bw4, Bw6, C1, C2, ...) — orthogonal axis, less useful
       as the canonical answer to "what serotype is this allele?"
    """
    return 0 if _LOCUS_SEROTYPE_RE.match(name) else 1


def _broader_locus_serotype_name(name: str, known_names: set[str]) -> str:
    """Return the nearest broader locus-specific serotype, if one exists.

    Some mhcgnomes entries are split serotypes like ``A2403`` or ``DR1404``.
    A query for the broad family (``A24`` / ``DR14``) should also match those
    split members — so when a broader parent serotype is itself present in the
    reference table, an allele carrying the split serotype is tagged with the
    parent too.  Returns ``""`` when there is no broader parent (``A2`` has no
    shorter form; ``A24`` is already two digits)."""
    match = _LOCUS_SEROTYPE_NAME_RE.match(name)
    if not match:
        return ""
    locus, digits = match.groups()
    if len(digits) <= 2:
        return ""
    for cut in range(len(digits) - 1, 0, -1):
        prefix = str(int(digits[:cut]))
        candidate = f"{locus}{prefix}"
        if candidate != name and candidate in known_names:
            return candidate
    return ""


def _serotype_table_key(prefix: str, allele_str: str) -> tuple[str, str]:
    """Use the same current identity for catalog entries and reverse lookups.

    Catalog values mix compact and colon spellings (#455) and can retain
    retired designations (#456). Normalize both before building the map so
    the catalog's own members remain reachable through their current names.
    """
    result = _cached_parse(resolve_allele_identity(f"{prefix}-{allele_str}"))
    return result.species.mhc_prefix, f"{result.gene.name}*{''.join(result.allele_fields)}"


@lru_cache(maxsize=1)
def _build_allele_to_serotypes_map() -> dict[tuple[str, str], tuple[str, ...]]:
    """Build a reverse map from (species prefix, compact allele) to its serotypes.

    Returns a dict of ``{allele_key: (serotype1, serotype2, ...)}`` where
    the tuple is ordered by specificity:
    1. Locus-specific serotypes first (A24, B57, DR15)
    2. Public epitopes after (Bw4, Bw6)
    3. Prefer memberships under a current designation over a retired alias
    4. Break remaining ties by name length and spelling

    Returns empty dict if mhcgnomes is unavailable.
    """
    try:
        from mhcgnomes.data import serotypes
    except ImportError:
        return {}

    reverse: dict[tuple[str, str], list[str]] = {}
    current_memberships: set[tuple[tuple[str, str], str]] = set()
    for prefix, table in serotypes.items():
        known_names = set(table)
        for sero_name, allele_list in table.items():
            # HLA split serotypes also imply their catalogued broad parent.
            broader_name = (
                _broader_locus_serotype_name(sero_name, known_names) if prefix == "HLA" else ""
            )
            names_for_sero = [sero_name] if not broader_name else [sero_name, broader_name]
            for allele_str in allele_list:
                key = _serotype_table_key(prefix, allele_str)
                reverse.setdefault(key, []).extend(names_for_sero)
                reported = normalize_allele(f"{prefix}-{allele_str}")
                if resolve_allele_identity(reported) == reported:
                    current_memberships.update((key, name) for name in names_for_sero)

    return {
        (prefix, allele): tuple(
            f"{prefix}-{s}"
            for s in sorted(
                set(names),
                key=lambda n: (
                    _serotype_specificity_rank(n),
                    ((prefix, allele), n) not in current_memberships,
                    len(n),
                    n,
                ),
            )
        )
        for (prefix, allele), names in reverse.items()
    }


@cache
def _renamed_serotype_members() -> frozenset[str]:
    from mhcgnomes.data import serotypes

    return frozenset(
        resolve_allele_identity(f"{prefix}-{allele}")
        for prefix, table in serotypes.items()
        for alleles in table.values()
        for allele in alleles
        if resolve_allele_identity(f"{prefix}-{allele}") != normalize_allele(f"{prefix}-{allele}")
    )


@lru_cache(maxsize=8192)
def serotype_requires_alias_refresh(mhc_restriction: str) -> bool:
    """Whether a reported or catalogued retirement can change this annotation.

    A stored current name can also need refreshing when its catalog membership
    was recorded under a retired alias, e.g. B*15:112 -> B*15:11 (#456).
    """
    return any(
        resolve_allele_identity(part) != normalize_allele(part)
        or resolve_allele_identity(part) in _renamed_serotype_members()
        for part in (mhc_restriction or "").split(";")
        if part.strip()
    )


@lru_cache(maxsize=8192)
def allele_to_all_serotypes(mhc_restriction: str) -> tuple[str, ...]:
    """All serotypes an allele belongs to, most-specific first.

    Unlike :func:`allele_to_serotype`, this returns every serotype the
    allele is a member of.  Many alleles legitimately belong to both a
    locus-specific serotype (A24, B57) and a public epitope shared
    across loci (Bw4 is carried by subsets of A- and B-locus alleles —
    the axis KIR3DL1 recognizes).

    Cached by input string — same ~100k-vocab argument as
    ``classify_mhc_species`` / ``classify_allele_resolution``. Returns
    a tuple (immutable) so cache aliasing is safe.

    Examples::

        allele_to_all_serotypes("HLA-A*24:02")  # ("HLA-A24", "HLA-Bw4")
        allele_to_all_serotypes("HLA-B*57:01")  # ("HLA-B57", "HLA-B17", "HLA-Bw4")
        allele_to_all_serotypes("HLA-A*02:01")  # ("HLA-A2",)

    Returns an empty tuple when the allele cannot be mapped or input is empty.
    """
    if not mhc_restriction:
        return ()

    result = _cached_parse(resolve_allele_identity(mhc_restriction))
    if result is not None:
        try:
            from mhcgnomes.allele import Allele
            from mhcgnomes.serotype import Serotype

            if isinstance(result, Serotype):
                return (result.to_string(),)
            if isinstance(result, Allele):
                key = (
                    result.species.mhc_prefix,
                    f"{result.gene.name}*{''.join(result.allele_fields)}",
                )
                return _build_allele_to_serotypes_map().get(key, ())
        except ImportError:
            pass

    return ()


def allele_to_serotype(mhc_restriction: str) -> str:
    """Map an allele or serotype annotation to its species-qualified serotype.

    Uses mhcgnomes when available. Returns the most-specific serotype
    (e.g. ``"HLA-A24"`` rather than ``"HLA-Bw4"`` for HLA-A*24:02).  Use
    :func:`allele_to_all_serotypes` for the full list when an allele
    belongs to both a locus-specific serotype and a public epitope.

    Parameters
    ----------
    mhc_restriction
        IEDB "MHC Restriction" field value.

    Returns
    -------
    str
        Serotype name (e.g. ``"HLA-A2"``), or empty string if the
        allele cannot be mapped.
    """
    all_sero = allele_to_all_serotypes(mhc_restriction)
    return all_sero[0] if all_sero else ""


@lru_cache(maxsize=1)
def _build_serotype_to_alleles_map() -> dict[str, tuple[str, ...]]:
    """Forward map from canonical serotype name to its 4-digit members.

    Reads ``mhcgnomes.data.serotypes`` across all species. The shipped
    table stores alleles in compact form (``A*0201``) — we canonicalize
    each via ``normalize_allele`` to the colon-separated 4-digit form
    (``HLA-A*02:01``) so callers can match against the parquet's
    normalized strings. Members are sorted lexicographically; for typical
    locus-specific serotypes that puts the lowest-numbered allele first,
    which is also (by IPD's discovery-order numbering) usually the
    population-dominant allele (A2 → A*02:01, B7 → B*07:02, DR4 →
    DRB1*04:01).

    Keys carry the species prefix (``"HLA-A2"``, ``"BoLA-A18"``). Returns empty dict if
    mhcgnomes is unavailable.
    """
    try:
        from mhcgnomes.data import serotypes
    except ImportError:
        return {}

    out: dict[str, tuple[str, ...]] = {}
    for prefix, table in serotypes.items():
        for sero_name, allele_list in table.items():
            canon = {resolve_allele_identity(f"{prefix}-{allele}") for allele in allele_list}
            out[f"{prefix}-{sero_name}"] = tuple(sorted(canon))
    return out


@lru_cache(maxsize=8192)
def normalize_serotype_query(raw: str) -> str:
    """Canonicalize a serotype query, preserving its MHC species.

    Human queries may omit the prefix (``a2`` -> ``HLA-A2``). Explicit
    non-human names retain it (``bola-a18`` -> ``BoLA-A18``). Unknown queries
    keep the historical HLA spelling fallback and simply match no catalog row.
    """
    from mhcgnomes.serotype import Serotype

    query = str(raw).strip()
    if not query:
        return ""
    parsed = _cached_parse(query)
    if isinstance(parsed, Serotype):
        return parsed.to_string()
    if query.upper().startswith("HLA-"):
        query = query[4:]
    low = query.lower()
    if low.startswith("bw"):
        query = "Bw" + query[2:]
    elif low.startswith(("dr", "dq", "dp", "dm", "do")):
        query = low[:2].upper() + query[2:]
    else:
        query = query[:1].upper() + query[1:]
    return f"HLA-{query}"


@lru_cache(maxsize=8192)
def serotype_to_alleles(serotype: str) -> tuple[str, ...]:
    """Enumerate the 4-digit alleles that belong to a serotype.

    Inverse of :func:`allele_to_serotype`. Used to expand a user-supplied
    serotype query (``HLA-A2``) into the candidate 4-digit alleles
    (``HLA-A*02:01``, ``HLA-A*02:02``, ...) so the parquet pushdown finds
    the matching rows.

    Returns an empty tuple when the input is empty, not a serotype, or
    not in mhcgnomes' serotype catalog.

    Examples::

        serotype_to_alleles("HLA-A2")   # ("HLA-A*02:01", "HLA-A*02:02", ...)
        serotype_to_alleles("HLA-A*02:01")  # () — already 4-digit
    """
    if not serotype:
        return ()
    from mhcgnomes.serotype import Serotype

    parsed = _cached_parse(serotype)
    if not isinstance(parsed, Serotype):
        return ()
    return _build_serotype_to_alleles_map().get(parsed.to_string(), ())


@lru_cache(maxsize=8192)
def best_4digit_for_serotype(serotype: str) -> str:
    """Pick the most-likely 4-digit allele for a serotype.

    Heuristic: lowest-numbered member. By IPD-IMGT/HLA convention, the
    earliest-discovered alleles get the lowest numbers, and these are
    almost always the population-dominant ones (A2 → A*02:01 is ~50%
    of A2 carriers; B7 → B*07:02 is ~95% of B7). The guess is wrong for
    a handful of serotypes (notably A24, where A*24:02 dominates over
    A*24:01), so callers should treat the answer as a best-effort
    default, not ground truth.

    Returns ``""`` when the input is empty or not a known serotype.
    """
    members = serotype_to_alleles(serotype)
    return members[0] if members else ""


# ── Mono-allelic cell line detection ──────────────────────────────────────


@lru_cache(maxsize=1)
def load_monoallelic_lines() -> list[dict]:
    """Load known mono-allelic cell line systems from YAML.

    Returns
    -------
    list[dict]
        Each entry has keys: name, aliases (list[str]), hla_status,
        endogenous_alleles (list[str]).
    """
    return load_curation_yaml(_data_path("monoallelic_lines.yaml"))


@lru_cache(maxsize=1)
def _ebv_lcl_mono_hosts() -> frozenset:
    """Canonical names of mono-allelic hosts that are EBV-transformed B-LCLs.

    Peptidomes produced on these hosts (721.221, C1R) are EBV-immortalized
    B-cell material, not tumors, so they classify as ``ebv_lcl`` (never
    ``src_cancer``) regardless of IEDB's inconsistent culture-condition
    tagging.  Flagged via ``ebv_lcl: true`` in ``monoallelic_lines.yaml``.
    """
    return frozenset(e["name"] for e in load_monoallelic_lines() if e.get("ebv_lcl"))


def detect_monoallelic(cell_name: str, mhc_restriction: str = "") -> tuple[bool, str]:
    """Detect if a row comes from a known mono-allelic cell line system.

    Parameters
    ----------
    cell_name
        IEDB "Cell Name" field value.
    mhc_restriction
        IEDB "MHC Restriction" field value (the reported allele).

    Returns
    -------
    tuple[bool, str]
        ``(is_monoallelic, host_name)``. ``is_monoallelic`` is True when
        the cell_name matches a known HLA-null/low host AND the reported
        allele is not one of the host's endogenous alleles.
    """
    if not cell_name:
        return False, ""

    cell_name_lower = cell_name.lower()
    for entry in load_monoallelic_lines():
        for alias in entry["aliases"]:
            if alias in cell_name_lower:
                endogenous = entry.get("endogenous_alleles", [])
                if mhc_restriction and mhc_restriction in endogenous:
                    return False, ""
                return True, entry["name"]
    return False, ""


def _is_resolved_allele(mhc_restriction: str) -> bool:
    """True when the allele is specific enough to claim mono-allelic status.

    Rows with empty, ``HLA class I`` / ``class_only``, or ``unresolved``
    MHC restriction cannot be flagged mono-allelic — we do not know
    which allele (if any) produced the peptide.  This is the sole gate
    on the PMID-level override: cell_name is not a reliable
    discriminator because IEDB frequently mis-annotates the host
    (e.g., 721.221 recorded as ``"HeLa cells-Epithelial cell"`` in
    Trolle 2016) — the PMID override exists to correct exactly that.
    """
    return classify_allele_resolution(mhc_restriction) in ("four_digit", "two_digit", "serological")


# ── Exact-allele set expansion (issue #137) ────────────────────────────────


def _is_exact_allele_candidate(s: str, species_context: str = "") -> bool:
    """A complete allele designation, or a pair with both chains complete.

    Share the reported-resolution predicate across all species (#600). A
    partial pair, allele group or swallowed class sentinel is not exact typing.
    """
    if not isinstance(s, str):
        return False
    parsed, _, _ = _parse_with_context(s.strip(), species_context)
    if _swallowed_class_sentinel(s, parsed):
        return False
    if isinstance(parsed, Allele):
        return _side_resolution(parsed) == "four_digit"
    if isinstance(parsed, Pair):
        return all(_side_resolution(side) == "four_digit" for side in (parsed.alpha, parsed.beta))
    return False


def _exact_typing_tokens(text: str) -> frozenset[str]:
    """Consume full designations before splitting genotype separators.

    Malformed mutation text must not yield a fabricated wild-type candidate.
    The original field remains available as evidence even when no token qualifies.
    """
    try:
        spans = _mhc_field_spans(text)
    except ValueError:
        return frozenset()
    return frozenset(token for token, _ in spans if _is_exact_allele_candidate(token))


def _flatten_hla_alleles(value) -> set[str]:
    """Recursively collect exact designations from a curated ``hla_alleles`` value.

    Tolerates the four shapes seen in pmid_overrides.yaml:
    flat list, dict-of-lists keyed by donor / cell line, dict-of-strings
    (free-text descriptions are filtered out by the ontology predicate),
    and **space-separated multi-allele genotype strings** like
    ``"HLA-A*01:01 HLA-B*07:02 HLA-C*12:03"`` — used in ~32% of
    ms_samples to encode a donor's genotype as one field. Without
    this split, downstream qc reports report the whole genotype as a
    single phantom "allele".
    """
    out: set[str] = set()
    if value is None:
        return out
    if isinstance(value, str):
        out.update(_exact_typing_tokens(value))
    elif isinstance(value, list):
        for v in value:
            out |= _flatten_hla_alleles(v)
    elif isinstance(value, dict):
        for v in value.values():
            out |= _flatten_hla_alleles(v)
    return out


@lru_cache(maxsize=512)
def _pmid_allele_pool(pmid_int: int) -> frozenset[str]:
    """All curated 4-digit alleles for a PMID, flattened across the
    ``hla_alleles`` block regardless of nested shape.

    Returns an empty frozenset if no override exists or the override has
    no ``hla_alleles`` curation.
    """
    overrides = load_pmid_overrides()
    entry = overrides.get(pmid_int)
    if entry is None:
        return frozenset()
    return frozenset(_flatten_hla_alleles(entry.get("hla_alleles")))


#: mhcgnomes result types that name a *set* of molecules rather than one.
#: ``Serotype`` carries a member list and can be expanded; the rest name a
#: locus or a whole class and expand to nothing by design.
_MHC_SEROTYPE_TYPES = frozenset({"Serotype"})
_MHC_IMPRECISE_TYPES = frozenset({"Class2Locus", "MhcClass", "Species"})


@dataclass(frozen=True)
class SampleMhcCandidates:
    """What a curated ``ms_samples[].mhc`` value licenses as an attribution claim.

    A sample's ``mhc`` field is written at whatever precision the study
    reported, and three precisions occur.  Conflating them is how #380
    happened, so they are kept apart here:

    ``exact``
        Molecules named outright — ``HLA-A*02:01``, ``H2-K*b``,
        ``BoLA-6*013:01``.  Safe to report to a reader as an observed
        allele.
    ``serotypes`` / ``serotype_alleles``
        A serological designation — ``HLA-DR15``, ``HLA-DQ8``.  The study
        typed to serotype, not to allele.  ``serotype_alleles`` is the
        member set from the IPD-IMGT/HLA catalog, which is a legitimate
        *candidate* set for the allele-level join; ``serotypes`` is what
        should be shown to a reader.  Merging the two would turn "this
        donor is DR15" into the false claim "this peptide was observed on
        DRB1*15:01".
    ``imprecise``
        A locus or class designation — ``SLA-DR``, ``BoLA-DR``,
        ``Bos taurus class I``.  These name no allele, and expanding one
        would fabricate a restriction the study never reported.  Carried
        rather than dropped so a caller can say *why* a sample has no
        candidates instead of treating it as an unparseable typo.

    Notes
    -----
    Before #380 everything except ``exact`` yielded the empty set, so
    seven samples across five PMIDs fell out of the allele-level join
    silently — indistinguishable from a curation error.
    """

    exact: frozenset[str] = frozenset()
    serotypes: tuple[str, ...] = ()
    serotype_alleles: frozenset[str] = frozenset()
    imprecise: tuple[str, ...] = ()

    @property
    def join_alleles(self) -> frozenset[str]:
        """Candidate alleles for the allele-level join.

        Includes serotype members: for matching purposes "the donor is one
        of these seven DRB1*15 alleles" is a real narrowing, and strictly
        more specific than the study-wide class pool the sample otherwise
        falls back to.  Use :attr:`exact` anywhere the answer is presented
        as an allele that was actually observed.
        """
        return self.exact | self.serotype_alleles

    @property
    def is_empty(self) -> bool:
        """True when the field named nothing at all.

        Distinct from "named something imprecise": an empty result means
        the string parsed to no MHC entity, which is a curation defect
        worth surfacing, whereas ``imprecise`` is a faithful record of a
        study that only typed to locus or class.
        """
        return not (self.exact or self.serotypes or self.imprecise)


@lru_cache(maxsize=4096)
def _mhc_field_scan(text: str) -> tuple[tuple, tuple[str, ...]]:
    """Split a field into recognized MHC spans and the tokens left over.

    One pass, two answers.  The leftovers used to be discarded inside the loop,
    which made an unrecognized designation indistinguishable from an absent one:
    ``"HLA-A*02:01 HLA-B*07:NEW"`` looked exactly like ``"HLA-A*02:01"`` to
    every consumer.  A consumer deciding whether a candidate space is complete
    has to see them (#574), so they are returned alongside rather than dropped.
    """
    from mhcgnomes import Mutation

    # Haplotype designations carry species but are not individual molecules;
    # extraction and sample candidate consumers still exclude them.
    kinds = _MHC_MOLECULE_TYPES | _MHC_SEROTYPE_TYPES | _MHC_IMPRECISE_TYPES | {"Haplotype"}
    text = text.strip()
    if not text:
        return ((), ())
    if ";" in text:
        parts = [_mhc_field_scan(part) for part in text.split(";")]
        return (
            tuple(span for spans, _ in parts for span in spans),
            tuple(token for _, leftover in parts for token in leftover),
        )
    if Mutation.parse(text, raise_on_error=False) is not None:
        raise ValueError(f"Unassigned mutation in sample MHC field: {text!r}")
    whole = _cached_parse(text)
    if type(whole).__name__ in kinds:
        return (((text, whole),), ())

    # Commas inside mutation lists are optional to mhcgnomes.
    tokens = [token for token in re.split(r"[\s,]+", text) if token]
    spans = []
    unparsed: list[str] = []
    start = 0
    while start < len(tokens):
        if Mutation.parse(tokens[start], raise_on_error=False) is not None or re.search(
            r"\bmutants?\b", tokens[start], re.IGNORECASE
        ):
            raise ValueError(f"Unassigned or malformed mutation in sample MHC field: {text!r}")
        for end in range(len(tokens), start, -1):
            span = " ".join(tokens[start:end])
            parsed = _cached_parse(span)
            if type(parsed).__name__ in kinds:
                spans.append((span, parsed))
                start = end
                break
        else:
            # Preserve the existing treatment of unrecognized non-mutation
            # labels; an unresolved modifier cannot fabricate a genotype.  It
            # is reported rather than silently forgotten.
            unparsed.append(tokens[start])
            start += 1
    return (tuple(spans), tuple(unparsed))


def _mhc_field_spans(text: str) -> tuple:
    """Consume complete MHC designations before genotype separators (#528, #537)."""
    return _mhc_field_scan(text)[0]


def sample_mhc_candidates(mhc_field) -> SampleMhcCandidates:
    """Classify a curated ``ms_samples[].mhc`` value by precision.

    The single place reported experimental MHC typing becomes attribution
    candidates, so the allele-level join and the peptide summary cannot
    drift apart about what a given designation means (#380).

    Parameters
    ----------
    mhc_field
        A ``ms_samples[].mhc`` value: a string (``"HLA-A*02:01"``, the
        bare space-joined ``"A*02:01 A*24:02 B*15:01"``, a serotype, or a
        locus/class designation), a list of any of those, or ``None``.

    Returns
    -------
    SampleMhcCandidates
        Empty when the field is absent or names no MHC entity.

    Raises
    ------
    ValueError
        A mutation label cannot be assigned to a complete molecule. Such a
        field must not silently become a wild-type or expanded genotype.

    Examples
    --------
    >>> sorted(sample_mhc_candidates("HLA-A*02:01 HLA-B*07:02").exact)
    ['HLA-A*02:01', 'HLA-B*07:02']
    >>> c = sample_mhc_candidates("HLA-DQ8")
    >>> c.exact, c.serotypes
    (frozenset(), ('HLA-DQ8',))
    >>> sorted(c.serotype_alleles)[:2]
    ['HLA-DQB1*03:02', 'HLA-DQB1*03:05']
    >>> sample_mhc_candidates("BoLA-DR").imprecise
    ('BoLA-DR',)

    See Also
    --------
    serotype_to_alleles : the serotype expansion this uses.
    """
    if mhc_field is None:
        return SampleMhcCandidates()
    if isinstance(mhc_field, (list, tuple)):
        parts = [sample_mhc_candidates(item) for item in mhc_field]
        return SampleMhcCandidates(
            exact=frozenset().union(*(p.exact for p in parts)) if parts else frozenset(),
            serotypes=tuple(dict.fromkeys(s for p in parts for s in p.serotypes)),
            serotype_alleles=(
                frozenset().union(*(p.serotype_alleles for p in parts)) if parts else frozenset()
            ),
            imprecise=tuple(dict.fromkeys(s for p in parts for s in p.imprecise)),
        )
    if not isinstance(mhc_field, str):
        return SampleMhcCandidates()

    exact: list[str] = []
    serotypes: list[str] = []
    serotype_alleles: set[str] = set()
    imprecise: list[str] = []
    for token, parsed in _mhc_field_spans(mhc_field):
        kind = type(parsed).__name__
        if kind in _MHC_MOLECULE_TYPES:
            # Candidate identity is derived; the source YAML retains the
            # reported designation and precision, including retired names.
            name = resolve_allele_identity(parsed.to_string())
            if name and name not in exact:
                exact.append(name)
        elif kind in _MHC_SEROTYPE_TYPES:
            name = parsed.to_string()
            if name and name not in serotypes:
                serotypes.append(name)
                serotype_alleles.update(serotype_to_alleles(name))
        elif kind in _MHC_IMPRECISE_TYPES:
            name = normalize_allele(token)
            if name and name not in imprecise:
                imprecise.append(name)
    return SampleMhcCandidates(
        exact=frozenset(exact),
        serotypes=tuple(serotypes),
        serotype_alleles=frozenset(serotype_alleles),
        imprecise=tuple(imprecise),
    )


#: Expression annotations meaning the molecule never reaches the cell surface:
#: ``N`` null, ``S`` secreted-only, ``C`` cytoplasm-only.  Such an allele cannot
#: be the presenting molecule for an eluted peptide, so it is not a candidate at
#: all.  ``L`` (low expression) and ``Q`` (questionable) *are* surface-expressed
#: -- less of it, or less certainly -- so they stay candidates (#574).
_NON_SURFACE_ANNOTATION_ATTRS = (
    "annotation_null",
    "annotation_secreted",
    "annotation_cystosolic",  # mhcgnomes' spelling
)


@dataclass(frozen=True)
class ClassIPredictionScope:
    """How a reported class-I candidate list divides at a predictor boundary.

    ``scorable`` and ``unscorable`` partition the class-I designations of one
    ``mhc`` field that could present a peptide.  Keeping the second half rather
    than dropping it is the point (#574): a best allele chosen from ``scorable``
    alone is a claim about a candidate space a non-empty ``unscorable`` shows we
    do not have, so :attr:`is_eligible` requires it to be empty.

    A dataclass rather than a ``NamedTuple`` so an empty scope is not falsy:
    ``if scope:`` on a tuple subclass would silently mean "has candidates",
    which is not the question any caller here is asking.
    """

    scorable: tuple[str, ...] = ()
    unscorable: tuple[str, ...] = ()

    @property
    def is_eligible(self) -> bool:
        """True when there is something to score and nothing unaccounted for."""
        return bool(self.scorable) and not self.unscorable


#: ``mhc_class`` values for class-I molecules that do not present peptides:
#: ``Ic`` is the MIC/stress-ligand family and ``Id`` the CD1/MR1 lineage, which
#: present lipids and metabolites.  Like a null allele, one of these cannot be
#: the answer for an eluted peptide, so it is dropped rather than counted
#: against completeness (#574).
_NON_PEPTIDE_CLASS_I = frozenset({"Ic", "Id"})

#: A class designation that mhcgnomes silently absorbs into a preceding allele:
#: ``parse("HLA-A*02:01 class I")`` returns just the allele, so the sentinel --
#: which says untyped class-I material is present -- vanishes.  Detected on the
#: raw span text instead (pirl-unc/mhcgnomes#200).
_CLASS_SENTINEL_RE = re.compile(r"\bclass\s+(I{1,3}|[12])\b", re.IGNORECASE)


def _swallowed_class_sentinel(token: str, parsed) -> str | None:
    """A class sentinel inside ``token`` that ``parsed`` does not account for.

    ``"HLA-A*02:01 HLA class I"`` splits into two spans and needs nothing here.
    ``"HLA-A*02:01 class I"`` and ``"... MHC class I"`` do not: mhcgnomes parses
    the whole string to one ``Allele`` and drops the sentinel, which would make
    an incompletely typed sample look completely typed.
    """
    if type(parsed).__name__ == "MhcClass":
        return None  # the sentinel is the span; it is already accounted for
    match = _CLASS_SENTINEL_RE.search(token)
    if match is None:
        return None
    numeral = match.group(1).upper().replace("1", "I").replace("2", "II")
    return f"class {numeral}"


def _scope_entry(parsed, token: str) -> tuple[str, bool] | None:
    """One class-I candidate as ``(designation, scorable)``, or ``None`` to drop.

    Three outcomes, and the difference between the last two is what keeps the
    rule honest:

    ``(name, True)``
        A human classical class-I protein a backend can score.
    ``(name, False)``
        A class-I designation that could present the peptide but cannot be
        scored -- a locus, a serotype, a class sentinel, a haplotype, a
        class-Ib or non-human allele.  It counts against completeness.
    ``None``
        Not a candidate for presenting this peptide at all, so dropping it
        leaves the remaining set complete: another class entirely, a molecule
        that presents something other than peptides (``Ic``/``Id``), a
        pseudogene product, or a non-surface expression variant.
    """
    kind = type(parsed).__name__
    if kind in ("Haplotype", "Species"):
        # Neither names a molecule, and both span the classes -- a haplotype
        # carries class-I genes by definition and a bare species names none of
        # them.  ``is_class1`` is False for both, which is why routing them
        # through the class gate made this branch unreachable (#574).
        return (parsed.to_string(), False)
    if not parsed.is_class1:
        return None
    if getattr(parsed, "is_pseudogene", False):
        return None  # HLA-H, HLA-V and friends make no protein
    if getattr(parsed, "mhc_class", None) in _NON_PEPTIDE_CLASS_I:
        return None  # CD1, MR1, MICA/MICB present lipids/metabolites, not peptides
    if isinstance(parsed, Allele):
        if any(getattr(parsed, attr) for attr in _NON_SURFACE_ANNOTATION_ATTRS):
            return None
        reported = resolve_allele_identity(parsed.to_string()) or parsed.to_string()
        if not (
            parsed.mhc_class == "Ia"
            and parsed.num_allele_fields >= 2
            and parsed.is_human
            and not parsed.is_mutant
        ):
            return (reported, False)
        return (_protein_identity(reported, parsed), True)
    # A Gene, Serotype or class sentinel names no single protein.
    name = parsed.to_string() if hasattr(parsed, "to_string") else token
    return (normalize_allele(name) or name, False)


def _protein_identity(reported: str, parsed) -> str:
    """The two-field protein a scorable designation denotes.

    A backend scores a protein, and its allele vocabulary is two-field: handing
    netMHCpan the reported ``HLA-A*02:01:01:02L`` spells an allele it does not
    know, and the caller's own identity check then rejects the reply it gets
    back.  The extra fields are synonymous DNA differences and an expression
    annotation, neither of which changes the binding groove, so the protein is
    the two-field name.  Collapsing here also makes ``A*02:01`` and
    ``A*02:01:01`` one candidate rather than two (#574).

    The reported precision is not lost -- it stays in ``sample_mhc``, which
    every result row carries.
    """
    allele = _cached_parse(reported)
    if not isinstance(allele, Allele):
        allele = parsed
    return allele.restrict_allele_fields(2).copy(annotations=()).to_string()


def class_i_prediction_scope(mhc_field) -> ClassIPredictionScope:
    """Split a sample's reported class-I designations by what a backend can score.

    The single place a reported MHC field becomes class-I predictor input, so
    the eligibility rule is stated once and asked of the *parsed* designation
    rather than re-derived from its string (#574).  It shares
    :func:`sample_mhc_candidates`' parse, so a field is parsed once no matter
    how many consumers ask.

    A designation is ``scorable`` when it is an :class:`mhcgnomes.Allele` that
    names one human classical class-I protein a binding predictor models:
    classical class ``Ia`` (the predictors model no ``Ib`` molecule such as
    ``HLA-E``), two or more allele fields (a one-field group such as ``HLA-B*27``
    spans 100+ proteins with different motifs), human (this project wires the
    human class-I models only), not a mutant, and not a pseudogene.  Three- and
    four-field names stay scorable -- the extra fields refine the DNA sequence
    or annotate expression level, not the protein's binding groove.

    Everything else that could present a class-I peptide is ``unscorable``: a
    ``Gene``, a serotype, a class sentinel, a class-Ib or non-human class-I
    allele.  These are precisely the values :attr:`SampleMhcCandidates.exact`
    and its sibling fields legitimately contain -- ``exact`` means *the source
    named this outright*, not *this is one protein* -- and each one leaves the
    class-I candidate space unresolved.

    Two kinds of designation are excluded rather than counted against
    completeness, because neither can be the presenting molecule:

    - Anything that is not class I.  A class-II allele or pair, a class-II locus
      such as ``BoLA-DR``, or a ``HLA class II`` sentinel is simply a different
      candidate space and does not hold back a class-I prediction.
    - A non-surface expression variant (``N``/``S``/``C``).  It reaches no cell
      surface, so removing it leaves the remaining candidates complete.

    Parameters
    ----------
    mhc_field
        A curated ``ms_samples[].mhc`` or exported ``sample_mhc`` string, or
        ``None``.  A string is required because the result is cached; callers
        holding a list should join it as :func:`sample_mhc_candidates` does.

    Returns
    -------
    ClassIPredictionScope
        Both halves of the partition, each sorted and deduplicated.

    Raises
    ------
    ValueError
        The field carries a mutation label that cannot be assigned to a complete
        molecule.  Propagated rather than caught: a mutant designation silently
        read as its wild type would fabricate a restriction.

    Examples
    --------
    >>> class_i_prediction_scope("HLA-A*02:01 HLA-B*07:02").is_eligible
    True
    >>> scope = class_i_prediction_scope("HLA-A2 HLA-B*07:02")
    >>> scope.scorable, scope.unscorable, scope.is_eligible
    (('HLA-B*07:02',), ('HLA-A2',), False)
    >>> class_i_prediction_scope("HLA-A*02:01 HLA-DRB1*15:01").is_eligible
    True

    See Also
    --------
    sample_mhc_candidates : the precision classification this builds on.
    """
    if isinstance(mhc_field, (list, tuple)):
        # YAML lets a curated ``mhc`` be a list, as :func:`sample_mhc_candidates`
        # accepts.  Joined here rather than inside the cached worker, because a
        # list is an unhashable cache key and would raise before the body ran.
        mhc_field = " ".join(str(item) for item in mhc_field if item)
    if not isinstance(mhc_field, str):
        return ClassIPredictionScope()
    return _class_i_prediction_scope(mhc_field)


@lru_cache(maxsize=4096)
def _class_i_prediction_scope(mhc_field: str) -> ClassIPredictionScope:
    """Cached worker for :func:`class_i_prediction_scope`; string keys only."""
    spans, unparsed = _mhc_field_scan(mhc_field)
    scorable: set[str] = set()
    unscorable: set[str] = set()
    for token, parsed in spans:
        entry = _scope_entry(parsed, token)
        if entry is not None and entry[0]:
            (scorable if entry[1] else unscorable).add(entry[0])
        sentinel = _swallowed_class_sentinel(token, parsed)
        if sentinel is not None and sentinel == "class I":
            unscorable.add(sentinel)
    # A token the parser could not classify may well name class-I material --
    # a new allele name, a typo, a local label.  Beside class-I candidates it
    # leaves the space unresolved; with no class-I material at all there is
    # nothing for it to be incomplete against, and a bare "unknown" stays the
    # quiet no-candidates case it has always been.
    if unparsed and (scorable or unscorable):
        unscorable.update(unparsed)
    return ClassIPredictionScope(tuple(sorted(scorable)), tuple(sorted(unscorable)))


def sample_mhc_metadata(sample: Mapping) -> dict[str, str]:
    """Validate and export cellular typing separately from experiment candidates.

    No fallback from ``mhc``: legacy values include selected restrictions and
    pooled candidates. Complete loci are a source claim, never inferred from
    the number of alleles. Typing a cell does not establish peptide binding.
    """
    result = {
        field: "" if sample.get(field) is None else sample[field] for field in MHC_TYPING_FIELDS
    }
    for field, value in result.items():
        if not isinstance(value, str) or value != value.strip():
            raise ValueError(f"{field} must be a stripped string")
    if result["mhc_basis"] not in ("", "selected_restriction", "sample_typing"):
        raise ValueError("mhc_basis must be selected_restriction, sample_typing, or blank")
    if result["mhc_basis"]:
        candidates = sample_mhc_candidates(sample.get("mhc"))
        # Class designations are nonempty parser results but name no candidate.
        if not (candidates.exact or candidates.serotypes):
            raise ValueError("mhc_basis requires experimental mhc candidates")

    genotype = result["mhc_genotype"]
    typing = sample_mhc_candidates(genotype)
    provenance = ("mhc_genotype_cell", "mhc_genotype_source")
    if genotype:
        for field in provenance:
            if not result[field]:
                raise ValueError(f"mhc_genotype requires {field}")
        if not (typing.exact or typing.serotypes):
            raise ValueError("mhc_genotype must name reported MHC typing")
    elif any(result[field] for field in (*provenance, "mhc_genotype_complete_loci")):
        raise ValueError("cellular typing metadata requires mhc_genotype")

    loci = {
        locus
        for allele in typing.exact
        for component in expand_allele_components(allele)
        if (locus := allele_locus(component))
    }
    for serotype in typing.serotypes:
        # Report the shared locus, never the inferred member alleles (#573).
        # Cross-locus antigens such as Bw4 cannot establish either locus alone.
        member_loci = {allele_locus(allele) for allele in serotype_to_alleles(serotype)}
        if len(member_loci) == 1 and "" not in member_loci:
            loci.update(member_loci)
    result["mhc_genotype_reported_loci"] = ";".join(sorted(loci))
    complete = result["mhc_genotype_complete_loci"]
    if complete and (
        complete != ";".join(sorted(set(complete.split(";"))))
        or not set(complete.split(";")) <= loci
    ):
        raise ValueError("mhc_genotype_complete_loci must be sorted, unique reported loci")
    return result


def reported_mhc_fields_overlap(first, second) -> bool | None:
    """Whether two precisely reported molecule sets have a compatible member.

    This is an exclusion boundary for heuristic sample attribution, not a
    claim that either field is a complete cellular genotype. Unknown,
    serological, gene-only, and one-field typing return None (undetermined).
    A missing locus is also unknown: disjointness requires both fields to
    cover the same loci. An observed DRB3 product cannot contradict a sample
    whose only reported class-II typing is DRB1 (#520).
    Compare reported molecules only; callers must exclude predicted or
    inferred restriction fields before using this check.
    """
    from mhcgnomes import Allele, Pair

    def precise_molecule(molecule):
        if isinstance(molecule, Pair):
            return precise_molecule(molecule.alpha) and precise_molecule(molecule.beta)
        return isinstance(molecule, Allele) and molecule.num_allele_fields >= 2

    def molecules(field):
        candidates = sample_mhc_candidates(field)
        if candidates.serotypes or candidates.imprecise or not candidates.exact:
            return ()
        parsed = tuple(_cached_parse(name) for name in candidates.exact)
        return parsed if all(precise_molecule(molecule) for molecule in parsed) else ()

    def compatible(left, right):
        if isinstance(left, Pair) and isinstance(right, Pair):
            # Parsers may retain a beta/alpha input order. Pair identity is
            # determined by the two chains, not their positions (#696).
            return (compatible(left.alpha, right.alpha) and compatible(left.beta, right.beta)) or (
                compatible(left.alpha, right.beta) and compatible(left.beta, right.alpha)
            )
        if isinstance(left, Pair):
            return compatible(left.alpha, right) or compatible(left.beta, right)
        if isinstance(right, Pair):
            return compatible(left, right.alpha) or compatible(left, right.beta)
        depth = min(left.num_allele_fields, right.num_allele_fields)
        return (
            left.gene.name == right.gene.name
            and species_compatible(left.species.name, right.species.name)
            and left.allele_fields[:depth] == right.allele_fields[:depth]
            and left.mutations == right.mutations
        )

    left, right = molecules(first), molecules(second)
    if not left or not right:
        return None
    if any(compatible(a, b) for a in left for b in right):
        return True

    def loci(items):
        return {
            chain.gene.name
            for molecule in items
            for chain in (
                (molecule.alpha, molecule.beta) if isinstance(molecule, Pair) else (molecule,)
            )
        }

    return False if loci(left) == loci(right) else None


def _parse_sample_mhc_field(mhc_field) -> frozenset[str]:
    """Normalized experimental candidates, including serotype members.

    Uses the shared precision-aware parser for human and nonhuman typing.
    This is not necessarily a cellular genotype or an observed restriction;
    callers reporting named molecules should use ``sample_mhc_candidates``
    and its ``exact`` field, which excludes serotype-derived candidates.
    """
    return sample_mhc_candidates(mhc_field).join_alleles


@lru_cache(maxsize=512)
def _pmid_sample_alleles(pmid_int: int) -> dict[str, frozenset[str]]:
    """Map ``sample_label → frozenset(4-digit alleles)`` for a PMID's ms_samples.

    Reads experimental ``mhc`` candidates, never ``mhc_genotype``. Per-peptide
    attribution uses this map to narrow candidates to the observed sample(s)
    without adding cellular background alleles excluded by the experiment.

    Empty mapping if no override or no ms_samples entries are present.
    """
    overrides = load_pmid_overrides()
    entry = overrides.get(pmid_int)
    if entry is None:
        return {}
    out: dict[str, frozenset[str]] = {}
    for sample in entry.get("ms_samples") or []:
        label = sample.get("sample_label", "")
        if not label:
            continue
        alleles = _parse_sample_mhc_field(sample.get("mhc"))
        if alleles:
            out[label] = alleles
    return out


@lru_cache(maxsize=512)
def _pmid_peptide_attributions(pmid_int: int) -> dict[str, frozenset[str]]:
    """Map ``peptide → frozenset(sample_label)`` for a PMID's per-peptide
    attribution CSV (#45).

    Some studies deposit per-peptide → sample mappings in their
    supplementary tables.  Curators register that evidence via a CSV
    referenced from the PMID's ``peptide_attributions:`` key in
    pmid_overrides.yaml.  For a class-only source row the mapping narrows
    a pooled genotype; for an already resolved source row it supplies
    sample identity without replacing the reported restriction.

    The CSV must have columns ``peptide`` and ``sample_label`` (semicolon-
    joined when a peptide was observed in multiple samples).

    Returns an empty mapping when no attribution CSV is registered.
    """
    overrides = load_pmid_overrides()
    entry = overrides.get(pmid_int)
    if entry is None:
        return {}
    rel_path = entry.get("peptide_attributions")
    if not rel_path:
        return {}
    csv_path = _asset_path(rel_path)
    table = pd.read_csv(csv_path, usecols=["peptide", "sample_label"])
    out: dict[str, frozenset[str]] = {}
    for pep, labels in zip(table["peptide"].astype(str), table["sample_label"].astype(str)):
        sample_set = frozenset(s for s in labels.split(";") if s)
        if pep and sample_set:
            out[pep] = sample_set
    return out


def _coerce_pmid(pmid: int | str) -> int | None:
    """PMID as an int, or None if it is not one.

    PMIDs arrive as ints from YAML and as strings from dataframe columns.
    ``load_pmid_overrides`` is keyed by int, so a string lookup silently
    misses — and for these functions a miss is indistinguishable from
    "this study deposited no attributions", which is the one confusion
    their docstrings warn against.  Every public entry point coerces here.
    """
    with contextlib.suppress(ValueError, TypeError):
        return int(pmid)
    return None


def peptide_attribution_applies_to_row(pmid: int | str, mhc_restriction: str) -> bool:
    """Whether a reported source restriction belongs to a mapped cohort.

    Apply before donor-set promotion. A peptide shared by separate cohorts
    does not transfer a sample identity between their observations (#534).
    An unscoped map preserves its existing study-wide applicability.
    """
    entry = load_pmid_overrides().get(_coerce_pmid(pmid), {})
    if not entry.get("peptide_attributions"):
        return False
    scope = entry.get("peptide_attribution_restrictions")
    return scope is None or str(mhc_restriction).strip().casefold() in {
        value.casefold() for value in scope
    }


@lru_cache(maxsize=512)
def _peptide_typings_by_pmid(
    pmid: int,
) -> Mapping[str, tuple[tuple[str, frozenset[str]], ...]]:
    """Build (and cache) the per-donor typing map for one study.

    Cached on the coerced int so ``31844290`` and ``"31844290"`` share one
    entry instead of building the 28k-peptide map twice.  Returned as a
    read-only view: the value is shared with every other caller and with
    the scanner, so a caller pruning it in place would silently change
    which observation rows the next build emits.
    """
    attributions = _pmid_peptide_attributions(pmid)
    if not attributions:
        return MappingProxyType({})
    sample_alleles = _pmid_sample_alleles(pmid)
    out: dict[str, tuple[tuple[str, frozenset[str]], ...]] = {}
    for pep, samples in attributions.items():
        per_sample = []
        for label in sorted(samples):
            alleles = sample_alleles.get(label, frozenset())
            if alleles:
                per_sample.append((label, alleles))
        if per_sample:
            out[pep] = tuple(per_sample)
    return MappingProxyType(out)


@lru_cache(maxsize=512)
def _peptide_alleles_by_pmid(pmid: int) -> Mapping[str, frozenset[str]]:
    """Merged view of :func:`_peptide_typings_by_pmid`, cached separately.

    Derived rather than rebuilt from the CSV, so the two public maps
    cannot disagree about which peptides survive the drop-empty filter.
    """
    return MappingProxyType(
        {
            peptide: frozenset().union(*(alleles for _, alleles in per_donor))
            for peptide, per_donor in _peptide_typings_by_pmid(pmid).items()
        }
    )


def sample_alleles_for_pmid(pmid: int | str) -> Mapping[str, frozenset[str]]:
    """Curated ``sample_label -> candidate alleles`` for one study's ms_samples.

    The sample-level counterpart to :func:`peptide_alleles_for_pmid`, before
    per-peptide narrowing. Reads experimental ``mhc`` candidates, which may
    describe selected ligand restrictions rather than cellular genotypes.
    Independent cellular typing is available through ``mhc_genotype`` in
    :func:`hitlist.export.generate_ms_samples_table`.

    Values are :attr:`SampleMhcCandidates.join_alleles` — exact molecules
    plus, for a serotype-typed sample, that serotype's member alleles.
    Samples typed only to a locus or class (``BoLA-DR``, ``HLA class II``)
    name no allele and are **omitted**, as are samples with no ``mhc``
    field.  Use :func:`sample_mhc_candidates` on the raw field when you
    need to tell "typed imprecisely" from "not typed at all", or when you
    need the exact molecules without serotype expansion.

    Parameters
    ----------
    pmid
        PubMed ID of the study, as an int or a string of digits.

    Returns
    -------
    Mapping[str, frozenset[str]]
        Empty when the PMID has no override, no ``ms_samples``, or no
        sample that names an allele.

    Examples
    --------
    >>> sorted(sample_alleles_for_pmid(26768311))
    ['HeLa + vaccinia (VACV) infection', 'HeLa uninfected']

    See Also
    --------
    sample_mhc_candidates : the per-field parse, keeping precision apart.
    peptide_alleles_for_pmid : per-peptide narrowing, where a study
        deposited peptide-to-donor attributions.
    """
    pmid_int = _coerce_pmid(pmid)
    if pmid_int is None:
        return MappingProxyType({})
    return MappingProxyType(dict(_pmid_sample_alleles(pmid_int)))


def peptide_alleles_for_pmid(pmid: int | str) -> Mapping[str, frozenset[str]]:
    """Per-peptide candidate alleles for one study, from curated attributions.

    Some studies deposit which donor each peptide was observed in.  Where
    that exists, a peptide's presenting allele narrows from "any allele in
    this study" to "the alleles of the donors it was actually seen in" —
    the per-peptide attribution overrides of #45.  This folds the two-step
    lookup (``peptide → samples``, then ``sample → alleles``) into one
    cached map.

    Parameters
    ----------
    pmid
        PubMed ID of the study, as an int or a string of digits.

    Returns
    -------
    Mapping[str, frozenset[str]]
        ``peptide → candidate alleles``.  Peptides whose donors have no
        curated genotype are omitted rather than mapped to an empty set.

    Notes
    -----
    **Empty for most studies, and that is not an error.**  It requires a
    ``peptide_attributions`` CSV, which only a handful of PMIDs have — as
    of version 1.57.1, PMIDs 31844290 and 36423003.  A sentinel test pins
    that list so this sentence fails loudly rather than going quietly
    stale.  Every other study returns an empty map, so a caller must treat
    "no entry" as "not narrowed", never as "no alleles".  This is worth
    stating because it is easy to reach for this function to explain an
    attribution result and conclude the wrong thing from an empty answer.

    Allele names are whatever the curated genotype uses, which is not
    always HLA: :func:`_parse_sample_mhc_field` deliberately handles
    non-human genotypes (``H2-K*b``, ``Patr-AL``), because restricting it
    to HLA-shaped names is the bug that stopped mouse studies from ever
    narrowing.  Do not assume an ``HLA-`` prefix.

    The value is a read-only view of a shared cache, so it cannot be
    mutated by accident; copy it if you need to modify it.

    Examples
    --------
    >>> alleles = peptide_alleles_for_pmid(31844290)
    >>> len(alleles)
    28031
    >>> sorted(alleles["AAAAAAAAAAAAAAPAP"])
    ['HLA-A*01:01', 'HLA-B*38:01', 'HLA-B*56:01', 'HLA-C*01:02', 'HLA-C*06:02']

    Those five are one donor's whole class-I genotype, not one presenting
    allele: the value is the union over every donor the peptide was seen
    in, so it narrows the candidates rather than identifying the restriction.
    Use :func:`peptide_typings_for_pmid` to see which donor supplied what.

    See Also
    --------
    peptide_typings_for_pmid : the same evidence kept per-donor rather
        than merged, for callers that need to know which donor
        contributed which alleles.
    attribute_peptide_to_sample_alleles : the same answer for a single
        peptide, without materializing the map.
    """
    pmid_int = _coerce_pmid(pmid)
    if pmid_int is None:
        return MappingProxyType({})
    return _peptide_alleles_by_pmid(pmid_int)


def peptide_typings_for_pmid(
    pmid: int | str,
) -> Mapping[str, tuple[tuple[str, frozenset[str]], ...]]:
    """Per-peptide donor typings for one study, kept per-donor.

    The same curated evidence as :func:`peptide_alleles_for_pmid`, but
    preserving which donor contributed which alleles instead of merging
    them into one union.  The scanner uses this to emit one observation
    row per matched donor (#236), so each row carries that donor's
    ``sample_label`` and its own typing.

    Parameters
    ----------
    pmid
        PubMed ID of the study, as an int or a string of digits.

    Returns
    -------
    Mapping[str, tuple[tuple[str, frozenset[str]], ...]]
        ``peptide → ((sample_label, alleles), ...)``, sorted by
        ``sample_label`` so emission order is deterministic.

    Notes
    -----
    Carries the same caveats as :func:`peptide_alleles_for_pmid`: it needs
    a ``peptide_attributions`` CSV, which only a handful of studies have,
    so an empty map means "not narrowed", not "no donors"; allele names
    are not necessarily HLA; and the result is a read-only shared view.

    Samples whose curated typing is empty are dropped — emitting a row
    with no allele set would just become an ``unmatched`` row downstream.

    Examples
    --------
    >>> typings = peptide_typings_for_pmid(31844290)
    >>> [(label, len(alleles)) for label, alleles in typings["AAAAAAAAAAAAAAPAP"]]
    [('MEL2 (13240-005)', 5)]

    See Also
    --------
    peptide_alleles_for_pmid : the same evidence merged into one candidate
        set per peptide.
    attribute_peptide_to_per_sample_typings : the same answer for a single
        peptide, without materializing the map.
    """
    pmid_int = _coerce_pmid(pmid)
    if pmid_int is None:
        return MappingProxyType({})
    return _peptide_typings_by_pmid(pmid_int)


def _clear_peptide_attribution_caches() -> None:
    """Drop both cached maps.

    The merged map is derived from the per-donor one, so clearing either
    alone leaves a stale layer behind.  Tests that monkeypatch
    ``_pmid_peptide_attributions`` or ``_pmid_sample_alleles`` need the
    whole chain gone, and previously had to know to clear two caches --
    which is the kind of thing a test forgets exactly once.
    """
    _peptide_typings_by_pmid.cache_clear()
    _peptide_alleles_by_pmid.cache_clear()


# `cache_clear` was reachable on these names while they were themselves
# `lru_cache`d.  Keep it working now that the cache sits one layer down, so
# existing callers do not silently lose the ability to invalidate.
peptide_alleles_for_pmid.cache_clear = _clear_peptide_attribution_caches
peptide_typings_for_pmid.cache_clear = _clear_peptide_attribution_caches


def attribute_peptide_to_per_sample_typings(
    pmid: int | str, peptide: str
) -> tuple[tuple[str, frozenset[str]], ...]:
    """Per-donor view of :func:`attribute_peptide_to_sample_alleles`.

    Returns a tuple of ``(sample_label, frozenset(alleles))`` pairs for
    each matched donor that observed the peptide, instead of merging
    them into one allele union.  Empty tuple when no attribution applies.

    The scanner uses this to emit one observation row per matched donor
    (issue #236), so polyspecific cohort rows decompose cleanly into
    per-sample rows with that donor's specific typing — instead of one
    row carrying the union of (e.g.) 15 alleles across 3 donors.  For an
    already resolved observation, the donor label is attached without
    rewriting the source's reported restriction (issue #414).
    """
    if not peptide:
        return ()
    return peptide_typings_for_pmid(pmid).get(peptide, ())


def attribute_peptide_to_sample_alleles(pmid: int | str, peptide: str) -> frozenset[str]:
    """Return the union of typed alleles across the samples a peptide was
    observed in within this PMID's curated cohort (#45), or an empty
    frozenset when no attribution is registered or the peptide is not
    in the map.

    Used at scan time to narrow ``host_mhc_types`` for class-only rows
    from the disease-wide union (e.g. all 14 alleles across GBM7+9+11)
    down to the matched donor's specific 6-allele genotype — turning
    14-18-allele candidate sets into 6-12-allele sets for
    set-membership / mhc_allele_in_set queries.

    Implemented as a single dict lookup against
    :func:`peptide_alleles_for_pmid` (the peptide-to-alleles map is
    pre-merged once per PMID).
    """
    if not peptide:
        return frozenset()
    return peptide_alleles_for_pmid(pmid).get(peptide, frozenset())


def _parse_host_mhc_types(host_mhc_types: str) -> frozenset[str]:
    """Parse IEDB ``Host | MHC Types Present`` into exact designations.

    IEDB uses ``;``-separated ``HLA-A*01:01;HLA-B*13:02;...`` strings.
    Free-text or non-allele tokens are dropped.
    """
    if not host_mhc_types:
        return frozenset()
    return _exact_typing_tokens(host_mhc_types)


def _filter_alleles_by_class(alleles, mhc_class: str) -> set[str]:
    """Filter a candidate allele set to those matching the row's MHC class.

    Broad class I includes non-classical class-I molecules. An explicit
    non-classical label retains only that subclass. Empty class disables filtering.
    Membership comes from the ontology, independently of species prefix.
    """
    token = normalize_mhc_class_token(mhc_class)
    if not token or token == "I+II":
        return set(alleles)
    out = set()
    for allele in alleles:
        parsed = _cached_parse(allele)
        if (
            (token == "I" and getattr(parsed, "is_class1", False))
            or (token == "II" and getattr(parsed, "is_class2", False))
            or (token == "non-classical" and _molecule_class(parsed) == "non-classical")
        ):
            out.add(allele)
    return out


# Only these historical class-only expansions replace the reported restriction.
# Gene/locus and serotype inference always retain the original coarse evidence.
CLASS_ONLY_CANDIDATE_PROVENANCES = frozenset(
    {"peptide_attribution", "sample_allele_match", "pmid_class_pool"}
)


def _candidate_matches_restriction(candidate: str, restriction, species: str) -> bool:
    """Intersect an exact designation with evidenced species, class and restriction."""
    parsed = _cached_parse(candidate)
    if species and not species_compatible(parsed.species.name, species):
        return False
    if restriction.is_class1 and not parsed.is_class1:
        return False
    if restriction.is_class2 and not parsed.is_class2:
        return False
    chains = (parsed.alpha, parsed.beta) if isinstance(parsed, Pair) else (parsed,)
    if isinstance(restriction, Gene):
        return any(
            chain.gene.name == restriction.name and chain.gene.mutations == restriction.mutations
            for chain in chains
        )
    if isinstance(restriction, Class2Locus):
        return all(chain.gene.name in restriction.gene_names for chain in chains)
    if isinstance(restriction, Serotype):
        return any(
            restriction.to_string() in allele_to_all_serotypes(chain.to_string())
            for chain in chains
        )
    return True


@lru_cache(maxsize=16384)
def expand_allele_set(
    mhc_restriction: str,
    host_mhc_types: str = "",
    pmid: int | str = "",
    mhc_class: str = "",
    attributed_alleles: frozenset[str] = frozenset(),
    *,
    species_context: str = "",
) -> tuple[str, str, int]:
    """Expand a (possibly coarse) MHC restriction to a candidate exact-allele
    set with provenance.

    Issue #137: downstream training pipelines need to know which exact
    4-digit alleles a row's restriction could plausibly map to, plus how
    that mapping was obtained, so they can do MIL / noisy-OR training over
    allele sets instead of silently collapsing or dropping coarse
    restrictions.

    Logic:

    - ``four_digit`` rows use the derived identity with provenance ``exact``.
      That tier is "names one molecule", so it includes haplotype-designated
      non-human alleles (``H2-Kb``, ``H2-AA*b/AB*b``, ``RT1-Bb*l``) whose
      single allele field is the complete designation (#597).
    - ``class_only`` rows (e.g. ``"HLA class I"``) are expanded against,
      in priority order:

      1. ``attributed_alleles`` — a per-peptide attribution from the
         paper supplement (#45), passed in by the caller after looking
         up the peptide in :func:`attribute_peptide_to_sample_alleles`.
         Provenance: ``peptide_attribution``.
      2. The row's ``Host | MHC Types Present`` (the donor's typed
         alleles, when IEDB carries them). Provenance: ``sample_allele_match``.
      3. The per-PMID ``hla_alleles`` block. Provenance: ``pmid_class_pool``.

      In all cases the candidate set is filtered to the row's MHC class.
    - Gene/locus restrictions use the same typing precedence, intersected with
      reported species, class and locus. Provenance is ``peptide_locus_match``,
      ``sample_locus_match`` or ``pmid_locus_pool``; the reported restriction
      stays coarse. Supplied chains/pairs remain intact; no partner is invented.
    - Serological restrictions use the same typing precedence, intersected
      with the known membership of each exact candidate. Provenance is
      ``peptide_serotype_match``, ``sample_serotype_match`` or
      ``pmid_serotype_pool``. The reported serotype remains unchanged; no
      catalog members are added to the candidate pool.
    - A populated, class-scoped haplotype uses only its mhcgnomes roster
      members with ``haplotype_roster`` provenance. Empty or ambiguous
      haplotypes remain unmatched; no class-II partner is synthesized.
    - Blank, two-digit and other unresolved restrictions remain ``unmatched``.
      No unrestricted catalog expansion is performed.

    A nonempty strongest typing tier never falls through to a broader pool if
    its compatible intersection is empty. Generic class labels have unknown
    species unless curated context supplies it; explicit MHC species dominates
    host/source species, including engineered and xenogeneic experiments.

    Note: ``attributed_alleles`` is taken as a hashable ``frozenset`` so the
    lru_cache key stays cheap. Pass ``frozenset()`` (the default) when no
    per-peptide attribution applies; otherwise the caller looks the
    peptide up against :func:`attribute_peptide_to_sample_alleles` once
    per row.  The ``frozenset`` shape gives identical sets from different
    peptides the same cache key, so peptides that map to the same
    sample union still share a cache slot.

    Returns
    -------
    tuple[str, str, int]
        ``(mhc_allele_set, mhc_allele_provenance, mhc_allele_set_size)``
        where the set is ``;``-joined (parquet-friendly, consistent with
        existing ``serotypes`` / ``gene_names`` columns).
    """
    resolution = classify_allele_resolution(mhc_restriction)
    if resolution == "four_digit":
        return resolve_allele_identity(mhc_restriction), "exact", 1

    species_context = species_context or pmid_mhc_species_context(pmid)
    restriction, _, _ = _parse_with_context(mhc_restriction, species_context)
    haplotype_class = _class_scoped_haplotype(restriction)
    if haplotype_class:
        candidates = {
            resolve_allele_identity(allele.to_string())
            for allele in restriction.alleles
            if _is_exact_allele_candidate(allele.to_string())
        }
        candidates = _filter_alleles_by_class(candidates, haplotype_class)
        candidates = _filter_alleles_by_class(candidates, mhc_class)
        if not candidates:
            return "", "unmatched", 0
        return ";".join(sorted(candidates)), "haplotype_roster", len(candidates)
    locus_inference = isinstance(restriction, (Gene, Class2Locus))
    serotype_inference = isinstance(restriction, Serotype) and resolution == "serological"
    if not (locus_inference or serotype_inference) and resolution != "class_only":
        return "", "unmatched", 0

    species = ""
    if species_context or getattr(restriction, "species_source", "") != "default":
        species = restriction.species.name

    sample_alleles = _parse_host_mhc_types(host_mhc_types)
    if (
        (locus_inference or serotype_inference)
        and not attributed_alleles
        and host_mhc_types
        and not sample_alleles
    ):
        # An incomplete donor designation is still a stronger typing tier.
        # Do not replace its missing fields/chains with a study-wide union.
        try:
            spans = _mhc_field_spans(host_mhc_types)
        except ValueError:
            return "", "unmatched", 0
        if any(isinstance(parsed, (Allele, Gene, Pair, Serotype)) for _, parsed in spans):
            return "", "unmatched", 0
    pmid_int: int | None = None
    if pmid:
        with contextlib.suppress(ValueError, TypeError):
            pmid_int = int(pmid)
    pool = _pmid_allele_pool(pmid_int) if pmid_int is not None else frozenset()

    candidates = attributed_alleles or sample_alleles or pool
    if not candidates:
        return "", "unmatched", 0

    candidates = {
        resolve_allele_identity(a, species_context)
        for a in candidates
        if _is_exact_allele_candidate(a, species_context)
    }
    candidates = {a for a in candidates if _candidate_matches_restriction(a, restriction, species)}
    candidates = _filter_alleles_by_class(candidates, mhc_class)
    if not candidates:
        return "", "unmatched", 0

    if locus_inference:
        provenances = ("peptide_locus_match", "sample_locus_match", "pmid_locus_pool")
    elif serotype_inference:
        provenances = ("peptide_serotype_match", "sample_serotype_match", "pmid_serotype_pool")
    else:
        provenances = ("peptide_attribution", "sample_allele_match", "pmid_class_pool")
    provenance = provenances[0 if attributed_alleles else 1 if sample_alleles else 2]
    return ";".join(sorted(candidates)), provenance, len(candidates)


def _matches_condition(row_fields: dict[str, str], condition: dict) -> bool:
    """Check if a row's fields match a condition dict.

    Each condition key is an IEDB field name, value is either a string
    or a list of strings. All conditions must match (AND logic).
    String matching is case-insensitive for Source Tissue.

    Field-specific matching:
      - "Source Tissue" — case-insensitive equality.
      - "Assay Comments" — case-insensitive substring match. IEDB sometimes
        concatenates per-arm provenance into a single Assay Comments cell
        (e.g. "eluted from CRC tissue. eluted from NMC tissue") so substring
        match is the only way to recognize an arm in a combined row.
      - All other fields — exact equality (case-sensitive).
    """
    for field, expected in condition.items():
        actual = row_fields.get(field, "")
        if field == "Assay Comments":
            actual_lower = actual.lower()
            if isinstance(expected, list):
                if not any(str(v).lower() in actual_lower for v in expected):
                    return False
            elif str(expected).lower() not in actual_lower:
                return False
        elif isinstance(expected, list):
            # Any of the listed values matches
            if field == "Source Tissue":
                if actual.lower() not in {v.lower() for v in expected}:
                    return False
            elif actual not in expected:
                return False
        else:
            if field == "Source Tissue":
                if actual.lower() != str(expected).lower():
                    return False
            elif actual != expected:
                return False
    return True


@lru_cache(maxsize=16384)
def restriction_evidence_for_row(
    mhc_restriction: str,
    *,
    pmid: int | str = "",
    submission_id: str = "",
    is_binding_assay: bool = False,
    is_monoallelic: bool = False,
    process_type: str = "",
    disease: str = "",
    culture_condition: str = "",
    source_tissue: str = "",
    cell_name: str = "",
    assay_comments: str = "",
    assay_method: str = "",
    response_measured: str = "",
    qualitative_measurement: str = "",
) -> str:
    """Classify how a row establishes its named MHC restriction.

    A restriction must name one resolved molecule before it can carry a
    positive evidence claim. Curated PMID rules win over safe structural
    inference; uncurated multi-allelic observations remain ``unknown`` even
    when their source export happens to contain a four-digit allele.
    """
    if not _is_resolved_allele(mhc_restriction):
        return "unknown"

    entry = None
    if pmid:
        with contextlib.suppress(ValueError, TypeError):
            entry = load_pmid_overrides().get(int(pmid))
    if entry is None and submission_id:
        entry = load_pmid_overrides().get(submission_id)

    if entry:
        row_fields = {
            "MHC Restriction": str(mhc_restriction),
            "Process Type": str(process_type),
            "Disease": str(disease),
            "Culture Condition": str(culture_condition),
            "Source Tissue": str(source_tissue),
            "Cell Name": str(cell_name),
            "Assay Comments": str(assay_comments),
            "Assay Method": str(assay_method),
            "Response Measured": str(response_measured),
            "Qualitative Measurement": str(qualitative_measurement),
        }
        for rule in entry.get("restriction_evidence_rules") or []:
            if _matches_condition(row_fields, rule.get("condition") or {}):
                return rule["evidence"]
        curated = entry.get("restriction_evidence")
        if curated:
            return curated

    if is_binding_assay:
        return "experimental"
    if is_monoallelic:
        return "monoallelic"
    return "unknown"


@lru_cache(maxsize=16384)
def classify_ms_row(
    process_type: str,
    disease: str,
    culture_condition: str,
    source_tissue: str = "",
    cell_name: str = "",
    pmid: int | str = "",
    mhc_restriction: str = "",
    mhc_species_context: str = "",
    submission_id: str = "",
    assay_comments: str = "",
) -> dict[str, bool | str]:
    """Classify a public-MS row into curated source-context flags.

    Uses data-driven PMID overrides and tissue categories from YAML files.

    Cached by the full argument tuple. In the IEDB scanner the same
    (process_type, disease, culture_condition, source_tissue, cell_name)
    tuple repeats across all rows of a study with at most a handful of
    unique mhc_restriction values per sample, so the cache keeps a
    couple tens of thousands of entries at most vs millions of row
    classifications. The returned dict is not mutated by any known
    caller (both scanner.py and supplement.py splat it with ``**`` or
    ``record.update`` — no in-place edits), so sharing the cached
    instance across rows is safe.

    Parameters
    ----------
    process_type
        IEDB "Process Type" field.
    disease
        IEDB "Disease" field.
    culture_condition
        IEDB "Culture Condition" field.
    source_tissue
        IEDB "Source Tissue" field.
    cell_name
        IEDB "Cell Name" field.
    pmid
        PubMed ID for per-study override lookup.
    mhc_restriction
        IEDB "MHC Restriction" field value. Used to check whether
        the reported allele is endogenous to a mono-allelic host.
    mhc_species_context
        Optional curated study species used to resolve ambiguous MHC
        nomenclature. Explicit cross-species designations still win.
    assay_comments
        IEDB "Assay Comments" field. Some studies (e.g. PMID 29789417,
        Löffler 2018 CRC) tag per-row arm provenance only in the
        free-text Assay Comments column, so PMID rules can match on it
        via substring search.

    Returns
    -------
    dict[str, bool | str]
        Source flags plus ``cell_line_name`` (the line, with any
        ``<line>-<cell_type>`` hybrid suffix stripped) and ``cell_type``
        (the tissue / cell-type part, ``""`` when unknown) — see #261.
    """
    process_type = str(process_type).strip() if pd.notna(process_type) else ""
    disease = str(disease).strip() if pd.notna(disease) else ""
    culture_condition = str(culture_condition).strip() if pd.notna(culture_condition) else ""
    source_tissue_str = str(source_tissue).strip() if pd.notna(source_tissue) else ""
    source_tissue_lower = source_tissue_str.lower()
    cell_name_str = str(cell_name).strip() if pd.notna(cell_name) else ""
    assay_comments_str = str(assay_comments).strip() if pd.notna(assay_comments) else ""

    categories = load_tissue_categories()
    overrides = load_pmid_overrides()

    # Parse PMID and submission_id
    pmid_int = None
    if pmid:
        with contextlib.suppress(ValueError, TypeError):
            pmid_int = int(pmid)
    submission_id_str = str(submission_id).strip() if pd.notna(submission_id) else ""

    # Base signals
    is_ex_vivo = culture_condition == "Direct Ex Vivo"
    is_cell_line = culture_condition in (
        "Cell Line / Clone",
        "Cell Line / Clone (EBV transformed, B-LCL)",
    )
    is_ebv_lcl = culture_condition == "Cell Line / Clone (EBV transformed, B-LCL)"

    # The curated cell-line registry (cell_lines.yaml) distinguishes
    # genuinely malignant EBV+ lines (Raji: is_ebv_lcl=false, the tumor
    # itself) from EBV-transformed reference/surrogate hosts (JY, C1R:
    # is_ebv_lcl=true, immortalized from an unrelated normal donor) --
    # a distinction IEDB's single generic "Cell Line / Clone (EBV
    # transformed, B-LCL)" Culture Condition tag conflates, and that tag
    # is sometimes simply absent for a row whose Cell Name plainly names
    # a registered line (e.g. THP-1). When the name resolves to a known
    # line, trust the registry over the raw IEDB tag for both signals --
    # the same precedent as the mono-allelic-host EBV-LCL correction
    # below, which already overrides IEDB "regardless of how [it] tagged
    # the culture condition." Every registry entry carries both fields
    # (see ``registry_verdict``), so a hit is always a complete verdict.
    _registry_cell_info = parse_cell_name(cell_name_str)
    _verdict = registry_verdict(_registry_cell_info.cell_line_name)
    if _verdict is not None:
        is_cell_line = True
        is_ebv_lcl = _verdict["is_ebv_lcl"]

    is_reproductive = source_tissue_lower in categories["reproductive"]
    is_reproductive_female = source_tissue_lower in categories["reproductive_female"]
    is_reproductive_male = source_tissue_lower in categories["reproductive_male"]
    is_thymus = source_tissue_lower in categories["thymus"]

    # Auto-detect activated APCs: DCs/macrophages from blood
    is_activated_apc = (
        cell_name_str.lower() in categories["activated_apc_cell_names"]
        and source_tissue_lower in categories["activated_apc_tissues"]
    )

    # ── Apply PMID override (three-level specificity) ─────────────────
    # Level 1: conditional rules (checked first, in order)
    # Level 2: PMID-level default override
    # Level 3: no match → fall through to structured-field classification
    effective_override = None
    # Look up override by PMID (int) or submission_id (str)
    entry = None
    if pmid_int and pmid_int in overrides:
        entry = overrides[pmid_int]
    elif submission_id_str and submission_id_str in overrides:
        entry = overrides[submission_id_str]

    if entry is not None:
        # Build row fields for condition matching
        row_fields = {
            "Source Tissue": source_tissue_str,
            "Culture Condition": culture_condition,
            "Cell Name": cell_name_str,
            "Disease": disease,
            "Process Type": process_type,
            "Assay Comments": assay_comments_str,
        }

        # Level 1: check conditional rules
        for rule in entry.get("rules", []):
            condition = rule.get("condition", {})
            if _matches_condition(row_fields, condition):
                effective_override = rule.get("override")
                break

        # Level 2: PMID-level default (only if no rule matched)
        if effective_override is None:
            effective_override = entry.get("override")

    # ── Classification ──────────────────────────────────────────────────
    if effective_override == "cancer_patient":
        is_cancer = True
        is_adjacent = False
        is_activated_apc = False
    elif effective_override == "adjacent":
        is_cancer = False
        is_adjacent = True
        is_activated_apc = False
    elif effective_override == "activated_apc":
        is_cancer = False
        is_adjacent = False
        is_activated_apc = True
    elif effective_override == "cell_line":
        # A registered line's curated verdict is authoritative when known
        # (see the default branch below for why is_ebv_lcl alone isn't
        # enough); otherwise fall back to the is_ebv_lcl heuristic.
        is_cancer = _verdict["is_cancer"] if _verdict is not None else not is_ebv_lcl
        is_adjacent = False
        is_activated_apc = False
    elif effective_override == "noncancer_cell_line":
        # Non-malignant immortalized line (hTERT / SV40-LT / engineered from
        # normal cells). A cell line, but not a tumor — so src_cell_line stays
        # True while src_cancer is forced False. Force is_cell_line even when
        # IEDB's culture_condition is missing/wrong (same as ebv_lcl).
        is_cancer = False
        is_adjacent = False
        is_activated_apc = False
        is_cell_line = True
    elif effective_override == "ebv_lcl":
        is_cancer = False
        is_adjacent = False
        is_activated_apc = False
        is_ebv_lcl = True  # force even if IEDB culture_condition is wrong
        is_cell_line = True
    elif effective_override == "healthy":
        is_cancer = False
        is_adjacent = False
        is_activated_apc = False
    else:
        # Default: non-EBV cell lines are cancer-derived. When the cell
        # name resolves to a registered line, its curated is_cancer verdict
        # is authoritative -- the is_ebv_lcl heuristic alone can't express
        # a non-malignant, non-EBV-LCL immortalized line (HEK293T: SV40-
        # transformed, is_cancer=false, is_ebv_lcl=false; JAWS II likewise).
        if _verdict is not None:
            is_cancer = process_type == "Occurrence of cancer" or _verdict["is_cancer"]
        else:
            is_cancer = process_type == "Occurrence of cancer" or (is_cell_line and not is_ebv_lcl)
        is_adjacent = False

    # Healthy requires: ex vivo, no cancer/adjacent/apc, no disease.
    # When override is "healthy", force the healthy path regardless of
    # process_type / disease fields (the override corrects bad IEDB metadata).
    is_healthy_donor = effective_override == "healthy" or (
        is_ex_vivo
        and not is_cancer
        and not is_adjacent
        and not is_activated_apc
        and process_type == "No immunization"
        and disease in ("healthy", "")
    )

    cl_name = cell_name_str if (is_cell_line or is_ebv_lcl) else ""

    # Mono-allelic detection: cell_name alias matching
    is_monoallelic = False
    mono_host = ""
    if is_cell_line or is_ebv_lcl:
        is_monoallelic, mono_host = detect_monoallelic(cell_name_str, mhc_restriction)

    # PMID-level mono-allelic override — is_monoallelic is a SAMPLE-level
    # claim, so the override applies per-row only when the row's allele
    # is resolved (four/two-digit or serological).  Class-only /
    # unresolved rows cannot be mono-allelic because we don't know which
    # allele produced the peptide — this single gate correctly de-flags
    # validation rows in mixed papers (Sarkizova 2020's 12 patient
    # tumors all have mhc_restriction == "HLA class I" in IEDB).  We
    # intentionally do NOT gate on cell_name: IEDB frequently records
    # the host under a wrong specific label (Trolle 2016's 721.221
    # transfectants appear as "HeLa cells-Epithelial cell"), and the
    # whole purpose of the PMID override is to correct that annotation.
    # ``entry`` is the PMID-level override dict looked up above (not
    # the rule-specific override), so it remains bound even when no
    # rules matched.
    if not is_monoallelic and entry is not None:
        host = entry.get("mono_allelic_host")
        if host and _is_resolved_allele(mhc_restriction):
            is_monoallelic = True
            mono_host = host
        # Method-based mono-allelic (e.g., MAPTAC tagged pulldown) —
        # not a cell line, so not in monoallelic_lines.yaml.
        method = entry.get("mono_allelic_method")
        if not is_monoallelic and method and _is_resolved_allele(mhc_restriction):
            is_monoallelic = True
            mono_host = method

    # A mono-allelic peptidome produced on a known EBV-LCL transfection host
    # (721.221, C1R) is EBV-immortalized B-cell material, not a tumor — so it
    # classifies as ebv_lcl and never src_cancer, regardless of how IEDB tagged
    # the culture condition (which is inconsistent for these hosts).  This is
    # the single source of truth: it auto-corrects ~313K observations across
    # all 721.221/C1R studies (Sarkizova 2020, Abelin 2017, ...) that were
    # previously mislabeled src_cancer because IEDB tagged them plain
    # "Cell Line / Clone".  Genuinely malignant hosts (K562 = CML) are not
    # flagged ebv_lcl in monoallelic_lines.yaml and keep src_cancer.
    if is_monoallelic and mono_host in _ebv_lcl_mono_hosts():
        is_ebv_lcl = True
        is_cancer = False

    # Decompose IEDB's catch-all ``Cell Name`` into a clean line name plus a
    # separate ``cell_type`` (#261 stage 2).  ``parse_cell_name`` strips the
    # ``<line>-<cell_type>`` hybrid suffix ("K562-Myeloid cell" → line
    # "K562", type "Myeloid cell") and canonicalizes known synonyms
    # ("HeLa cells" → "HeLa").  We only overwrite ``cl_name`` when this row
    # already had a line name, and fall back to the parser's raw line input
    # (then the original string) so a cell-line row whose line isn't in the
    # registry never loses its identifier.
    cell_info = parse_cell_name(
        cell_name_str,
        monoallelic_host=mono_host,
        src_cell_line=(is_cell_line or is_ebv_lcl),
    )
    cell_type = cell_info.cell_type
    if cl_name:
        cl_name = cell_info.cell_line_name or cell_info.cell_line_input or cl_name

    return {
        "src_cancer": is_cancer,
        "src_adjacent_to_tumor": is_adjacent,
        "src_activated_apc": is_activated_apc,
        "src_healthy_tissue": (
            is_healthy_donor
            and not is_reproductive
            and not is_reproductive_female
            and not is_reproductive_male
            and not is_thymus
        ),
        "src_healthy_thymus": is_healthy_donor and is_thymus,
        "src_healthy_reproductive": is_healthy_donor and is_reproductive,
        "src_healthy_reproductive_female": is_healthy_donor and is_reproductive_female,
        "src_healthy_reproductive_male": is_healthy_donor and is_reproductive_male,
        "src_cell_line": is_cell_line,
        "src_ebv_lcl": is_ebv_lcl,
        "src_ex_vivo": is_ex_vivo,
        "cell_line_name": cl_name,
        "cell_type": cell_type,
        "is_monoallelic": is_monoallelic,
        "monoallelic_host": mono_host,
        "allele_resolution": classify_allele_resolution(mhc_restriction),
        "serotype": allele_to_serotype(mhc_restriction),
        "serotypes": ";".join(allele_to_all_serotypes(mhc_restriction)),
        "mhc_species": classify_mhc_species(mhc_restriction, mhc_species_context),
    }


_BINDING_ASSAY_KEYWORDS = re.compile(
    r"microarray|binding|refolding|MEDi|iTopia|yeast display|mammalian epitope display",
    re.IGNORECASE,
)

_COMPETITIVE_BINDING_ASSAY_KEYWORDS = re.compile(
    r"acid strip(?:ped)?|reference peptide|IC50|(?:human\s+)?(?:beta2m|β2m)",
    re.IGNORECASE,
)


@cache
def is_binding_assay(
    qualitative_measurement: str,
    assay_comments: str,
    assay_method: str = "",
    response_measured: str = "",
) -> bool:
    """Identify binding assays; False alone never establishes MS evidence."""
    from .assays import assay_annotations

    return assay_annotations(
        qualitative_measurement, assay_comments, assay_method, response_measured
    )["is_binding_assay"]


def _legacy_is_binding_assay(
    qualitative_measurement: str,
    assay_comments: str,
) -> bool:
    """Comment/tier binding fallback when structured modality is unresolved."""
    qm = qualitative_measurement.strip() if qualitative_measurement else ""
    # Negative results and quantitative tiers are binding assays
    if qm in ("Negative", "Positive-High", "Positive-Intermediate", "Positive-Low"):
        return True
    # "Positive" rows can still be binding assays when the comments
    # describe the assay format explicitly.
    return bool(
        qm == "Positive"
        and assay_comments
        and (
            _BINDING_ASSAY_KEYWORDS.search(assay_comments)
            or _COMPETITIVE_BINDING_ASSAY_KEYWORDS.search(assay_comments)
        )
    )


def _clear_curation_caches() -> None:
    """Reload file-backed curation and its derived annotations on the next build."""
    from .cell_name_parser import _load_registry

    for cached in (
        load_pmid_overrides,
        ms_excluded_pmids,
        load_tissue_categories,
        load_tissue_groups,
        load_monoallelic_lines,
        pmid_provenance,
        pmid_mhc_species_context,
        _load_registry,
        _ebv_lcl_mono_hosts,
        _pmid_allele_pool,
        _pmid_sample_alleles,
        _pmid_peptide_attributions,
        _peptide_typings_by_pmid,
        _peptide_alleles_by_pmid,
        _class_i_prediction_scope,
        expand_allele_set,
        restriction_evidence_for_row,
        classify_ms_row,
    ):
        cached.cache_clear()


def is_cancer_specific(flags: dict[str, bool]) -> bool:
    """Test if a peptide's aggregated flags indicate cancer-specificity.

    Cancer-specific = found in cancer AND NOT found in healthy somatic tissue.
    """
    return bool(
        flags.get("found_in_cancer", False) and not flags.get("found_in_healthy_tissue", False)
    )
