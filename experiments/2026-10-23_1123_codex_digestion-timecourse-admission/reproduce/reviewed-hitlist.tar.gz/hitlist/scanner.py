# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""General-purpose IEDB/CEDAR MHC ligand CSV scanner.

Scans IEDB and CEDAR MHC ligand full exports, resolves column indices
dynamically from CSV headers, and applies source classification via
the curation module.

Supports both targeted peptide scanning and full dataset profiling,
with class I/II separation and tqdm progress bars.
"""

from __future__ import annotations

import csv
import os
import warnings
from pathlib import Path

import pandas as pd

try:
    from tqdm.auto import tqdm as _tqdm
except ImportError:
    _tqdm = None

from .curation import (
    CLASS_ONLY_CANDIDATE_PROVENANCES,
    classify_ms_row,
    expand_allele_set,
    restriction_evidence_for_row,
)
from .peptide_modifications import parse_peptide_modifications

# Sentinel so we can tell "user didn't pass mhc_species" apart from
# "user explicitly passed mhc_species=None (disable filter)".
_UNSET: object = object()

#: source_tissue values that mean "no anatomical site recorded" — treated as
#: unresolved so a curated per-PMID source_tissue can replace them (#307/#314).
_UNRESOLVED_TISSUE: frozenset[str] = frozenset(
    {"", "other", "unidentified", "unknown", "n/a", "na"}
)

# ── Column name → index resolution ─────────────────────────────────────────

_COLUMN_NAMES: dict[str, list[str]] = {
    "assay_iri": [
        "Assay ID | IEDB IRI",
        "Assay ID | CEDAR IRI",
        "Assay IRI",
        "Assay - Assay IRI",
    ],
    "ref_iri": [
        "Reference | IEDB IRI",
        "Reference | CEDAR IRI",
        "Reference IRI",
        "Reference - Reference IRI",
    ],
    "pmid": ["PMID", "Reference | PMID"],
    "submission_id": ["Submission ID", "Reference | Submission ID"],
    "ref_title": ["Title", "Reference | Title"],
    "epitope_name": ["Epitope | Name", "Epitope Name"],
    "source_organism": ["Source Organism", "Epitope | Source Organism"],
    "species": ["Epitope | Species", "Species"],
    "host": ["Host", "Host | Name"],
    "host_age": ["Host Age", "Host | Age"],
    "host_mhc_types": ["Host | MHC Types Present", "MHC Types Present"],
    "process_type": ["Process Type", "Host | Process Type"],
    "disease": ["Disease", "Host | Disease"],
    "disease_stage": ["Disease Stage", "Host | Disease Stage"],
    "antigen_processing_comments": ["Antigen Processing | Comments", "Antigen Processing Comments"],
    "qualitative_measurement": ["Qualitative Measurement"],
    "assay_method": ["Assay | Method", "Method"],
    "response_measured": ["Assay | Response measured", "Response measured"],
    "measurement_units": ["Assay | Units", "Units"],
    "measurement_inequality": ["Assay | Measurement Inequality", "Measurement Inequality"],
    "quantitative_measurement": [
        "Assay | Quantitative measurement",
        "Quantitative measurement",
    ],
    "assay_comments": ["Assay | Comments", "Assay Comments"],
    "source_tissue": ["Source Tissue", "Effector Cells | Source Tissue"],
    "cell_name": [
        "Antigen Presenting Cell | Name",
        "Cell Name",
        "Effector Cells | Cell Name",
    ],
    "culture_condition": ["Culture Condition", "Assay | Culture Condition"],
    "mhc_restriction": ["MHC Restriction | Name", "MHC Restriction Name"],
    "mhc_class": ["MHC Allele Class", "Class"],
}

_FALLBACK_INDICES: dict[str, int] = {
    "assay_iri": 0,
    "ref_iri": 1,
    "pmid": 3,
    "submission_id": 4,
    "ref_title": 8,
    "epitope_name": 11,
    "source_organism": 23,
    "species": 25,
    "host": 43,
    "host_age": 48,
    "host_mhc_types": 49,
    "process_type": 50,
    "disease": 51,
    "disease_stage": 53,
    "antigen_processing_comments": 88,
    "qualitative_measurement": 94,
    "assay_method": 90,
    "response_measured": 91,
    "measurement_units": 92,
    "measurement_inequality": 95,
    "quantitative_measurement": 96,
    "assay_comments": 101,
    "source_tissue": 102,
    "cell_name": 104,
    "culture_condition": 106,
    "mhc_restriction": 107,
    "mhc_class": 111,
}


def _resolve_columns(cat_header: list[str], field_header: list[str]) -> dict[str, int]:
    """Resolve column indices from IEDB/CEDAR header rows.

    Every key in :data:`_COLUMN_NAMES` is expected to resolve by matching
    the two header rows.  :data:`_FALLBACK_INDICES` exists only as a last
    resort and is deliberately never allowed to fire silently: a positional
    index is only meaningful against the exact layout it was measured from
    (112 IEDB columns), and CEDAR has added a column since without renaming
    anything (#470) -- proof that layouts drift.  A column that stops
    resolving by name is a genuine "hitlist doesn't recognize this header
    yet" and must say so, not guess a neighboring column and continue.
    """
    indices: dict[str, int] = {}
    combined_lower = []
    for i in range(max(len(cat_header), len(field_header))):
        cat = cat_header[i].strip() if i < len(cat_header) else ""
        fld = field_header[i].strip() if i < len(field_header) else ""
        combined_lower.append(f"{cat} | {fld}".lower() if cat and fld else (fld or cat).lower())
    field_lower = [f.strip().lower() for f in field_header]

    for key, candidates in _COLUMN_NAMES.items():
        for candidate in candidates:
            cl = candidate.lower()
            for i, hv in enumerate(combined_lower):
                if cl in hv or hv.endswith(cl):
                    indices[key] = i
                    break
            if key in indices:
                break
            for i, hv in enumerate(field_lower):
                if cl in hv or hv == cl:
                    indices[key] = i
                    break
            if key in indices:
                break
    unresolved = sorted(set(_COLUMN_NAMES) - set(indices))
    if unresolved:
        column_count = max(len(cat_header), len(field_header))
        raise ValueError(
            f"could not resolve column(s) {unresolved} by name against a "
            f"{column_count}-column header. _COLUMN_NAMES' candidates for "
            f"{unresolved} need a new entry matching this file's header text "
            f"-- a positional fallback here would be a guess with no way to "
            f"detect if it lands on the wrong column (#470). "
            f"Nearby header text: "
            + "; ".join(
                f"[{i}] {cat_header[i] if i < len(cat_header) else ''!r} | "
                f"{field_header[i] if i < len(field_header) else ''!r}"
                for i in sorted(
                    {
                        j
                        for key in unresolved
                        for j in range(
                            max(0, _FALLBACK_INDICES.get(key, 0) - 1),
                            min(column_count, _FALLBACK_INDICES.get(key, 0) + 2),
                        )
                    }
                )
            )
        )
    return indices


def _safe_col(row: list[str], idx: int) -> str:
    return row[idx] if len(row) > idx else ""


def _parse_float(value: str) -> float:
    """Parse a cell to ``float``; return NaN for empty or non-numeric values.

    IEDB's quantitative-measurement column is mostly numeric but contains
    stray empty strings, whitespace, and occasional free-text notes.
    Callers downstream filter with ``value.notna()`` + ``value.between(...)``,
    so NaN is the right sentinel.
    """
    if not value:
        return float("nan")
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return float("nan")


class _ByteCountingFile:
    """Wrap a text file so we can track how many bytes have been read.

    ``csv.reader`` disables ``tell()`` on the underlying file via its
    buffered-read optimization, so we count bytes ourselves in
    ``readline``.  Supports the subset of file methods ``csv.reader``
    actually uses.
    """

    __slots__ = ("_fh", "bytes_read")

    def __init__(self, fh):
        self._fh = fh
        self.bytes_read = 0

    def readline(self, *args, **kwargs) -> str:
        line = self._fh.readline(*args, **kwargs)
        # bytes_read tracks encoded size; line is already str, so use
        # its length (close enough — ASCII dominates IEDB exports).
        self.bytes_read += len(line)
        return line

    def __iter__(self):
        return self

    def __next__(self):
        line = self._fh.readline()
        if not line:
            raise StopIteration
        self.bytes_read += len(line)
        return line

    def close(self) -> None:
        self._fh.close()


def _open_csv(path: Path) -> tuple[csv.reader, dict[str, int], Path, _ByteCountingFile]:
    fh = _ByteCountingFile(open(path, newline=""))  # noqa: SIM115
    reader = csv.reader(fh)
    cat_header = next(reader, [])
    field_header = next(reader, [])
    cols = _resolve_columns(cat_header, field_header)
    return reader, cols, path, fh


def _progress(reader, path: Path, desc: str, fh: _ByteCountingFile | None = None):
    """Yield rows with a tqdm progress bar.

    Updates progress in bytes every ``update_every`` rows instead of
    per-row — avoids per-row ``sum(len(f) for f in row)`` which was
    >50% of scan time for large files.
    """
    if _tqdm is None:
        yield from reader
        return
    total = os.path.getsize(path)
    update_every = 1000
    with _tqdm(total=total, unit="B", unit_scale=True, desc=desc, leave=False) as pbar:
        last_bytes = 0
        for i, row in enumerate(reader):
            yield row
            if fh is not None and (i + 1) % update_every == 0:
                now = fh.bytes_read
                pbar.update(now - last_bytes)
                last_bytes = now
        if fh is not None:
            pbar.update(max(total - last_bytes, 0))


# ── Public API ──────────────────────────────────────────────────────────────


def scan(
    peptides: set[str] | None = None,
    iedb_path: str | Path | None = None,
    cedar_path: str | Path | None = None,
    mhc_species: str | object | None = _UNSET,
    species_fallback: bool = True,
    mhc_class: str | None = None,
    classify_source: bool = True,
    min_allele_resolution: str | None = None,
    human_only: bool | None = None,
    *,
    provenance=None,
) -> pd.DataFrame:
    """Scan IEDB/CEDAR for matching peptides, or profile entire dataset.

    Parameters
    ----------
    peptides
        Peptide sequences to match. If None, scans ALL rows (profile mode).
    iedb_path, cedar_path
        Paths to IEDB/CEDAR exports.
    mhc_species
        Keep only rows where the MHC molecule belongs to this species
        (e.g. ``"Homo sapiens"``, ``"Mus musculus"``).  Uses mhcgnomes on
        the MHC restriction annotation as the authoritative species source.
        Default ``"Homo sapiens"``.  Pass ``None`` to disable species
        filtering entirely.
    species_fallback
        When mhcgnomes cannot resolve the species from the MHC restriction
        string (e.g. bare ``"HLA class I"``), fall back to the ``host`` /
        ``species`` text columns for the species decision.  Default ``True``
        — matches historical behavior.  Pass ``False`` for strict
        mhcgnomes-only filtering; rows with unparseable restrictions are
        dropped.
    mhc_class
        Filter to ``"I"`` or ``"II"``. None = both.
    classify_source
        Run source classification (default True).
    min_allele_resolution
        Minimum allele resolution to keep. One of ``"four_digit"``,
        ``"two_digit"``, ``"serological"``, ``"class_only"``. Rows
        with coarser resolution are dropped. None = no filtering.
    human_only
        .. deprecated:: 1.9.0
            Use ``mhc_species`` instead.  ``human_only=True`` maps to
            ``mhc_species="Homo sapiens"``; ``human_only=False`` maps to
            ``mhc_species=None``.  If both are passed, ``mhc_species`` wins.
            Slated for removal in hitlist 2.0.

    Returns
    -------
    pd.DataFrame
        Deduplicated by assay IRI. Includes source classification columns
        when ``classify_source=True``.
    """
    # ── Deprecation / migration for human_only ────────────────────────────
    if human_only is not None:
        warnings.warn(
            "human_only is deprecated and will be removed in hitlist 2.0; "
            "use mhc_species='Homo sapiens' (or mhc_species=None to disable "
            "species filtering).",
            DeprecationWarning,
            stacklevel=2,
        )
        if mhc_species is _UNSET:
            mhc_species = "Homo sapiens" if human_only else None
        # else: both passed — mhc_species wins silently (explicit new kwarg).
    if mhc_species is _UNSET:
        mhc_species = "Homo sapiens"
    source_paths: list[Path] = []
    if iedb_path is not None:
        source_paths.append(Path(iedb_path))
    if cedar_path is not None:
        source_paths.append(Path(cedar_path))

    from .assays import assay_annotations
    from .curation import (
        allele_resolution_rank,
        attribute_peptide_to_per_sample_typings,
        classify_allele_resolution,
        is_non_peptide_ligand,
        normalize_species,
        peptide_attribution_applies_to_row,
        pmid_mhc_species_context,
        resolve_mhc_annotation,
    )

    if mhc_species is not None:
        mhc_species = normalize_species(mhc_species)
    min_res_rank = allele_resolution_rank(min_allele_resolution) if min_allele_resolution else None

    rows: list[dict] = []
    seen: set[str] = set()
    scan_id = provenance.begin_scan() if provenance is not None else None

    for source_path in source_paths:
        if not source_path.exists():
            continue
        dataset = "iedb" if iedb_path is not None and source_path == Path(iedb_path) else "cedar"
        if provenance is not None:
            provenance.register_source(dataset, source_path)
        reader, c, p, fh = _open_csv(source_path)
        for row_number, row in enumerate(_progress(reader, p, f"Scanning {p.name}", fh=fh), 1):
            if peptides is not None:
                pep_raw = _safe_col(row, c["epitope_name"])
                # Match the targeted-peptide filter against either the
                # raw string (back-compat) or the bare PTM-stripped form
                # (so callers passing bare AA sequences still match
                # rows that IEDB has annotated with PTMs).
                if pep_raw not in peptides:
                    bare = parse_peptide_modifications(pep_raw)[0]
                    if bare not in peptides:
                        continue
            # Dedup only on a *present* Assay IRI. A blank IRI is not an
            # identity — deduping on "" would collapse every blank-IRI row
            # (distinct observations) into one. _safe_col guards short rows.
            iri = _safe_col(row, c["assay_iri"])
            record_id = ""
            if provenance is not None:
                record_id = provenance.record(
                    dataset, row_number, {name: _safe_col(row, col) for name, col in c.items()}, row
                )
            if iri:
                if provenance is not None:
                    if provenance.duplicate_assay(scan_id, iri, record_id):
                        continue
                else:
                    if iri in seen:
                        continue
                    seen.add(iri)

            src_org = _safe_col(row, c["source_organism"])
            species = _safe_col(row, c["species"])
            host = _safe_col(row, c["host"])
            raw_pmid = _safe_col(row, c["pmid"]).strip()
            pmid: str | int = ""
            if raw_pmid:
                try:
                    pmid = int(raw_pmid)
                except ValueError:
                    pmid = raw_pmid

            mhc_res_raw = _safe_col(row, c["mhc_restriction"])
            reported_mhc_class = _safe_col(row, c["mhc_class"])
            mhc_species_context = pmid_mhc_species_context(pmid)
            mhc_annotation = resolve_mhc_annotation(
                mhc_res_raw,
                reported_mhc_class,
                mhc_species_context,
            )
            mhc_res = mhc_annotation.restriction

            # Species filtering: use MHC allele name (via mhcgnomes) as the
            # authoritative species source; when species_fallback=True and
            # mhcgnomes can't parse, fall back to host/species text columns.
            mhc_sp = mhc_annotation.mhc_species

            if mhc_species is not None:
                if mhc_sp:
                    if mhc_sp != mhc_species:
                        continue
                elif species_fallback:
                    if mhc_species not in (
                        normalize_species(host),
                        normalize_species(species),
                    ):
                        continue
                else:
                    # Strict mode: unparseable MHC restriction → drop.
                    continue
            if mhc_class is not None and mhc_annotation.mhc_class != mhc_class:
                continue
            if min_res_rank is not None:
                res = classify_allele_resolution(mhc_res)
                if allele_resolution_rank(res) > min_res_rank:
                    continue

            # Per-PMID source-organism curation (#307): fill the source proteome
            # for self-peptidome datasets IEDB left blank / "unidentified".  Only
            # fills genuinely-unresolved rows, and only for PMIDs explicitly
            # curated in pmid_overrides.yaml (NOT a blanket source=host rule).
            if not src_org or src_org.strip().lower() == "unidentified":
                from .curation import pmid_source_organism

                curated_src, curated_spc = pmid_source_organism(pmid)
                if curated_src:
                    src_org = curated_src
                    if not species or species.strip().lower() == "unidentified":
                        species = curated_spc

            process_type = _safe_col(row, c["process_type"])
            disease = _safe_col(row, c["disease"])
            culture_condition = _safe_col(row, c["culture_condition"])
            source_tissue = _safe_col(row, c["source_tissue"])
            cell_name = _safe_col(row, c["cell_name"])

            # Per-PMID provenance curation (#314): fill blank source_tissue /
            # cell_name / disease / culture_condition for epitope-ID papers IEDB
            # left unlabeled, from the PMID's pmid_overrides entry.  Fills before
            # classification so a curated cell line classifies correctly.  Only
            # fills unresolved values.  IEDB's "Other"/"unidentified" sentinels
            # (for source_tissue or cell_name) count as unresolved, so curating
            # the real value replaces them (#36 / "Other"-tissue papers).
            from .cell_name_parser import _UNINFORMATIVE_CELL_NAMES

            _cell_unresolved = cell_name.strip().lower() in _UNINFORMATIVE_CELL_NAMES
            _tissue_unresolved = source_tissue.strip().lower() in _UNRESOLVED_TISSUE
            if not (
                not _tissue_unresolved and not _cell_unresolved and disease and culture_condition
            ):
                from .curation import pmid_provenance

                _prov = pmid_provenance(pmid)
                if _prov:
                    if _tissue_unresolved and _prov.get("source_tissue"):
                        source_tissue = _prov["source_tissue"]
                    if _cell_unresolved and _prov.get("cell_name"):
                        cell_name = _prov["cell_name"]
                    disease = disease or _prov.get("disease", "")
                    culture_condition = culture_condition or _prov.get("culture_condition", "")

            # IEDB embeds PTMs inline in the Epitope|Name column
            # (e.g. "LQPFPQPQLPY + DEAM(Q8)"). Pull them into structured
            # columns so length filters, AA validation, and model
            # training inputs see clean sequences while PTM information
            # is preserved alongside (#194).
            (
                bare_peptide,
                peptide_modifications_str,
                has_ptm,
                peptide_extended,
            ) = parse_peptide_modifications(_safe_col(row, c["epitope_name"]))

            record: dict = {
                "peptide": bare_peptide,
                "peptide_modifications": peptide_modifications_str,
                "has_ptm": has_ptm,
                "peptide_extended": peptide_extended,
                **mhc_annotation.as_record_fields(),
                "assay_iri": iri,
                "reference_iri": _safe_col(row, c["ref_iri"]),
                "pmid": pmid,
                "submission_id": _safe_col(row, c["submission_id"]),
                "reference_title": _safe_col(row, c["ref_title"]),
                "source_organism": src_org,
                "species": species,
                "host": _safe_col(row, c["host"]),
                "host_age": _safe_col(row, c["host_age"]),
                "host_mhc_types": _safe_col(row, c["host_mhc_types"]),
                "process_type": process_type,
                "disease": disease,
                "disease_stage": _safe_col(row, c["disease_stage"]),
                "source_tissue": source_tissue,
                "cell_name": cell_name,
                "culture_condition": culture_condition,
                "antigen_processing_comments": _safe_col(row, c["antigen_processing_comments"]),
                "assay_comments": _safe_col(row, c["assay_comments"]),
                "qualitative_measurement": _safe_col(row, c["qualitative_measurement"]),
                # Structured quantitative binding-assay fields from IEDB /
                # CEDAR (issue #148, issue #135).  The raw string is preserved
                # so consumers can audit parsing; ``quantitative_value`` is the
                # float cast (NaN when the cell is empty / non-numeric) for
                # downstream filtering.  ``measurement_inequality`` ("", "<",
                # ">", "=", "<=", ">=") paired with ``quantitative_value``
                # distinguishes exact IC50 measurements from bounded ones.
                # ``response_measured`` (e.g. "qualitative binding",
                # "half life", "ligand presentation", "dissociation constant
                # KD") is the readout type — combined with ``assay_method``
                # and ``measurement_units`` it tells consumers whether a
                # numeric value is IC50 vs Kd vs t_half vs Tm.
                "assay_method": _safe_col(row, c["assay_method"]),
                "response_measured": _safe_col(row, c["response_measured"]),
                "measurement_units": _safe_col(row, c["measurement_units"]),
                "measurement_inequality": _safe_col(row, c["measurement_inequality"]),
                "quantitative_measurement": _safe_col(row, c["quantitative_measurement"]),
                "quantitative_value": _parse_float(_safe_col(row, c["quantitative_measurement"])),
                **assay_annotations(
                    _safe_col(row, c["qualitative_measurement"]),
                    _safe_col(row, c["assay_comments"]),
                    _safe_col(row, c["assay_method"]),
                    _safe_col(row, c["response_measured"]),
                ),
                # Flags rows whose MHC molecule presents lipids / metabolites
                # rather than peptides (CD1, MR1, MIC, ULBP, etc. — see #228).
                # IEDB curates these alongside peptide-MHC and stores chemical
                # names or compound IDs in the peptide column; downstream
                # peptide consumers should filter these out.
                "is_non_peptide_ligand": is_non_peptide_ligand(mhc_res),
            }

            if classify_source:
                record.update(
                    classify_ms_row(
                        process_type,
                        disease,
                        culture_condition,
                        source_tissue,
                        cell_name,
                        pmid,
                        mhc_restriction=mhc_res,
                        mhc_species_context=mhc_species_context,
                        submission_id=record.get("submission_id", ""),
                        assay_comments=record.get("assay_comments", ""),
                    )
                )
            record["restriction_evidence"] = restriction_evidence_for_row(
                mhc_res,
                pmid=pmid,
                submission_id=record.get("submission_id", ""),
                is_binding_assay=bool(record["is_binding_assay"]),
                is_monoallelic=bool(record.get("is_monoallelic", False)),
                process_type=process_type,
                disease=disease,
                culture_condition=culture_condition,
                source_tissue=source_tissue,
                cell_name=cell_name,
                assay_comments=record.get("assay_comments", ""),
                assay_method=record.get("assay_method", ""),
                response_measured=record.get("response_measured", ""),
                qualitative_measurement=record.get("qualitative_measurement", ""),
            )
            # Exact-allele set expansion (issue #137).  Computed off the
            # row's MHC restriction + the donor's typed alleles (Host |
            # MHC Types Present, when IEDB carries them) + the per-PMID
            # ``hla_alleles`` curation pool.  Provenance disambiguates
            # ``exact`` (already 4-digit) / ``sample_allele_match`` /
            # ``pmid_class_pool`` / ``unmatched``.  Always emitted so the
            # parquet schema is uniform across modalities.
            #
            # Per-peptide attribution lookup (#45 / #236 / #414): for PMIDs
            # that registered a ``peptide_attributions:`` CSV, the helper
            # returns one ``(sample_label, alleles)`` pair per matched donor.
            # Class-only rows narrow to that donor's typing; already resolved
            # rows retain their reported restriction and gain only the
            # source-backed sample label when that source cohort is eligible
            # for the registered map (#534). Multiple matched
            # donors emit one record apiece.  For every other row the helper
            # returns ``()`` and the original single-record path is unchanged.
            per_sample_typings: tuple[tuple[str, frozenset[str]], ...] = ()
            if bare_peptide and peptide_attribution_applies_to_row(pmid, mhc_res_raw):
                per_sample_typings = attribute_peptide_to_per_sample_typings(pmid, bare_peptide)

            host_mhc_types = record.get("host_mhc_types", "")
            row_mhc_class = record.get("mhc_class", "")

            if per_sample_typings:
                # Multi-donor split: one emitted record per matched donor.
                for sample_label, donor_alleles in per_sample_typings:
                    donor_allele_set, donor_prov, donor_size = expand_allele_set(
                        mhc_res,
                        host_mhc_types,
                        pmid,
                        row_mhc_class,
                        donor_alleles,
                        species_context=mhc_species_context,
                    )
                    donor_record = dict(record)
                    donor_record["mhc_allele_set"] = donor_allele_set
                    donor_record["mhc_allele_provenance"] = donor_prov
                    donor_record["mhc_allele_set_size"] = donor_size
                    donor_record["attributed_sample_label"] = sample_label
                    if provenance is not None:
                        donor_record["provenance_id"] = provenance.observe(record_id, sample_label)
                    # Promote a narrowed class-only set to ``mhc_restriction``
                    # (#45).  An exact source restriction remains unchanged;
                    # the curated donor label is independent metadata (#414).
                    if donor_size > 0 and donor_prov in CLASS_ONLY_CANDIDATE_PROVENANCES:
                        donor_annotation = resolve_mhc_annotation(
                            donor_allele_set,
                            reported_mhc_class,
                            mhc_species_context,
                        )
                        donor_record.update(donor_annotation.as_record_fields())
                    rows.append(donor_record)
                continue

            allele_set, set_provenance, set_size = expand_allele_set(
                mhc_res,
                host_mhc_types,
                pmid,
                row_mhc_class,
                frozenset(),
                species_context=mhc_species_context,
            )
            record["mhc_allele_set"] = allele_set
            record["mhc_allele_provenance"] = set_provenance
            record["mhc_allele_set_size"] = set_size
            record["attributed_sample_label"] = ""
            if provenance is not None:
                record["provenance_id"] = provenance.observe(record_id)

            # Retain historical class-only promotion (#45). New gene/locus
            # inference remains a separate candidate set even for a singleton;
            # it never upgrades the reported restriction's precision (#599).
            if set_size > 0 and set_provenance in CLASS_ONLY_CANDIDATE_PROVENANCES:
                promoted_annotation = resolve_mhc_annotation(
                    allele_set,
                    reported_mhc_class,
                    mhc_species_context,
                )
                record.update(promoted_annotation.as_record_fields())

            rows.append(record)
        # Close the wrapped file handle explicitly — relying on garbage
        # collection produced ResourceWarnings under pytest's strict-
        # warning filters (the noqa: SIM115 in _open_csv signals the
        # close lives at the call site).
        fh.close()

    return pd.DataFrame(rows)
