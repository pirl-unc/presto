# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Build the unified peptide indexes from IEDB + CEDAR.

Runs the full scanner (with source classification from YAML overrides)
on each registered data source, deduplicates by assay IRI, partitions
rows by assay type, maps peptides to source proteins with flanking
context, and writes TWO parquet indexes to the data directory
(:func:`hitlist.downloads.data_dir`):

- ``observations.parquet`` — MS-eluted immunopeptidome rows (plus
  manually-curated supplementary data).
- ``binding.parquet`` — binding-assay rows (peptide microarray,
  refolding, MEDi, and quantitative-tier measurements).

- ``other_assays.parquet`` — structural, non-MS ligand, unknown/conflicting
  assays and explicit negative MS results, retained with source contributors.

Modality is independent of result polarity. Curated supplements are MS-only.
All three indexes use the same peptide-mappings sidecar.

Usage::

    from hitlist.builder import build_observations

    path = build_observations()                     # IEDB + CEDAR
    path = build_observations(with_flanking=True)   # + proteome mapping

CLI::

    hitlist build observations
    hitlist build observations --with-flanking
    hitlist build observations --force
"""

from __future__ import annotations

import contextlib
import csv
import hashlib
import json
from pathlib import Path

import pandas as pd

from .dataset import dataset_cache_check, dataset_path, dataset_snapshot
from .downloads import data_dir
from .parquet_io import atomic_write_parquet, concat_non_empty

#: Schema/semantic contract for observations + binding artifacts. Metadata
#: without this exact value is legacy and must rebuild once on upgrade.
#:
#: 3: ``serotype_source`` names whether a serotype is reported or computed
#:    (#458), and the serotype reverse map reaches the six C-locus
#:    specificities it used to drop (#455), so stored serotypes change.
#: 4: Serotypes retain their MHC species and include non-human catalog
#:    memberships, avoiding collisions with human alleles (#463).
#: 5: The MS index honors the curated ``exclude_from_ms`` flag, so 11
#:    non-MS studies no longer contribute rows (#444).  A cache built
#:    before this still holds them, which is why it must rebuild.
#: 6: Peptide-to-patient maps respect source-cohort restrictions (#534),
#:    preventing false labels and donor copies of monoallelic observations.
#: 7: Every retained observation links to all contributors before deduplication.
#: 9: Positive MS modality, separate other-assay retention and provenance (#644).
#: 10: Established positive outcomes; unknown MS results remain other evidence (#665).
_OBSERVATIONS_ARTIFACT_VERSION = 10


def _source_paths() -> dict[str, Path]:
    """Resolve registered IEDB/CEDAR paths."""
    from .downloads import get_path

    sources: dict[str, Path] = {}
    for name in ("iedb", "cedar"):
        with contextlib.suppress(KeyError, FileNotFoundError):
            p = get_path(name)
            if p.exists():
                sources[name] = p
    return sources


def _stat_fingerprint(path: Path) -> dict:
    """Standard size + mtime + path fingerprint."""
    stat = path.stat()
    return {
        "path": str(path),
        "size": stat.st_size,
        "mtime": stat.st_mtime,
    }


def _mhcgnomes_version() -> str:
    """Version of the library that computed the derived MHC columns."""
    try:
        import mhcgnomes

        return str(getattr(mhcgnomes, "__version__", "") or "unknown")
    except ImportError:  # pragma: no cover - mhcgnomes is a hard dependency
        return "unavailable"


def _source_fingerprints(paths: dict[str, Path], *, fetch_missing_assets: bool = True) -> dict:
    """File identity for cache invalidation.

    ``fetch_missing_assets=False`` keeps this free of network side effects
    for the cache-validity predicate (#448); see :func:`_curation_fingerprints`.
    """
    fp = {name: _stat_fingerprint(p) for name, p in paths.items()}
    fp.update(_curation_fingerprints(fetch_missing_assets=fetch_missing_assets))
    # Include supplementary manifest so adding a new supplement invalidates cache
    from .supplement import load_supplementary_manifest, manifest_path

    mp = manifest_path()
    if mp.exists():
        fp["supplementary_manifest"] = _stat_fingerprint(mp)
        # Also fingerprint each referenced CSV so edits invalidate cache
        supp_dir = mp.parent / "supplementary"
        for entry in load_supplementary_manifest():
            csv_path = supp_dir / entry["file"]
            if csv_path.exists():
                fp[f"supplementary_csv:{entry['file']}"] = _stat_fingerprint(csv_path)

    # ── Line-expression cache fingerprints (issue #150, #577) ───────────
    # The stamp a built line-expression index carries: a content hash of
    # every packaged build input (anchor registry, sources.yaml, packaged
    # CSVs, the ENSG -> symbol map) plus the index build version.  Recording
    # the same mapping here means the rebuild a stale-index warning asks for
    # is one this cache agrees is needed, from the same evidence.  A
    # content hash also replaces the per-file stat entries it supersedes:
    # sizes and timestamps can survive an install that changed the bytes.
    from .line_expression import line_expression_index_stamp

    fp["line_expression_index"] = line_expression_index_stamp()

    # DepMap inputs are registered via downloads.py and live outside the
    # repo; fingerprint by registered path so a re-register / re-download
    # forces a line-expression rebuild.
    from .downloads import _load_manifest

    manifest = _load_manifest()
    registered = manifest.get("datasets", {}) or {}
    for key in ("depmap_rna", "depmap_rna_transcript", "depmap_models"):
        entry = registered.get(key)
        if not entry:
            continue
        path_str = entry.get("path")
        if not path_str:
            continue
        p = Path(path_str)
        if p.exists():
            fp[f"line_expression_input:{key}"] = _stat_fingerprint(p)

    return fp


def _curation_fingerprints(*, fetch_missing_assets: bool = True) -> dict:
    """Content identity of inputs used to annotate persisted evidence (#424).

    Externalized ``peptide_attributions`` CSVs are fetched when a wheel
    install has not cached them yet, because a build needs their bytes.
    With ``fetch_missing_assets=False`` an absent asset is recorded as
    ``{"missing": True}`` instead. That never equals a stored fingerprint, so
    the cache reads as stale — the verdict a build would reach anyway, since
    fetching stamps a fresh mtime — and no network is touched (#448).
    """
    from .cell_name_parser import _registry_path
    from .curation import _asset_path, _data_path
    from .curation_yaml import load_curation_yaml
    from .downloads import packaged_or_cached

    paths: dict[str, Path | None] = {
        name: Path(_data_path(name))
        for name in ("pmid_overrides.yaml", "tissue_categories.yaml", "monoallelic_lines.yaml")
    }
    paths["cell_lines.yaml"] = _registry_path()
    # Read the on-disk YAML, not the cached curation loader: an edit may add
    # or remove a dependency while this interpreter still has the old map.
    entries = load_curation_yaml(paths["pmid_overrides.yaml"]) or []
    for entry in entries:
        rel_path = entry.get("peptide_attributions")
        if not rel_path:
            continue
        if fetch_missing_assets:
            paths[rel_path] = Path(_asset_path(rel_path))
        else:
            paths[rel_path] = packaged_or_cached(_data_path(rel_path), Path(rel_path).name)
    return {
        f"curation:{name}": (
            {"missing": True}
            if path is None
            else {
                **_stat_fingerprint(path),
                # These inputs are small. Hashing detects same-size edits even
                # when a checkout or copy preserves the file's timestamp.
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
        )
        for name, path in sorted(paths.items())
    }


def _observations_path() -> Path:
    return dataset_path("observations.parquet", root=data_dir())


def _binding_path() -> Path:
    return dataset_path("binding.parquet", root=data_dir())


def _other_assays_path() -> Path:
    return dataset_path("other_assays.parquet", root=data_dir())


def _bulk_proteomics_path() -> Path:
    return dataset_path("bulk_proteomics.parquet", root=data_dir())


def _meta_path() -> Path:
    return dataset_path("observations_meta.json", root=data_dir())


@dataset_snapshot()
def _parquet_fingerprints() -> dict:
    """Size + mtime of the four index parquets, for cache validation.

    Pairs with ``_source_fingerprints`` to detect either (a) source CSV
    changes or (b) a parquet file being manually edited / replaced
    between builds.  Issue #150: ``line_expression`` joined the
    fingerprint set so a manually-rewritten ``line_expression.parquet``
    (or a registered DepMap input replaced after the last build) forces
    the next ``hitlist build observations`` to rebuild the line-expression
    index instead of trusting the stale parquet.
    """
    fp: dict = {}
    for label, p in (
        ("observations", _observations_path()),
        ("binding", _binding_path()),
        ("other_assays", _other_assays_path()),
        ("bulk_proteomics", _bulk_proteomics_path()),
        ("line_expression", _line_expression_path()),
        ("contributors", dataset_path("observation_contributors.parquet", root=data_dir())),
    ):
        if p.exists():
            stat = p.stat()
            fp[label] = {"size": stat.st_size, "mtime": stat.st_mtime}
    return fp


@dataset_cache_check
def _cache_is_valid(
    paths: dict[str, Path], with_flanking: bool = False, *, fetch_missing_assets: bool = True
) -> bool:
    """Check if the cached indexes are still valid for the requested build.

    All four parquets (``observations``, ``binding``, ``bulk_proteomics``,
    ``line_expression``) must be present AND their fingerprints must
    match the stored metadata.  Binding was added in 1.7.0,
    bulk_proteomics in 1.11.2, and line_expression in 1.16.0, so older
    installs rebuild once on upgrade.

    ``fetch_missing_assets=False`` is the read-only mode the public
    :func:`hitlist.observations.observations_cache_is_current` uses (#448).
    """
    meta = _meta_path()
    if not meta.exists():
        return False
    if not _observations_path().exists():
        return False
    if not _binding_path().exists():
        return False
    if not _other_assays_path().exists():
        return False
    if not _bulk_proteomics_path().exists():
        return False
    if not _line_expression_path().exists():
        return False
    if not (dataset_path("observation_contributors.parquet", root=data_dir())).exists():
        return False
    stored = json.loads(meta.read_text())
    if stored.get("artifact_version") != _OBSERVATIONS_ARTIFACT_VERSION:
        return False
    from .provenance import SCHEMA_VERSION

    contract = stored.get("provenance", {})
    if contract.get("schema_version") != SCHEMA_VERSION:
        return False
    if not {"contributors", "indexes", "sources"} <= contract.keys():
        return False
    if stored.get("sources") != _source_fingerprints(
        paths, fetch_missing_assets=fetch_missing_assets
    ):
        return False
    stored_parquets = stored.get("parquets")
    return not (stored_parquets is not None and stored_parquets != _parquet_fingerprints())


@dataset_snapshot()
def _cache_meta() -> dict:
    """Load the observations_meta.json for user-facing info."""
    meta = _meta_path()
    if meta.exists():
        return json.loads(meta.read_text())
    return {}


#: Columns whose distinct-value cardinality is small relative to row count —
#: converting to ``category`` dtype before concat / write cuts the in-memory
#: footprint of the observations frame ~5-10x (Python ``str`` overhead is
#: 50-100 bytes per cell vs. 1-4 bytes for a category code on a small
#: dictionary).  Holding the full obs + binding frames in RAM during the
#: ``build_peptide_mappings`` step previously peaked at ~40 GB; categorical
#: compression brings the peak down to single-digit GB without changing the
#: written parquet (pyarrow stores categoricals as dictionary-encoded columns
#: regardless, so the on-disk artifact is byte-identical).
#:
#: Excluded by design:
#:
#: - ``peptide`` — millions of distinct values, no repetition. Categorical
#:   would *increase* memory (codes + dictionary > raw strings).
#: - ``assay_iri`` / ``reference_iri`` — unique-per-row IRIs; same as above.
#: - ``pmid`` — already stored as ``Int64`` (8 bytes / row); ~38 MB on a
#:   4.4 M-row frame, no further compression worthwhile.
#: - ``mhc_allele_set`` / ``serotypes`` / ``gene_names`` etc. —
#:   semicolon-joined multi-value columns whose consumers split on ``;``.
#:
#:   The cardinality half of this rationale is false, and measuring it is how
#:   #566 went wrong: the list says "every donor set is roughly distinct", but
#:   the built corpus has 969 distinct ``mhc_allele_set`` values across 4.4M
#:   rows, 638 ``serotypes`` and 878 ``host_mhc_types``. As plain strings they
#:   cost ~700 MB.
#:
#:   What was measured, and what was not:
#:
#:   - Encoding them at *read* time is a loss. It requires converting the
#:     Arrow table ourselves, which holds the table alongside the frame and
#:     measured worse than ``pd.read_parquet``; the zero-copy variants that do
#:     cut peak hand back read-only buffers and break every
#:     ``df.loc[mask, col] = ...`` in the load path.
#:   - Encoding them at *build* time -- i.e. adding them to this list -- was
#:     not tried, and the read-time blocker above does not apply to it: a
#:     ``category`` column survives ``to_parquet``/``read_parquet`` as a
#:     category with no custom Arrow read (see the note above, and
#:     ``observations`` relying on ``mhc_class`` arriving categorical).
#:     Against it: ``load_observations`` expands ``mhc_allele_set`` when an
#:     identity refresh is pending and ``serotypes`` when an alias refresh is
#:     -- both conditional, both firing on today's corpus -- so some of the
#:     saving is given back on load, and how much is unmeasured.
#:
#:   So the list is unchanged because the cheap option is untested, not
#:   because it is known to fail. Measure the build-time variant before
#:   changing it, and do not act on the cardinality numbers alone (#566).
_CATEGORICAL_BUILD_COLUMNS: tuple[str, ...] = (
    "source",
    "mhc_class",
    "mhc_class_reported",
    "mhc_class_source",
    "mhc_species",
    "mhc_species_source",
    "mhc_restriction",
    "mhc_allele_provenance",
    "restriction_evidence",
    "allele_resolution",
    "serotype",
    "serotype_source",
    "host",
    "host_age",
    "process_type",
    "disease",
    "disease_stage",
    "source_tissue",
    "cell_name",
    "cell_line_name",
    "cell_type",
    "culture_condition",
    "assay_method",
    "assay_modality",
    "assay_modality_source",
    "ms_outcome_status",
    "response_measured",
    "measurement_units",
    "measurement_inequality",
    "qualitative_measurement",
    "species",
    "source_organism",
)

#: ``promote_options`` for the cross-source ``pa.concat_tables`` calls below.
#:
#: Each of the 28 columns above is compressed to a pandas ``category`` — and
#: therefore an Arrow ``dictionary`` — independently per source partition
#: (IEDB, CEDAR), so pyarrow's dictionary-index width is chosen from *that
#: partition's own* distinct-value count: <=127 categories fits ``int8``,
#: more needs ``int16``.  ``"default"`` promotes null-typed/missing columns
#: but does not reconcile two dictionaries of the same value type at
#: different index widths, and raises ``ArrowTypeError`` the moment one
#: source's cardinality crosses the ``int8`` boundary and another's doesn't
#: (#478).  ``"permissive"`` does the same null/missing promotion *and*
#: widens mismatched-but-compatible types (dictionary index width, integer
#: width, string vs large_string, ...) to a common denominator — it still
#: rejects a genuine mismatch like ``int64`` vs ``string``, so this is not a
#: relaxation of the schema check, only of the width it insists on.
_CONCAT_PROMOTE_OPTIONS = "permissive"


def _compress_categoricals(df: pd.DataFrame, *, strict: bool = False) -> None:
    """In-place ``object → category`` for low-cardinality string columns.

    No-op for columns not present (unless ``strict=True``) or already
    non-object.  Mutates the frame.

    Parameters
    ----------
    strict
        Raise ``KeyError`` if any column listed in
        :data:`_CATEGORICAL_BUILD_COLUMNS` is missing from ``df``.  Use
        on the full post-concat observations frame so a typo in the
        allowlist (e.g. ``"mhc_clas"``) fails loudly instead of silently
        no-op'ing.  Default ``False`` to keep the helper safe to call on
        per-source partitions where some columns may be absent.
    """
    if df.empty:
        return
    if strict:
        missing = [c for c in _CATEGORICAL_BUILD_COLUMNS if c not in df.columns]
        if missing:
            raise KeyError(
                f"_compress_categoricals(strict=True): missing columns {missing}; "
                "either fix the typo in _CATEGORICAL_BUILD_COLUMNS or call with strict=False."
            )
    for col in _CATEGORICAL_BUILD_COLUMNS:
        if col not in df.columns:
            continue
        # ``is_string_dtype`` covers ``object``, pandas ``StringDtype``,
        # and Arrow-backed string dtypes — newer pandas versions infer
        # ``str`` dtype by default for plain string columns, so an
        # ``== "object"`` check would silently skip them.  Already-
        # categorical columns return False (they're a separate dtype),
        # which is what we want for idempotence.
        if pd.api.types.is_string_dtype(df[col]) and df[col].dtype.name != "category":
            series = df[col].astype("category")
            # Pre-add ``""`` to the category set so downstream ``fillna("")``
            # idioms (export.py, supplement.py, scanner.py) don't raise the
            # categorical out-of-category ``TypeError`` when the column had
            # no empty strings in source data.  Same bug class as v1.30.41 /
            # v1.30.43; fixing systemically here avoids the whack-a-mole of
            # patching every individual fillna site.
            if "" not in series.cat.categories:
                series = series.cat.add_categories([""])
            df[col] = series


#: Scheme + host of an IRI.  Stripped before the dedup comparison so the
#: same assay matches whichever database served it.
_IRI_ORIGIN_RE = r"^https?://[^/]+"


def _union_columns(frames) -> list[str]:
    """Ordered union of the columns across ``frames``."""
    out: list[str] = []
    for frame in frames:
        for col in frame.columns:
            if col not in out:
                out.append(col)
    return out


def _drop_duplicate_iris(df: pd.DataFrame, label: str, *, provenance=None) -> pd.DataFrame:
    """Drop cross-source duplicates by ``assay_iri`` (#146).

    Replaces the prior per-source-loop ``ms_seen_iris: set[str]`` Python
    set, which held all ~4 M IRIs as ``str`` objects (~300 MB).  Doing
    the dedup post-concat with ``drop_duplicates(keep="first")`` is
    pandas-vectorized and uses an ephemeral hash table; the concat
    order (IEDB before CEDAR) preserves the prior "IEDB wins" tie-break.

    Falls back to ``reference_iri`` for rows missing ``assay_iri``,
    which is unusual but possible during partial rebuilds from older
    intermediates.

    IRIs are compared by path, not raw string.  IEDB and CEDAR publish
    the same assay under different scheme *and* host —
    ``http://www.iedb.org/assay/25034276`` vs
    ``https://cedar.iedb.org/assay/25034276`` — so the raw strings never
    collided and every shared assay was counted twice (#351).  Stripping
    the origin is a no-op when both sources already agree on a host.
    """
    if df.empty:
        return df
    if "assay_iri" in df.columns:
        primary = df["assay_iri"].fillna("").astype(str)
        if "reference_iri" in df.columns:
            ref = df["reference_iri"].fillna("").astype(str)
            primary = primary.where(primary.ne(""), ref)
    elif "reference_iri" in df.columns:
        primary = df["reference_iri"].fillna("").astype(str)
    else:
        return df
    # Compare by path so the same assay matches across IEDB / CEDAR
    # hosts (#351).  Non-IRI values are left untouched.
    primary = primary.str.strip().str.replace(_IRI_ORIGIN_RE, "", regex=True)
    # Per-donor split rows (#236) share assay_iri but differ in
    # ``attributed_sample_label`` — fold the label into the dedup key so
    # the split survives.  Empty label (non-attributed rows) preserves
    # the original behavior.
    if "attributed_sample_label" in df.columns:
        sample_label = df["attributed_sample_label"].fillna("").astype(str)
        key = primary.str.cat(sample_label, sep="\x1f")
    else:
        key = primary
    before = len(df)
    if provenance is not None:
        identified = primary.ne("")
        if "provenance_id" in df:
            missing_assay = (
                df["assay_iri"].astype("string").fillna("").str.strip().eq("")
                if "assay_iri" in df
                else pd.Series(True, index=df.index)
            )
            provenance.retain_duplicates(
                df.loc[identified, ["provenance_id"]],
                key.loc[identified],
                "database_copy",
                uncertain_keys=set(key.loc[identified & missing_assay]),
            )
    # ``Series.duplicated`` is the boolean-mask analog of ``drop_duplicates``;
    # avoids round-tripping through a temporary ``_iri_key`` column.
    df = df[primary.eq("") | ~key.duplicated(keep="first")].reset_index(drop=True)
    dropped = before - len(df)
    if dropped:
        print(f"  Deduplicated {dropped:,} {label} rows by assay_iri (cross-source overlap)")
    return df


def _drop_supplementary_duplicates(
    supp: pd.DataFrame, obs: pd.DataFrame, *, provenance=None
) -> pd.DataFrame:
    """Anti-join supplementary rows against IEDB/CEDAR rows on
    ``(peptide, mhc_restriction, pmid)`` — IEDB/CEDAR wins when the
    triple is shared (#45 supplements are intentionally redundant
    when the paper is also in IEDB).

    Replaces an earlier ``set(zip(...))`` Python set that held ~4 M
    tuples (~800 MB).  ``pandas.merge(indicator=True)`` runs the same
    hash-join in C without materializing a Python set.

    Three correctness guards baked in:

    1. Empty ``obs`` (no IEDB/CEDAR rows scanned) → synthesize an
       empty key frame so ``.merge`` returns ``supp`` unchanged
       instead of raising ``KeyError`` on missing columns.
    2. ``peptide`` / ``mhc_restriction`` may be categorical on obs and
       object on supp → cast both to ``str`` so the join keys share
       dtype.
    3. ``pmid`` may be ``Int64`` on one side and Python ``int`` /
       object on the other → normalize to ``Int64`` on both sides
       so ``1`` (int) doesn't silently miss ``1`` (Int64).  The
       full-frame ``pmid → Int64`` cast in :func:`build_observations`
       happens AFTER this dedup, so we align dtypes locally here.

    Returns
    -------
    pd.DataFrame
        Filtered ``supp`` with the merge indicator column dropped and
        the index reset.
    """
    if supp.empty:
        return supp
    join_cols = ["peptide", "mhc_restriction", "pmid"]
    if obs.empty:
        obs_keys = pd.DataFrame({c: pd.Series(dtype="object") for c in join_cols})
    else:
        obs_keys = (
            obs[join_cols]
            .drop_duplicates()
            .assign(
                peptide=lambda d: d["peptide"].astype(str),
                mhc_restriction=lambda d: d["mhc_restriction"].astype("string").fillna(""),
                pmid=lambda d: pd.to_numeric(d["pmid"], errors="coerce").astype("Int64"),
            )
        )
    supp = supp.astype({"peptide": str, "mhc_restriction": str})
    supp["pmid"] = pd.to_numeric(supp["pmid"], errors="coerce").astype("Int64")
    if provenance is not None and not obs.empty and "provenance_id" in obs:
        candidates = obs[[*join_cols, "provenance_id"]].assign(
            peptide=lambda d: d["peptide"].astype(str),
            mhc_restriction=lambda d: d["mhc_restriction"].astype("string").fillna(""),
            pmid=lambda d: pd.to_numeric(d["pmid"], errors="coerce").astype("Int64"),
        )
        matches = supp[[*join_cols, "provenance_id"]].merge(candidates, on=join_cols)
        for source, target in matches[["provenance_id_x", "provenance_id_y"]].itertuples(
            index=False, name=None
        ):
            provenance.redirect(source, target, "supplementary_overlap")
    return (
        supp.merge(obs_keys, on=join_cols, how="left", indicator=True)
        .query("_merge == 'left_only'")
        .drop(columns="_merge")
        .reset_index(drop=True)
    )


def _drop_masked_rows(
    df: pd.DataFrame, mask: pd.Series, label: str, what: str, reason: str, *, top_n: int = 5
) -> pd.DataFrame:
    """Shared skeleton for a "drop these rows and print an audit trail" filter.

    Prints the drop count and the top-``top_n`` PMIDs affected, matching the
    other per-PMID print loops in this module. Factored out of
    :func:`_drop_short_mhc2_rows` and :func:`_drop_excluded_from_ms` (#471),
    which had drifted to duplicate the print-and-filter shape while only one
    of the two capped its per-PMID breakdown.
    """
    n_drop = int(mask.sum())
    if n_drop == 0:
        return df
    print(f"  Dropped {n_drop:,} {what} from {label} ({reason})")
    if "pmid" in df.columns:
        for pmid, n in df.loc[mask, "pmid"].value_counts().head(top_n).items():
            print(f"    PMID {pmid}: {n:,} rows")
    return df[~mask].reset_index(drop=True)


def _drop_short_mhc2_rows(df: pd.DataFrame, label: str) -> pd.DataFrame:
    """Drop ``mhc_class == "II"`` rows with peptides shorter than 12 aa.

    MHC-II binding requires ~12-25 aa peptides; 8-11 aa rows annotated
    as class II are overwhelmingly IEDB import errors (e.g. HLA Ligand
    Atlas PMID 33858848 attributing class-I elutions to the class-II
    bucket).  Prints the drop count and top-5 PMIDs affected so the
    curator can audit.  See pirl-unc/hitlist#122.
    """
    if df.empty or "mhc_class" not in df.columns or "peptide" not in df.columns:
        return df
    mask = (df["mhc_class"] == "II") & (df["peptide"].str.len() < 12)
    return _drop_masked_rows(df, mask, label, "short MHC-II rows", "peptide < 12 aa, #122")


def _drop_excluded_from_ms(df: pd.DataFrame, label: str) -> pd.DataFrame:
    """Drop rows from studies curated as *not* MS elution experiments.

    A curator who reads a paper and concludes it is a yeast-display
    selection, a peptide microarray, a computational prediction, or a
    refolding / crystallography experiment sets ``exclude_from_ms`` on
    the study.  IEDB does not always flag those rows as binding assays,
    so they land on the MS side of the ``is_binding_assay`` fork and sit
    in a corpus whose premise is MS-observed eluted ligands.  The flag
    was documented and curated on 11 studies for a long time with no
    reader at all (#444).

    Call this on the MS frame ONLY.  The exclusion says "this is not an
    elution experiment", not "distrust this publication": these studies
    measure real peptide-MHC binding, and their ``binding.parquet`` rows
    are deliberately kept.  Prints the drop count and the top-5 per-PMID
    breakdown so the corpus change is auditable in the build log.
    """
    if df.empty or "pmid" not in df.columns:
        return df
    from .curation import ms_excluded_pmids

    excluded = ms_excluded_pmids()
    if not excluded:
        return df
    mask = df["pmid"].isin(excluded)
    return _drop_masked_rows(df, mask, label, "rows", "curated exclude_from_ms, #444")


def _report_mhc_identity_summary(df: pd.DataFrame, label: str) -> None:
    """Print high-signal MHC corrections made by the shared resolver."""
    if df.empty:
        return
    corrected = (
        int(df["mhc_class_corrected"].fillna(False).astype(bool).sum())
        if "mhc_class_corrected" in df.columns
        else 0
    )
    conflicts = (
        int(df["mhc_species_context_disagrees"].fillna(False).astype(bool).sum())
        if "mhc_species_context_disagrees" in df.columns
        else 0
    )
    print(
        f"  {label} MHC identity: {corrected:,} class corrections; {conflicts:,} context conflicts"
    )
    if corrected:
        corrected_rows = df[df["mhc_class_corrected"].fillna(False).astype(bool)]
        for restriction, n_records in (
            corrected_rows["mhc_restriction"].value_counts().head(5).items()
        ):
            print(f"    class corrected {restriction}: {n_records:,} rows")
    if conflicts:
        conflict_rows = df[df["mhc_species_context_disagrees"].fillna(False).astype(bool)]
        for restriction, n_records in (
            conflict_rows["mhc_restriction"].value_counts().head(5).items()
        ):
            print(f"    context conflict {restriction}: {n_records:,} rows")


def _validate_mhc_tokens(obs: pd.DataFrame, binding: pd.DataFrame, other=None) -> pd.DataFrame:
    """Audit all MHC token surfaces and reject newly unrecognized values."""
    from .qc import mhc_token_audit

    frames = {"ms": obs, "binding": binding}
    if other is not None:
        frames["other"] = other
    audit = mhc_token_audit(evidence_frames=frames)
    if audit.empty:
        print("  MHC token audit: no findings")
        return audit
    status_counts = audit.groupby("status", observed=True)["n_records"].sum().sort_index()
    summary = "; ".join(f"{status}={int(count):,}" for status, count in status_counts.items())
    print(f"  MHC token audit: {summary}")
    unknown = audit[audit["status"] == "unrecognized"]
    if not unknown.empty:
        tokens = ", ".join(sorted(unknown["token"].astype(str).unique()))
        raise RuntimeError(
            "Unrecognized MHC tokens found across evidence and curation: "
            f"{tokens}. Run 'hitlist qc mhc-tokens' for provenance and either fix the source "
            "or add a reviewed, documented classification."
        )
    return audit


def build_observations(
    with_flanking: bool = True,
    proteome_release: int = 112,
    force: bool = False,
    fetch_missing_proteomes: bool = True,
    use_uniprot_search: bool = False,
    build_mappings: bool = True,
) -> Path:
    """Build the unified observations table from IEDB + CEDAR.

    Scans each registered source CSV through the full classification
    pipeline (YAML overrides, tissue categories, mono-allelic detection),
    deduplicates by assay IRI, and writes ``observations.parquet``.

    By default also builds the peptide→protein mappings sidecar
    (``peptide_mappings.parquet``) which preserves multi-mapping so that
    paralog attribution (MAGEA1/A4/A10/A12), repeat regions, and
    cross-proteome hits are not collapsed.

    Parameters
    ----------
    with_flanking
        Deprecated.  Retained for backward compat — the mapping sidecar
        now always includes flanking sequences.  Only disables mapping
        entirely when set to False AND ``build_mappings`` is False.
    proteome_release
        Ensembl release for Ensembl-supported species (default 112).
    force
        Rebuild even if cache is valid.
    fetch_missing_proteomes
        Auto-download reference proteomes for any species present in
        the observations.  Default True.
    build_mappings
        Build ``peptide_mappings.parquet`` sidecar (default True).  Adds
        ~5-10 min to the build on the first run (cached after that).

    Returns
    -------
    Path
        Path to ``observations.parquet`` (the MS index).  The binding
        index is written alongside at ``binding.parquet``.
    """
    from .curation import _clear_curation_caches
    from .dataset import INDEX_FILES, MAPPING_FILES, publish_dataset
    from .provenance import ContributorCollector, file_digest

    # A rebuild in a long-lived Python process must use the same current
    # curation whose fingerprints will be written into its metadata.
    _clear_curation_caches()
    paths = _source_paths()
    if not paths:
        raise FileNotFoundError(
            "No IEDB/CEDAR data registered. Use: hitlist data register iedb /path/to/file.csv"
        )

    if not force and _cache_is_valid(paths, with_flanking=with_flanking):
        out_path = _observations_path()
        binding_out = _binding_path()
        if build_mappings:
            # The observations and mappings artifacts have independent cache
            # contracts. A package upgrade can change mapping semantics while
            # the source parquets remain byte-for-byte current (#404), so the
            # observations fast path must still validate/rebuild the sidecar.
            from .mappings import build_peptide_mappings

            build_peptide_mappings(
                release=proteome_release,
                fetch_missing=fetch_missing_proteomes,
                use_uniprot=use_uniprot_search,
                force=False,
            )
        meta = _cache_meta()
        size_mb = out_path.stat().st_size / 1e6 if out_path.exists() else 0
        print(f"Observations already built ({meta.get('n_rows', '?'):,} rows, {size_mb:.1f} MB)")
        print(f"  Path:          {out_path}")
        print(f"  With flanking: {meta.get('with_flanking', False)}")
        print(f"  Peptides:      {meta.get('n_peptides', '?'):,}")
        print(f"  Alleles:       {meta.get('n_alleles', '?'):,}")
        print(f"  Species:       {meta.get('n_species', '?')}")
        if binding_out.exists():
            b_size = binding_out.stat().st_size / 1e6
            print(
                f"  Binding index: {meta.get('n_binding_rows', '?'):,} rows, "
                f"{b_size:.1f} MB → {binding_out}"
            )
        print("\nUse --force to rebuild.")
        return _observations_path()

    fingerprints = _source_fingerprints(paths)
    sources = {
        name: {
            "path": str(path),
            "sha256": (digest := file_digest(path))["sha256"],
            "size": digest["size_bytes"],
        }
        for name, path in paths.items()
    }

    def build(copied_paths):
        with ContributorCollector() as provenance:
            _build_observations(
                copied_paths,
                _observations_path(),
                _binding_path(),
                with_flanking,
                proteome_release,
                force,
                fetch_missing_proteomes,
                use_uniprot_search,
                build_mappings,
                provenance,
            )
        if _source_fingerprints(paths) != fingerprints:
            raise RuntimeError("Dataset inputs changed during the build; retry with stable sources")
        # The scanner reads datacache-owned copies. Freshness and source locators
        # refer to the registered originals, never deleted staging paths.
        metadata = json.loads(_meta_path().read_text())
        metadata["sources"] = fingerprints
        for name, path in paths.items():
            metadata["provenance"]["sources"][name]["path"] = str(path)
        _meta_path().write_text(json.dumps(metadata, indent=2, default=str) + "\n")

    files = (*INDEX_FILES, *(MAPPING_FILES if build_mappings else ()))
    published = publish_dataset(
        sources,
        files,
        build,
        root=data_dir(),
        options={
            "artifact_version": _OBSERVATIONS_ARTIFACT_VERSION,
            "proteome_release": proteome_release,
            "build_mappings": build_mappings,
            "fetch_missing_proteomes": fetch_missing_proteomes,
            "use_uniprot_search": use_uniprot_search,
        },
    )
    print(f"Published complete dataset: {published['observations.parquet'].parent}")
    return published["observations.parquet"]


def _build_observations(
    paths,
    out_path,
    binding_out,
    with_flanking,
    proteome_release,
    force,
    fetch_missing_proteomes,
    use_uniprot_search,
    build_mappings,
    provenance,
):
    import pyarrow as pa

    from .assays import ANNOTATION_COLUMNS, annotate_assays
    from .provenance import contributors_path, file_digest
    from .scanner import scan

    # Buffer per-source partitions as pyarrow Tables, not pandas frames.
    # Two reasons:
    #
    # 1. Arrow's string array uses an offset+char-buffer layout (~10 bytes /
    #    cell) instead of pandas' object dtype (~50-100 bytes / cell with
    #    full Python ``str`` overhead).  Holding 4 partitions as Arrow
    #    saves ~5-10x vs holding them as pandas DataFrames.
    # 2. ``pa.concat_tables`` is zero-copy when schemas match — it just
    #    chains the input chunk arrays.  Replaces the ``pd.concat`` 2x
    #    transient peak that allocated a fresh union frame.
    #
    # We only convert back to pandas at the very end of the merge phase
    # (post-supplementary, before the gene-annotation merge), since
    # downstream pandas consumers (mappings build, supplement dedup) need
    # a DataFrame.  Categorical compression is applied at that boundary.
    ms_tables: list[pa.Table] = []
    binding_tables: list[pa.Table] = []
    other_tables: list[pa.Table] = []
    empty_schema = pd.DataFrame()

    for name in ("iedb", "cedar"):
        if name not in paths:
            continue
        print(f"Scanning {name} ({paths[name].name})...")
        df = scan(
            peptides=None,
            iedb_path=paths[name] if name == "iedb" else None,
            cedar_path=paths[name] if name == "cedar" else None,
            mhc_species=None,  # builder indexes all species; downstream filters per-call
            classify_source=True,
            provenance=provenance,
        )
        df["source"] = name

        # A false binding flag never establishes MS modality. Retain all
        # remaining assays independently, including explicit negative MS.
        if not set(ANNOTATION_COLUMNS) <= set(df):
            annotate_assays(df)
        empty_schema = df.iloc[:0].copy()
        ms_df = df[df["is_ms_observation"]].copy()
        bd_df = df[df["is_binding_assay"]].copy()
        other_df = df[~(df["is_ms_observation"] | df["is_binding_assay"])].copy()
        del df  # free the source scan's frame before the next source's scan
        n_ms, n_bd, n_other = len(ms_df), len(bd_df), len(other_df)

        # Normalize ``pmid`` to ``Int64`` *per-partition* before the
        # Arrow conversion.  The scanner emits ``pmid`` as object dtype
        # with ``""`` for missing rows and integer-like strings for
        # present ones; pyarrow's ``Table.from_pandas`` infers a single
        # type per column and chokes on the mixed shapes (#232).  The
        # full-frame normalization at the bottom of this function is
        # kept as defensive scaffolding but is now a no-op.
        for frame in (ms_df, bd_df, other_df):
            if "pmid" in frame.columns:
                frame["pmid"] = pd.to_numeric(frame["pmid"], errors="coerce").astype("Int64")

        # Compress per-partition before Arrow conversion so dictionary-encoded
        # categories survive the round-trip (Arrow ``DictionaryArray`` ↔
        # pandas ``category`` is preserved by ``pa.Table.from_pandas`` /
        # ``Table.to_pandas``).
        _compress_categoricals(ms_df)
        _compress_categoricals(bd_df)
        _compress_categoricals(other_df)

        # Convert to Arrow eagerly and free the pandas frame.  Holding the
        # accumulated partitions as Arrow keeps the per-source memory cost
        # ~5x lower than pandas.
        if n_ms:
            ms_tables.append(pa.Table.from_pandas(ms_df, preserve_index=False))
        if n_bd:
            binding_tables.append(pa.Table.from_pandas(bd_df, preserve_index=False))
        if n_other:
            other_tables.append(pa.Table.from_pandas(other_df, preserve_index=False))
        del ms_df, bd_df, other_df
        print(f"  {n_ms:,} MS + {n_bd:,} binding + {n_other:,} other assay rows from {name}")

    if not ms_tables and not binding_tables and not other_tables:
        raise RuntimeError("No data scanned.")

    # ``pa.concat_tables`` is zero-copy when schemas match (which they do,
    # since both sources came through the same scanner).  ``_CONCAT_PROMOTE_OPTIONS``
    # widens to a common type if any column dtype diverged across sources —
    # see its own docstring; a plain "default" raises on this exact pair of
    # per-source-compressed partitions (#478).
    if ms_tables:
        ms_table = pa.concat_tables(ms_tables, promote_options=_CONCAT_PROMOTE_OPTIONS)
        ms_tables.clear()
        # Cross-source dedup by assay IRI (#146): pyarrow doesn't expose a
        # direct ``drop_duplicates`` so we materialize as pandas here, then
        # compress.  This is the FIRST pandas allocation — peak memory is
        # bounded by the post-dedup obs frame size.
        obs = ms_table.to_pandas()
        del ms_table
        obs = _drop_duplicate_iris(obs, label="MS", provenance=provenance)
        _compress_categoricals(obs, strict=True)
    else:
        obs = empty_schema.copy()

    if binding_tables:
        binding_table = pa.concat_tables(binding_tables, promote_options=_CONCAT_PROMOTE_OPTIONS)
        binding_tables.clear()
        binding = binding_table.to_pandas()
        del binding_table
        binding = _drop_duplicate_iris(binding, label="binding", provenance=provenance)
        _compress_categoricals(binding, strict=True)
    else:
        binding = empty_schema.copy()

    if other_tables:
        other_table = pa.concat_tables(other_tables, promote_options=_CONCAT_PROMOTE_OPTIONS)
        other_tables.clear()
        other = other_table.to_pandas()
        del other_table
        other = _drop_duplicate_iris(other, label="other assays", provenance=provenance)
        _compress_categoricals(other, strict=True)
    else:
        other = empty_schema.copy()

    # --- Supplementary data (MS only — manually curated from papers) ---
    from .supplement import scan_supplementary

    supp = scan_supplementary(classify_source=True, provenance=provenance)
    if not supp.empty:
        supp["source"] = "supplement"
        if not set(ANNOTATION_COLUMNS) <= set(supp):
            annotate_assays(supp)
        # Keep explicit conflicting/negative supplementary records auditable.
        binding = pd.concat([binding, supp[supp.is_binding_assay]], ignore_index=True)
        other = pd.concat(
            [other, supp[~(supp.is_ms_observation | supp.is_binding_assay)]], ignore_index=True
        )
        supp = supp[supp.is_ms_observation].copy()
        before = len(supp)
        supp = _drop_supplementary_duplicates(supp, obs, provenance=provenance)
        dupes = before - len(supp)
        if dupes:
            print(f"  Deduplicated {dupes:,} supplementary rows (already in IEDB/CEDAR)")
        n_supp_added = len(supp)
        obs = pd.concat([obs, supp], ignore_index=True)
        del supp
        _compress_categoricals(obs)
        print(f"  {n_supp_added:,} rows from supplementary data (MS)")

    # Drop short MHC-II rows (#122) — biologically implausible, and
    # overwhelmingly IEDB import errors (e.g. HLA Ligand Atlas 9-mers).
    obs = _drop_short_mhc2_rows(obs, "MS observations")
    binding = _drop_short_mhc2_rows(binding, "binding")

    # Honor the curated exclude_from_ms flag (#444).  Applied to the MS
    # frame only and deliberately not to ``binding`` — ``binding`` is the
    # independently classified binding partition of the same scan.
    obs = _drop_excluded_from_ms(obs, "MS observations")

    _report_mhc_identity_summary(obs, "MS")
    _report_mhc_identity_summary(binding, "binding")
    _report_mhc_identity_summary(other, "other assays")
    _validate_mhc_tokens(obs, binding, other)

    print(f"\nMS observations: {len(obs):,} rows")
    if len(obs):
        print(f"  Unique peptides: {obs['peptide'].nunique():,}")
        print(f"  Unique alleles:  {obs['mhc_restriction'].nunique():,}")
        print(f"  Species:         {obs['mhc_species'].nunique()}")
    print(f"Other assay rows: {len(other):,}")
    print(f"Binding rows:    {len(binding):,}")
    if len(binding):
        print(f"  Unique peptides: {binding['peptide'].nunique():,}")
        print(f"  Unique alleles:  {binding['mhc_restriction'].nunique():,}")

    # Fix mixed types for parquet compatibility
    for frame in (obs, binding, other):
        if "pmid" in frame.columns:
            frame["pmid"] = pd.to_numeric(frame["pmid"], errors="coerce").astype("Int64")

    # Build the long-form peptide → protein mappings sidecar, then
    # annotate BOTH parquets with semicolon-joined gene/protein columns.
    # Hold obs/binding in memory so the canonical parquets aren't briefly
    # missing their ``gene_names`` column mid-rebuild (#105).  The
    # mappings build consumes the frames directly via ``obs_override`` /
    # ``binding_override`` instead of re-reading the canonical files.
    if build_mappings:
        from .mappings import (
            _obs_fingerprint,
            build_peptide_mappings,
            mappings_meta_path,
        )

        build_peptide_mappings(
            release=proteome_release,
            fetch_missing=fetch_missing_proteomes,
            use_uniprot=use_uniprot_search,
            force=force,
            obs_override=obs,
            binding_override=binding,
            other_override=other,
        )

        # Issue #238: gene/protein columns are NO LONGER attached to
        # observations.parquet / binding.parquet at build time.  The same
        # information is the authoritative content of peptide_mappings.parquet
        # (one row per peptide x protein); duplicating it onto every obs row
        # cost ~71 MB on the parquet (38.8% of total bytes pre-v1.30.46) and
        # forced a full-frame merge during build that pinned ~1-2 GB of
        # transient memory.
        #
        # Consumers that need ``gene_names`` / ``gene_ids`` / ``protein_ids`` /
        # ``n_source_proteins`` / ``n_source_genes`` columns now get them via a
        # query-time join:
        # ``load_observations`` auto-attaches them when requested in
        # ``columns=`` but absent from the parquet (post-v1.30.46), routing
        # through ``annotate_observations_with_genes`` against the matched-
        # peptides slice of peptide_mappings.parquet.
        print("\nGene/protein columns elided from observations + binding parquets (#238).")
        print("  Source-of-truth: peptide_mappings.parquet")
        print("  Consumers that need gene_names/etc get them via on-demand join at load time.")

    # Atomic rename write (#105): write to a sibling .partial, then rename
    # over the canonical path.  This keeps any prior index in place — and
    # queryable — throughout the rebuild; readers never see a half-written
    # or not-yet-annotated parquet.
    provenance_meta = provenance.write((obs, binding, other), contributors_path())
    atomic_write_parquet(obs, out_path)
    print(f"\nWrote {out_path} ({out_path.stat().st_size / 1e6:.1f} MB)")
    atomic_write_parquet(binding, binding_out)
    print(f"Wrote {binding_out} ({binding_out.stat().st_size / 1e6:.1f} MB)")
    other_out = _other_assays_path()
    atomic_write_parquet(other, other_out)
    print(f"Wrote {other_out} ({other_out.stat().st_size / 1e6:.1f} MB)")
    provenance_meta["indexes"] = {
        "observations": file_digest(out_path),
        "binding": file_digest(binding_out),
        "other_assays": file_digest(other_out),
    }

    if build_mappings:
        # Rewrite mappings cache fingerprint to reflect the just-renamed
        # canonical parquets — it was stamped from whatever was on disk
        # before the atomic rename (empty on a fresh build, stale otherwise).
        meta_p = mappings_meta_path()
        if meta_p.exists():
            stored = json.loads(meta_p.read_text())
            stored["observations"] = _obs_fingerprint()
            meta_p.write_text(json.dumps(stored, indent=2, default=str) + "\n")

    # --- Bulk proteomics index (non-MHC shotgun MS) ---
    print("\nBuilding bulk_proteomics.parquet ...")
    bulk_df = build_bulk_proteomics(verbose=True)

    # --- Line-expression index (per-line RNA / transcript TPM) ---
    print("\nBuilding line_expression.parquet ...")
    line_expr_df = build_line_expression(verbose=True)

    # Save metadata
    meta = {
        "artifact_version": _OBSERVATIONS_ARTIFACT_VERSION,
        "provenance": provenance_meta,
        # Serotype and class projections are only as current as the library
        # that computed them, which is a property of the build rather than of
        # the observation. Recording it makes a rebuild that silently changes
        # 1.6M serotype values attributable (#458).
        "mhcgnomes_version": _mhcgnomes_version(),
        "sources": _source_fingerprints(paths),
        "parquets": _parquet_fingerprints(),
        "n_rows": len(obs),
        "n_peptides": int(obs["peptide"].nunique()) if len(obs) else 0,
        "n_alleles": int(obs["mhc_restriction"].nunique()) if len(obs) else 0,
        "n_species": int(obs["mhc_species"].nunique()) if len(obs) else 0,
        "n_binding_rows": len(binding),
        "n_other_assay_rows": len(other),
        "n_binding_peptides": int(binding["peptide"].nunique()) if len(binding) else 0,
        "n_bulk_rows": len(bulk_df),
        "n_bulk_protein_rows": int((bulk_df["granularity"] == "protein").sum())
        if len(bulk_df)
        else 0,
        "n_bulk_peptide_rows": int((bulk_df["granularity"] == "peptide").sum())
        if len(bulk_df)
        else 0,
        "n_line_expression_rows": len(line_expr_df),
        "n_line_expression_lines": int(line_expr_df["line_key"].nunique())
        if len(line_expr_df)
        else 0,
        "with_flanking": with_flanking,
        "with_mappings": build_mappings,
    }
    # No mkdir here: the observations/binding parquets were written into this
    # very directory a few dozen lines up, so it exists by now.
    _meta_path().write_text(json.dumps(meta, indent=2, default=str) + "\n")

    return out_path


def build_bulk_proteomics(verbose: bool = False) -> pd.DataFrame:
    """Build ``bulk_proteomics.parquet`` — long-form bulk MS index.

    Emits a single parquet in ``data_dir()`` with protein- and peptide-level
    rows (distinguished by ``granularity``), denormalizing per-source
    acquisition metadata (instrument, digest, fragmentation, labeling,
    fractionation, search engine, FDR) onto every row so the file is
    self-contained for MS-bias modeling.

    Acquisition column names (``instrument``, ``instrument_type``,
    ``fragmentation``, ``acquisition_mode``, ``labeling``,
    ``search_engine``, ``fdr``) are harmonized with the per-sample schema
    used by :mod:`hitlist.export` so the same columns can be extracted
    from ``observations.parquet`` (via ``generate_observations_table``)
    and ``bulk_proteomics.parquet`` for joint MS-bias analysis.

    Source data ships inside the package under
    ``hitlist/data/bulk_proteomics/`` (CSV.gz + ``sources.yaml``). This
    function just reshapes it into the long parquet written to
    the data directory.

    Returns
    -------
    pd.DataFrame
        The concatenated long-form table that was written. Empty frame
        if the packaged CSVs are missing.
    """
    from .bulk_proteomics import (
        _load_bj,
        _load_bj_protein,
        _load_ccle,
        _load_sources_yaml,
    )
    from .export import _classify_instrument

    sources_yaml = {s["source_id"]: s for s in _load_sources_yaml()}

    def _study_meta(source_id: str) -> dict:
        """Extract the harmonized acquisition/study metadata for a source."""
        s = sources_yaml.get(source_id, {})
        pmid = s.get("pmid")
        instrument = s.get("instrument", "") or ""
        ph = s.get("fractionation_ph")
        return {
            "pmid": int(pmid) if pmid else pd.NA,
            "reference": s.get("reference", "") or "",
            "study_label": s.get("study_label", "") or "",
            "species": s.get("species", "") or "",
            "instrument": instrument,
            "instrument_type": _classify_instrument(instrument),
            "fragmentation": s.get("fragmentation", "") or "",
            "acquisition_mode": s.get("acquisition_mode", "") or "",
            "labeling": s.get("labeling", "") or "",
            "search_engine": s.get("search_engine", "") or "",
            "fdr": s.get("fdr", "") or "",
            "digestion": s.get("digestion", "") or "",
            "digestion_enzyme": s.get("digestion_enzyme", "") or "",
            "fractionation": s.get("fractionation", "") or "",
            "n_fractions": int(s["n_fractions"]) if s.get("n_fractions") else pd.NA,
            # Source-level pH applies only where reviewed per-row metadata
            # is absent. Bekker-Jensen has no blanket numeric default.
            "fractionation_ph": float(ph) if ph is not None else pd.NA,
            "quantification": s.get("quantification", "") or "",
        }

    import numpy as np

    frames: list[pd.DataFrame] = []

    def _stamp_bj_per_row(df: pd.DataFrame, meta: dict) -> pd.DataFrame:
        """Merge source-level meta into a Bekker-Jensen frame.

        Five columns are authoritative at the ROW level (set by the
        ingest script from the MaxQuant experiment name):
        ``digestion_enzyme``, ``n_fractions_in_run``, ``enrichment``,
        ``fractionation_ph``, ``modifications``. When any of them is
        present on the source CSV we:
          - skip overwriting it with the source-level default
          - for ``digestion``: derive a coarse 'tryptic' / 'non-tryptic'
            label from the per-row enzyme so ``df.query("digestion == 'tryptic'")``
            still works after the ancillary arms were added
          - for ``n_fractions``: derive from ``n_fractions_in_run`` so
            the coarse source-level ``n_fractions`` matches the arm
            actually indexed in each row (14/39/46/50/70/12 per the
            Fig 1b design matrix).
        """
        has_per_row_enzyme = "digestion_enzyme" in df.columns
        has_per_row_fracs = "n_fractions_in_run" in df.columns
        has_per_row_ph = "fractionation_ph" in df.columns
        for k, v in meta.items():
            if k == "digestion_enzyme" and has_per_row_enzyme:
                continue
            if k == "fractionation_ph" and has_per_row_ph:
                # Preserve reviewed pH and explicit unknowns.
                continue
            if k == "digestion" and has_per_row_enzyme:
                df["digestion"] = df["digestion_enzyme"].apply(
                    lambda e: "tryptic" if str(e).startswith("Trypsin") else "non-tryptic"
                )
                continue
            if k == "n_fractions" and has_per_row_fracs:
                # Keep the coarse source-level ``n_fractions`` in sync
                # with the authoritative per-row value. Callers filtering
                # ``df["n_fractions"] == 46`` then get the 46-frac arm
                # rows; callers filtering on ``n_fractions_in_run`` get
                # the same thing explicitly.
                df["n_fractions"] = df["n_fractions_in_run"]
                continue
            df[k] = v
        return df

    # --- CCLE protein-level ---
    ccle = _load_ccle().copy()
    if len(ccle):
        ccle["abundance_percentile"] = ccle.groupby("cell_line")["abundance_log2_normalized"].rank(
            pct=True
        )
        ccle["granularity"] = "protein"
        ccle["peptide"] = ""
        ccle["length"] = np.nan
        ccle["start_position"] = np.nan
        ccle["end_position"] = np.nan
        ccle["log2_intensity"] = np.nan
        ccle["n_peptides"] = np.nan
        meta = _study_meta("CCLE_Nusinow_2020")
        for k, v in meta.items():
            ccle[k] = v
        frames.append(ccle)

    # --- Bekker-Jensen protein-level ---
    bj_protein = _load_bj_protein().copy()
    if len(bj_protein):
        bj_protein["granularity"] = "protein"
        bj_protein["peptide"] = ""
        bj_protein["length"] = np.nan
        bj_protein["start_position"] = np.nan
        bj_protein["end_position"] = np.nan
        bj_protein["abundance_log2_normalized"] = np.nan
        meta = _study_meta("Bekker-Jensen_2017")
        bj_protein = _stamp_bj_per_row(bj_protein, meta)
        frames.append(bj_protein)

    # --- Bekker-Jensen peptide-level ---
    from .bulk_replicates import (
        INTEGER_REPLICATE_COLUMNS,
        REPLICATE_COLUMNS,
        curate_replicate_counts,
    )

    bj_peptide = curate_replicate_counts(_load_bj())
    if len(bj_peptide):
        bj_peptide["granularity"] = "peptide"
        bj_peptide["log2_intensity"] = np.nan
        bj_peptide["abundance_log2_normalized"] = np.nan
        bj_peptide["abundance_percentile"] = np.nan
        bj_peptide["n_peptides"] = np.nan
        meta = _study_meta("Bekker-Jensen_2017")
        bj_peptide = _stamp_bj_per_row(bj_peptide, meta)
        frames.append(bj_peptide)

    if not frames:
        empty = pd.DataFrame()
        _write_bulk_index(empty)
        return empty

    df = concat_non_empty(frames, _union_columns(frames), sort=False)

    # Harmonize column names: cell_line -> cell_line_name to match
    # observations.parquet; keep sample_label alias for ms_samples parity.
    df = df.rename(columns={"cell_line": "cell_line_name"})
    df["sample_label"] = df["cell_line_name"]
    df["evidence_kind"] = "bulk_proteomics"
    # perturbation is empty for all currently-indexed sources (untreated
    # baseline cell-line proteomes); column exists so joins with
    # observations/export stay schema-stable.
    df["perturbation"] = ""

    # Integer columns with nullable dtype so parquet round-trips cleanly.
    int_cols = (
        "length",
        "start_position",
        "end_position",
        "n_peptides",
        "n_fractions",
        "n_fractions_in_run",
        "n_replicates_detected",
        *INTEGER_REPLICATE_COLUMNS,
        "pmid",
    )
    for col in int_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").astype("Int64")

    # fractionation_ph is continuous (float) so it gets its own cast.
    if "fractionation_ph" in df.columns:
        df["fractionation_ph"] = pd.to_numeric(df["fractionation_ph"], errors="coerce")

    # For rows that don't carry per-row Fig 1b axes (CCLE protein rows),
    # fill the columns with sensible defaults so parquet has a stable
    # schema rather than mixed-NA dtypes. CCLE is non-enriched baseline
    # shotgun with no modification enrichment, so ``enrichment="none"``
    # and ``modifications=""`` are correct.
    if "enrichment" in df.columns:
        df["enrichment"] = df["enrichment"].fillna("none").replace("", "none")
    else:
        df["enrichment"] = "none"
    if "modifications" not in df.columns:
        df["modifications"] = ""
    else:
        df["modifications"] = df["modifications"].fillna("")

    ordered_cols = [
        # evidence + granularity
        "evidence_kind",
        "granularity",
        # study identity (harmonized with observations.parquet / ms_samples)
        "source",
        "reference",
        "pmid",
        "study_label",
        "species",
        # sample identity (harmonized with observations.parquet)
        "cell_line_name",
        "sample_label",
        "perturbation",
        # biological target
        "gene_symbol",
        "uniprot_acc",
        "peptide",
        "length",
        "start_position",
        "end_position",
        # quant
        "log2_intensity",
        "abundance_log2_normalized",
        "abundance_percentile",
        "n_peptides",
        "n_replicates_detected",
        *REPLICATE_COLUMNS,
        # acquisition metadata (harmonized with ms_samples schema)
        "instrument",
        "instrument_type",
        "fragmentation",
        "acquisition_mode",
        "labeling",
        "search_engine",
        "fdr",
        # bulk-specific prep/digest info — per-row Fig 1b axes for
        # Bekker-Jensen (authoritative) and source-level defaults for
        # CCLE (all tryptic, 12-frac, no enrichment).
        "digestion",
        "digestion_enzyme",
        "fractionation",
        "n_fractions",
        "n_fractions_in_run",
        "fractionation_ph",
        "legacy_fractionation_ph",
        "fractionation_protocol_id",
        "fractionation_ph_basis",
        "fractionation_ph_reference",
        "fractionation_ph_evidence_id",
        "enrichment",
        "modifications",
        "quantification",
    ]
    # Drop any stray input columns (e.g. CCLE's FASTA-header protein_id
    # which duplicates uniprot_acc) so the parquet schema is stable.
    df = df[[c for c in ordered_cols if c in df.columns]]

    out = _write_bulk_index(df)
    if verbose:
        n_prot = int((df["granularity"] == "protein").sum())
        n_pep = int((df["granularity"] == "peptide").sum())
        size_mb = out.stat().st_size / 1e6
        print(f"  {len(df):,} rows ({n_prot:,} protein + {n_pep:,} peptide) → {size_mb:.1f} MB")
        print(f"  Wrote {out}")
    return df


def _write_bulk_index(df):
    from .dataset import update_dataset

    granularity = df.get("granularity", pd.Series(dtype=str))
    return update_dataset(
        ("bulk_proteomics.parquet",),
        lambda: atomic_write_parquet(df, _bulk_proteomics_path()),
        root=data_dir(),
        metadata_updates={
            "n_bulk_rows": len(df),
            "n_bulk_protein_rows": int(granularity.eq("protein").sum()),
            "n_bulk_peptide_rows": int(granularity.eq("peptide").sum()),
        },
    )


# ── Line-expression index ──────────────────────────────────────────────────


def _line_expression_path() -> Path:
    from .downloads import data_dir

    return dataset_path("line_expression.parquet", root=data_dir())


def _read_depmap_csv(
    path: Path,
    granularity: str,
    *,
    line_keys: dict[str, str] | None = None,
    profiles: dict[str, str] | None = None,
) -> pd.DataFrame:
    """Parse a DepMap log2(TPM+1) matrix into long-form.

    Gene rows use ``ModelID`` (ACH-...), whereas the official transcript
    matrix uses ``ProfileID`` (PR-...). ``profiles`` selects the release's
    default RNA profile per model, and ``line_keys`` maps models
    to registered systems before expansion. Omitting both mappings retains
    input identifiers for standalone parsing.

    Feature headers are ``TP53 (7157)`` or ``TP53 (ENST00000269305)``.
    Previously supported ``ENST00000269305.9 (TP53)`` headers remain valid.

    DepMap normalization is log2(TPM+1); raw TPM is reconstituted via
    ``tpm = 2**log2_tpm - 1`` so downstream joins can compare across
    sources that ship raw TPM.
    """
    # The transcript matrix is over 4 GB. Select input rows before numeric
    # parsing/expansion; retaining every model before melt exhausts memory.
    frames = []
    with path.open(newline="") as handle:
        reader = csv.reader(handle)
        header = next(reader, [])
        for row in reader:
            if not row:
                continue
            model_id = row[0]
            if model_id.startswith("PR-") and line_keys is not None:
                if profiles is None:
                    raise ValueError(
                        "DepMap ProfileID rows require depmap_profiles and "
                        "depmap_default_profiles; fetch the depmap bundle or register both."
                    )
                model_id = profiles.get(model_id, "")
            if line_keys is not None:
                if model_id not in line_keys:
                    model_id = model_id.casefold()
                if model_id not in line_keys:
                    continue
            frame = pd.DataFrame({"_label": header[1:], "log2_tpm": row[1:]})
            frame["log2_tpm"] = pd.to_numeric(frame["log2_tpm"].replace("", float("nan")))
            frame["line_key"] = line_keys[model_id] if line_keys is not None else model_id
            frame["profile_id"] = row[0] if row[0].startswith("PR-") else ""
            frames.append(frame)
    if not frames:
        return pd.DataFrame()
    long = pd.concat(frames, ignore_index=True)
    long = long.dropna(subset=["log2_tpm"])

    if granularity == "gene":
        # Labels: "GENE (entrez)" — Entrez ID is not used here.
        parsed = long["_label"].str.extract(r"^(?P<gene_name>[^(]+?)\s*(?:\([^)]+\))?\s*$")
        long["gene_name"] = parsed["gene_name"].str.strip()
        long["gene_id"] = ""
        long["transcript_id"] = ""
    else:
        parsed = long["_label"].str.extract(
            r"^(?P<gene_name>.+?)\s*\((?P<transcript_id>ENST\d+)(?:\.\d+)?\)\s*$"
        )
        legacy = long["_label"].str.extract(
            r"^(?P<transcript_id>ENST\d+)"
            r"(?:\.\d+)?"
            r"\s*\((?P<gene_name>[^)]+)\)\s*$"
        )
        parsed = parsed.combine_first(legacy)
        long["transcript_id"] = parsed["transcript_id"].fillna("")
        long["gene_name"] = parsed["gene_name"].fillna("").str.strip()
        long["gene_id"] = ""

    long = long.drop(columns=["_label"], errors="ignore")
    long["tpm"] = 2.0 ** long["log2_tpm"].astype(float) - 1.0
    long["granularity"] = granularity

    # Drop rows where we couldn't parse an identifier.
    if granularity == "gene":
        long = long[long["gene_name"].astype(bool)]
    else:
        long = long[long["transcript_id"].astype(bool)]

    return long.reset_index(drop=True)


def _load_depmap_model_lookup(model_csv_path: Path | None) -> dict[str, str]:
    """Return ``{ModelID: display_name}`` from a DepMap ``Model.csv``.

    Empty dict when the file is missing or unreadable.  ``display_name``
    prefers ``StrippedCellLineName`` (e.g. ``"HELA"``, ``"SAOS2"``) and
    falls back to ``CellLineName``.
    """
    if not model_csv_path or not Path(model_csv_path).exists():
        return {}
    try:
        df = pd.read_csv(model_csv_path)
    except Exception as exc:
        print(f"  warning: failed to read DepMap Model.csv ({exc}); skipping harmonization")
        return {}
    if "ModelID" not in df.columns:
        return {}

    # Walk the columns as Python lists rather than pandas rows so the
    # ``isinstance(v, str)`` checks on the display-name candidates stay
    # cheap and we don't invoke ``iterrows()``.  ``str(m) if m else ""``
    # matches the original ``str(row.get("ModelID") or "").strip()``
    # — including the quirk that a NaN ModelID is coerced to the string
    # ``"nan"`` (harmless: ``resolve_line_key("nan")`` returns None so the
    # row is later dropped by ``_harmonize_depmap_line_keys``).
    mids = [(str(m) if m else "").strip() for m in df["ModelID"].tolist()]
    stripped_list = (
        df["StrippedCellLineName"].tolist()
        if "StrippedCellLineName" in df.columns
        else [None] * len(df)
    )
    fallback_list = (
        df["CellLineName"].tolist() if "CellLineName" in df.columns else [None] * len(df)
    )

    out: dict[str, str] = {}
    for mid, s, f in zip(mids, stripped_list, fallback_list):
        if not mid:
            continue
        name = ""
        if isinstance(s, str) and s.strip():
            name = s.strip()
        elif isinstance(f, str) and f.strip():
            name = f.strip()
        if name:
            out[mid] = name
    return out


def _harmonize_depmap_line_keys(
    df: pd.DataFrame,
    model_lookup: dict[str, str] | None = None,
) -> pd.DataFrame:
    """Harmonize DepMap ``ModelID`` (and display names) onto registry keys.

    Two lookups are applied in order, then unmatched rows are dropped:

    1. ``ModelID → StrippedCellLineName`` via the caller-supplied
       ``model_lookup`` built from DepMap's ``Model.csv``.
    2. ``StrippedCellLineName / display name → expression_key`` via
       :func:`hitlist.line_expression.resolve_line_key` (which consults
       the anchor YAML's aliases, canonical names, and punctuation-
       stripped canonical names — so DepMap's ``"SAOS2"`` / ``"HELA"``
       / ``"THP1"`` match the registry's ``"SaOS-2"`` / ``"HeLa"`` /
       ``"THP-1"``).

    Rows whose ``line_key`` doesn't resolve are dropped so the parquet
    never carries raw DepMap IDs that the resolver can't join against.
    A warning is printed with the number of dropped rows.
    """
    from .line_expression import resolve_line_key

    if df.empty:
        return df
    model_lookup = model_lookup or {}

    def _map(raw: str) -> str | None:
        raw = str(raw)
        # Step 1: ModelID → display name (if the caller gave us a table).
        display = model_lookup.get(raw, raw)
        # Step 2: display name → expression_key via registry aliases.
        return resolve_line_key(display)

    resolved = df["line_key"].astype(str).map(_map)
    mask = resolved.notna()
    n_dropped = int((~mask).sum())
    if n_dropped:
        unresolved_sample = df.loc[~mask, "line_key"].astype(str).drop_duplicates().head(5).tolist()
        print(
            f"  warning: dropped {n_dropped:,} DepMap rows whose line_key "
            f"did not resolve to a registry entry "
            f"(sample: {unresolved_sample}). Register depmap_models to map "
            f"ModelIDs → display names."
        )
    out = df.loc[mask].copy()
    out["line_key"] = resolved[mask].astype(str)
    return out.reset_index(drop=True)


#: Ensembl releases to consult (in order) when filling gene_name from gene_id.
#: The packaged line-expression union is GRCh37/Ensembl-75-based (release 75
#: resolves ~81% of the blanks); 112 (GRCh38, the proteome release) backfills a
#: few hundred recently-added IDs that 75 predates.  Together ~85%.
_GENE_NAME_FILL_RELEASES: tuple[int, ...] = (75, 112)


def _fill_gene_names_via_ensembl(
    df: pd.DataFrame,
    *,
    releases: tuple[int, ...] = _GENE_NAME_FILL_RELEASES,
    verbose: bool = False,
) -> pd.DataFrame:
    """Fill empty ``gene_name`` from the Ensembl gene ID via pyensembl.

    The packaged line-expression union carries human ``ENSG`` gene IDs but no
    HGNC symbol for ~9k genes (the symbol lives only on the DepMap rows).  Map
    ``gene_id`` → symbol so ``gene_name`` queries reach those rows too, trying
    each ``release`` in order per ID (the IDs are GRCh37-based, so older 75
    covers most; newer releases backfill recent additions).  A missing pyensembl
    install no-ops with a note; an individual release whose data isn't installed
    is skipped — the build never hard-fails on this (symbols just stay blank).
    """
    if "gene_name" not in df.columns or "gene_id" not in df.columns:
        return df
    gn = df["gene_name"].astype("string").fillna("")
    gid = df["gene_id"].astype("string").fillna("")
    need = (gn.str.strip() == "") & gid.str.startswith("ENSG")  # human Ensembl IDs only
    if not need.any():
        return df
    want = sorted({g.split(".")[0] for g in gid[need]})

    id2name: dict[str, str] = {}
    for release in releases:
        remaining = [i for i in want if i not in id2name]
        if not remaining:
            break
        try:
            from pyensembl import EnsemblRelease
        except ImportError as e:  # pyensembl not installed at all
            if verbose:
                print(f"  gene_name fill skipped — pyensembl unavailable ({e})")
            return df
        try:
            data = EnsemblRelease(release)
            present = set(data.gene_ids())  # raises if this release's DB isn't built
        except Exception:  # this release's data not installed/indexed — try the next
            continue
        for i in remaining:
            if i not in present:  # absent from this release — a later one may have it
                continue
            try:
                nm = data.gene_name_of_gene_id(i)
            except Exception:
                continue
            if nm:
                id2name[i] = nm

    if not id2name:
        if verbose:
            print(f"  gene_name fill: no usable Ensembl release; {len(want):,} kept blank")
        return df
    filled = gid[need].map(lambda g: id2name.get(g.split(".")[0], ""))
    df.loc[need, "gene_name"] = filled.to_numpy()
    if verbose:
        print(
            f"  Filled {int((filled != '').sum()):,}/{len(want):,} blank gene_names "
            f"from Ensembl IDs (releases {','.join(map(str, releases))})"
        )
    return df


def _depmap_default_rna_profiles(
    profiles_path: Path | None, defaults_path: Path | None
) -> dict[str, str] | None:
    """Map the release's default RNA ProfileIDs to their ModelIDs.

    Matrix membership decides availability. Library strandedness is distinct
    from the quantification mode: a stranded library can have values in a
    matrix processed in unstranded mode (HAP1 in 24Q4, for example).
    """
    if profiles_path is None or defaults_path is None:
        return None
    profiles = pd.read_csv(profiles_path, dtype=str).fillna("")
    defaults = pd.read_csv(defaults_path, dtype=str).fillna("")
    defaults = defaults[defaults["ProfileType"].eq("rna")]
    if defaults["ModelID"].duplicated().any():
        raise ValueError("DepMap default RNA profiles must be unique per ModelID")
    selected = defaults.merge(
        profiles,
        on=["ModelID", "ProfileID"],
        how="left",
        validate="one_to_one",
        indicator=True,
    )
    if selected["_merge"].ne("both").any():
        raise ValueError("DepMap default RNA profiles do not match OmicsProfiles metadata")
    if selected["Datatype"].ne("rna").any():
        raise ValueError("DepMap default RNA profile points to a non-RNA profile")
    return dict(zip(selected["ProfileID"], selected["ModelID"]))


def build_line_expression(verbose: bool = False) -> pd.DataFrame:
    """Build ``line_expression.parquet`` — per-line RNA / transcript TPM.

    Reads:

    - Every packaged CSV in ``hitlist/data/line_expression/`` that the
      ``sources.yaml`` registry marks ``build_status: packaged``.
    - Optional DepMap gene / transcript log2(TPM+1) matrices when the
      ``depmap_rna`` / ``depmap_rna_transcript`` datasets are registered
      via :mod:`hitlist.downloads`.

    Writes a long-form parquet keyed by ``(line_key, source_id,
    granularity, gene_id/transcript_id)``.  Rows are shaped by
    :func:`hitlist.line_expression.enrich_line_expression_rows` — the same
    function readers apply to the packaged sources when no current index
    exists — then gene symbols still blank get an optional pyensembl
    backfill.  Written through
    :func:`hitlist.line_expression.write_line_expression_index`, which
    stamps the index for this release and renames atomically.

    Returns
    -------
    pd.DataFrame
        The long-form table that was written.  Empty when no sources
        contain shippable data (packaged CSVs all missing AND no DepMap
        dataset registered).
    """
    from .line_expression import (
        LINE_EXPRESSION_COLUMNS,
        _alias_to_expression_key,
        _load_packaged_union,
        enrich_line_expression_rows,
        load_line_expression_anchors,
        resolve_line_key,
        write_line_expression_index,
    )

    # --- Packaged CSVs (already long-form) ---
    frames: list[pd.DataFrame] = [_load_packaged_union()]

    # --- Optional DepMap gene / transcript matrices ---
    from .downloads import _load_manifest

    manifest = _load_manifest()
    registered = manifest.get("datasets", {}) or {}

    def _registered_path(key: str) -> Path | None:
        entry = registered.get(key)
        if not entry or "path" not in entry:
            return None
        p = Path(entry["path"])
        return p if p.exists() else None

    # ModelID → display-name table, shared across gene + transcript matrices.
    model_csv = _registered_path("depmap_models")
    model_lookup = _load_depmap_model_lookup(model_csv)
    # Resolve the small metadata table before touching wide expression rows.
    line_keys = {
        model_id: key
        for model_id, name in model_lookup.items()
        if (key := resolve_line_key(name)) is not None
    }
    # Previously registered matrices can already use canonical line names.
    aliases = _alias_to_expression_key()
    line_keys.update(aliases)
    line_keys.update({key: key for key in aliases.values()})
    profiles = _depmap_default_rna_profiles(
        _registered_path("depmap_profiles"), _registered_path("depmap_default_profiles")
    )
    if verbose and model_csv is not None:
        print(f"  Loaded DepMap Model.csv lookup ({len(model_lookup):,} ModelIDs)")

    for key, source_id, granularity in (
        ("depmap_rna", "DepMap_24Q4_gene", "gene"),
        ("depmap_rna_transcript", "DepMap_24Q4_transcript", "transcript"),
    ):
        p = _registered_path(key)
        if p is None:
            continue
        if verbose:
            print(f"  Reading {key} from {p}")
        # The registry chooses the source for each line. In particular, the
        # complete packaged HAP1 gene profile replaces its downloadable copy.
        eligible = {
            entry.get("expression_key")
            for entry in load_line_expression_anchors()
            if source_id in (entry.get("source_ids") or [])
        }
        selected_keys = {label: value for label, value in line_keys.items() if value in eligible}
        long = _read_depmap_csv(
            p, granularity=granularity, line_keys=selected_keys, profiles=profiles
        )
        if long.empty:
            continue
        long["source_id"] = source_id
        frames.append(long)

    df = concat_non_empty(frames, LINE_EXPRESSION_COLUMNS, sort=False)
    if df.empty:
        empty = pd.DataFrame(columns=list(LINE_EXPRESSION_COLUMNS))
        out = write_line_expression_index(empty)
        if verbose:
            print(f"  No line-expression sources present — wrote empty {out}")
        return empty

    # Source metadata, parent_line_key and packaged gene symbols: the shared
    # row definition.  Then a live pyensembl lookup for IDs the packaged map
    # does not cover (e.g. newly-added genes) — a build-only backfill.
    df = enrich_line_expression_rows(df)
    df = _fill_gene_names_via_ensembl(df, verbose=verbose)

    out = write_line_expression_index(df)

    if verbose:
        n_gene = int((df["granularity"] == "gene").sum())
        n_tx = int((df["granularity"] == "transcript").sum())
        n_lines = int(df["line_key"].nunique())
        size_mb = out.stat().st_size / 1e6
        print(
            f"  {len(df):,} rows ({n_gene:,} gene + {n_tx:,} transcript) "
            f"across {n_lines} lines → {size_mb:.1f} MB"
        )
        print(f"  Wrote {out}")
    return df


#: Columns selected from ``ProteomeIndex.map_peptides`` output, in its
#: own naming.  ``n_sources`` is renamed to ``n_source_proteins`` on the
#: way out, so this is the *pre-rename* view.
_FLANKING_SOURCE_COLS = (
    "gene_name",
    "gene_id",
    "protein_id",
    "position",
    "n_flank",
    "c_flank",
    "n_sources",
)

#: Rename applied between the mapper's naming and ours.
_FLANKING_RENAME = {"n_sources": "n_source_proteins"}

#: The flanking schema as it appears on observations — derived from the
#: source columns rather than restated, so adding a column to the select
#: cannot leave this behind.
_FLANKING_COLS = (
    *(_FLANKING_RENAME.get(c, c) for c in _FLANKING_SOURCE_COLS),
    "flanking_species",
)


def _load_species_index(
    organism: str,
    release: int,
    verbose: bool,
    use_uniprot: bool = False,
):
    """Build a ProteomeIndex for a given species/organism, or None if unsupported."""
    from .downloads import lookup_proteome
    from .proteome import ProteomeIndex

    entry = lookup_proteome(organism, use_uniprot=use_uniprot)
    if entry is None:
        return None, None

    canonical = entry.get("canonical_species", organism)
    kind = entry["kind"]

    if kind == "ensembl":
        species = entry.get("species", "human")
        try:
            if verbose:
                print(f"  [{canonical}] loading pyensembl (species={species}, release={release})")
            idx = ProteomeIndex.from_ensembl(
                release=release,
                species=species,
                verbose=verbose,
            )
            return idx, canonical
        except Exception as e:
            if verbose:
                print(f"  [{canonical}] pyensembl failed: {e}")
            return None, None

    # UniProt FASTA
    from .downloads import fetch_species_proteome

    path = fetch_species_proteome(organism, verbose=verbose, use_uniprot=use_uniprot)
    if path is None or not path.exists():
        return None, None
    if verbose:
        print(f"  [{canonical}] indexing FASTA {path.name}")
    idx = ProteomeIndex.from_fasta(path, verbose=verbose)
    return idx, canonical


def _collect_pmid_extra_proteomes() -> dict[int, list[dict]]:
    """Load per-PMID reference_proteomes overrides from pmid_overrides.yaml.

    Returns a map ``{pmid_int: [{"upid": "UP...", "label": "..."}, ...]}``
    preserving the per-sample ordering (host first, viruses after).  Entries
    may be either dicts with a ``uniprot`` key or bare UPID strings.
    """
    from .curation import load_pmid_overrides

    overrides = load_pmid_overrides()
    result: dict[int, list[dict]] = {}
    for pmid, entry in overrides.items():
        seen: set[str] = set()
        upids: list[dict] = []
        for sample in entry.get("ms_samples", []):
            for proteome in sample.get("reference_proteomes", []):
                if isinstance(proteome, dict):
                    upid = proteome.get("uniprot")
                    label = proteome.get("proteome_label") or proteome.get("label")
                    if proteome.get("label") and not proteome.get("proteome_label"):
                        import warnings

                        warnings.warn(
                            f"PMID {pmid}: reference_proteomes uses deprecated "
                            f"'label:' key, use 'proteome_label:' (v1.7.5).",
                            DeprecationWarning,
                            stacklevel=2,
                        )
                else:
                    upid = str(proteome).strip()
                    label = None
                if not upid or upid in seen:
                    continue
                seen.add(upid)
                upids.append({"upid": upid, "label": label or upid})
        if upids:
            try:
                result[int(pmid)] = upids
            except (ValueError, TypeError):
                continue
    return result


def _map_extra_proteomes(obs: pd.DataFrame, release: int, use_uniprot: bool) -> pd.DataFrame:
    """Fill in flanking for peptides unmapped by the primary species pass
    using per-PMID ``reference_proteomes`` overrides."""
    pmid_extras = _collect_pmid_extra_proteomes()
    if not pmid_extras:
        return obs

    from .downloads import fetch_proteome_by_upid
    from .proteome import DEFAULT_FLANK, ProteomeIndex

    # Collect per-UPID peptides (for any PMID that references it, take only
    # observations that didn't match in the primary pass)
    pmid_col = obs["pmid"] if "pmid" in obs.columns else None
    if pmid_col is None:
        return obs
    unmatched_mask = obs["gene_name"].isna()

    upid_to_peptides: dict[str, tuple[str, set[str]]] = {}
    pmid_priority: dict[int, list[str]] = {}
    for pmid_int, upid_entries in pmid_extras.items():
        sel = unmatched_mask & (pmid_col == pmid_int)
        if not sel.any():
            continue
        peptides = set(obs.loc[sel, "peptide"].dropna())
        pmid_priority[pmid_int] = [e["upid"] for e in upid_entries]
        for e in upid_entries:
            upid = e["upid"]
            label = e["label"]
            if upid not in upid_to_peptides:
                upid_to_peptides[upid] = (label, set())
            upid_to_peptides[upid][1].update(peptides)

    if not upid_to_peptides:
        return obs

    # Map peptides against each extra proteome; store per-UPID best hits
    upid_to_hits: dict[str, pd.DataFrame] = {}
    print(
        f"\n  [extras] mapping {len(upid_to_peptides)} per-PMID override proteome(s) "
        f"for {sum(len(p) for _, p in upid_to_peptides.values()):,} unmatched peptides"
    )
    for upid, (label, peptides) in upid_to_peptides.items():
        path = fetch_proteome_by_upid(upid, label=label, verbose=True)
        if path is None or not path.exists():
            continue
        idx = ProteomeIndex.from_fasta(path, verbose=False)
        flanking = idx.map_peptides(sorted(peptides), flank=DEFAULT_FLANK, verbose=False)
        if flanking.empty:
            continue
        best = flanking.sort_values("n_sources").drop_duplicates("peptide", keep="first")
        best = best[["peptide", *_FLANKING_SOURCE_COLS]].copy()
        best = best.rename(columns=_FLANKING_RENAME)
        best["flanking_species"] = label
        upid_to_hits[upid] = best.set_index("peptide")
        print(f"    [{label}] matched {len(best):,} / {len(peptides):,} peptides")

    if not upid_to_hits:
        return obs

    # For each unmatched observation, try its PMID's priority list and take
    # the first hit.  Update in place.
    for pmid_int, priority in pmid_priority.items():
        sel = unmatched_mask & (pmid_col == pmid_int)
        if not sel.any():
            continue
        for upid in priority:
            hits = upid_to_hits.get(upid)
            if hits is None:
                continue
            # Find which unmatched rows of this PMID have a hit in this UPID
            still_unmatched = unmatched_mask & (pmid_col == pmid_int) & obs["gene_name"].isna()
            if not still_unmatched.any():
                break
            peps = obs.loc[still_unmatched, "peptide"]
            matched_peps = peps[peps.isin(hits.index)]
            if matched_peps.empty:
                continue
            for col in _FLANKING_COLS:
                if col in hits.columns:
                    obs.loc[matched_peps.index, col] = matched_peps.map(hits[col])
            # Recompute unmatched_mask locally for subsequent priority items
            # within this PMID
            unmatched_mask = obs["gene_name"].isna()
    return obs


def _add_flanking(
    obs: pd.DataFrame,
    release: int = 112,
    fetch_missing: bool = True,
    use_uniprot: bool = False,
) -> pd.DataFrame:
    """Map peptides to source proteins with flanking context.

    Routes each observation to its species-specific reference proteome
    based on ``source_organism`` (with ``mhc_species`` as a fallback).
    Reports per-species and overall progress.

    Flanks are stored at :data:`~hitlist.proteome.DEFAULT_FLANK` residues per
    side, truncated at protein termini.

    Parameters
    ----------
    obs
        Observations DataFrame with ``peptide`` + ``source_organism`` columns.
    release
        Ensembl release for Ensembl-supported species.
    fetch_missing
        If True, auto-download missing UniProt proteomes.
    use_uniprot
        If True, fall back to UniProt REST search for organisms that
        aren't in the curated registry.  Resolved mappings are cached
        in the manifest.
    """
    from .proteome import DEFAULT_FLANK

    try:
        from tqdm.auto import tqdm
    except ImportError:
        tqdm = None

    from .downloads import fetch_species_proteome, lookup_proteome

    # Decide the organism for each observation: source_organism > mhc_species
    organism = obs["source_organism"].astype(str).str.strip()
    organism = organism.where(organism != "", obs["mhc_species"].astype(str).str.strip())
    obs = obs.assign(_flanking_organism=organism)

    # Group peptides by (registered) canonical proteome.  We cache lookups
    # by raw organism string to avoid redundant UniProt queries.
    lookup_cache: dict[str, dict | None] = {}

    def _lookup(org: str) -> dict | None:
        if org in lookup_cache:
            return lookup_cache[org]
        entry = lookup_proteome(org, use_uniprot=use_uniprot)
        lookup_cache[org] = entry
        return entry

    species_to_peptides: dict[str, set[str]] = {}
    unmapped_organisms: dict[str, int] = {}
    for org, pep in zip(obs["_flanking_organism"], obs["peptide"]):
        if not org:
            continue
        entry = _lookup(org)
        if entry is None:
            unmapped_organisms[org] = unmapped_organisms.get(org, 0) + 1
            continue
        canonical = entry.get("canonical_species", org)
        species_to_peptides.setdefault(canonical, set()).add(pep)

    total_peptides = sum(len(v) for v in species_to_peptides.values())
    n_species = len(species_to_peptides)
    print(
        f"\nMapping peptides to source proteins:"
        f"  {total_peptides:,} unique peptides across {n_species} species"
    )

    if fetch_missing and n_species:
        print("\nEnsuring reference proteomes are available ...")
        for canonical in sorted(species_to_peptides):
            fetch_species_proteome(canonical, verbose=True, use_uniprot=use_uniprot)

    # Map per species; collect representative per peptide (global)
    best_rows: list[dict] = []
    per_species_stats: list[tuple[str, int, int]] = []

    species_iter = sorted(species_to_peptides)
    if tqdm is not None and n_species > 1:
        species_iter = tqdm(species_iter, desc="Flanking annotation", unit="species")

    for canonical in species_iter:
        peptides = species_to_peptides[canonical]
        if tqdm is not None and n_species > 1:
            species_iter.set_postfix_str(f"{canonical} ({len(peptides):,} peps)")
        else:
            print(f"\n  [{canonical}] mapping {len(peptides):,} peptides ...")

        idx, _canonical_out = _load_species_index(
            canonical, release=release, verbose=True, use_uniprot=use_uniprot
        )
        if idx is None:
            per_species_stats.append((canonical, len(peptides), 0))
            continue

        flanking = idx.map_peptides(sorted(peptides), flank=DEFAULT_FLANK, verbose=True)
        if flanking.empty:
            per_species_stats.append((canonical, len(peptides), 0))
            continue

        best = flanking.sort_values("n_sources").drop_duplicates("peptide", keep="first")
        best = best[["peptide", *_FLANKING_SOURCE_COLS]].copy()
        best = best.rename(columns=_FLANKING_RENAME)
        best["flanking_species"] = canonical

        best_rows.append(best)
        per_species_stats.append((canonical, len(peptides), len(best)))

    # Merge per-species results into single (peptide, species) → flanking map.
    # We key on (peptide, _flanking_organism_canonical) so a given peptide
    # routed to different species via different observations can get different
    # source proteins.
    if best_rows:
        best_all = pd.concat(best_rows, ignore_index=True)
    else:
        # _FLANKING_COLS already ends with flanking_species; listing it
        # again produced a duplicate column whose rename yielded two
        # _canonical_species keys and made the merge below raise
        # "column label is not unique" — on the path where no proteome
        # maps anything, i.e. a fresh machine with no pyensembl cache.
        best_all = pd.DataFrame(columns=["peptide", *_FLANKING_COLS])

    # Attach canonical species to each obs row for the join key
    canonical_lookup: dict[str, str] = {}
    for org in obs["_flanking_organism"].unique():
        if not org:
            continue
        entry = _lookup(org)
        if entry is None:
            continue
        canonical_lookup[org] = entry.get("canonical_species", org)
    obs["_canonical_species"] = obs["_flanking_organism"].map(lambda o: canonical_lookup.get(o, ""))

    obs = obs.merge(
        best_all.rename(columns={"flanking_species": "_canonical_species"}),
        on=["peptide", "_canonical_species"],
        how="left",
    )
    obs["flanking_species"] = obs["_canonical_species"].replace("", pd.NA)
    obs.drop(columns=["_canonical_species", "_flanking_organism"], inplace=True)

    # --- Per-sample reference_proteomes override ---
    # For PMIDs whose ms_samples list additional reference_proteomes (e.g.
    # EBV for B-LCLs, Influenza A for infected lung), try each extra
    # proteome for the peptides of that PMID that the primary mapping
    # didn't match.  First hit wins in user-specified order.
    obs = _map_extra_proteomes(obs, release=release, use_uniprot=use_uniprot)

    # --- Coverage report ---
    print("\n  Flanking coverage by species:")
    for canonical, n_peps, n_mapped in sorted(per_species_stats):
        n_obs = int((obs["flanking_species"] == canonical).sum())
        print(f"    {canonical:40s}  peptides: {n_mapped:>8,} / {n_peps:<8,}  rows: {n_obs:>10,}")

    if unmapped_organisms:
        print(f"\n  Organisms with no registered proteome ({len(unmapped_organisms)}):")
        for org, n in sorted(unmapped_organisms.items(), key=lambda x: -x[1])[:10]:
            print(f"    {org!r:60s}  {n:>10,} rows")
        if len(unmapped_organisms) > 10:
            print(f"    ... and {len(unmapped_organisms) - 10} more")

    n_mapped = int(obs["gene_name"].notna().sum())
    print(
        f"\n  Mapped: {n_mapped:,} / {len(obs):,} observations ({100 * n_mapped / len(obs):.1f}%)"
    )

    return obs
