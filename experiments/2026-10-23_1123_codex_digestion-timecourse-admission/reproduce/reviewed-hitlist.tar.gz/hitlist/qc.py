# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Corpus + curation QC checks.

Independent diagnostics, each returning a DataFrame so consumers can
print, write to CSV, or feed into a notebook:

- :func:`resolution_histogram` — count rows per (mhc_class, source,
  allele_resolution) bucket.  Tells you what fraction of the corpus is
  4-digit / 2-digit / serotype / class-only / unresolved.
- :func:`normalization_drift` — alleles in ``pmid_overrides.yaml`` whose
  ``normalize_allele`` output differs from the curated input.  Catches
  silent normalization changes.
- :func:`cross_reference` — alleles listed in YAML sample genotypes that
  never appear as ``mhc_restriction`` in the data for that PMID, and the
  reverse: data alleles for a PMID never listed in any sample.  Catches
  curation/data divergence.
- :func:`mhc_token_audit` — unparseable restriction, host-typing, serotype,
  and curated-sample tokens across MS and binding, classified as source
  defects, known parser gaps, or new unrecognized values.
- :func:`sample_attribution_audit` — curated arms that were profiled but
  reach zero observation rows.  Catches curation that describes something
  the corpus cannot see.
- :func:`engineering_drift_audit` — curated arms silent on an engineering
  column that a same-material sibling asserts.  Catches the per-arm gap that
  costs an expression-anchor tier (#586).

Each function returns the same shape: a DataFrame with one row per
finding plus a ``severity`` column (``info`` / ``warn`` / ``error``) so
:func:`run_all` can produce a unified summary.
"""

from __future__ import annotations

import re
from collections.abc import Mapping

import pandas as pd

from .conditions import (
    CONDITION_COLUMNS,
    ENGINEERING_CONDITION_COLUMNS,
    MATERIAL_IDENTITY_COLUMNS,
    MULTI_VALUE_CONDITION_COLUMNS,
    NONE_PERMITTED_CONDITION_COLUMNS,
    TOKENIZED_MATERIAL_IDENTITY_COLUMNS,
    asserts_condition,
    condition_columns_for_sample,
    is_engineered_material,
    split_condition_tokens,
)
from .curation import (
    _cached_parse,
    _flatten_hla_alleles,
    allele_resolution_rank,
    is_class_only_token,
    load_pmid_overrides,
    ms_excluded_pmids,
    normalize_allele,
)
from .dataset import dataset_snapshot
from .pandas_utils import fillna_scalar_safe

_MHC_AUDIT_COLUMNS = [
    "evidence_kind",
    "field",
    "token",
    "status",
    "reason",
    "pmid",
    "n_records",
    "severity",
]

# These are source-data defects, not parser failures. Keep them visible even
# if a future mhcgnomes release becomes permissive enough to parse them.
_KNOWN_INVALID_MHC_TOKENS: dict[str, str] = {
    "HLA-B23": "not a recognized HLA-B serological specificity; source intent is unrecoverable",
    "HLA-DR7A": "IEDB token is not a valid HLA gene, allele, serotype, or class designation",
    "HLA-DR3A": "IEDB token is not a valid HLA gene, allele, serotype, or class designation",
    "HLA-DR1B": "IEDB token is not a valid HLA gene, allele, serotype, or class designation",
}

# A valid historical HLA-C serotype spelling that mhcgnomes does not yet
# recognize. If the parser learns it, the normal parse path wins and this
# finding disappears, making the allowlist self-expiring.
_KNOWN_MHC_PARSER_GAPS: dict[str, str] = {
    "HLA-Cw16": "valid HLA-Cw16 serotype spelling not recognized by mhcgnomes",
}

_MHC_TOKEN_SENTINELS = frozenset({"", "unknown", "mutant", "not typed", "n/a", "na"})
_MHC_DESIGNATION_TYPES = frozenset(
    {"Allele", "Gene", "Pair", "Serotype", "Class2Locus", "MhcClass", "Haplotype"}
)


def _split_mhc_audit_tokens(value: object, *, curated: bool = False) -> list[str]:
    """Split one MHC field without breaking multi-word class designations."""
    if value is None or pd.isna(value):
        return []
    text = str(value).strip()
    if not text or text.lower() in _MHC_TOKEN_SENTINELS:
        return []
    if is_class_only_token(text):
        return [text]
    tokens = []
    for component in re.split(r"[;,]+", text):
        component = component.strip()
        if not component:
            continue
        # Unknown class-I typing can accompany a typed class-II allele.
        # Recognize each complete designation before splitting the space-
        # joined allele lists used by curation (#561).
        if curated and not is_class_only_token(component):
            tokens.extend(component.split())
        else:
            tokens.append(component)
    return tokens


@dataset_snapshot()
def _default_mhc_audit_frames() -> dict[str, pd.DataFrame]:
    """Read only audit columns that exist in each built evidence parquet."""
    import pyarrow.parquet as pq

    from .observations import binding_path, observations_path

    wanted = ["pmid", "mhc_restriction", "host_mhc_types", "serotype", "serotypes"]
    frames: dict[str, pd.DataFrame] = {}
    for evidence_kind, path in (("ms", observations_path()), ("binding", binding_path())):
        if not path.exists():
            continue
        available = set(pq.read_schema(path).names)
        columns = [column for column in wanted if column in available]
        frames[evidence_kind] = pd.read_parquet(path, columns=columns)
    return frames


def _default_curated_mhc_samples() -> pd.DataFrame:
    """Flatten PMID ``ms_samples`` into the fields needed by the token audit.

    Skips ``exclude_from_ms`` studies (#444, #471): their curated samples
    describe a system that never reaches the MS index, so their tokens have
    nothing in ``evidence_frames["ms"]`` to reconcile against.
    """
    excluded = ms_excluded_pmids()
    rows = []
    for pmid, entry in load_pmid_overrides().items():
        if pmid in excluded:
            continue
        for sample in entry.get("ms_samples", []) or []:
            rows.append(
                {
                    "pmid": pmid,
                    "sample_label": sample.get("sample_label", ""),
                    "mhc": sample.get("mhc", ""),
                    "mhc_genotype": sample.get("mhc_genotype", ""),
                }
            )
    return pd.DataFrame(rows, columns=["pmid", "sample_label", "mhc", "mhc_genotype"])


def mhc_token_audit(
    evidence_frames: Mapping[str, pd.DataFrame] | None = None,
    curated_samples: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Report unparseable MHC tokens across every catalogued modality.

    Parameters
    ----------
    evidence_frames
        Optional mapping such as ``{"ms": observations, "binding": binding}``.
        Each frame may contain ``mhc_restriction``, ``host_mhc_types``,
        ``serotype``, and ``serotypes`` plus ``pmid``. When omitted, the
        corresponding columns are read from whichever built artifacts exist.
    curated_samples
        Optional frame containing curated ``pmid``, ``sample_label``, and
        free-text ``mhc`` and ``mhc_genotype`` fields. When omitted, these are flattened from
        ``pmid_overrides.yaml``.

    Returns
    -------
    pd.DataFrame
        One row per modality/field/token/PMID finding. ``status`` distinguishes
        upstream-invalid source values, known parser gaps, and wholly new
        unrecognized tokens. Valid designations and exact sentinel values are
        omitted. ``n_records`` records repeated evidence without hiding its
        provenance.
    """
    if evidence_frames is None:
        evidence_frames = _default_mhc_audit_frames()
    if curated_samples is None:
        curated_samples = _default_curated_mhc_samples()

    findings: list[dict] = []

    def inspect(
        evidence_kind: str,
        field: str,
        token: str,
        pmid: object,
        n_records: int,
    ) -> None:
        if token.lower() in _MHC_TOKEN_SENTINELS:
            return
        if token in _KNOWN_INVALID_MHC_TOKENS:
            status = "invalid_source"
            reason = _KNOWN_INVALID_MHC_TOKENS[token]
            severity = "error"
        else:
            parsed = _cached_parse(token)
            if type(parsed).__name__ in _MHC_DESIGNATION_TYPES:
                return
            if token in _KNOWN_MHC_PARSER_GAPS:
                status = "parser_gap"
                reason = _KNOWN_MHC_PARSER_GAPS[token]
                severity = "warn"
            else:
                status = "unrecognized"
                reason = "not recognized as an MHC designation and not in the reviewed allowlist"
                severity = "error"
        findings.append(
            {
                "evidence_kind": evidence_kind,
                "field": field,
                "token": token,
                "status": status,
                "reason": reason,
                "pmid": pmid,
                "n_records": n_records,
                "severity": severity,
            }
        )

    def inspect_series(
        evidence_kind: str,
        field: str,
        frame: pd.DataFrame,
        *,
        curated: bool = False,
    ) -> None:
        if field not in frame.columns:
            return
        values = frame[[field]].copy()
        values["pmid"] = frame["pmid"] if "pmid" in frame.columns else ""
        values["token"] = (
            values[field]
            .astype("object")
            .map(lambda value: _split_mhc_audit_tokens(value, curated=curated))
        )
        counts = (
            values[["pmid", "token"]]
            .explode("token")
            .dropna(subset=["token"])
            .groupby(["pmid", "token"], dropna=False, observed=True)
            .size()
            .reset_index(name="n_records")
        )
        for row in counts.itertuples(index=False):
            inspect(evidence_kind, field, row.token, row.pmid, int(row.n_records))

    evidence_fields = ("mhc_restriction", "host_mhc_types", "serotype", "serotypes")
    for evidence_kind, frame in evidence_frames.items():
        for field in evidence_fields:
            inspect_series(evidence_kind, field, frame)

    if not curated_samples.empty:
        for field in ("mhc", "mhc_genotype"):
            inspect_series("curation", field, curated_samples, curated=True)
        for finding in findings:
            if finding["evidence_kind"] == "curation" and finding["field"] == "mhc":
                finding["field"] = "sample_mhc"

    if not findings:
        return pd.DataFrame(columns=_MHC_AUDIT_COLUMNS)
    return (
        pd.DataFrame(findings)
        .groupby(
            [
                "evidence_kind",
                "field",
                "token",
                "status",
                "reason",
                "pmid",
                "severity",
            ],
            dropna=False,
            as_index=False,
        )["n_records"]
        .sum()
        .reset_index()[_MHC_AUDIT_COLUMNS]
        .sort_values(["severity", "status", "token", "evidence_kind", "pmid"], kind="stable")
        .reset_index(drop=True)
    )


#: A diploid genome carries at most two alleles at one locus.  Anything above
#: this in one curated sample's ``mhc`` or ``mhc_genotype`` is a union across
#: several donors, transfectants, or mono-allelic constructs rather than one
#: sample's own molecules (#564).
MAX_ALLELES_PER_LOCUS = 2

_PLOIDY_AUDIT_COLUMNS = [
    "pmid",
    "sample_label",
    "field",
    "locus",
    "n_alleles",
    "alleles",
    "n_alleles_total",
    "reason",
]


def sample_ploidy_audit(overrides: Mapping[int, dict] | None = None) -> pd.DataFrame:
    """Flag curated samples carrying more alleles at a locus than a genome can.

    Both ``mhc`` and ``mhc_genotype`` are audited (#564).  A diploid donor has
    at most two alleles at any locus, so three or more is proof the field pools
    several donors, transfectants, or mono-allelic constructs into one entry.

    ``mhc_genotype`` is where that invariant now literally holds -- it is
    defined as one cell's or donor's typing -- and it had no enforcement:
    :func:`hitlist.curation.sample_mhc_metadata` validates completeness and
    provenance and never counts alleles per locus, so pooling two donors'
    typing onto one sample loaded cleanly.  ``mhc`` is still audited because a
    selected ligand restriction is a subset of one cell's molecules, so three
    at a locus means a union there too; what #520 changed is that a clean
    ``mhc`` no longer implies the field *is* a genotype.

    That pooling is not cosmetic.  The allele-level join treats every
    listed allele as a candidate for every peptide in the sample, so a
    union of ten mono-allelic MAPTAC constructs asserts that any of the
    ten could have presented any peptide — the same false-widening bug
    class as #392, where a study-level perturbation panel marked every
    arm as perturbed for every gene.

    Locus is species-qualified (:func:`hitlist.curation.allele_locus`), so
    ``HLA-DRB3`` and ``BoLA-DRB3`` are counted apart.  Class-II
    heterodimer pairs are decomposed into their chains first, and each
    chain is charged to its own locus.

    Deliberately **not** flagged:

    - Serotype and locus/class designations, which name no allele.
    - Multiple loci on one sample.  A donor legitimately carries
      ``HLA-DRB1`` x2 plus a linked ``HLA-DRB3``/``DRB4``/``DRB5``.

    Returns
    -------
    pd.DataFrame
        One row per offending (sample, field, locus), empty when the corpus is
        clean.  ``n_alleles_total`` gives the audited field's whole allele count
        for context, since a badly pooled sample usually breaks several
        loci at once.

    Notes
    -----
    Aneuploid lines are the one real source of false positives: HeLa is
    hypertriploid and could in principle carry three alleles at a locus.
    Such a sample still warrants a curation note explaining why it is
    exempt, so it is reported rather than special-cased here.
    """
    from .curation import (
        allele_locus,
        expand_allele_components,
        load_pmid_overrides,
        sample_mhc_candidates,
    )

    if overrides is None:
        overrides = load_pmid_overrides()

    findings: list[dict] = []
    for pmid, entry in overrides.items():
        for sample in entry.get("ms_samples") or []:
            for field in ("mhc", "mhc_genotype"):
                candidates = sample_mhc_candidates(sample.get(field))
                if not candidates.exact:
                    continue
                by_locus: dict[str, set[str]] = {}
                for allele in candidates.exact:
                    # A pair spans two loci; charge each chain to its own.
                    components = expand_allele_components(allele)
                    chains = [c for c in components if allele_locus(c)] or [allele]
                    for chain in chains:
                        locus = allele_locus(chain)
                        if locus:
                            by_locus.setdefault(locus, set()).add(chain)
                for locus, alleles in sorted(by_locus.items()):
                    if len(alleles) <= MAX_ALLELES_PER_LOCUS:
                        continue
                    findings.append(
                        {
                            "pmid": pmid,
                            "sample_label": sample.get("sample_label", ""),
                            "field": field,
                            "locus": locus,
                            "n_alleles": len(alleles),
                            "alleles": " ".join(sorted(alleles)),
                            "n_alleles_total": len(candidates.exact),
                            "reason": (
                                f"{len(alleles)} alleles at {locus}; a diploid sample carries at "
                                f"most {MAX_ALLELES_PER_LOCUS}, so this {field} field pools "
                                "several samples"
                            ),
                        }
                    )
    if not findings:
        return pd.DataFrame(columns=_PLOIDY_AUDIT_COLUMNS)
    return (
        pd.DataFrame(findings)
        .sort_values(
            ["n_alleles", "pmid", "sample_label", "locus"], ascending=[False, True, True, True]
        )
        .reset_index(drop=True)[_PLOIDY_AUDIT_COLUMNS]
    )


_ENGINEERING_DRIFT_AUDIT_COLUMNS = [
    "pmid",
    "condition_id",
    "sample_label",
    "column",
    "asserted_by",
    "asserted_values",
    "n_silent_arms",
    "n_asserting_arms",
    "tier_at_risk",
    "severity",
    "reason",
]

#: Arms whose ``condition_status`` says a blank engineering cell is deliberate.
#: ``unreported`` states that nothing was recorded; ``mixed`` fills only facts
#: true of *every* contributing condition, so a blank is what the contract asks
#: for.  Flagging either would fail CI for a PR that curated correctly.
_ENGINEERING_DRIFT_EXEMPT_STATUSES = frozenset({"unreported", "mixed"})


def _material_identity(sample: Mapping[str, object]) -> tuple:
    """Which material an arm is, over :data:`~hitlist.conditions.MATERIAL_IDENTITY_COLUMNS`.

    Multi-token columns compare as unordered sets, so a genotype written in a
    different order is not a different material.  Condition cells read the same
    from the record as from :func:`condition_columns_for_sample`, which is only
    a strip, so one lookup serves both kinds of column.
    """
    identity = []
    for column in MATERIAL_IDENTITY_COLUMNS:
        value = str(sample.get(column) or "").strip()
        if column in TOKENIZED_MATERIAL_IDENTITY_COLUMNS:
            identity.append(tuple(sorted(value.split())))
        elif column in MULTI_VALUE_CONDITION_COLUMNS:
            identity.append(tuple(sorted(split_condition_tokens(value))))
        else:
            identity.append((value,))
    return tuple(identity)


def _engineering_remedy(column: str) -> str:
    """What a curator can *truthfully write* to resolve a finding on ``column``.

    Branching matters because ``condition_mhc_context`` is the one engineering
    column :data:`~hitlist.conditions.NONE_PERMITTED_CONDITION_COLUMNS` excludes.
    Prescribing ``none`` there would tell a curator to write a token the loader
    rejects, breaking the package for everyone — so where the vocabulary cannot
    state absence, this says so instead of inventing a remedy.
    """
    # Every branch below has to be something the loader accepts, or a curator
    # following it stops the package loading.  `sample_group` is opt-in per
    # study, all-or-none, and rejects a one-to-one group/arm mapping, so on a
    # two-arm study it cannot separate them at all; `mhc_genotype_cell` alone
    # is rejected without the rest of the trio (#587 review 3).
    separate = (
        "if these are different materials, say so with mhc_genotype + "
        "mhc_genotype_cell + mhc_genotype_source together -- all three are required, "
        "and mhc_genotype is audited for ploidy and against mhc_genotype_complete_loci "
        "-- or with sample_group, which must be set on every arm of the study and must "
        "not give each arm its own group, so it cannot separate a two-arm study"
    )
    if column in NONE_PERMITTED_CONDITION_COLUMNS:
        return (
            f"record the real value; or 'none' if this arm genuinely lacks {column}; or {separate}"
        )
    return (
        f"record the real value; or {separate}.  'none' is NOT permitted in {column}, so "
        f"this column cannot state absence: an arm whose MHC really is not introduced has "
        f"no token to say so, and leaving it blank keeps this finding.  That is a "
        f"documented gap in the vocabulary, not a curation error"
    )


def engineering_drift_audit(overrides: Mapping[int, dict] | None = None) -> pd.DataFrame:
    """Flag arms silent on an engineering column a same-material sibling asserts.

    ``condition_mhc_context``, the knockout/knockdown/overexpression/variant
    columns and the transfection/transduction columns say the profiled material
    is not the parental line.  Since #576 that is per arm: an arm whose
    engineering block is blank does not satisfy
    :func:`hitlist.conditions.is_engineered_material`, so
    :func:`hitlist.line_expression.resolve_sample_expression_anchor` reports its
    reference line's RNA at tier 1 — as RNA measured in the sample — while an
    identically-engineered sibling correctly resolves at tier 2.  #586 is that
    defect on five of ten arms of PMID 26768311.

    ``""`` is *not established*, which is why silence is what this looks for.
    ``none`` is a positive claim of absence and passes, so a genuine wild-type
    arm beside a knockout sibling is annotated rather than flagged.  An arm
    whose ``condition_status`` is ``unreported`` or ``mixed`` is exempt: both
    are documented ways for a blank to be the right answer.

    This is an **audit, not a load-time rule**.  It ran inside
    ``load_pmid_overrides`` in the first cut of #587, where a single false
    positive would make the installed package unimportable for every consumer
    — a catastrophic failure mode to buy a per-arm tier correction.  Here a
    disagreement fails CI for whoever makes the edit, who can adjudicate it.

    Deliberately **not** flagged:

    - A column no asserting sibling actually *engineers*.  A sibling asserting
      only ``soluble_mhc`` is not engineered either, so there is no tier to
      differ and nothing this audit is about (#587 review 3).
    - Two arms that both assert, but differ (``B2M`` beside ``B2M;TAP1``).
      Both are engineered, both resolve at tier 2, and which genes a study
      knocked out per arm is the experiment.
    - Arms of different materials, per
      :data:`~hitlist.conditions.MATERIAL_IDENTITY_COLUMNS`.
    - Studies excluded from MS (``exclude_from_ms``), whose arms reach zero
      observation rows, so no anchor is ever resolved for them.
    - Studies that curate no condition block at all, which
      :func:`hitlist.conditions.validate_study_conditions` also skips.
    - A ``condition_mhc_context`` naming only capture tokens (``soluble_mhc``,
      ``refolded_mhc``) beside an engineered sibling.  Silence here is an empty
      cell, not "no engineering token", because ``none`` is not permitted in
      this column, so there would be no truthful remedy to offer an arm whose
      MHC really was only captured — patient plasma sHLA is exactly that.  The
      cost is a known miss: a transfectant curated ``soluble_mhc`` alone reads
      as unengineered and is not flagged.

    Material identity is thin in practice — ``sample_group`` is set on a
    minority of arms — so arms of one study often group together on the
    strength of blank columns.  That is why this reports rather than raises,
    and why every finding is adjudicated rather than auto-remedied: ``none``
    is a positive claim about an experiment, which someone must verify.

    Parameters
    ----------
    overrides
        Curated studies, defaulting to the packaged ``pmid_overrides.yaml``.

    Returns
    -------
    pd.DataFrame
        One row per (silent arm, engineering column), empty when the corpus is
        clean.  ``asserted_by`` and ``asserted_values`` are *lists* rendered as
        text, never ``;``-joined: ``;`` separates tokens **within** one cell, so
        a join of two cells would read as one combination nobody performed.
    """
    if overrides is None:
        overrides = load_pmid_overrides()
    engineering_columns = sorted(ENGINEERING_CONDITION_COLUMNS)
    excluded = ms_excluded_pmids()

    findings: list[dict] = []
    for pmid, entry in sorted(overrides.items()):
        if pmid in excluded:
            continue
        samples = entry.get("ms_samples") or []
        if not any(column in sample for sample in samples for column in CONDITION_COLUMNS):
            continue  # uncurated study; the loader opts it out too
        groups: dict[tuple, list[tuple[Mapping[str, object], Mapping[str, str]]]] = {}
        for sample in samples:
            cells = condition_columns_for_sample(sample)
            groups.setdefault(_material_identity(sample), []).append((sample, cells))
        for arms in groups.values():
            if len(arms) < 2:
                continue
            for column in engineering_columns:
                # Three-way, per the conditions module's missing-value contract:
                # a named intervention asserts, ``none`` is a curated claim of
                # absence and is neither, and only ``""`` is silence.
                asserting = [(s, c) for s, c in arms if asserts_condition(c[column])]
                silent = [
                    (s, c)
                    for s, c in arms
                    if not c[column]
                    and str(s.get("condition_status") or "").strip()
                    not in _ENGINEERING_DRIFT_EXEMPT_STATUSES
                ]
                if not asserting or not silent:
                    continue
                # A sibling asserting a capture-only mhc_context is not
                # engineered either, so no tier differs and this is not
                # engineering drift (#587 review 3).
                if not any(is_engineered_material({column: c[column]}) for _, c in asserting):
                    continue
                asserted_by = repr(sorted(str(s.get("condition_id") or "?") for s, _ in asserting))
                asserted_values = repr(sorted({c[column] for _, c in asserting}))
                remedy = _engineering_remedy(column)
                for sample, cells in silent:
                    # The tier consequence is real only where nothing else in
                    # the block engineers this arm; otherwise the cost is an
                    # under-recorded column, not a wrong anchor.
                    tier_at_risk = not is_engineered_material(cells)
                    consequence = (
                        "Blank reads as 'not established', so this arm does not count as "
                        "engineered material and takes its reference line's RNA at tier 1 "
                        "while the sibling takes it at tier 2."
                        if tier_at_risk
                        else "Another engineering column still marks this arm engineered, so "
                        "the anchor is unaffected; what is lost is which intervention it was."
                    )
                    findings.append(
                        {
                            "pmid": pmid,
                            "condition_id": str(sample.get("condition_id") or "?"),
                            "sample_label": str(sample.get("sample_label") or ""),
                            "column": column,
                            "asserted_by": asserted_by,
                            "asserted_values": asserted_values,
                            "n_silent_arms": len(silent),
                            "n_asserting_arms": len(asserting),
                            "tier_at_risk": tier_at_risk,
                            "severity": "error" if tier_at_risk else "warn",
                            "reason": (
                                f"{column} is blank here but asserted on same-material "
                                f"sibling(s) {asserted_by} as {asserted_values}.  "
                                f"{consequence}  To resolve: {remedy}"
                            ),
                        }
                    )
    if not findings:
        return pd.DataFrame(columns=_ENGINEERING_DRIFT_AUDIT_COLUMNS)
    return (
        pd.DataFrame(findings)
        .sort_values(["pmid", "condition_id", "column"])
        .reset_index(drop=True)[_ENGINEERING_DRIFT_AUDIT_COLUMNS]
    )


_SAMPLE_ATTRIBUTION_AUDIT_COLUMNS = [
    "pmid",
    "study_label",
    "sample_label",
    "mhc_class",
    "condition",
    "bucket",
    "arm_resolution",
    "n_study_arms",
    "n_attributed_arms",
    "reason",
    "severity",
]


@dataset_snapshot()
def sample_attribution_audit(
    samples: pd.DataFrame | None = None,
    observations: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Curated arms that were profiled but reach zero observation rows.

    A curated ``ms_samples`` entry describes an experimental arm. If no
    evidence row is ever attributed to it, the curation is describing
    something the corpus cannot see — and today a curator adding an arm
    gets no signal about whether it landed. 232 of 684 profiled arms are
    in that state (#442).

    Arms explicitly curated as unprofiled are excluded: they have no MS
    data by construction and are supposed to reach no row (#437). The
    predicate comes from :func:`hitlist.export._observation_eligible_samples`
    so this check and the join agree on what "joinable" means.

    Findings are bucketed, because the two shapes need different triage:

    ``label_mismatch_candidate``
        The study has other arms that *do* attribute, so the mechanism
        demonstrably works here and this arm's label is the suspect.
        PMID 31844290 attributes 86 of its 107 arms; the 21 that fail
        are the interesting ones.
    ``study_unattributed``
        No arm in the study attributes at all. That is a different
        failure — possibly a study whose evidence cannot be resolved to
        an arm at all — and is triaged per study, not per label (#366).

    The ``arm_resolution`` column carries the study's recorded verdict, so a
    finding in a study already known to be unresolvable can be separated from
    one nobody has looked at. Only ``curation_gap`` and a blank marks work.

    Parameters
    ----------
    samples
        Curated sample frame; defaults to
        :func:`hitlist.export.generate_ms_samples_table`.
    observations
        Enriched observation frame carrying ``pmid`` and ``sample_label``;
        defaults to :func:`hitlist.export.generate_observations_table`.

    Returns
    -------
    pd.DataFrame
        One row per orphaned arm, ordered by study size then PMID.

    Notes
    -----
    Deliberately **not** wired into :func:`run_all` or
    :func:`curation_plan`. ``sample_label`` is synthesized by the export
    join and is not a column of ``observations.parquet``, so this is the
    only check that needs the full enriched table rather than a narrow
    ``load_observations`` projection. Wiring it into either rollup would
    make every ``hitlist qc`` invocation pay that build.
    :func:`sample_ploidy_audit` and :func:`species_axis_audit` are the
    precedent for a check that ships standalone.
    """
    from .export import (
        _observation_eligible_samples,
        generate_ms_samples_table,
        generate_observations_table,
    )

    if samples is None:
        samples = generate_ms_samples_table()
    if observations is None:
        observations = generate_observations_table(columns=["pmid", "sample_label"])

    overrides = load_pmid_overrides()
    eligible = _observation_eligible_samples(samples)
    if eligible.empty or observations.empty:
        return pd.DataFrame(columns=_SAMPLE_ATTRIBUTION_AUDIT_COLUMNS)

    obs = observations[observations["pmid"].notna()]
    obs_pmids = set(obs["pmid"].astype(int))
    # Both series come from one frame and have the same length.
    attributed = {
        (int(pmid), str(label))
        for pmid, label in zip(obs["pmid"], obs["sample_label"].astype(str))
        if str(label)
    }

    # An arm in a PMID with no rows at all is not an attribution failure —
    # the study simply is not in this corpus build.
    in_scope = eligible[eligible["pmid"].notna()]
    in_scope = in_scope[in_scope["pmid"].astype(int).isin(obs_pmids)]

    attributed_per_pmid: dict[int, int] = {}
    arms_per_pmid: dict[int, int] = {}
    for row in in_scope.itertuples():
        pmid = int(row.pmid)
        arms_per_pmid[pmid] = arms_per_pmid.get(pmid, 0) + 1
        if (pmid, str(row.sample_label)) in attributed:
            attributed_per_pmid[pmid] = attributed_per_pmid.get(pmid, 0) + 1

    findings = []
    for row in in_scope.itertuples():
        pmid = int(row.pmid)
        if (pmid, str(row.sample_label)) in attributed:
            continue
        n_attributed = attributed_per_pmid.get(pmid, 0)
        if n_attributed:
            bucket, severity = "label_mismatch_candidate", "warn"
            reason = (
                f"{n_attributed} of {arms_per_pmid[pmid]} arms in this study do attribute, "
                f"so the join works here and this arm's label is the suspect"
            )
        else:
            bucket, severity = "study_unattributed", "info"
            reason = (
                f"no arm of this study attributes ({arms_per_pmid[pmid]} curated); triage per "
                f"study rather than per label"
            )
        findings.append(
            {
                "pmid": pmid,
                "study_label": str(getattr(row, "study_label", "") or ""),
                "sample_label": str(row.sample_label),
                "mhc_class": str(getattr(row, "mhc_class", "") or ""),
                "condition": str(getattr(row, "condition", "") or ""),
                "bucket": bucket,
                # The study's recorded arm-resolution verdict (#366), so a
                # reader can tell "nobody has looked at this" from "this was
                # investigated and the deposit cannot answer it".
                "arm_resolution": str(overrides.get(pmid, {}).get("arm_resolution", "") or ""),
                "n_study_arms": arms_per_pmid[pmid],
                "n_attributed_arms": n_attributed,
                "reason": reason,
                "severity": severity,
            }
        )

    if not findings:
        return pd.DataFrame(columns=_SAMPLE_ATTRIBUTION_AUDIT_COLUMNS)
    return (
        pd.DataFrame(findings)
        .sort_values(["n_study_arms", "pmid", "sample_label"], ascending=[False, True, True])
        .reset_index(drop=True)[_SAMPLE_ATTRIBUTION_AUDIT_COLUMNS]
    )


def resolution_histogram(
    mhc_class: str | None = None,
    species: str | None = None,
    source: str | None = None,
) -> pd.DataFrame:
    """Count observations per ``(mhc_class, source, allele_resolution)``.

    Parameters
    ----------
    mhc_class, species, source
        Optional filters passed through to ``load_observations``.

    Returns
    -------
    pd.DataFrame
        Columns: ``mhc_class``, ``source``, ``allele_resolution``,
        ``n_observations``, ``pct_within_class``.  Sorted by class then
        bucket so the most-resolved row in each class is first.
    """
    from .observations import is_built, load_observations

    if not is_built():
        raise FileNotFoundError(
            "observations.parquet has not been built. Run 'hitlist build observations' first."
        )

    df = load_observations(
        mhc_class=mhc_class,
        species=species,
        source=source,
        columns=["mhc_class", "source", "allele_resolution"],
    )
    if df.empty:
        return pd.DataFrame(
            columns=[
                "mhc_class",
                "source",
                "allele_resolution",
                "n_observations",
                "pct_within_class",
            ]
        )

    # ``observed=True``: all three keys arrive from the parquet as dictionary-
    # encoded categoricals, and the default takes their Cartesian product. On
    # the built corpus that is 112 rows of which 84 are combinations that never
    # occur, plus an all-NaN block for a class with no rows -- and two pandas
    # FutureWarnings. The frame this function documents is one row per observed
    # combination (#597).
    counts = (
        df.groupby(["mhc_class", "source", "allele_resolution"], dropna=False, observed=True)
        .size()
        .reset_index(name="n_observations")
    )
    class_totals = counts.groupby("mhc_class", observed=True)["n_observations"].transform("sum")
    counts["pct_within_class"] = (counts["n_observations"] / class_totals * 100).round(2)

    # Order buckets most-resolved to least so output is readable. The ordering
    # comes from :func:`hitlist.curation.allele_resolution_rank` rather than a
    # literal copy of it: the copy this replaced predated ``donor_set`` and
    # never gained it, so the second-most-specific tier -- the one covering
    # every row narrowed to a donor's typing -- fell to a ``fillna(99)``
    # default and sorted *below* ``unresolved`` (#597).
    #
    # ``.astype("int64")`` is load-bearing, not tidying. ``allele_resolution``
    # is categorical here, and ``Categorical.map`` returns a *Categorical* when
    # the mapping is total -- whose categories keep the original alphabetical
    # order, so ``sort_values`` would order by allele_resolution's spelling and
    # put ``class_only`` first. The literal dict this replaced escaped that
    # only by accident: leaving ``donor_set`` unmapped forced a NaN, which
    # forced the float64 fallback, which sorted numerically.
    counts["_bucket_rank"] = counts["allele_resolution"].map(allele_resolution_rank).astype("int64")
    counts = counts.sort_values(["mhc_class", "_bucket_rank", "source"], kind="stable").drop(
        columns="_bucket_rank"
    )
    return counts.reset_index(drop=True)


@dataset_snapshot()
def normalization_drift() -> pd.DataFrame:
    """Find alleles in pmid_overrides whose normalized form differs from input.

    Walks every ``hla_alleles`` value in every PMID, runs each 4-digit
    string through ``normalize_allele``, and emits a row whenever the
    output differs from the input.

    Returns
    -------
    pd.DataFrame
        Columns: ``pmid``, ``study_label``, ``allele_raw``,
        ``allele_normalized``, ``severity``.  Empty if no drift exists.
    """
    overrides = load_pmid_overrides()
    rows: list[dict] = []
    for pmid_int, entry in sorted(overrides.items()):
        study_label = entry.get("study_label", "")
        hla_alleles = entry.get("hla_alleles", {})
        if not hla_alleles:
            continue
        # _flatten_hla_alleles handles flat list, dict-of-lists, and
        # dict-of-strings shapes uniformly.
        for allele_raw in sorted(_flatten_hla_alleles(hla_alleles)):
            allele_norm = normalize_allele(allele_raw)
            if allele_norm and allele_norm != allele_raw:
                rows.append(
                    {
                        "pmid": pmid_int,
                        "study_label": study_label,
                        "allele_raw": allele_raw,
                        "allele_normalized": allele_norm,
                        "severity": "warn",
                    }
                )
    return pd.DataFrame(
        rows,
        columns=[
            "pmid",
            "study_label",
            "allele_raw",
            "allele_normalized",
            "severity",
        ],
    )


@dataset_snapshot()
def species_axis_audit() -> pd.DataFrame:
    """Audit the #46 multi-axis species columns for chimeric / suspicious rows.

    Loads the observations index with the load-time-derived axis columns
    (``host_organism``, ``source_species``, ``mhc_species``, ``is_chimeric``,
    ``is_engineered_mhc``, ``xenograft``), keeps the chimeric rows, and groups
    them by the (host, source, MHC) triple so each distinct cross-species
    system surfaces once with its row/PMID counts.

    A ``severity`` column flags combinations that warrant manual review or a
    per-PMID override:

    - ``review`` — host species is populated but the MHC genus differs from
      the host genus *and* the source genus also differs from the host
      (neither the engineered-MHC nor the native-MHC reading is obvious;
      e.g. a human-host row carrying a mouse MHC, often a data-entry error).
    - ``info`` — a recognized engineered-MHC system (host genus == source
      genus, MHC heterologous: HLA-transgenic rat, allogeneic transfectant).

    Returns
    -------
    pd.DataFrame
        Columns: ``host_organism``, ``source_species``, ``mhc_species``,
        ``is_engineered_mhc``, ``xenograft``, ``n_rows``, ``n_pmids``,
        ``example_pmids``, ``severity``. Empty if the index has no chimeric
        rows. Sorted by ``n_rows`` descending.
    """
    from .observations import load_observations

    cols = [
        "pmid",
        "host_organism",
        "source_species",
        "mhc_species",
        "is_chimeric",
        "is_engineered_mhc",
        "xenograft",
    ]
    df = load_observations(columns=cols)
    df = df[df["is_chimeric"]]
    out_columns = [
        "host_organism",
        "source_species",
        "mhc_species",
        "is_engineered_mhc",
        "xenograft",
        "n_rows",
        "n_pmids",
        "example_pmids",
        "severity",
    ]
    if df.empty:
        return pd.DataFrame(columns=out_columns)

    rows: list[dict] = []
    group_keys = [
        "host_organism",
        "source_species",
        "mhc_species",
        "is_engineered_mhc",
        "xenograft",
    ]
    # ``observed=True``: the group keys are categoricals off the parquet, and
    # the default walks their Cartesian product, inventing empty groups and
    # emitting a FutureWarning per call (#597).
    for key, grp in df.groupby(group_keys, dropna=False, observed=True):
        host_org, src_sp, mhc_sp, engineered, xeno = key
        pmids = sorted({int(p) for p in grp["pmid"].dropna().unique()})
        # ``review`` = chimeric with a populated host whose genus matches
        # neither a clean engineered-MHC nor a native-MHC reading.
        if host_org and not engineered and not xeno:
            severity = "review"
        else:
            severity = "info"
        rows.append(
            {
                "host_organism": host_org,
                "source_species": src_sp,
                "mhc_species": mhc_sp,
                "is_engineered_mhc": bool(engineered),
                "xenograft": bool(xeno),
                "n_rows": len(grp),
                "n_pmids": len(pmids),
                "example_pmids": ";".join(str(p) for p in pmids[:5]),
                "severity": severity,
            }
        )
    return (
        pd.DataFrame(rows, columns=out_columns)
        .sort_values("n_rows", ascending=False)
        .reset_index(drop=True)
    )


@dataset_snapshot()
def cross_reference(mhc_class: str | None = None) -> pd.DataFrame:
    """Find allele/data mismatches between curation YAML and observations.

    Three divergence directions:

    - **yaml_only**: an allele is listed in a YAML sample's ``mhc`` block
      but no observation row for that PMID has that ``mhc_restriction``.
      Likely a typo in curation, or genotype curated from the paper text
      but no measurements actually attributed to that allele.
    - **data_only**: a 4-digit allele appears as ``mhc_restriction`` for
      a PMID but no YAML sample for that PMID lists it.  Likely a curation
      gap (sample present in data but not yet added to YAML).
    - **needs_deconvolution**: PMID has YAML alleles but ZERO 4-digit
      observation rows (data is 100% class-only / serotype). Emitted as
      a single row per PMID rather than per-allele — the gap is
      structural (paper says class-I, IEDB lost the per-peptide allele)
      so listing every YAML allele under ``yaml_only`` would balloon
      the report with non-actionable rows. The discrepancies report's
      ``class_pool_n`` and ``monoallelic_class_only_n`` columns surface
      the same studies with row counts attached.

    Parameters
    ----------
    mhc_class
        Filter to ``"I"`` or ``"II"``.

    Returns
    -------
    pd.DataFrame
        Columns: ``pmid``, ``study_label``, ``allele``, ``direction``,
        ``severity``. ``direction`` is one of ``"yaml_only"``,
        ``"data_only"``, or ``"needs_deconvolution"``.
    """
    from .observations import is_built, load_observations

    if not is_built():
        raise FileNotFoundError(
            "observations.parquet has not been built. Run 'hitlist build observations' first."
        )

    obs = load_observations(
        mhc_class=mhc_class,
        columns=["pmid", "mhc_restriction", "allele_resolution"],
    )
    # Only 4-digit data alleles are comparable to curated YAML alleles.
    obs_4d = obs[obs["allele_resolution"] == "four_digit"]
    data_by_pmid: dict[int, set[str]] = (
        obs_4d.groupby("pmid")["mhc_restriction"]
        .apply(lambda s: set(s.dropna().astype(str)))
        .to_dict()
    )
    # PMIDs whose data exists but has zero 4-digit alleles (100% class-
    # only / serotype). Cached so we can route those into the
    # needs_deconvolution bucket rather than spamming yaml_only.
    pmids_with_any_data = set(obs["pmid"].dropna().astype(int).unique().tolist())
    pmids_with_4digit_data = {int(p) for p in data_by_pmid if pd.notna(p)}

    overrides = load_pmid_overrides()
    excluded = ms_excluded_pmids()
    rows: list[dict] = []
    for pmid_int, entry in sorted(overrides.items()):
        if pmid_int in excluded:
            # exclude_from_ms studies never reach ``obs`` (#444), so every
            # curated allele here would otherwise read as yaml_only — a
            # false gap, not a real one (#471).
            continue
        study_label = entry.get("study_label", "")
        # YAML-curated alleles for this PMID (sample-level + paper-level pool).
        yaml_alleles = _flatten_hla_alleles(entry.get("hla_alleles", {}))
        ms_samples = entry.get("ms_samples", []) or []
        for sample in ms_samples:
            yaml_alleles |= _flatten_hla_alleles(sample.get("mhc", []))

        data_alleles = data_by_pmid.get(pmid_int, set())

        # Special case: data exists for the PMID but it's 100% class-
        # only. Per-allele yaml_only rows aren't actionable here — emit
        # a single needs_deconvolution sentinel instead.
        if (
            yaml_alleles
            and not data_alleles
            and int(pmid_int) in pmids_with_any_data
            and int(pmid_int) not in pmids_with_4digit_data
        ):
            rows.append(
                {
                    "pmid": pmid_int,
                    "study_label": study_label,
                    "allele": f"({len(yaml_alleles)} YAML alleles)",
                    "direction": "needs_deconvolution",
                    "severity": "info",
                }
            )
            continue

        for allele in sorted(yaml_alleles - data_alleles):
            rows.append(
                {
                    "pmid": pmid_int,
                    "study_label": study_label,
                    "allele": allele,
                    "direction": "yaml_only",
                    "severity": "warn",
                }
            )
        for allele in sorted(data_alleles - yaml_alleles):
            rows.append(
                {
                    "pmid": pmid_int,
                    "study_label": study_label,
                    "allele": allele,
                    "direction": "data_only",
                    "severity": "info",
                }
            )

    return pd.DataFrame(
        rows,
        columns=["pmid", "study_label", "allele", "direction", "severity"],
    )


@dataset_snapshot()
def discrepancies(
    mhc_class: str | None = None,
    min_rows: int = 50,
    by: str = "pmid",
) -> pd.DataFrame:
    """Per-PMID (or per-sample) rate of biologically suspicious patterns.

    A scan over ``observations.parquet`` that surfaces curation issues
    visible from the data alone — without re-reading any papers. One
    output row per bucket, sorted by suspect-row score so a curator
    picks targets from the top.

    Detected patterns:

    - **suspect_class_label_n / _rate** — rows where the curated
      class disagrees with the peptide length. Equivalent to the
      ``mhc_class_label_suspect`` boolean flag (severity in
      {suspect, implausible}).
    - **borderline_class_label_n / implausible_class_label_n** —
      finer-grained breakdown of the same signal using
      ``mhc_class_label_severity``. Borderline = bulged class-I
      (13-14aa) or short class-II (8-10aa) — uncommon-but-real
      biology, often legitimate. Implausible = class-I ≥18aa or
      ≤7aa, class-II ≤4 or ≥45aa — almost always curation drift.
    - **length_p50 / _p99** — peptide length median + 99th percentile
      per bucket. Class I should have p50 ≈ 9 and a thin upper tail
      (p99 ≤ 12); class II should have p50 ≈ 14-15. Outliers on
      either tail are usually IEDB curation drift.
    - **monoallelic_class_only_n** — mono-allelic rows whose
      ``mhc_restriction`` is the class sentinel ("HLA class I/II")
      rather than a 4-digit allele. These are #45 candidates: the
      paper knows the allele, IEDB lost it.
    - **class_pool_n / _rate** — rows whose ``mhc_allele_provenance``
      came down the pmid_class_pool fallback (no per-peptide allele
      resolution, the #37 problem).
    - **nonstandard_aa_n** — peptides containing ``X`` / ``B`` /
      ``Z`` / ``U`` / ``O`` / ``*`` / lowercase / digits. Either
      ambiguous IDs from MS or upstream string corruption.

    Parameters
    ----------
    mhc_class
        Optional class filter.
    min_rows
        Drop buckets with fewer than this many rows — small buckets
        produce noisy length percentiles. Default 50.
    by
        Aggregation level. ``"pmid"`` (default) groups by
        (pmid, mhc_class) — one row per study/class. ``"sample"``
        groups by (pmid, mhc_class, cell_name) so a curator can spot
        per-sample issues like "the K562-A0201 transfectant has 30%
        suspect rows but K562-B0702 has 0%". Falls back to
        ``"(no cell_name)"`` for rows without a sample identifier.

    Returns
    -------
    pd.DataFrame
        One row per bucket. Sorted descending by
        ``suspect_class_label_n + monoallelic_class_only_n +
        nonstandard_aa_n`` — the rougher cuts, useful for picking a
        triage target.
    """
    import re

    from .observations import is_built, load_observations

    if by not in ("pmid", "sample"):
        raise ValueError(f"by must be 'pmid' or 'sample', got {by!r}")

    if not is_built():
        raise FileNotFoundError(
            "observations.parquet has not been built. Run 'hitlist build observations' first."
        )

    cols = [
        "pmid",
        "peptide",
        "mhc_class",
        "mhc_restriction",
        "is_monoallelic",
        "mhc_class_label_suspect",
        "mhc_class_label_severity",
    ]
    if by == "sample":
        cols.append("cell_name")
    # mhc_allele_provenance is only present in indexes built since #137
    # (v1.23.0); degrade gracefully on older parquets.
    try:
        sample = load_observations(columns=["mhc_allele_provenance"])
        if "mhc_allele_provenance" in sample.columns:
            cols.append("mhc_allele_provenance")
    except Exception:
        pass

    df = load_observations(mhc_class=mhc_class, columns=cols)
    output_cols = [
        "pmid",
        "study_label",
        "mhc_class",
    ]
    if by == "sample":
        output_cols.append("cell_name")
    output_cols.extend(
        [
            "n_rows",
            "suspect_class_label_n",
            "suspect_class_label_rate",
            "borderline_class_label_n",
            "implausible_class_label_n",
            "length_p50",
            "length_p99",
            "monoallelic_class_only_n",
            "class_pool_n",
            "class_pool_rate",
            "nonstandard_aa_n",
            "severity",
        ]
    )
    if df.empty:
        return pd.DataFrame(columns=output_cols)

    # Compute per-row diagnostics in one pass to avoid groupby overhead
    # on the 4.4M-row corpus.
    df = df.copy()
    df["_len"] = df["peptide"].str.len()
    nonstandard_re = re.compile(r"[^ACDEFGHIKLMNPQRSTVWY]")
    df["_nonstandard"] = df["peptide"].astype(str).str.contains(nonstandard_re)
    df["_class_only"] = fillna_scalar_safe(df["mhc_restriction"], "").str.startswith("HLA class")
    df["_mono_class_only"] = df["is_monoallelic"].fillna(False) & df["_class_only"]
    # Borderline (bulged class-I 13-14aa or short class-II 8-10aa) is
    # uncommon-but-real biology and doesn't fire the binary suspect
    # flag, but it's still worth a per-bucket count so curators can
    # spot studies dominated by borderline rows.
    if "mhc_class_label_severity" in df.columns:
        sev = df["mhc_class_label_severity"].fillna("ok")
        df["_borderline"] = sev == "borderline"
        df["_implausible"] = sev == "implausible"
    else:
        df["_borderline"] = False
        df["_implausible"] = False
    if "mhc_allele_provenance" in df.columns:
        df["_class_pool"] = df["mhc_allele_provenance"] == "pmid_class_pool"
    else:
        df["_class_pool"] = False

    if by == "sample":
        cell_names = fillna_scalar_safe(df["cell_name"], "(no cell_name)")
        df["cell_name"] = cell_names.mask(cell_names.eq(""), "(no cell_name)")
        group_keys = ["pmid", "mhc_class", "cell_name"]
    else:
        group_keys = ["pmid", "mhc_class"]

    # ``observed=True`` -- see the note in ``species_axis_audit`` (#597).
    grouped = df.groupby(group_keys, dropna=False, observed=True)
    out = grouped.agg(
        n_rows=("peptide", "size"),
        suspect_class_label_n=("mhc_class_label_suspect", "sum"),
        borderline_class_label_n=("_borderline", "sum"),
        implausible_class_label_n=("_implausible", "sum"),
        length_p50=("_len", lambda s: int(s.median()) if len(s) else 0),
        length_p99=("_len", lambda s: int(s.quantile(0.99)) if len(s) else 0),
        monoallelic_class_only_n=("_mono_class_only", "sum"),
        class_pool_n=("_class_pool", "sum"),
        nonstandard_aa_n=("_nonstandard", "sum"),
    ).reset_index()
    out = out[out["n_rows"] >= min_rows].copy()
    out["suspect_class_label_rate"] = out["suspect_class_label_n"] / out["n_rows"]
    out["class_pool_rate"] = out["class_pool_n"] / out["n_rows"]

    # Attach study labels from pmid_overrides.yaml.
    overrides = load_pmid_overrides()
    out["study_label"] = out["pmid"].map(
        lambda p: overrides.get(int(p), {}).get("study_label", "") if pd.notna(p) else ""
    )

    # Severity heuristic — pick the worst signal per row.
    def _severity(row) -> str:
        if (
            row["suspect_class_label_rate"] >= 0.05
            or row["monoallelic_class_only_n"] > 0
            or row["nonstandard_aa_n"] > 0
        ):
            return "warn"
        if row["class_pool_rate"] >= 0.5:
            return "info"
        return "info"

    out["severity"] = out.apply(_severity, axis=1)
    out["_score"] = (
        out["suspect_class_label_n"] + out["monoallelic_class_only_n"] + out["nonstandard_aa_n"]
    )
    out = out.sort_values(["_score", "n_rows"], ascending=[False, False], kind="stable").drop(
        columns=["_score"]
    )

    return out[output_cols].reset_index(drop=True)


@dataset_snapshot()
def run_all(mhc_class: str | None = None) -> dict[str, pd.DataFrame]:
    """Run every QC check and return a name → DataFrame mapping.

    The CLI ``hitlist qc`` (no subcommand) calls this and prints a summary
    table per check. ``curation_plan`` is intentionally absent — it's a
    pure rollup of the other checks, so including it would double-count
    every signal in the summary.
    """
    return {
        "resolution": resolution_histogram(mhc_class=mhc_class),
        "normalization": normalization_drift(),
        "mhc_tokens": mhc_token_audit(),
        "cross_reference": cross_reference(mhc_class=mhc_class),
        "discrepancies": discrepancies(mhc_class=mhc_class),
        "proteome_coverage": proteome_coverage(),
        "engineering_drift": engineering_drift_audit(),
    }


#: Numeric metric columns of the curation plan, in report order.
#:
#: Listed once.  Three consumers derive from it: the column list built
#: by :func:`_curation_plan_columns`, the numeric-fill loop, and the
#: int-cast loop.  They used to be four hand-maintained copies, so a new
#: metric had to be added in four places and missing one produced a
#: dropped column, an unfilled NaN, or a float truncated to int.
_CURATION_PLAN_METRIC_COLUMNS = (
    "n_rows",
    "suspect_class_label_n",
    "suspect_class_label_rate",
    "borderline_class_label_n",
    "implausible_class_label_n",
    "monoallelic_class_only_n",
    "class_pool_n",
    "nonstandard_aa_n",
    "yaml_only_alleles_n",
    "data_only_alleles_n",
    "normalization_drifts_n",
)

#: Metrics an older ``discrepancies`` frame may simply not have.  Every
#: other metric column is always produced, so "is it available?" is a
#: question only these two can answer.
_OPTIONAL_METRIC_COLUMNS = (
    "borderline_class_label_n",
    "implausible_class_label_n",
)

#: Metrics that are ratios, not counts.  Declared rather than inferred
#: from the column name: an int-cast driven by a ``_rate`` suffix would
#: silently truncate a future ``*_fraction`` / ``*_pct`` metric to zero.
_CURATION_PLAN_FLOAT_METRICS = frozenset({"suspect_class_label_rate"})


def _available_optional_metrics(source_columns) -> list[str]:
    """Which optional metric columns this run actually has.

    ``curation_plan`` asks this same question in three places — when
    building the aggregation, the empty-frame schema and the report
    column list — and used to answer it with a pair of booleans named
    ``has_borderline`` / ``has_implausible``, threaded through a
    string-keyed flag mapping.  Naming the question once removes the
    flags, the mapping and the possibility of a new optional metric
    silently inheriting another tier's answer.
    """
    present = set(source_columns)
    return [c for c in _OPTIONAL_METRIC_COLUMNS if c in present]


def _curation_plan_columns(available_optional: list[str]) -> list[str]:
    """Full curation-plan column list, in report order.

    ``curation_plan`` built this list four separate times — the
    empty-frame schema, the numeric-fill loop, the int-cast loop and the
    final output projection.  This helper serves the two that need the
    *full* list; the fill and cast loops iterate
    :data:`_CURATION_PLAN_METRIC_COLUMNS` directly.
    """
    included = set(available_optional)
    return [
        "pmid",
        "study_label",
        *(
            c
            for c in _CURATION_PLAN_METRIC_COLUMNS
            if c not in _OPTIONAL_METRIC_COLUMNS or c in included
        ),
        "priority_score",
        "severity",
    ]


@dataset_snapshot()
def curation_plan(
    mhc_class: str | None = None,
    min_rows: int = 50,
) -> pd.DataFrame:
    """Per-PMID curation roadmap — joins every other qc signal.

    Combines :func:`discrepancies`, :func:`cross_reference`, and
    :func:`normalization_drift` into one ranked table answering
    "which study should I curate next?". One row per PMID with
    columns:

    - ``study_label`` — friendly study name from
      ``pmid_overrides.yaml``.
    - ``n_rows`` — total observation rows in the corpus for this PMID
      (sum across class I/II buckets).
    - ``suspect_class_label_n`` / ``suspect_class_label_rate`` —
      summed across class buckets (#182). Counts rows whose
      ``mhc_class_label_severity`` is ``suspect`` or ``implausible``.
    - ``borderline_class_label_n`` / ``implausible_class_label_n`` —
      finer-grained breakdown of the same signal. Borderline (bulged
      class-I 13-14aa, short class-II 8-10aa) is uncommon-but-real
      biology and does NOT count toward suspect; implausible is
      almost always curation drift and DOES.
    - ``monoallelic_class_only_n`` — rows where the paper knows the
      allele but IEDB lost it (#45 candidates).
    - ``class_pool_n`` — rows that fell back to per-PMID class pool
      (#37 deconvolution candidates).
    - ``nonstandard_aa_n`` — peptides with X / B / Z / lowercase /
      digits.
    - ``yaml_only_alleles_n`` — alleles in YAML samples but not in
      data — likely curation typo or unmeasured allele.
    - ``data_only_alleles_n`` — 4-digit alleles in data but not in
      any YAML sample — gap in YAML curation.
    - ``normalization_drifts_n`` — alleles in YAML whose
      ``normalize_allele`` output differs from the curated string.
    - ``priority_score`` — sum of the action signals weighted by
      curator-time-cost; higher = more impactful to fix.
    - ``severity`` — propagated worst severity across all signals.

    Sort: descending by ``priority_score``. Use this to pick the
    next study to curate without bouncing between three reports.

    Parameters
    ----------
    mhc_class
        Optional class filter (passed through to ``discrepancies``
        and ``cross_reference``). YAML signals are class-agnostic.
    min_rows
        Drop PMID buckets with fewer than this many rows in the
        discrepancies pass — small buckets give noisy
        percentile-based metrics.
    """
    disc = discrepancies(mhc_class=mhc_class, min_rows=min_rows)
    xref = cross_reference(mhc_class=mhc_class)
    drift = normalization_drift()

    # ── Discrepancies: roll up across class I/II per PMID ────────────
    # A caller fixturing an older discrepancies DataFrame may not have
    # the severity-tier columns, so ask once which of them are here and
    # carry that answer through the three places that need it.
    available_optional = _available_optional_metrics(disc.columns)
    if not disc.empty:
        summed = [
            "n_rows",
            "suspect_class_label_n",
            "monoallelic_class_only_n",
            "class_pool_n",
            "nonstandard_aa_n",
            *available_optional,
        ]
        agg_kwargs: dict = {"study_label": ("study_label", "first")}
        agg_kwargs.update({col: (col, "sum") for col in summed})
        disc_pmid = disc.groupby("pmid", as_index=False).agg(**agg_kwargs).copy()
        disc_pmid["suspect_class_label_rate"] = disc_pmid["suspect_class_label_n"] / disc_pmid[
            "n_rows"
        ].clip(lower=1)
    else:
        disc_pmid = pd.DataFrame(
            columns=[
                "pmid",
                "study_label",
                "n_rows",
                "suspect_class_label_n",
                "monoallelic_class_only_n",
                "class_pool_n",
                "nonstandard_aa_n",
                "suspect_class_label_rate",
                *available_optional,
            ]
        )

    # ── Cross-reference: per-PMID counts of yaml_only / data_only ────
    if not xref.empty:
        xref_pmid = (
            xref.assign(
                _yaml_only=(xref["direction"] == "yaml_only").astype(int),
                _data_only=(xref["direction"] == "data_only").astype(int),
            )
            .groupby("pmid", as_index=False)
            .agg(
                yaml_only_alleles_n=("_yaml_only", "sum"),
                data_only_alleles_n=("_data_only", "sum"),
            )
        )
    else:
        xref_pmid = pd.DataFrame(columns=["pmid", "yaml_only_alleles_n", "data_only_alleles_n"])

    # ── Normalization drift: per-PMID drift count ────────────────────
    if not drift.empty:
        drift_pmid = (
            drift.groupby("pmid", as_index=False)
            .size()
            .rename(columns={"size": "normalization_drifts_n"})
        )
    else:
        drift_pmid = pd.DataFrame(columns=["pmid", "normalization_drifts_n"])

    # ── Outer-merge on pmid ──────────────────────────────────────────
    plan = disc_pmid.merge(xref_pmid, on="pmid", how="outer").merge(
        drift_pmid, on="pmid", how="outer"
    )
    if plan.empty:
        return pd.DataFrame(columns=_curation_plan_columns(available_optional))

    # Backfill study_label for PMIDs that came in via xref/drift only.
    overrides = load_pmid_overrides()
    needs_label = plan["study_label"].isna() | (plan["study_label"] == "")
    plan.loc[needs_label, "study_label"] = plan.loc[needs_label, "pmid"].map(
        lambda p: overrides.get(int(p), {}).get("study_label", "") if pd.notna(p) else ""
    )

    for c in _CURATION_PLAN_METRIC_COLUMNS:
        if c in plan.columns:
            # Avoid the pandas 3.0 FutureWarning about implicit
            # downcast-on-fillna by going through numeric coercion.
            plan[c] = pd.to_numeric(plan[c], errors="coerce").fillna(0)

    # Priority score — weights chosen so each signal contributes a
    # comparable share when present at typical scale (rows per study
    # are O(10-100K), allele divergences O(1-10), so multiplying allele
    # counts by a constant aligns them with rate-style row signals).
    plan["priority_score"] = (
        plan["suspect_class_label_n"]
        + plan["monoallelic_class_only_n"]
        + plan["nonstandard_aa_n"]
        + 1000 * plan["yaml_only_alleles_n"]
        + 100 * plan["data_only_alleles_n"]
        + 10000 * plan["normalization_drifts_n"]
    )

    def _severity(row) -> str:
        if (
            row["normalization_drifts_n"] > 0
            or row["yaml_only_alleles_n"] > 0
            or (row["suspect_class_label_rate"] >= 0.05 and row["suspect_class_label_n"] > 0)
            or row["monoallelic_class_only_n"] > 0
            or row["nonstandard_aa_n"] > 0
        ):
            return "warn"
        if row["data_only_alleles_n"] > 0 or row["class_pool_n"] > 0:
            return "info"
        return "info"

    plan["severity"] = plan.apply(_severity, axis=1)
    plan = plan.sort_values(["priority_score", "n_rows"], ascending=[False, False], kind="stable")

    # Cast counts to int (groupby + outer merge may have promoted them
    # to float64 via NaN fills).
    int_cols = [
        c
        for c in _curation_plan_columns(available_optional)
        if c in _CURATION_PLAN_METRIC_COLUMNS and c not in _CURATION_PLAN_FLOAT_METRICS
    ]
    for c in int_cols:
        if c in plan.columns:
            plan[c] = plan[c].astype(int)

    output_cols = _curation_plan_columns(available_optional)
    return plan[output_cols].reset_index(drop=True)


@dataset_snapshot()
def proteome_coverage(
    min_rows: int = 1,
    use_uniprot: bool = False,
) -> pd.DataFrame:
    """Per-source-organism proteome registry coverage.

    Buckets observation rows by ``source_organism`` and reports whether
    a reference proteome is registered in
    :data:`hitlist.downloads.SPECIES_PROTEOMES` /
    :data:`hitlist.downloads.VIRAL_PROTEOMES`. Surfaces the gap that
    blocks downstream features needing a per-organism proteome — flank
    extraction, gene-name lookup, source-protein audits — without
    actually fetching anything (#39).

    Parameters
    ----------
    min_rows
        Drop organisms with fewer than this many rows (default ``1``;
        the long-tail of singleton organisms is uninteresting for
        coverage decisions).
    use_uniprot
        Forwarded to :func:`hitlist.downloads.lookup_proteome`. When
        ``True``, the resolver will hit UniProt's REST endpoint for
        organisms not in the curated registry — slower but more
        permissive. Default ``False`` so this report is offline.

    Returns
    -------
    pd.DataFrame
        Sorted descending by ``n_rows``. Columns:

        - ``source_organism`` — IEDB / supplement organism string
        - ``n_rows`` — observation rows for that organism
        - ``n_pmids`` — distinct PMIDs in that bucket
        - ``has_proteome`` — ``True`` iff
          :func:`lookup_proteome` resolves it
        - ``proteome_kind`` — ``"ensembl"`` / ``"uniprot"`` / ``""``
        - ``proteome_id`` — UPID or Ensembl species name
        - ``severity`` — ``"warn"`` if no proteome and ``n_rows >= 100``
          (curation-priority cluster), ``"info"`` otherwise

    Examples
    --------
    >>> from hitlist.qc import proteome_coverage
    >>> df = proteome_coverage(min_rows=100)
    >>> df[~df.has_proteome].head()
    """
    from .downloads import lookup_proteome
    from .observations import is_built, load_observations

    if not is_built():
        raise FileNotFoundError(
            "observations.parquet has not been built. Run 'hitlist build observations' first."
        )

    df = load_observations(columns=["source_organism", "pmid"])
    if df.empty:
        return pd.DataFrame(
            columns=[
                "source_organism",
                "n_rows",
                "n_pmids",
                "has_proteome",
                "proteome_kind",
                "proteome_id",
                "severity",
            ]
        )

    df["source_organism"] = fillna_scalar_safe(df["source_organism"], "")
    # ``observed=True`` -- ``source_organism`` is categorical (#597).
    grouped = df.groupby("source_organism", as_index=False, observed=True).agg(
        n_rows=("source_organism", "size"),
        n_pmids=("pmid", "nunique"),
    )
    grouped = grouped[grouped["n_rows"] >= min_rows].copy()

    # Resolve each unique organism string once (lookup is @cache'd at
    # the species-name layer but the substring fallback is not, so
    # hoisting per-row to per-unique avoids re-scanning VIRAL_PROTEOMES
    # for every row).
    def _resolve(org: str) -> tuple[bool, str, str]:
        if not org:
            return (False, "", "")
        entry = lookup_proteome(org, use_uniprot=use_uniprot)
        if entry is None:
            return (False, "", "")
        kind = str(entry.get("kind", ""))
        if kind == "ensembl":
            pid = str(entry.get("species", ""))
        else:
            pid = str(entry.get("proteome_id", ""))
        return (True, kind, pid)

    # Iterate rather than ``Series.map``: ``source_organism`` is one of
    # ``builder._CATEGORICAL_BUILD_COLUMNS``, so ``load_observations`` hands it
    # over as a ``category``, and ``Categorical.map`` tries to build new
    # *categories* out of ``_resolve``'s tuples -- which raises
    # ``NotImplementedError: initializing a Series from a MultiIndex``. That
    # made ``qc.proteome_coverage()`` fail outright on the built corpus; the
    # tests missed it because the fixture wrote plain strings, a dtype
    # production never has (#597).
    resolved = [_resolve(organism) for organism in grouped["source_organism"]]
    grouped["has_proteome"] = [r[0] for r in resolved]
    grouped["proteome_kind"] = [r[1] for r in resolved]
    grouped["proteome_id"] = [r[2] for r in resolved]

    # Curation-priority severity: a missing-proteome organism with >=100
    # rows is a real gap; <100 rows is the long tail and not worth
    # registering one-at-a-time.
    grouped["severity"] = "info"
    warn_mask = (~grouped["has_proteome"]) & (grouped["n_rows"] >= 100)
    grouped.loc[warn_mask, "severity"] = "warn"

    grouped = grouped.sort_values(["n_rows", "source_organism"], ascending=[False, True])
    return grouped.reset_index(drop=True)
