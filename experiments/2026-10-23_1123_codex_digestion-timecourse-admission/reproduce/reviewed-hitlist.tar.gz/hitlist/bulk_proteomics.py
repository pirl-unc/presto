"""Bulk (non-MHC) proteomics detectability indices.

All data in this module is **shotgun / whole-cell MS**, not MHC-ligand
immunopeptidomics. It lives alongside ``observations.parquet`` (MS
elution) and ``binding.parquet`` (in-vitro binding) as a third,
strictly non-MHC table so downstream consumers can use it as a
detectability prior without ever conflating it with immunopeptidomics
data.

Data flow:

- **Source CSVs + metadata** ship inside the package under
  ``hitlist/data/bulk_proteomics/`` (always readable, no build needed).
- **``bulk_proteomics.parquet``** is written by
  :func:`hitlist.builder.build_bulk_proteomics` into the data directory as
  a long-form table with both protein- and peptide-level rows plus
  per-source acquisition metadata (instrument, digest, fragmentation,
  quantification, …) denormalized onto every row. The acquisition
  column names are harmonized with the per-sample schema used by
  ``observations.parquet`` so the same columns can be extracted from
  either index for joint MS-bias modeling.

Three loaders, each with its own granularity:

- ``load_bulk_proteomics`` — protein-level abundance per cell line.
  Union of CCLE (Nusinow et al. 2020, PMID 31978347; TMT-normalized)
  and Bekker-Jensen (PMID 28601559; label-free sum-of-intensities).
  Use the ``source=`` filter to pick one.

- ``load_bulk_peptides`` — peptide-level detection per cell line
  (Bekker-Jensen et al. 2017). Good for "within this protein, which
  tryptic peptides are ever observable by MS?" (the intra-protein
  detectability bias model).

- ``load_bulk_sources`` — per-source metadata (instrument, digest,
  fractionation, quantification method, cell lines covered). Consult
  before using intensity/abundance values across sources — CCLE is
  TMT-normalized, Bekker-Jensen is label-free; their numbers are not
  directly comparable.

Loaders prefer the built parquet (fast, with full acquisition metadata
columns) and fall back to the packaged CSVs when it has not been built.
"""

from __future__ import annotations

import warnings
from collections.abc import Iterable
from functools import lru_cache
from importlib.resources import files
from pathlib import Path

import pandas as pd
from pyarrow.lib import ArrowInvalid

from .curation_yaml import load_curation_yaml
from .dataset import dataset_path, dataset_snapshot

_DATA_MODULE = "hitlist.data.bulk_proteomics"


def bulk_proteomics_path() -> Path:
    """Path to the built ``bulk_proteomics.parquet`` in ``data_dir()``."""
    from .downloads import data_dir

    return dataset_path("bulk_proteomics.parquet", root=data_dir())


def is_bulk_proteomics_built() -> bool:
    """Check whether the bulk proteomics parquet has been built."""
    return bulk_proteomics_path().exists()


def _bulk_data_path(filename: str) -> str:
    """Resolve a bulk-proteomics CSV: the packaged copy if present (source /
    editable install), else fetch the externalized copy via datacache (#303)."""
    from .downloads import packaged_or_fetched

    return str(packaged_or_fetched(files(_DATA_MODULE) / filename, filename))


@lru_cache(maxsize=1)
def _load_ccle() -> pd.DataFrame:
    df = pd.read_csv(_bulk_data_path("ccle_nusinow_2020.csv.gz"), compression="gzip")
    df["source"] = "CCLE_Nusinow_2020"
    return df


@lru_cache(maxsize=1)
def _load_bj_protein() -> pd.DataFrame:
    return _curate_bj_metadata(
        pd.read_csv(
            _bulk_data_path("bekker_jensen_2017_protein_abundance.csv.gz"), compression="gzip"
        )
    )


@lru_cache(maxsize=1)
def _load_bj() -> pd.DataFrame:
    return _curate_bj_metadata(
        pd.read_csv(_bulk_data_path("bekker_jensen_2017_peptides.csv.gz"), compression="gzip")
    )


def _correct_bj_reference(df: pd.DataFrame) -> pd.DataFrame:
    """Correct the unrelated historical PMID while preserving its reported value."""
    if "source" not in df or "reference" not in df:
        return df
    selected = df["source"].eq("Bekker-Jensen_2017")
    if not selected.any():
        return df
    df = df.copy()
    if "reported_reference" not in df:
        df["reported_reference"] = df["reference"].astype("string")
    df["reference"] = df["reference"].astype("string")
    df.loc[selected, "reference"] = "PMID:28601559"
    if "pmid" in df:
        df["pmid"] = df["pmid"].astype("Int64")
        df.loc[selected, "pmid"] = 28601559
    return df


def _curate_bj_metadata(df: pd.DataFrame) -> pd.DataFrame:
    from .bulk_fractionation import curate_fractionation_ph

    return curate_fractionation_ph(_correct_bj_reference(df))


@lru_cache(maxsize=1)
def _load_sources_yaml() -> list[dict]:
    data = load_curation_yaml(files(_DATA_MODULE) / "sources.yaml")
    return data.get("sources", [])


def _source_defaults(source_id: str) -> dict:
    """Source-level metadata defaults for a given source_id.

    Used by the CSV-fallback path in :func:`load_bulk_proteomics` when
    ``hitlist build observations`` hasn't been run and the CSVs don't carry all
    the axes the parquet would have. Mirrors the stamping the builder
    does in :func:`hitlist.builder.build_bulk_proteomics`.
    """
    for s in _load_sources_yaml():
        if s.get("source_id") == source_id:
            return dict(s)
    return {}


@lru_cache(maxsize=2)
def _read_parquet_cached(path_str: str, mtime_ns: int, size: int) -> pd.DataFrame:
    """Read + memoize a parquet keyed on its file signature.

    Every ``load_bulk_peptides`` / ``load_bulk_proteomics`` call previously
    re-read the full ``bulk_proteomics.parquet`` from disk; a suite that
    calls the loaders dozens of times (and ``deploy.sh --all``) paid that
    I/O each time.  Keying on ``(path, mtime_ns, size)`` makes repeated
    reads within a process free while a rebuild (atomic temp+rename → fresh
    mtime) busts the cache automatically.  The public loaders all ``.copy()``
    the returned frame before filtering, so sharing the cached object is
    safe.
    """
    return _curate_bj_metadata(pd.read_parquet(path_str))


def _load_parquet_or_none() -> pd.DataFrame | None:
    """Return the built parquet if readable, else None.

    The packaged CSV/YAML sources are the canonical fallback, so a stale
    or truncated ``bulk_proteomics.parquet`` should not crash the public
    loaders. Warn and fall back instead.
    """
    p = bulk_proteomics_path()
    if not p.exists():
        return None
    try:
        st = p.stat()
        return _read_parquet_cached(str(p), st.st_mtime_ns, st.st_size)
    except (ArrowInvalid, OSError, ValueError) as exc:
        warnings.warn(
            f"Failed to read built bulk proteomics parquet at {p}; "
            f"falling back to packaged sources. {exc}",
            RuntimeWarning,
            stacklevel=2,
        )
        return None


def _apply_cell_line_filter(df: pd.DataFrame, cell_line) -> pd.DataFrame:
    if cell_line is None:
        return df
    if isinstance(cell_line, str):
        cell_line = [cell_line]
    wanted = {c.casefold() for c in cell_line}
    return df[df["cell_line_name"].str.casefold().isin(wanted)]


def _apply_gene_filter(df: pd.DataFrame, gene_name) -> pd.DataFrame:
    if gene_name is None:
        return df
    if isinstance(gene_name, str):
        gene_name = [gene_name]
    return df[df["gene_symbol"].isin(list(gene_name))]


def _apply_uniprot_filter(df: pd.DataFrame, uniprot_acc) -> pd.DataFrame:
    if uniprot_acc is None:
        return df
    if isinstance(uniprot_acc, str):
        uniprot_acc = [uniprot_acc]
    return df[df["uniprot_acc"].isin(list(uniprot_acc))]


def _apply_enzyme_filter(df: pd.DataFrame, digestion_enzyme) -> pd.DataFrame:
    if digestion_enzyme is None or "digestion_enzyme" not in df.columns:
        return df
    if isinstance(digestion_enzyme, str):
        digestion_enzyme = [digestion_enzyme]
    return df[df["digestion_enzyme"].isin(list(digestion_enzyme))]


def _apply_fractions_filter(df: pd.DataFrame, n_fractions_in_run) -> pd.DataFrame:
    if n_fractions_in_run is None or "n_fractions_in_run" not in df.columns:
        return df
    if isinstance(n_fractions_in_run, int):
        n_fractions_in_run = [n_fractions_in_run]
    return df[df["n_fractions_in_run"].isin(list(n_fractions_in_run))]


def _apply_ph_filter(df: pd.DataFrame, fractionation_ph) -> pd.DataFrame:
    if fractionation_ph is None or "fractionation_ph" not in df.columns:
        return df
    if isinstance(fractionation_ph, (int, float)):
        wanted = [float(fractionation_ph)]
    else:
        wanted = [float(v) for v in fractionation_ph]
    return df[df["fractionation_ph"].isin(wanted)]


def _apply_length_bounds(
    df: pd.DataFrame, length_min: int | None, length_max: int | None
) -> pd.DataFrame:
    """Filter peptide rows by inclusive [length_min, length_max] bounds.

    Silently passes through rows that lack a ``length`` column (protein
    rows — peptide-only axis). The ``length`` column is ``Int64`` nullable
    in the parquet; ``.between`` handles NA cleanly by excluding NaNs.
    """
    if length_min is None and length_max is None:
        return df
    if "length" not in df.columns:
        return df
    lo = length_min if length_min is not None else -1
    hi = length_max if length_max is not None else 10**9
    return df[df["length"].between(lo, hi)]


def _add_n_replicates_possible(df: pd.DataFrame) -> pd.DataFrame:
    """Project reviewed experiment totals and nullable per-peptide counts (#699)."""
    from .bulk_replicates import curate_replicate_counts

    return curate_replicate_counts(df)


def _apply_reproducibility_filter(
    df: pd.DataFrame, min_reproducibility: float | None
) -> pd.DataFrame:
    """Keep only qualified experiment fractions meeting a finite [0, 1] cutoff."""
    import math

    if min_reproducibility is None:
        return df
    if not math.isfinite(min_reproducibility) or not 0 <= min_reproducibility <= 1:
        raise ValueError("min_reproducibility must be finite and between 0 and 1")
    if "reproducibility_fraction" not in df:
        return df.iloc[:0]
    return df[df.reproducibility_fraction.ge(min_reproducibility).fillna(False)]


def _apply_percentile_bounds(
    df: pd.DataFrame,
    percentile_min: float | None,
    percentile_max: float | None,
) -> pd.DataFrame:
    """Filter protein rows by inclusive [percentile_min, percentile_max]."""
    if percentile_min is None and percentile_max is None:
        return df
    if "abundance_percentile" not in df.columns:
        return df
    lo = percentile_min if percentile_min is not None else 0.0
    hi = percentile_max if percentile_max is not None else 1.0
    col = df["abundance_percentile"]
    # Explicit notna guard — peptide-level rows carry NaN here and should
    # be excluded whenever a bound is provided (the question "top 10%
    # abundant" is only meaningful on protein rows).
    return df[col.between(lo, hi) & col.notna()]


# ``enrichment`` filter is slightly special: we accept a sentinel
# "__default__" string so the loader defaults can pass through "match
# only the non-enriched rows" semantics even when the caller explicitly
# passes ``enrichment=None`` to mean "don't filter" (both populations).
_ENRICHMENT_DEFAULT = "__default__"


def _apply_enrichment_filter(df: pd.DataFrame, enrichment) -> pd.DataFrame:
    if enrichment is None or "enrichment" not in df.columns:
        return df
    return df[df["enrichment"] == enrichment]


@dataset_snapshot()
def load_bulk_proteomics(
    cell_line: str | Iterable[str] | None = None,
    gene_name: str | Iterable[str] | None = None,
    source: str | None = None,
    digestion_enzyme: str | Iterable[str] | None = None,
    n_fractions_in_run: int | Iterable[int] | None = None,
    enrichment: str | None = _ENRICHMENT_DEFAULT,
    fractionation_ph: float | Iterable[float] | None = None,
    abundance_percentile_min: float | None = None,
    abundance_percentile_max: float | None = None,
) -> pd.DataFrame:
    """Protein-level bulk proteomics abundance (shotgun MS, NOT MHC ligands).

    Union of CCLE and Bekker-Jensen protein-level abundance. The two
    sources use different quantification schemes — CCLE is TMT log2-
    normalized relative to the CCLE panel median; Bekker-Jensen is
    label-free log2 sum-of-peptide-intensity. **Intensity values are
    not directly comparable across sources.** Use ``abundance_percentile``
    (rank within cell line) for cross-source comparisons, or filter to
    a single source with ``source=``. See ``load_bulk_sources()`` for
    full per-source metadata.

    Parameters
    ----------
    cell_line
        Filter to a single cell line (e.g. ``"MDA-MB-231"``) or iterable
        of cell lines. Matched case-insensitively.
    gene_name
        Filter to one or more HGNC gene symbols (exact match).
    source
        Restrict to one source (``"CCLE_Nusinow_2020"`` or
        ``"Bekker-Jensen_2017"``). ``None`` returns the union.
    digestion_enzyme
        Filter Bekker-Jensen rows to one or more digestion enzymes
        (exact match against ``digestion_enzyme`` column — canonical
        values: ``"Trypsin/P (cleaves K/R except before P)"``,
        ``"Chymotrypsin"``, ``"GluC"``, ``"LysC"``). CCLE rows are
        unaffected (all CCLE is tryptic).
    n_fractions_in_run
        Filter Bekker-Jensen rows to one or more fractionation depths
        (integer in ``{12, 14, 39, 46, 50, 70}`` — authoritative values
        discovered in PXD004452). CCLE rows are unaffected.
    enrichment
        Filter Bekker-Jensen rows by enrichment: ``"none"`` (baseline,
        default), ``"TiO2"`` (phosphopeptide enrichment), or ``None``
        for both. **Defaults to ``"none"``** so baseline detectability
        queries do not mix in phospho-biased TiO2 rows; callers opt
        into TiO2 explicitly. CCLE is not phospho-enriched so the
        filter is a no-op there.
    fractionation_ph
        Filter by reviewed fractionation pH, retaining its source basis.
        Bekker-Jensen ordinary 39/46/70-fraction arms use reported buffer
        pH 8; named phosphopeptide arms retain their label-derived 8/10
        values, and unresolved protocols are null. CCLE's separately
        sourced pH 10 is unchanged. A float or iterable excludes unknowns;
        ``None`` retains all rows. See ``fractionation_ph_basis/reference``
        and the preserved ``legacy_fractionation_ph`` annotations.
    abundance_percentile_min, abundance_percentile_max
        Inclusive bounds (0.0 to 1.0) on within-arm abundance rank. Useful
        for training-set construction: ``abundance_percentile_min=0.9``
        returns only the top decile most-abundant proteins for each
        (cell_line, enzyme, fractions, enrichment, pH) arm. Excludes
        rows with NaN percentile.

    Returns
    -------
    DataFrame with columns: evidence_kind, granularity, cell_line_name,
    gene_symbol, uniprot_acc, abundance_percentile (0-1 within arm for
    Bekker-Jensen; within cell_line for CCLE), acquisition metadata
    (instrument, fragmentation, labeling, ...), and bulk-specific prep
    fields (digestion, digestion_enzyme, fractionation, n_fractions,
    n_fractions_in_run, enrichment, ...). When the parquet is built,
    columns match :func:`hitlist.export.generate_ms_samples_table` for
    the acquisition fields so the same schema works across indexes.
    """
    # Resolve the enrichment default. "__default__" means "filter to
    # non-enriched rows" (the baseline detectability prior); explicit
    # None means "don't filter" (both populations).
    if enrichment == _ENRICHMENT_DEFAULT:
        enrichment = "none"

    parquet = _load_parquet_or_none()
    if parquet is not None:
        df = parquet[parquet["granularity"] == "protein"].copy()
    else:
        ccle = _load_ccle().copy()
        ccle["abundance_percentile"] = ccle.groupby("cell_line")["abundance_log2_normalized"].rank(
            pct=True
        )
        # CCLE CSV doesn't carry the Fig 1b row-level axes — stamp
        # fractionation_ph from the source-level default in sources.yaml
        # so the column is populated even on the CSV-fallback path
        # (no ``hitlist build observations`` required). Mirror the builder's
        # source-level stamping.
        ccle_src = _source_defaults("CCLE_Nusinow_2020")
        if "fractionation_ph" not in ccle.columns:
            ccle["fractionation_ph"] = ccle_src.get("fractionation_ph")
        bj = _load_bj_protein().copy()
        from .parquet_io import concat_non_empty

        # Same deprecation as the line-expression build: an empty or
        # all-NA frame must not drive result dtypes.  Either side can be
        # empty on the CSV-fallback path.
        df = concat_non_empty([ccle, bj], set(ccle.columns) | set(bj.columns))
        df = df.rename(columns={"cell_line": "cell_line_name"})

    if source is not None:
        df = df[df["source"] == source]
    df = _apply_cell_line_filter(df, cell_line)
    df = _apply_gene_filter(df, gene_name)
    df = _apply_enzyme_filter(df, digestion_enzyme)
    df = _apply_fractions_filter(df, n_fractions_in_run)
    df = _apply_ph_filter(df, fractionation_ph)
    df = _apply_percentile_bounds(df, abundance_percentile_min, abundance_percentile_max)
    # For CCLE rows, the `enrichment` column will not be set (or will
    # be empty/NA) — we only apply the enrichment filter to rows that
    # have a populated value, so CCLE passes through untouched.
    if enrichment is not None and "enrichment" in df.columns:
        has_enrich = df["enrichment"].notna() & (df["enrichment"] != "")
        keep_enrich = has_enrich & (df["enrichment"] == enrichment)
        keep_no_enrich = ~has_enrich
        df = df[keep_enrich | keep_no_enrich]
    return df.reset_index(drop=True)


def load_bulk_sources(*, include_canine=False) -> list[dict]:
    """Per-source metadata for the bulk proteomics indices.

    By default, returns a list of dicts with keys: ``source_id``, ``reference``,
    ``pmid``, ``study_label``, ``species``, ``title``, ``granularity``,
    ``digestion``, ``digestion_enzyme``, ``instrument``, ``fragmentation``,
    ``acquisition_mode``, ``labeling``, ``fractionation``, ``n_fractions``,
    ``quantification``, ``search_engine``, ``fdr``, ``cell_lines_covered``,
    ``note``.

    With ``include_canine=True``, append the source records from
    :func:`hitlist.canine_bulk.canine_bulk_catalog`. These use that catalog's
    versioned schema (``source_taxon``, ``study``, ``assets``, ``limitations``)
    rather than the legacy cell-line index schema. Missing protocol details
    and cell-line fields are not fabricated. Use their ``source_id`` with
    :func:`hitlist.canine_bulk.curate_canine_bulk` to obtain tissue/pool evidence.

    The acquisition fields (``instrument``, ``fragmentation``,
    ``acquisition_mode``, ``labeling``, ``search_engine``, ``fdr``) use
    the same names as the per-sample schema emitted by
    :func:`hitlist.export.generate_ms_samples_table` for joint MS-bias
    modeling across observations and bulk proteomics.

    Use when building detectability models — the digest enzyme determines
    which peptide bonds are cleavable (affects which theoretical peptides
    could have been observed), and the instrument/fractionation determine
    dynamic range and sensitivity limits.
    """
    sources = [dict(s) for s in _load_sources_yaml()]
    if include_canine:
        from .canine_bulk import canine_bulk_catalog

        sources.extend(
            {"source_id": key, **value} for key, value in canine_bulk_catalog()["sources"].items()
        )
    return sources


def load_bulk_evidence(directory, *, table="peptides", tissue=None, peptide=None, max_rows=250000):
    """Read a checked source bundle with tissue/pool scope and source-native units.

    See :func:`hitlist.canine_bulk.curate_canine_bulk`. Existing cell-line loaders
    retain their original defaults; this explicit source query never loads a
    human dataset or interprets bulk peptides as MHC ligands.
    """
    from .canine_bulk import load_bulk_evidence as read

    return read(directory, table=table, tissue=tissue, peptide=peptide, max_rows=max_rows)


def load_bulk_peptides(
    cell_line: str | Iterable[str] | None = None,
    gene_name: str | Iterable[str] | None = None,
    uniprot_acc: str | Iterable[str] | None = None,
    digestion_enzyme: str | Iterable[str] | None = None,
    n_fractions_in_run: int | Iterable[int] | None = None,
    enrichment: str | None = _ENRICHMENT_DEFAULT,
    fractionation_ph: float | Iterable[float] | None = None,
    length_min: int | None = None,
    length_max: int | None = None,
    min_reproducibility: float | None = None,
) -> pd.DataFrame:
    """Peptide-level bulk proteomics detections (shotgun MS, NOT MHC ligands).

    Identifies which peptides *within* a protein were ever observed by
    deep shotgun MS on a given cell line — the intra-protein
    detectability prior for MHC-ligandome analyses. Source: Bekker-Jensen
    et al. 2017 (PMID 28601559) across the full Figure 1b design
    matrix: HeLa across four enzymes (Trypsin/P + Chymotrypsin / GluC /
    LysC), four fractionation depths (14, 39, 46, 70), and ± TiO2
    phospho enrichment; plus the 46-fraction tryptic panel for A549,
    HCT116, HEK293, and MCF7. A peptide is included here if detected
    at non-zero intensity in any replicate of that arm.

    Every row carries four per-row axes: ``digestion_enzyme``,
    ``n_fractions_in_run``, ``enrichment``, and ``modifications``. The
    default call applies ``enrichment="none"`` so baseline detectability
    queries are not contaminated by phospho-biased TiO2 rows — pass
    ``enrichment="TiO2"`` (or ``enrichment=None`` to see both) to opt
    into the phospho arms.

    Parameters
    ----------
    cell_line
        Filter to one or more cell lines (case-insensitive match).
    gene_name
        Filter to one or more HGNC gene symbols (exact match).
    uniprot_acc
        Filter to one or more UniProt accessions (exact match).
    digestion_enzyme
        Filter to one or more canonical enzyme strings — e.g.
        ``"Trypsin/P (cleaves K/R except before P)"``, ``"Chymotrypsin"``,
        ``"GluC"``, ``"LysC"``. Non-tryptic arms are HeLa-only.
    n_fractions_in_run
        Filter to one or more fractionation depths (authoritative set
        discovered in PXD004452: ``{12, 14, 39, 46, 50, 70}`` — 14/39/46/
        70 are the Fig 1b tryptic sweep; 12 and 50 are the two TiO2
        phospho arms).
    enrichment
        ``"none"`` (baseline, the **default**), ``"TiO2"`` (phospho
        enrichment), or ``None`` to include both populations.
    fractionation_ph
        Filter by reviewed fractionation pH. Ordinary 39/46/70-fraction
        arms carry the paper's reported buffer pH 8; named 12-fraction
        phosphopeptide arms retain their label-derived 8/10 distinction.
        Reused 14-fraction and unresolved 50-fraction protocols are unknown.
        Numeric filters exclude unknowns; ``None`` retains them. Inspect
        ``fractionation_ph_basis`` and ``fractionation_ph_reference`` before
        comparing protocols. Original CSV annotations remain separately in
        ``legacy_fractionation_ph``.
    length_min, length_max
        Inclusive peptide length bounds. Typical usage:
        ``length_min=8, length_max=11`` for MHC-I-compatible peptides;
        ``length_min=7, length_max=30`` for the detectability-training
        input range. Leave unset for no length filter.
    min_reproducibility
        Keep peptides with a qualified detected-experiment fraction at least this
        value (finite, between 0 and 1). Totals come from the curated deposited
        experiment inventory, never the maximum observed detection count. The
        legacy ``n_replicates_*`` columns are compatibility names for experiment
        counts, not biological replicates. Pooled HeLa 46-fraction per-peptide
        counts and unsupported/invalid counts remain unknown and are excluded by
        every threshold, including zero. ``None`` preserves all observations.
        Inspect ``replicate_count_status``, ``replicate_experiment_ids``, source
        reference/hash and preserved ``reported_n_replicates_*`` fields. Separate
        ``n_acquisition_runs`` and unknown ``n_biological_replicates`` prevent
        interpreting fractions or experiments as independent biological samples.

    Returns
    -------
    DataFrame with columns:
        peptide, cell_line_name, uniprot_acc, gene_symbol, length,
        start_position, end_position, digestion_enzyme,
        n_fractions_in_run, enrichment, fractionation_ph, modifications,
        n_replicates_detected, n_replicates_possible, reproducibility_fraction,
        n_experiments_detected, n_experiments_possible, replicate_count_status, source,
        reference (plus acquisition metadata when the parquet is built).
    """
    if enrichment == _ENRICHMENT_DEFAULT:
        enrichment = "none"

    parquet = _load_parquet_or_none()
    if parquet is not None:
        df = parquet[parquet["granularity"] == "peptide"].copy()
    else:
        df = _load_bj().copy().rename(columns={"cell_line": "cell_line_name"})

    # Source-backed counts are independent of query filters. Reapplication to
    # a current parquet retains the original reported values and is idempotent.
    df = _add_n_replicates_possible(df)

    df = _apply_cell_line_filter(df, cell_line)
    df = _apply_gene_filter(df, gene_name)
    df = _apply_uniprot_filter(df, uniprot_acc)
    df = _apply_enzyme_filter(df, digestion_enzyme)
    df = _apply_fractions_filter(df, n_fractions_in_run)
    df = _apply_enrichment_filter(df, enrichment)
    df = _apply_ph_filter(df, fractionation_ph)
    df = _apply_length_bounds(df, length_min, length_max)
    df = _apply_reproducibility_filter(df, min_reproducibility)
    return df.reset_index(drop=True)


def available_cell_lines() -> list[str]:
    """Return the union of cell lines across all bulk proteomics indices."""
    protein = set(_load_ccle()["cell_line"].unique())
    peptide = set(_load_bj()["cell_line"].unique())
    return sorted(protein | peptide)


def available_protein_cell_lines() -> list[str]:
    """Cell lines covered by the protein-level index (load_bulk_proteomics)."""
    ccle = set(_load_ccle()["cell_line"].unique())
    bj = set(_load_bj_protein()["cell_line"].unique())
    return sorted(ccle | bj)


def available_peptide_cell_lines() -> list[str]:
    """Cell lines covered by the peptide-level index (load_bulk_peptides)."""
    return sorted(_load_bj()["cell_line"].unique().tolist())


def build_detectability_training_set(**kwargs):
    """Build search-scoped candidates; see :mod:`hitlist.detectability`."""
    from .detectability import build_detectability_training_set as build

    return build(**kwargs)


def iter_detectability_training_set(**kwargs):
    """Stream search-scoped candidate batches; see :mod:`hitlist.detectability`."""
    from .detectability import iter_detectability_training_set as iterate

    return iterate(**kwargs)


def export_detectability_training_set(output_dir, **kwargs):
    """Write a bounded Parquet dataset and provenance manifest atomically."""
    from .detectability import export_detectability_training_set as export

    return export(output_dir, **kwargs)
