# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Load supplementary peptide data from curated CSVs.

Some immunopeptidome studies deposit peptide-level data in PRIDE or
paper supplements that is not (or only partially) in IEDB.  This
module reads a YAML manifest that links each supplementary CSV to
its PMID (already curated in ``pmid_overrides.yaml``) and provides
IEDB-equivalent column defaults for source classification.

The output DataFrame matches the schema of :func:`hitlist.scanner.scan`
so it can be concatenated directly into the observations table.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .curation import (
    CLASS_ONLY_CANDIDATE_PROVENANCES,
    classify_ms_row,
    expand_allele_set,
    is_non_peptide_ligand,
    ms_excluded_pmids,
    normalize_species,
    pmid_mhc_species_context,
    resolve_mhc_annotation,
    restriction_evidence_for_row,
)
from .curation_yaml import load_curation_yaml

_DATA_DIR = Path(__file__).parent / "data"
_MANIFEST_PATH = _DATA_DIR / "supplementary.yaml"
_SUPP_DIR = _DATA_DIR / "supplementary"


def manifest_path() -> Path:
    """Return the path to the supplementary manifest YAML."""
    return _MANIFEST_PATH


def load_supplementary_manifest() -> list[dict]:
    """Load the supplementary data manifest.

    Returns
    -------
    list[dict]
        Each entry has ``pmid``, ``file``, ``study_label``, and ``defaults``.
        Returns an empty list if the manifest does not exist.

    Raises
    ------
    ValueError
        If a manifest entry's PMID is also curated ``exclude_from_ms: true``.
        Without this check the build silently drops those hand-vetted rows a
        few steps after ``scan_supplementary`` logs them as added, with no
        warning that the two curations disagree (#444, #471).
    """
    if not _MANIFEST_PATH.exists():
        return []
    entries = load_curation_yaml(_MANIFEST_PATH)
    entries = entries if entries else []
    _validate_ms_entries(entries)
    return entries


def _validate_ms_entries(entries):
    """Apply the same scientific admission check to every input manifest."""
    excluded = ms_excluded_pmids()
    conflicts = sorted({int(e["pmid"]) for e in entries if int(e["pmid"]) in excluded})
    if conflicts:
        raise ValueError(
            f"supplementary.yaml curates hand-vetted MS rows for PMID(s) {conflicts}, "
            f"but pmid_overrides.yaml also marks them exclude_from_ms: true.  These "
            f"disagree about whether the study is an MS elution experiment: either "
            f"remove exclude_from_ms (the supplementary rows are real elution data) "
            f"or remove the supplementary entry (the study genuinely isn't one)."
        )


def scan_supplementary(
    classify_source: bool = True,
    *,
    provenance=None,
    entries=None,
    directory=None,
    allow_download=True,
) -> pd.DataFrame:
    """Load all supplementary CSVs and return a scanner-compatible DataFrame.

    For each entry in the manifest, reads the CSV, fills missing columns
    from the entry's ``defaults`` dict, and runs :func:`classify_ms_row`
    for source classification.

    Parameters
    ----------
    classify_source
        Run source classification (default True).  When False, only
        allele resolution and species are computed.
    entries, directory
        Explicitly reviewed MS manifest entries and their local CSV directory.
        These retain the same curation checks and contributor graph as packaged
        sources. Optional ``sha256`` and ``size_bytes`` pin each input file.
        Explicit entries never fall back to the global download registry.
    allow_download
        False fails on missing files without accessing the network. The default
        preserves on-demand acquisition for the packaged manifest only.

    Returns
    -------
    pd.DataFrame
        Same column schema as :func:`hitlist.scanner.scan` output.
        Empty DataFrame if no supplementary data is configured.
    """
    explicit_entries = entries is not None
    entries = list(entries) if explicit_entries else load_supplementary_manifest()
    _validate_ms_entries(entries)
    supplement_directory = _SUPP_DIR if directory is None else Path(directory)
    if not entries:
        return pd.DataFrame()

    per_entry_frames: list[pd.DataFrame] = []

    for entry in entries:
        pmid = entry["pmid"]
        if explicit_entries and (
            not isinstance(entry["file"], str)
            or not entry["file"]
            or Path(entry["file"]).name != entry["file"]
            or entry["file"] in {".", ".."}
        ):
            raise ValueError("Explicit supplementary filename must be one local component")
        csv_path = supplement_directory / entry["file"]
        defaults = entry.get("defaults", {})

        if not csv_path.exists():
            if explicit_entries or not allow_download:
                raise FileNotFoundError(csv_path)
            # Large supplementary CSVs are externalized from the wheel (#303);
            # fetch them on demand via datacache. Files that are neither packaged
            # nor externalized are genuinely absent — skip as before.
            from .downloads import EXTERNAL_DATA_ASSETS, fetch_data_asset

            if entry["file"] in EXTERNAL_DATA_ASSETS:
                csv_path = fetch_data_asset(entry["file"])
            else:
                continue

        expected = {key: entry[key] for key in ("sha256", "size_bytes") if key in entry}
        if expected:
            from .provenance import file_digest

            before = file_digest(csv_path)
            if any(before[key] != value for key, value in expected.items()):
                raise ValueError(f"Supplementary checksum/size mismatch: {csv_path.name}")
        df = pd.read_csv(csv_path, dtype=str).fillna("")
        if expected:
            after = file_digest(csv_path)
            if after != before:
                raise ValueError(
                    f"Supplementary checksum/size changed during read: {csv_path.name}"
                )
        if "peptide" not in df.columns:
            if explicit_entries:
                raise ValueError(f"Supplementary file lacks peptide column: {csv_path.name}")
            continue

        if provenance is not None:
            dataset = f"supplement:{entry['file']}"
            provenance.register_source(dataset, csv_path, description=entry.get("source", ""))
            observation_ids = []
            for row_number, values in enumerate(df.itertuples(index=False, name=None), 1):
                fields = dict(zip(df.columns, values))
                fields["manifest"] = entry
                source_id = provenance.record(dataset, row_number, fields, list(values))
                label = fields.get(
                    "attributed_sample_label", defaults.get("attributed_sample_label", "")
                )
                observation_ids.append(provenance.observe(source_id, sample_label=label))
            df["provenance_id"] = observation_ids

        df["peptide"] = df["peptide"].str.strip()
        df = df[df["peptide"] != ""]
        if df.empty:
            continue

        if "mhc_restriction" in df.columns:
            df["mhc_restriction"] = df["mhc_restriction"].str.strip()
        else:
            df["mhc_restriction"] = ""
        if "mhc_class" in df.columns:
            df["mhc_class"] = df["mhc_class"].str.strip()
        else:
            df["mhc_class"] = ""

        if "is_potential_contaminant" in df.columns:
            df["is_potential_contaminant"] = (
                df["is_potential_contaminant"]
                .astype(str)
                .str.strip()
                .str.lower()
                .isin({"true", "1", "yes"})
            )
        else:
            df["is_potential_contaminant"] = False

        process_type = defaults.get("process_type", "")
        disease = defaults.get("disease", "")
        culture_condition = defaults.get("culture_condition", "")
        source_tissue = defaults.get("source_tissue", "")
        cell_name = defaults.get("cell_name", "")
        # source_organism / species are curated PER PAPER in each entry's
        # ``defaults`` — never assumed.  A blank here surfaces as "unresolved
        # source organism" downstream (the pmhc warning) and is excluded by the
        # source_species filter (#46), which is the correct, loud behavior for a
        # genuinely uncurated entry rather than a silent species assumption.
        source_organism = defaults.get("source_organism", "")
        species_default = defaults.get("species", "")
        mhc_species_context = pmid_mhc_species_context(pmid) or normalize_species(species_default)

        # A supplement repeats a small set of MHC inputs across hundreds of
        # thousands of peptides. Resolve each input once within this entry;
        # reported class is part of the key so conflicts remain row-specific.
        identity_by_input = {
            (restriction, reported_class): resolve_mhc_annotation(
                restriction, reported_class, mhc_species_context
            ).as_record_fields()
            for restriction, reported_class in df[["mhc_restriction", "mhc_class"]]
            .drop_duplicates()
            .itertuples(index=False, name=None)
        }
        identity = pd.DataFrame(
            identity_by_input[key] for key in zip(df["mhc_restriction"], df["mhc_class"])
        )

        # Include the supplementary filename in the synthesized IRI so the
        # same peptide / allele seen in, e.g. ``gomez_zepeda_2024_jy.csv`` and
        # ``gomez_zepeda_2024_raji.csv`` yields distinct row identifiers
        # and doesn't get collapsed by the ``drop_duplicates`` below (issue
        # #147).  The filename doubles as a per-sample provenance column.
        supp_file = entry["file"]
        synth_iri = (
            "supplement:"
            + str(pmid)
            + ":"
            + supp_file
            + ":"
            + df["peptide"]
            + ":"
            + df["mhc_restriction"]
        ).to_numpy()
        record = pd.DataFrame(
            {
                "peptide": df["peptide"].to_numpy(),
                **{column: identity[column].to_numpy() for column in identity.columns},
                # Supplementary rows don't carry an IEDB assay IRI, but the
                # synthesized string is already row-unique within a PMID + file,
                # so reuse it as ``assay_iri`` too.  Downstream exports can then
                # treat ``assay_iri`` as the stable evidence-row identifier
                # (issue #146) without branching on source.
                "assay_iri": synth_iri,
                "reference_iri": synth_iri,
                "supplementary_file": supp_file,
                "pmid": pmid,
                "submission_id": "",
                "reference_title": entry.get("study_label", ""),
                "source_organism": source_organism,
                "species": species_default,
                "host": defaults.get("host", ""),
                "host_age": "",
                # Supplementary rows don't carry IEDB's per-row "Host | MHC
                # Types Present"; set expansion will fall back to the
                # per-PMID curated allele pool when the row's
                # mhc_restriction is class-only (issue #137).
                "host_mhc_types": "",
                "process_type": process_type,
                "disease": disease,
                "disease_stage": "",
                "source_tissue": source_tissue,
                "cell_name": cell_name,
                "culture_condition": culture_condition,
                "antigen_processing_comments": "",
                "assay_comments": "",
                "qualitative_measurement": "",
                # Supplementary rows are MS-only (is_binding_assay=False)
                # and don't carry quantitative-binding-assay values, but
                # the columns are kept so observations.parquet stays
                # schema-compatible with scanner output (issue #148, #135).
                "assay_method": "",
                "response_measured": "",
                "measurement_units": "",
                "measurement_inequality": "",
                "quantitative_measurement": "",
                "quantitative_value": float("nan"),
                "is_binding_assay": False,
                "is_ms_observation": True,
                "assay_modality": "ms",
                "assay_modality_source": "curated_ms_supplement",
                "ms_outcome_status": "curated_ligand_table",
                "is_non_peptide_ligand": [
                    is_non_peptide_ligand(a) for a in df["mhc_restriction"].to_numpy()
                ],
                "is_potential_contaminant": df["is_potential_contaminant"].to_numpy(),
            }
        )

        # Classify per-unique-allele, then map back onto every row.
        if provenance is not None:
            record["provenance_id"] = df["provenance_id"].to_numpy()
        if "attributed_sample_label" in defaults:
            record["attributed_sample_label"] = defaults["attributed_sample_label"]
        if "attributed_sample_label" in df.columns:
            record["attributed_sample_label"] = df["attributed_sample_label"].to_numpy()

        # Within a single supplementary entry the non-allele inputs are
        # constant (from manifest defaults), so classify_ms_row varies
        # only by mhc_restriction.  Set expansion (issue #137) is also
        # per-allele since host_mhc_types is empty for supplements and
        # pmid + mhc_class don't vary within an entry.
        unique_alleles = record["mhc_restriction"].unique()

        def _set_for(
            allele: str, _record=record, _pmid=pmid, _mhc_species_context=mhc_species_context
        ) -> dict:
            mhc_class_filter = ""
            # Pull per-allele class from the just-built ``record`` if the
            # supplement CSV carries one; otherwise let set expansion
            # skip the class filter (returns the unfiltered candidate
            # set, which is fine because supplements rarely mix class I
            # and class II in one entry).
            if "mhc_class" in _record.columns:
                cls_match = _record.loc[_record["mhc_restriction"] == allele, "mhc_class"]
                if len(cls_match):
                    mhc_class_filter = str(cls_match.iloc[0])
            allele_set, prov, size = expand_allele_set(
                allele, "", _pmid, mhc_class_filter, species_context=_mhc_species_context
            )
            return {
                "mhc_allele_set": allele_set,
                "mhc_allele_provenance": prov,
                "mhc_allele_set_size": size,
            }

        def _classification_for(
            allele: str,
            _process_type=process_type,
            _disease=disease,
            _culture_condition=culture_condition,
            _source_tissue=source_tissue,
            _cell_name=cell_name,
            _pmid=pmid,
            _mhc_species_context=mhc_species_context,
        ) -> dict:
            classification = dict(
                classify_ms_row(
                    _process_type,
                    _disease,
                    _culture_condition,
                    _source_tissue,
                    _cell_name,
                    _pmid,
                    mhc_restriction=allele,
                    mhc_species_context=_mhc_species_context,
                )
            )
            # Identity is owned by resolve_mhc_annotation above; avoid a
            # duplicate merge column from classify_ms_row's compatibility API.
            for identity_column in ("mhc_species", "allele_resolution", "serotype", "serotypes"):
                classification.pop(identity_column, None)
            classification["restriction_evidence"] = restriction_evidence_for_row(
                allele,
                pmid=_pmid,
                is_monoallelic=bool(classification.get("is_monoallelic", False)),
                process_type=_process_type,
                disease=_disease,
                culture_condition=_culture_condition,
                source_tissue=_source_tissue,
                cell_name=_cell_name,
            )
            return classification

        if classify_source:
            flag_rows = [
                {
                    "mhc_restriction": a,
                    **_classification_for(a),
                    **_set_for(a),
                }
                for a in unique_alleles
            ]
        else:
            flag_rows = [
                {
                    "mhc_restriction": a,
                    "restriction_evidence": restriction_evidence_for_row(a, pmid=pmid),
                    **_set_for(a),
                }
                for a in unique_alleles
            ]
        flags = pd.DataFrame(flag_rows)
        record = record.merge(flags, on="mhc_restriction", how="left")

        # Promote set → mhc_restriction (#45) for class-only supplement
        # rows where PMID-pool expansion produced a tightened set.  When
        # Retain historical class-only promotion, as in scanner.py. Gene/locus
        # candidates never replace the reported restriction or its precision.
        if "mhc_allele_set" in record.columns and "mhc_allele_provenance" in record.columns:
            promote_mask = (
                (record["mhc_allele_set_size"].fillna(0) > 0)
                & record["mhc_allele_provenance"].isin(CLASS_ONLY_CANDIDATE_PROVENANCES)
                & record["mhc_allele_set"].notna()
                & (record["mhc_allele_set"] != "")
            )
            if promote_mask.any():
                record.loc[promote_mask, "mhc_restriction"] = record.loc[
                    promote_mask, "mhc_allele_set"
                ]
                promoted = [
                    resolve_mhc_annotation(
                        row["mhc_restriction"],
                        row["mhc_class_reported"],
                        mhc_species_context,
                    )
                    for _, row in record.loc[promote_mask].iterrows()
                ]
                promoted_identity = pd.DataFrame(
                    [annotation.as_record_fields() for annotation in promoted],
                    index=record.index[promote_mask],
                )
                for column in promoted_identity.columns:
                    record.loc[promote_mask, column] = promoted_identity[column]

        # Fallback: derive mhc_species from host when allele-based
        # classification is empty (e.g. supplementary peptides without
        # per-peptide allele assignments).
        host_species = normalize_species(defaults.get("host", ""))
        if "mhc_species" in record.columns:
            # Cast to ``StringDtype`` before fillna/replace — ``mhc_species``
            # may be a post-#137 categorical whose category set excludes
            # ``""`` and ``host_species``, in which case the in-place
            # assignment would raise ``TypeError``.  StringDtype accepts
            # any string fill.
            record["mhc_species"] = record["mhc_species"].astype("string").fillna("")
            host_fallback = (record["mhc_species"] == "") & bool(host_species)
            record.loc[host_fallback, "mhc_species"] = host_species
            record.loc[host_fallback, "mhc_species_source"] = "host_fallback"
        else:
            record["mhc_species"] = host_species

        per_entry_frames.append(record)

    if not per_entry_frames:
        return pd.DataFrame()

    result = pd.concat(per_entry_frames, ignore_index=True)

    # Deduplicate within supplementary data.  Before #147 the key was
    # ``(peptide, mhc_restriction, pmid)`` which collapsed the same
    # peptide / allele seen in multiple sample CSVs from a single paper
    # (e.g. a peptide presented by both JY and Raji in Gomez-Zepeda 2024)
    # onto one arbitrary sample context.  Including ``supplementary_file``
    # preserves per-sample evidence while still de-duplicating within one
    # CSV — file-level duplicates still collapse correctly.
    dedupe_cols = ["peptide", "mhc_restriction", "pmid"]
    if "supplementary_file" in result.columns:
        dedupe_cols.append("supplementary_file")
    if "attributed_sample_label" in result.columns:
        # One explicit CSV may contain observations from several named arms.
        # Their identical peptide/restriction pairs are distinct observations.
        dedupe_cols.append("attributed_sample_label")
    if provenance is not None:
        provenance.retain_duplicates(
            result, pd.MultiIndex.from_frame(result[dedupe_cols]), "within_file_overlap"
        )
    result = result.drop_duplicates(subset=dedupe_cols)

    return result
