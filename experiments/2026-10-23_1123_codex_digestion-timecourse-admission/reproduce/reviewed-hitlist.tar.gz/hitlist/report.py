# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Automated data quality reports for IEDB/CEDAR mass spec evidence.

Generates comprehensive summaries of MHC class distribution, source
classification, tissue coverage, disease breakdown, allele coverage,
peptide counts, and cell line annotations from registered datasets.

CLI::

    hitlist report                     # report on all registered MS data
    hitlist report --class I           # class I only
    hitlist report --output report.txt # save to file
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

from .pandas_utils import fillna_scalar_safe


def generate_report(
    df: pd.DataFrame,
    mhc_class_filter: str | None = None,
    output: str | Path | None = None,
) -> str:
    """Generate a data quality report from a scanned DataFrame.

    Parameters
    ----------
    df
        DataFrame from :func:`hitlist.scanner.scan` with ``classify_source=True``.
    mhc_class_filter
        If set, report only on this MHC class (``"I"`` or ``"II"``).
    output
        If set, write report to this file path.

    Returns
    -------
    str
        The report text.
    """
    lines: list[str] = []

    def p(text: str = "") -> None:
        lines.append(text)

    def table(header: str, rows: list[tuple], col_widths: tuple = (35, 10, 8)) -> None:
        p(header)
        for row in rows:
            parts = []
            for i, val in enumerate(row):
                w = col_widths[i] if i < len(col_widths) else 10
                if isinstance(val, int):
                    parts.append(f"{val:>{w},}")
                elif isinstance(val, float):
                    parts.append(f"{val:>{w}.1f}%")
                elif isinstance(val, str):
                    parts.append(f"{val:<{w}}")
                else:
                    parts.append(f"{val!s:<{w}}")
            p("  " + "  ".join(parts))
        p()

    total = len(df)
    if total == 0:
        p("No data to report.")
        text = "\n".join(lines)
        if output:
            Path(output).write_text(text)
        return text

    p("=" * 72)
    p("HITLIST DATA QUALITY REPORT")
    p("=" * 72)
    p()

    # ── MHC class distribution ──────────────────────────────────────────
    p("── MHC Class Distribution ──")
    p()
    class_counts = df["mhc_class"].value_counts()
    table(
        f"  {'Class':<20} {'Rows':>12} {'Pct':>8}",
        [(cls, count, count / total * 100) for cls, count in class_counts.items()],
        (20, 12, 8),
    )

    # Apply class filter if requested
    if mhc_class_filter:
        df = df[df["mhc_class"] == mhc_class_filter]
        total = len(df)
        p(f"  [Filtered to class {mhc_class_filter}: {total:,} rows]")
        p()

    # ── Source classification ───────────────────────────────────────────
    p("── Source Classification ──")
    p()
    src_flags = [
        ("src_cancer", "Cancer (tumor + non-EBV cell lines)"),
        ("src_adjacent_to_tumor", "Tumor-adjacent normal tissue"),
        ("src_activated_apc", "Activated APCs (DC/macrophage artifact)"),
        ("src_healthy_tissue", "Healthy somatic tissue (SAFETY SIGNAL)"),
        ("src_healthy_thymus", "Healthy thymus (expected for CTAs)"),
        ("src_healthy_reproductive", "Healthy reproductive, privileged (expected for CTAs)"),
        ("src_healthy_reproductive_female", "Healthy female-reproductive (sex-stratified)"),
        ("src_healthy_reproductive_male", "Healthy male-reproductive (sex-stratified)"),
        ("src_cell_line", "Any cell line (incl. EBV-LCL)"),
        ("src_ebv_lcl", "EBV-transformed B-LCL"),
        ("src_ex_vivo", "Direct ex vivo"),
    ]
    for flag, label in src_flags:
        if flag in df.columns:
            count = int(df[flag].sum())
            p(f"  {label:<50s} {count:>10,} ({count / total * 100:.1f}%)")
    p()

    # ── Unique peptides ─────────────────────────────────────────────────
    p("── Unique Peptides ──")
    p()
    p(f"  Total unique peptides:        {df['peptide'].nunique():>10,}")
    if "src_cancer" in df.columns:
        cancer_peps = set(df[df["src_cancer"]]["peptide"])
        healthy_peps = set(df[df.get("src_healthy_tissue", False) == True]["peptide"])  # noqa: E712
        p(f"  Cancer peptides:              {len(cancer_peps):>10,}")
        p(f"  Healthy somatic peptides:     {len(healthy_peps):>10,}")
        overlap = cancer_peps & healthy_peps
        p(f"  Overlap (cancer AND healthy): {len(overlap):>10,}")
        cancer_only = cancer_peps - healthy_peps
        p(f"  Cancer-specific (no healthy): {len(cancer_only):>10,}")
    p()

    # ── Tissue coverage (healthy) ───────────────────────────────────────
    if "src_healthy_tissue" in df.columns:
        healthy = df[df["src_healthy_tissue"]]
        if len(healthy) > 0:
            p("── Healthy Tissue Coverage ──")
            p()
            tissue_counts = healthy["source_tissue"].value_counts().head(25)
            p(f"  {healthy['source_tissue'].nunique()} tissues represented")
            p()
            for tissue, count in tissue_counts.items():
                peps = healthy[healthy["source_tissue"] == tissue]["peptide"].nunique()
                p(f"  {tissue:<30s} {count:>8,} rows  {peps:>8,} peptides")
            p()

    # ── Cancer disease breakdown ────────────────────────────────────────
    if "src_cancer" in df.columns:
        cancer = df[df["src_cancer"]]
        if len(cancer) > 0:
            p("── Cancer Disease Breakdown ──")
            p()
            nonempty = cancer[fillna_scalar_safe(cancer["disease"], "").str.strip() != ""]
            p(
                f"  Rows with disease annotation: {len(nonempty):,} / {len(cancer):,} "
                f"({len(nonempty) / len(cancer) * 100:.1f}%)"
            )
            p(f"  Unique diseases: {cancer['disease'].nunique()}")
            p()

            # Filter out "healthy" (mislabeled cell lines) and empty
            real_diseases = cancer[
                ~cancer["disease"].isin(["", "healthy"]) & cancer["disease"].notna()
            ]
            if len(real_diseases) > 0:
                disease_counts = real_diseases["disease"].value_counts().head(15)
                p("  Top cancer types (excluding cell line 'healthy' label):")
                for disease, count in disease_counts.items():
                    p(f"    {disease:<35s} {count:>8,} ({count / len(real_diseases) * 100:.1f}%)")
                p()

    # ── HLA allele coverage ─────────────────────────────────────────────
    p("── HLA Allele Coverage ──")
    p()
    allele_counts = df["mhc_restriction"].value_counts()
    p(f"  Unique alleles: {len(allele_counts)}")
    p()
    for allele, count in allele_counts.head(20).items():
        peps = df[df["mhc_restriction"] == allele]["peptide"].nunique()
        p(f"  {allele:<25s} {count:>8,} rows  {peps:>8,} peptides")
    p()

    # ── Cell line inventory ─────────────────────────────────────────────
    if "cell_line_name" in df.columns:
        cl_data = df[fillna_scalar_safe(df["cell_line_name"], "").str.strip() != ""]
        if len(cl_data) > 0:
            p("── Cell Line Inventory ──")
            p()
            cl_counts = cl_data["cell_line_name"].value_counts().head(20)
            p(f"  Named cell lines: {cl_data['cell_line_name'].nunique()}")
            p()
            for cl, count in cl_counts.items():
                peps = cl_data[cl_data["cell_line_name"] == cl]["peptide"].nunique()
                p(f"  {cl:<35s} {count:>8,} rows  {peps:>8,} peptides")
            p()

    # ── Mono-allelic evidence ─────────────────────────────────────────
    if "is_monoallelic" in df.columns:
        mono = df[df["is_monoallelic"]]
        if len(mono) > 0:
            p("── Mono-allelic Evidence ──")
            p()
            p(f"  Mono-allelic rows:            {len(mono):>10,} ({len(mono) / total * 100:.1f}%)")
            p(f"  Unique peptides (mono):       {mono['peptide'].nunique():>10,}")
            p(f"  Unique alleles (mono):        {mono['mhc_restriction'].nunique():>10,}")
            p()
            if "monoallelic_host" in df.columns:
                host_counts = mono["monoallelic_host"].value_counts()
                p("  Host cell lines:")
                for host, count in host_counts.items():
                    peps = mono[mono["monoallelic_host"] == host]["peptide"].nunique()
                    p(f"    {host:<25s} {count:>8,} rows  {peps:>8,} peptides")
                p()
            mono_alleles = mono["mhc_restriction"].value_counts().head(15)
            p("  Top alleles with mono-allelic evidence:")
            for allele, count in mono_alleles.items():
                peps = mono[mono["mhc_restriction"] == allele]["peptide"].nunique()
                p(f"    {allele:<25s} {count:>8,} rows  {peps:>8,} peptides")
            p()

    # ── Per-PMID study summary ──────────────────────────────────────────
    if "pmid" in df.columns:
        p("── Top Studies by Row Count ──")
        p()
        pmid_counts = (
            df.groupby("pmid")
            .agg(
                rows=("peptide", "size"),
                peptides=("peptide", "nunique"),
            )
            .sort_values("rows", ascending=False)
            .head(15)
        )
        for pmid, row in pmid_counts.iterrows():
            p(
                f"  PMID {pmid!s:<12s} {int(row['rows']):>8,} rows  {int(row['peptides']):>8,} peptides"
            )
        p()

    # ── PMID override summary ───────────────────────────────────────────
    from .curation import load_pmid_overrides

    overrides = load_pmid_overrides()
    override_pmids = set(overrides.keys())
    # Compute the integer PMID once, then use vectorized ``isin`` and
    # ``value_counts`` instead of nesting ``.apply(lambda)`` in a loop —
    # the previous code was O(overrides x matched_rows) ~= 200 x 1.5M
    # python-level lambdas, which hung on the production index.
    pmid_int_col = pd.to_numeric(df["pmid"], errors="coerce").astype("Int64")
    matched_mask = pmid_int_col.isin(override_pmids)
    if matched_mask.any():
        per_pmid_count = pmid_int_col[matched_mask].value_counts()
        p("── Curated Study Overrides Applied ──")
        p()
        for pmid_int, entry in sorted(overrides.items()):
            n_rows = int(per_pmid_count.get(pmid_int, 0))
            if n_rows > 0:
                # ``label`` was renamed to ``study_label`` in v1.7.0; the
                # YAML schema only carries the new key now. Fall back to
                # the empty string for entries that omit it (the override
                # itself is the load-bearing field for the report).
                study_label = entry.get("study_label", "")
                override_kind = entry.get("override", "")
                p(f"  PMID {pmid_int}: {study_label}")
                p(f"    Override: {override_kind}  |  Rows: {n_rows:,}")
                if entry.get("tissue_overrides"):
                    p(f"    Tissue overrides: {len(entry['tissue_overrides'])} tissues")
        p()

    p("=" * 72)
    p("Report complete.")

    text = "\n".join(lines)
    if output:
        Path(output).write_text(text)
        print(f"Report saved to {output}")
    return text


def _safe_int(v) -> int:
    try:
        return int(v)
    except (ValueError, TypeError):
        return -1


_REPORT_COLUMNS = (
    "peptide",
    "pmid",
    "mhc_class",
    "mhc_restriction",
    "is_monoallelic",
    "monoallelic_host",
    "cell_line_name",
    "source_tissue",
    "disease",
    "src_cancer",
    "src_healthy_tissue",
)


def run_report(
    iedb_path: str | Path | None = None,
    cedar_path: str | Path | None = None,
    mhc_class: str | None = None,
    output: str | Path | None = None,
    from_csv: bool = False,
) -> str:
    """Convenience function: load + report in one call.

    By default reads ``observations.parquet`` (instant on a built corpus).
    Pass ``from_csv=True`` to fall back to live raw-CSV scanning, useful
    on a fresh download before ``hitlist build observations`` has run.

    Parameters
    ----------
    iedb_path, cedar_path
        Only used when ``from_csv=True``.  Paths to IEDB/CEDAR exports;
        ``None`` resolves from the dataset registry.
    mhc_class
        MHC class filter for the report.
    output
        Optional output file path.
    from_csv
        If True, scan the raw IEDB/CEDAR CSVs every call (legacy behavior;
        slow).  Default False reads ``observations.parquet``.

    Returns
    -------
    str
        The report text.
    """
    if from_csv:
        return _run_report_from_csv(
            iedb_path=iedb_path,
            cedar_path=cedar_path,
            mhc_class=mhc_class,
            output=output,
        )

    from .observations import is_built, load_observations

    if not is_built():
        print(
            "observations.parquet has not been built. Run "
            "`hitlist build observations` first, or pass --from-csv to scan "
            "the raw IEDB/CEDAR CSVs.",
            file=sys.stderr,
        )
        return ""

    print("Loading observations.parquet...", file=sys.stderr, flush=True)
    df = load_observations(
        species="Homo sapiens",
        columns=list(_REPORT_COLUMNS),
    )
    print(f"  {len(df):,} rows loaded; generating report...", file=sys.stderr, flush=True)
    return generate_report(df, mhc_class_filter=mhc_class, output=output)


def _run_report_from_csv(
    iedb_path: str | Path | None = None,
    cedar_path: str | Path | None = None,
    mhc_class: str | None = None,
    output: str | Path | None = None,
) -> str:
    """Legacy live-scan path.  Reads raw IEDB/CEDAR CSVs every invocation;
    minutes-slow on a full corpus.  Kept for users who want a sanity check
    on a fresh download before ``hitlist build observations`` has run."""
    import contextlib

    from .downloads import get_path
    from .scanner import scan

    if iedb_path is None:
        with contextlib.suppress(KeyError, FileNotFoundError):
            iedb_path = str(get_path("iedb"))
    if cedar_path is None:
        with contextlib.suppress(KeyError, FileNotFoundError):
            cedar_path = str(get_path("cedar"))

    if iedb_path is None and cedar_path is None:
        print(
            "No IEDB or CEDAR data registered. Run 'hitlist data available' for instructions.",
            file=sys.stderr,
        )
        return ""

    df = scan(
        peptides=None,
        iedb_path=iedb_path,
        cedar_path=cedar_path,
        mhc_species="Homo sapiens",
        classify_source=True,
    )
    from .assays import positive_ms_mask

    df = _drop_excluded_ms_rows(df[positive_ms_mask(df)])
    return generate_report(df, mhc_class_filter=mhc_class, output=output)


def _drop_excluded_ms_rows(df: pd.DataFrame) -> pd.DataFrame:
    """Drop ``exclude_from_ms`` MS rows from a raw scanned frame (#444, #471).

    The built-corpus path (``hitlist report``) reads ``observations.parquet``,
    which never had these rows to begin with — :func:`hitlist.builder.
    build_observations` drops them at build time. ``--from-csv`` scans raw
    IEDB/CEDAR CSVs directly and skipped that step entirely, so its counts
    diverged from the built path's for the same underlying data. Scoped to
    MS rows only, same as the builder: a binding row for an excluded PMID is
    real evidence and stays, ``df`` here is the raw *mixed* scan (unlike the
    builder's already-split ``obs``), so scoping has to happen here rather
    than by reusing :func:`hitlist.builder._drop_excluded_from_ms` directly.
    """
    if df.empty or "pmid" not in df.columns:
        return df
    from .curation import ms_excluded_pmids

    excluded = ms_excluded_pmids()
    if not excluded:
        return df
    from .assays import positive_ms_mask

    is_ms = positive_ms_mask(df)
    mask = is_ms & df["pmid"].isin(excluded)
    if not mask.any():
        return df
    return df[~mask].reset_index(drop=True)
