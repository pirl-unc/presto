# hitlist

[![Tests](https://github.com/pirl-unc/hitlist/actions/workflows/tests.yml/badge.svg)](https://github.com/pirl-unc/hitlist/actions/workflows/tests.yml)
[![PyPI](https://img.shields.io/pypi/v/hitlist.svg)](https://pypi.org/project/hitlist/)

A curated, harmonized, **ML-training-ready** MHC ligand mass-spectrometry dataset,
built from [IEDB](https://www.iedb.org/), [CEDAR](https://cedar.iedb.org/), and
paper supplementary tables.

hitlist scans the raw exports, **fills missing provenance** and **corrects
mislabels** from expert per-study curation, **classifies every observation by
biological source** (cancer tissue, healthy tissue, cell line, tumor-adjacent,
EBV-LCL, …), partitions positive MS, binding, and other assays into three
separate parquet files, maps peptides to source proteins with flanking context,
and ships everything as parquet plus a pandas-friendly Python API. The curation
overrides and classification rules are YAML data files, not hardcoded Python.

New here? Start with **[How curation works](curation-process.md)** for the
end-to-end pipeline and the ideas behind it. See [assay modality](assay-modality.md)
for MS admission and migration after #644.
The [evidence catalog](evidence-catalog.md) defines the versioned Hitlist 2.0
logical fields, row grains and task requirements across all current modalities.

## Install

```bash
pip install hitlist
```

## Quick start

```bash
# Register your IEDB/CEDAR downloads, then build the indexes
hitlist data register iedb /path/to/mhc_ligand_full.csv
hitlist data register cedar /path/to/cedar-mhc-ligand-full.csv
hitlist data build                 # writes observations.parquet + binding.parquet (+ sidecars)

# Data-quality report
hitlist report --class I --output report.txt
```

```python
from hitlist.scanner import scan
from hitlist.aggregate import aggregate_per_peptide

# Scan for specific peptides...
hits = scan(peptides={"SLYNTVATL", "GILGFVFTL"}, iedb_path="mhc_ligand_full.csv", mhc_class="I")

# ...or profile the entire dataset, then summarize per peptide with the
# is_cancer_specific flag.
full = scan(peptides=None, iedb_path="mhc_ligand_full.csv")
summary = aggregate_per_peptide(hits)
```

## The curation layer

The value of hitlist is the curation between download and parquet:

- **[How curation works](curation-process.md)** — the scan → fill → classify →
  partition → build pipeline, supplementary ingestion, and the design principles.
- **[Source classification](source-classification.md)** — the biological-source
  taxonomy (`src_cancer`, `src_healthy_tissue`, `src_ebv_lcl`, …), mono-allelic
  evidence, cross-species systems, and the cancer-specific definition.
- **[PMID curation overrides](pmid-curation.md)** — the `pmid_overrides.yaml`
  schema and how to add a study.

Two quick illustrations of why curation matters:

```yaml
# Reclassify a multi-arm study by IEDB field, in pmid_overrides.yaml.
# IEDB lumps every row under one Disease/Process Type; the only per-row
# signal is free-text Assay Comments, so the rules match on substring.
- pmid: 29789417
  study_label: "Loffler 2018 — CRC + matched normal colon"
  rules:
    - condition: { Assay Comments: "eluted from colorectal carcinoma (CRC) tissue." }
      override: cancer_patient
    - condition: { Assay Comments: "eluted from nonmalignant colon (NMC) tissue." }
      override: adjacent
```

All non-EBV cell lines are classified as cancer-derived even when IEDB labels
them "No immunization" (catching HeLa, THP-1, A549, …), while EBV-LCLs on
HLA-null hosts (721.221, C1R) are auto-corrected *out* of the cancer set. See
[Source classification](source-classification.md).

## Proteome mapping

Map peptides to source proteins with flanking context:

```python
from hitlist.proteome import ProteomeIndex

# Human proteome from pyensembl, or human + viral in one index
idx = ProteomeIndex.from_ensembl(release=112)
idx = ProteomeIndex.from_ensembl_plus_fastas(fasta_paths=["hpv16.fasta", "ebv.fasta"])

df = idx.map_peptides(["SLLMWITQC"], flank=5)
# → protein_id, gene_name, gene_id, position, n_flank, c_flank, ...
```

## Per-sample peptidome context

The full peptidome of each sample is essential context for judging whether a
peptide's presence is meaningful:

```python
from hitlist.scanner import scan
from hitlist.samples import sample_peptidomes, overlay_targets

full = scan(peptides=None, iedb_path="mhc_ligand_full.csv", mhc_class="I")
samples = sample_peptidomes(full)

# Overlay a target set for context fractions:
# "1 CTA out of 762 peptides = 0.13% = stochastic noise"
context = overlay_targets(full, target_peptides=my_cta_set, label="cta")
```

## Data management

See [versioned UniProt references](uniprot-references.md) for pinned human FASTAs,
source provenance and bounded download/cache storage.

```bash
hitlist data available          # list known datasets (IEDB/CEDAR + fetchable viral proteomes)
hitlist data fetch hpv16        # auto-download a viral proteome from UniProt
hitlist data register iedb /path/to/file  # register a manual download
hitlist data list               # registered datasets + mirrored assets with cache status
hitlist data list --all --json   # all cache files with inspection/provenance
hitlist data list --verify      # verify trusted mirrored-asset hashes
hitlist data info iedb          # detailed JSON metadata
hitlist data path iedb          # resolve to file path
hitlist data dirs               # every directory hitlist uses, and why
```

Storage: hitlist keeps built indexes in the `datacache` cache directory the
openvax ecosystem shares — `~/Library/Caches/hitlist` on macOS,
`~/.cache/hitlist` on Linux. Installs that already have data in the legacy
`~/.hitlist` keep using it; nothing has to move. Resolution order:

1. `hitlist.downloads.set_data_dir()`
2. the `HITLIST_DATA_DIR` env var (the directory itself, stripped and
   `~`-expanded; empty means unset)
3. an existing, **populated** `~/.hitlist` (legacy — announced once per process)
4. `datacache.get_data_dir(subdir="hitlist")`

"Populated" means the directory holds a regular file at the top level, or a
subdirectory holding a regular file — a structural test, so an artifact added
later cannot drift out of it. An empty `~/.hitlist`, or one holding only the
empty `proteomes/` / `gene_cache/` directories older releases created eagerly,
does not count.

Mirrored data assets (paper-derived CSVs, #303) are fetched by `datacache` into
its own cache dir, which `HITLIST_DATA_DIR` does not move; on a default install
that is the same directory as the indexes. `hitlist data dirs` prints every
location, including `<data directory>/proteome_index_cache`. This cache follows
`HITLIST_DATA_DIR` and `set_data_dir()` unless `proteome.set_disk_cache_dir()`
explicitly overrides it; passing `None` restores the dynamic default. Existing
unconfigured legacy caches remain in use. Explicitly relocating the data
directory leaves old files in place; copy `proteome_index_cache/` into the new
directory to reuse those indexes.

## Development

```bash
./develop.sh    # install in dev mode
./format.sh     # ruff format
./lint.sh       # ruff check + format check
./test.sh       # pytest with coverage
./deploy.sh     # lint + test + build + upload to PyPI
```

For Presto training, see [search-scoped bulk MS detectability datasets](detectability.md): occurrence-preserving digests, scoped observations, verified search references, and bounded evidence exports.
