"""CPU audit and assembly; uses the frozen canonical runtime."""
from pathlib import Path
import json
import time
import modal
from common import NAME,E,ROOT,BASE,VOLUME,dump
app=modal.App('presto-processing-data-audit')
image=BASE
if modal.is_local():
    image=(image.add_local_dir(E/'reproduce/runtime','/runtime/presto').add_local_dir(E/'code','/bundle')
           .add_local_file(ROOT/'data/shared-presentation-20261117/proteins.fa.gz','/inputs/proteins.fa.gz'))

@app.function(image=image,cpu=8,memory=65536,timeout=14400,volumes={'/volume':VOLUME})
def run(action,stage):
    import pool_analysis
    root=Path('/volume')/NAME
    if action=='analyze':result=pool_analysis.analyze(root,stage)
    elif action=='assemble':result=pool_analysis.assemble(root,stage)
    elif action=='finalize':
        pool_analysis.analyze(root,stage);VOLUME.commit()
        result=pool_analysis.assemble(root,stage)
    elif action=='validation':
        try:result=pool_analysis.validation(root)
        finally:VOLUME.commit()
    else:raise ValueError(action)
    VOLUME.commit();return result

@app.local_entrypoint()
def main(action:str='analyze',stage:int=1):
    call=run.spawn(action,stage);dump(E/'reproduce'/f'data-{action}-stage{stage}-call.json',{'call':call.object_id})
    result=call.get();dump(E/'results'/f'data-{action}-stage{stage}.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('jobs','studies')}),flush=True)
