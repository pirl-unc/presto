# Sources and design decision

Official BA percentile rank is predictor-affinity rank against random natural peptides for each MHC molecule; BA and EL ranks are distinct. The frozen comparison keeps NetMHCpan4.2c and NetMHCIIpan4.3e, not newer official updates.

- https://services.healthtech.dtu.dk/services/NetMHCpan-4.2/
- https://services.healthtech.dtu.dk/services/NetMHCIIpan-4.3/
- https://pubmed.ncbi.nlm.nih.gov/32711842/ — MHCflurry2.0 primary paper (Cell Systems2020): processing discrimination among predicted strong binders and combination with affinity motivates conditional supervision. This does not establish that our proposed auxiliary loss or junction representation will help.

All details above were read from the primary/official sources during this task. NetMHC scores select backgrounds; literal source MS detections remain positives and unobserved sampled peptides are not experimentally confirmed negatives. No affinity-matching approach identifies processing causally or removes MS biases.

TRAIN-only cache audit chooses the primary all-candidate hybrid rule: identical typed MHC candidates, same predicted best BA-rank candidate, every candidate within0.5 percentage points and0.3 log10((rank+.01)) units. The .01 floor handles printed zeros. This reduces the flat.5pp class-I BA-only AUROC from.5714 to.5086. Residual pair-level imbalance remains and must be reported. Original .1log10(nM), absolute-rank and minimum-only policies remain sensitivity analyses. New-cohort AUROC is never substituted into the old benchmark table without common-example rescoring.
