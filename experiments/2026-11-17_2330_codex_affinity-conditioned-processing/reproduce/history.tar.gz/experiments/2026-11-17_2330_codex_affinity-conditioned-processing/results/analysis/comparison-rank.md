| Model | Ordinary I / II AUROC | Matched I / II AUROC | Matched I / II pair wins | Retention guards |
|---|---:|---:|---:|---|
| Parent | 0.8759 / 0.8373 | 0.6263 / 0.5482 | 0.6890 / 0.5839 | reference |
| continued, seed 42, selected | 0.8777 / 0.8436 | 0.6246 / 0.5476 | 0.6842 / 0.5620 | pass |
| continued, seed 42, terminal | 0.8769 / 0.8449 | 0.6279 / 0.5488 | 0.6890 / 0.5766 | pass |
| continued, seed 43, selected | 0.8761 / 0.8438 | 0.6229 / 0.5492 | 0.6842 / 0.5766 | pass |
| continued, seed 43, terminal | 0.8763 / 0.8444 | 0.6219 / 0.5472 | 0.6842 / 0.5839 | pass |
| paired, seed 42, selected | 0.8703 / 0.8358 | 0.6414 / 0.5581 | 0.7081 / 0.5985 | fails ordinary I |
| paired, seed 42, terminal | 0.8699 / 0.8371 | 0.6540 / 0.5644 | 0.7129 / 0.6204 | fails ordinary I |
| paired, seed 43, selected | 0.8723 / 0.8398 | 0.6417 / 0.5579 | 0.6890 / 0.5985 | pass |
| paired, seed 43, terminal | 0.8704 / 0.8362 | 0.6491 / 0.5667 | 0.7321 / 0.6204 | fails ordinary I |
| paired-junction, seed 42, selected | 0.8709 / 0.8373 | 0.6437 / 0.5605 | 0.7129 / 0.5839 | pass |
| paired-junction, seed 42, terminal | 0.8723 / 0.8417 | 0.6616 / 0.5722 | 0.7321 / 0.5839 | pass |
| paired-junction, seed 43, selected | 0.8718 / 0.8417 | 0.6431 / 0.5607 | 0.6986 / 0.5912 | pass |
| paired-junction, seed 43, terminal | 0.8707 / 0.8420 | 0.6552 / 0.5741 | 0.7321 / 0.5693 | fails ordinary I |
