| Model | Ordinary I / II AUROC | Matched I / II AUROC | Matched I / II pair wins | Retention guards |
|---|---:|---:|---:|---|
| Parent | 0.8759 / 0.8373 | 0.6142 / 0.5692 | 0.6588 / 0.6076 | reference |
| continued, seed 42, selected | 0.8777 / 0.8436 | 0.6141 / 0.5691 | 0.6618 / 0.5886 | pass |
| continued, seed 42, terminal | 0.8769 / 0.8449 | 0.6156 / 0.5701 | 0.6588 / 0.6013 | pass |
| continued, seed 43, selected | 0.8761 / 0.8438 | 0.6156 / 0.5711 | 0.6647 / 0.6013 | pass |
| continued, seed 43, terminal | 0.8763 / 0.8444 | 0.6150 / 0.5685 | 0.6618 / 0.6076 | pass |
| paired, seed 42, selected | 0.8703 / 0.8358 | 0.6279 / 0.5770 | 0.6794 / 0.6139 | fails ordinary I |
| paired, seed 42, terminal | 0.8699 / 0.8371 | 0.6346 / 0.5822 | 0.7088 / 0.6266 | fails ordinary I |
| paired, seed 43, selected | 0.8723 / 0.8398 | 0.6288 / 0.5765 | 0.6794 / 0.6139 | pass |
| paired, seed 43, terminal | 0.8704 / 0.8362 | 0.6320 / 0.5843 | 0.7029 / 0.6329 | fails ordinary I |
| paired-junction, seed 42, selected | 0.8709 / 0.8373 | 0.6301 / 0.5791 | 0.6853 / 0.6013 | pass |
| paired-junction, seed 42, terminal | 0.8723 / 0.8417 | 0.6403 / 0.5908 | 0.7000 / 0.5949 | pass |
| paired-junction, seed 43, selected | 0.8718 / 0.8417 | 0.6319 / 0.5800 | 0.6824 / 0.6139 | pass |
| paired-junction, seed 43, terminal | 0.8707 / 0.8420 | 0.6389 / 0.5938 | 0.7029 / 0.6076 | fails ordinary I |
