# Shared pathway-conditioned presentation processing

Status: proposed follow-up; no new fit launched. Agent Codex / GPT-6.

## Evidence and question

The uncapped native data comparison is running with6,000 updates and fixed class/study-balanced presentation selection. Interim seed42 expanded-none class-II AUROC rises from.7600 at1,000 to.7813 at3,000; seed43 is.7714 at2,000. Class-I retention is unresolved. These are exploratory intermediate results, not a selected final gain.

Code inspection at core2da11504 shows that `Presto._pmhc` computes generic `elution_processing` before the MHC-class loop. With identical peptide/source/context inputs it therefore yields the same generic processing score in both classes. Binding and harmonized APC terms are class-sensitive; the generic source-processing function has no direct pathway input. This is a restriction to test, not proof of the cause of a performance deficit.

## Minimal shared mechanism

Add optional `elution_pathway_conditioning: bool = False`. When enabled for staged presentation, use one bias-free2→d_model linear map of declared class identity, added to the shared processing MLP preactivation before its GELU. Zero-initialize the new map. Keep one shared sequence encoder, source/flank representation, MLP and output readout; each class may condition the same nonlinear function. APC state remains the separate observed-context residual with class masks, and all-unknown APC stays zero. No class-specific fake supervision, gene severity, expression or external-predictor labels are introduced. The intrinsic affinity path does not consume the new pathway term.

The256 extra weights at d_model128 preserve initial predictions exactly when transferring from a compatible parent. Default-off serialization and old checkpoints remain unchanged. Add the parameters to declared elution dependencies and input-support accounting. Register both class input columns, and require actual gradient/update support from the relevant class. Reject enabling the option outside staged elution. Warm-start adds the zero module explicitly; disallow removing an existing trained pathway module implicitly.

## Verification before training

- Default-off config serialization/checkpoint behavior unchanged.
- Zero-initialized expansion reproduces both-class presentation and affinity outputs.
- A controlled nonzero pathway map can change class-II processing without changing class-I processing; measured affinity stays unchanged.
- Actual presentation backward/optimizer updates use the same source encoder and processing weights in both classes, and train both pathway columns.
- Dependency and coverage checks include the added module; supported public inference and checkpoint round-trip work.
- Run canonical relevant regressions and lint on immutable source.

## Experiment activation

Wait for the current StageA fits and per-cohort/affinity checks before launching a predictive comparison. Record a new timestamped experiment and the decision using those completed results. The first comparison should keep the exact prepared sources, parent,6,000-update budget, sampler, optimizer, selection criterion, seed42 and H100! hardware of the corresponding broad shared-state arm. The only intended difference is pathway conditioning. Compare against that arm on fixed/new ordinary populations and fixed BA-matched validation for both classes, retain full per-example dumps and protein/condition paired bootstraps. Replicate with seed43 if it provides a practical candidate. Do not modify the six already-running fits or reselect their checkpoints. TEST remains sealed.

## Related follow-up kept separate

A general pMHC/register presentation residual independent of the IC50 decoder and APC state is another testable restriction, but is not part of the first pathway ablation. Reverse-oriented class-II candidates require explicit ordered residue indices and preservation of real source cleavage context; neither orientation nor register-pooling semantics should change with this pathway test.

## Scientific context

The class-I processing model in [O’Donnell et al.,2020](https://pubmed.ncbi.nlm.nih.gov/32711842/) and class-II context analysis in [Nilsson et al.,2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC10672173/) support investigating source-processing signals in both pathways. They do not establish that this specific architecture will improve Presto; that is the experiment.

## Implementation staging amendment

Implement and test the opt-in mechanism while the frozen baseline jobs finish; defer predictive launch and any promotion until completed StageA checks. All current jobs use their immutable2da11504 runtime. Require an explicit `allow_pathway_expansion` warm-start flag; adding the new module does not silently change a retained presentation contract. Allocate the zero-initialized pathway map after existing modules inside a forked RNG scope so control-arm initialization and subsequent RNG state remain unchanged.

## Adaptive re-plan from completed exposure audit, 2026-11-17 20:30 UTC

The first completed broad-data no-APC fit passes required coverage and independent11,572-row selected-loss recomputation. Its new-validation AUROC is I.861729/II.803675 versus previous-default.850342/.687188; IC50 Spearman/RMSE are retained in both classes. Older APC/matched cohorts regress, so it is not promoted. Long class-II peptides improve strongly (.477543→.747232 on340 rows), showing that the earlier deficit is not a biological ceiling.

The actual selected-step sampling order exposes a major imbalance:43 class-I studies with at most10 pairs contain262/419,390 rows (0.0625%) but receive27.09% of class-I presentation draws. Eleven class-II tiny studies contain96/356,358 rows (0.0269%) but receive26.22% of class-II presentation draws. The6,000-step budget visits only48,730 class-I and31,017 class-II distinct presentation rows under this sampling contract. This is an observed optimization-allocation problem; it is not proven to explain every predictive regression.

Preserve all original fits, selection and data. Add three controlled recipes with study sampling mass proportional to sqrt(admitted TRAIN rows), separately normalized inside class; retain50% concentration/25% class-I/25% class-II draws. No study or row is excluded or capped. This reduces tiny-study presentation mass to1.96% I/1.54% II; the largest study receives4.86% I/19.14% II rather than row-proportional14.64%/39.28%. Retain equal-class/equal-study BCE checkpoint selection unchanged.

New arms: `expanded-none-sqrt` (no APC), `expanded-state-sqrt` (shared64 APC), and `expanded-pathway-state-sqrt` (same APC plus the optional256-weight shared pathway conditioning). Use the same canonical parent, exact TRAIN/validation sources, full trainability, batch64,6,000 updates, optimizer/schedule, H100! and public evaluation. Replicate all three symmetrically with seeds42 and43; register/freeze before their outcomes exist. The no-state/state contrast measures APC-associated gains; state/pathway contrast measures only pathway conditioning. None establishes isolated gene/drug causality.

The pathway implementation has251 regression tests plus6 final focused tests and exact old-public-output parity; its separate full-data16-step integration must finish and pass artifact checks before its predictive launch. The completed broad-data fit provides the competent class-II baseline required to activate this stage while the remaining original controls finish. All comparisons remain adaptive development on validation; TEST stays sealed. No change to sequence/protein leakage guards or predictor-label policy.
